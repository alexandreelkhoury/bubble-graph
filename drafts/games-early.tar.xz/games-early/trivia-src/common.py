def M(id, diff, topic, source, en, fr, ar, es, d=None, region=None, easy=None):
    return dict(id=id, type="mc4", difficulty=diff, topic=topic, source=source, draft=d, region=region,
                easyIn=easy or [], loc=dict(en=en, fr=fr, ar=ar, es=es))

def T(id, diff, topic, truth, source, en, fr, ar, es, d=None, region=None, easy=None):
    return dict(id=id, type="tf", difficulty=diff, topic=topic, source=source, draft=d, region=region,
                easyIn=easy or [], truth=truth, loc=dict(en=en, fr=fr, ar=ar, es=es))
