import json, os, re, sys, collections
sys.path.insert(0, os.path.dirname(__file__))
import lebanon, world
OUT = "/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/games-early/content/trivia"
VOCAB = json.load(open("/home/user/bubble-graph/content/vocab.json"))
TF = dict(en=("True","False"), fr=("Vrai","Faux"), ar=("صح","غلط"), es=("Verdadero","Falso"))
SCRIPT = dict(en="Latn", fr="Latn", ar="Arab", es="Latn")
SPREAD = [2, 0, 3, 1]

PACKS = [
  dict(family="lb-quiz-01", mod=lebanon, domain="lebanon", featured=["music","dance","football"], tier="free",
       title=dict(en="Lebanon: the big quiz", fr="Liban : le grand quiz", ar="لبنان: المسابقة الكبيرة", es="Líbano: el gran quiz"),
       description=dict(en="From Fairuz to the Cedars: songs, dabke, football, food and every corner of the map.",
                        fr="De Fairouz aux Cèdres : chansons, dabké, foot, cuisine et tous les coins du pays.",
                        ar="من فيروز لرجال الأرز: غناني، دبكة، فوتبول، أكل وكل زاوية من لبنان.",
                        es="De Fairuz a los Cedros: canciones, dabke, fútbol, comida y cada rincón del país.")),
  dict(family="world-mix-01", mod=world, domain="world", featured=["geography","science","cinema-tv"], tier="free",
       title=dict(en="World Mix", fr="Le monde en vrac", ar="خلطة من العالم", es="Mezcla mundial"),
       description=dict(en="Planets, paintings, penalties and paella: a quick lap around everything.",
                        fr="Planètes, tableaux, penalties et paella : un petit tour de tout.",
                        ar="كواكب ولوحات وركلات ترجيح وباييا: جولة سريعة حول كلّ شيء.",
                        es="Planetas, cuadros, penaltis y paella: una vuelta rápida por todo.")),
]

def build(pk):
    qs = pk["mod"].QUESTIONS
    topics_used = []
    for q in qs:
        if q["topic"] not in topics_used: topics_used.append(q["topic"])
    topics = list(pk["featured"]) + [t for t in topics_used if t not in pk["featured"]]
    mean = sum(q["difficulty"] for q in qs) / len(qs)
    stars = min((1,2,3), key=lambda s: abs(s-mean))
    k = 0; out = {}
    for loc in ("en","fr","ar","es"):
        items = []; k = 0
        for q in qs:
            L = q["loc"][loc]
            it = dict(id=q["id"], type=q["type"], text=L[0])
            if q["type"] == "mc4":
                correct, *wrong = L[1]
                pos = SPREAD[k % 4]; k += 1
                opts = list(wrong); opts.insert(pos, correct)
                it["options"] = opts; it["answer"] = pos; expl = L[2]
            else:
                it["options"] = list(TF[loc]); it["answer"] = 0 if q["truth"] else 1; expl = L[1]
            it["topic"] = q["topic"]; it["difficulty"] = q["difficulty"]
            if q["easyIn"]: it["easyIn"] = q["easyIn"]
            if q["region"]: it["region"] = q["region"]
            if expl: it["explain"] = expl
            it["source"] = q["source"]
            items.append(it)
        pid = f'{pk["family"]}-{loc}'
        pack = dict(id=pid, family=pk["family"], game="trivia", version=1, locale=loc, script=SCRIPT[loc],
                    title=pk["title"], description=pk["description"], domain=pk["domain"], topics=topics,
                    featuredTopics=pk["featured"], stars=stars, ageRating="all", tier=pk["tier"],
                    license="CC-BY-4.0", source="original", status="draft", reviewedBy=[], questions=items)
        out[loc] = pack
    return out, mean, stars

errs = []; report = []
for pk in PACKS:
    packs, mean, stars = build(pk)
    for loc, p in packs.items():
        os.makedirs(f"{OUT}/{loc}", exist_ok=True)
        with open(f"{OUT}/{loc}/{p['id']}.json", "w", encoding="utf-8") as f:
            json.dump(p, f, ensure_ascii=False, indent=2); f.write("\n")
        qs = p["questions"]; ids = [q["id"] for q in qs]
        if len(set(ids)) != len(ids): errs.append(f"{p['id']}: dup ids")
        for q in qs:
            tag = f"{p['id']}/{q['id']}"
            if not re.fullmatch(r"q\d{3,4}", q["id"]): errs.append(f"{tag} id")
            if not 5 <= len(q["text"]) <= 160: errs.append(f"{tag} text len {len(q['text'])}")
            if len(set(q["options"])) != len(q["options"]) or any(not o.strip() for o in q["options"]): errs.append(f"{tag} options not unique")
            for o in q["options"]:
                if len(o) > 48: errs.append(f"{tag} option >48: {o}")
            if len(q.get("explain","")) > 200: errs.append(f"{tag} explain {len(q['explain'])}")
            if not q.get("explain"): errs.append(f"{tag} no explain")
            if q["topic"] not in VOCAB["topics"]: errs.append(f"{tag} topic {q['topic']}")
            if q.get("region") and q["region"] not in VOCAB["regions"]: errs.append(f"{tag} region")
            if "[VERIFY]" not in q["source"]: errs.append(f"{tag} source lacks [VERIFY]")
            if loc == "es" and q["text"].endswith("?") and "¿" not in q["text"]: errs.append(f"{tag} missing ¿")
        mc = [q for q in qs if q["type"]=="mc4"]; tf = [q for q in qs if q["type"]=="tf"]
        dist = collections.Counter(q["answer"] for q in mc)
        if max(dist.values()) > 0.4*len(mc): errs.append(f"{p['id']}: answer spread {dist}")
        tr = sum(1 for q in tf if q["answer"]==0)/len(tf)
        if not .35 <= tr <= .65: errs.append(f"{p['id']}: tf true ratio {tr}")
        if abs(stars-mean) > .67: errs.append("stars")
        if set(p["topics"]) != {q["topic"] for q in qs}: errs.append("topics mismatch")
        reg = collections.Counter(q["region"] for q in qs if q.get("region"))
        if reg and max(reg.values()) > .35*sum(reg.values()): errs.append(f"{p['id']}: region {reg}")
        d3 = sum(1 for q in qs if q["difficulty"]==3)
        if d3 < 15: errs.append(f"{p['id']}: only {d3} difficulty-3")
        if loc == "en":
            report.append(dict(pack=pk["family"], n=len(qs), mc4=len(mc), tf=len(tf), tfTrue=round(tr,2), mean=round(mean,2), stars=stars,
                               diff=dict(collections.Counter(q["difficulty"] for q in qs)), topics=dict(collections.Counter(q["topic"] for q in qs)),
                               regions=dict(reg), answerDist=dict(dist)))
    # cross-locale identity
    base = packs["en"]["questions"]
    for loc in ("fr","ar","es"):
        for a, b in zip(base, packs[loc]["questions"]):
            for f in ("id","type","answer","topic","difficulty","easyIn","region"):
                if a.get(f) != b.get(f): errs.append(f"{pk['family']} {loc} {a['id']} field {f}")
print(json.dumps(report, ensure_ascii=False, indent=1))
print("ERRORS:", len(errs)); print("\n".join(errs))
