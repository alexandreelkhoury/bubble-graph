// Synthetic unique-token catalog (JAMAA-PLATFORM §2.2 "leak tests use synthetic catalogs"), a scripted driver and the
// generic leak checker (whole-leaf secrets, leakCheck, forbidden keys), mirroring shared/src/testing/room-leaks.ts.
import { expect } from "vitest";
import { definition } from "../src/definition";
import type { BluffCatalog, BluffItem, BluffPack, BluffType } from "../src/content";
import type { BluffIntent, BluffSettings, BluffState } from "../src/state";
import type { ErrorCode, GameAction, GameActor, GameReduceResult, Locale, RosterEntry } from "../src/types";

export const T0 = 1_790_000_000_000;
export const GRACE = 2_500;

const WORDS = ["apple", "grape", "lemon", "mango", "olive"];

export function item(id: string, type: BluffType, n: number, over: Partial<BluffItem> = {}): BluffItem {
  const tag = id.replace(/[^a-z0-9]/g, "");
  const noTruth = type === "no_truth";
  return {
    id,
    type,
    tier: "free",
    difficulty: ((n % 3) + 1) as 1 | 2 | 3,
    knownIn: [],
    prompt: { original: `Zprompt ${tag} opens`, translit: null, display: {} },
    truth: noTruth ? {} : { en: `Truth${tag} quokka` },
    truthAlt: noTruth ? {} : { en: [`Alt${tag} numbat`] },
    houseLies: { en: WORDS.slice(0, 3).map((w) => `Hz${tag}${w}`) },
    note: { en: `Note${tag} explained` },
    review: { status: "verified", source: "synthetic" },
    ...over,
  };
}

export function pack(id: string, items: BluffItem[], over: Partial<BluffPack> = {}): BluffPack {
  return {
    schemaVersion: 1, id, game: "bluff",
    title: { en: id, fr: id, ar: id }, description: { en: "", fr: "", ar: "" },
    sourceLocale: "en", playableIn: ["en"], ageRating: "all", fallbackHouseLies: {}, items, ...over,
  };
}

export function synthCatalog(n = { sayings: 10, facts: 10, finals: 4 }): BluffCatalog & { packs: BluffPack[] } {
  const range = (k: number) => Array.from({ length: k }, (_, i) => i + 1);
  return {
    packs: [
      pack("syn-sayings", range(n.sayings).map((i) => item(`s${String(i).padStart(2, "0")}`, "proverb_end", i))),
      pack("syn-facts", range(n.facts).map((i) => item(`f${String(i).padStart(2, "0")}`, "fact_blank", i))),
      pack("syn-finals", range(n.finals).map((i) => item(`n${String(i).padStart(2, "0")}`, "no_truth", i))),
    ],
    blocklist: { en: ["zzblockedword"] },
  };
}

export const pid = (i: number): string => `p${i}`;
export const P = (playerId: string): GameActor => ({ kind: "player", playerId });
export const TV: GameActor = { kind: "tv" };

export interface GOpts { players?: number; seed?: number; settings?: Partial<BluffSettings>; cat?: BluffCatalog; locale?: Locale; host?: string | null; usedKeys?: string[]; ids?: string[] }

/** Scripted driver: clock, reduce, invariants + leak checks after every dispatch. */
export class G {
  s: BluffState;
  now = T0;
  cat: BluffCatalog;
  host: string | null;
  checkLeaks = true;
  constructor(o: GOpts = {}) {
    this.cat = o.cat ?? synthCatalog();
    const ids = o.ids ?? Array.from({ length: o.players ?? 4 }, (_, i) => pid(i + 1));
    const roster: RosterEntry[] = ids.map((id, i) => ({ id, seat: i, locale: o.locale ?? "en", connected: true, carryScore: 0 }));
    const settings: BluffSettings = { packIds: [], length: "normal", pace: "normal", ...o.settings };
    const r = definition.start({ roster, settings, locale: o.locale ?? "en", memory: { usedKeys: o.usedKeys ?? [] }, seed: o.seed ?? 7, now: this.now, graceMs: GRACE, content: this.cat });
    if (!r.ok) throw new Error(`start failed: ${r.error}`);
    this.s = r.state;
    this.host = o.host === undefined ? (ids[0] ?? null) : o.host;
    this.after();
  }
  get ids(): string[] { return this.s.players.map((p) => p.id); }
  ctx() {
    return { now: this.now, content: this.cat, isHost: (a: GameActor) => a.kind === "tv" || a.playerId === this.host, hostPlayerId: this.host };
  }
  after(): void {
    definition.assertInvariants(this.s);
    if (this.checkLeaks) expect(findLeaks(this.s)).toEqual([]);
  }
  dispatch(a: GameAction<BluffIntent>): GameReduceResult<BluffState> {
    const before = this.s;
    const r = definition.reduce(before, a, this.ctx());
    if (!r.ok && r.state === before) { /* rejected, untouched */ }
    for (const p of before.players) {
      const q = r.state.players.find((x) => x.id === p.id);
      if (q && q.score < p.score) throw new Error(`score went down for ${p.id}`);
    }
    this.s = r.state;
    this.after();
    return r;
  }
  do(i: BluffIntent, by: GameActor = TV): BluffState {
    const r = this.dispatch({ type: "INTENT", intent: i, by });
    if (!r.ok) throw new Error(`${i.type} by ${JSON.stringify(by)} failed: ${r.error} (phase ${this.s.phase})`);
    return r.state;
  }
  err(i: BluffIntent, by: GameActor = TV): ErrorCode {
    const r = this.dispatch({ type: "INTENT", intent: i, by });
    if (r.ok) throw new Error(`${i.type} unexpectedly ok`);
    return r.error;
  }
  tick(): void {
    if (this.s.deadline === null) throw new Error(`no deadline in ${this.s.phase}`);
    this.now = Math.max(this.now, this.s.deadline);
    this.dispatch({ type: "TICK" });
  }
  advance(ms: number): void { this.now += ms; }
  untilPhase(ph: BluffState["phase"], max = 50): void {
    for (let i = 0; i < max && this.s.phase !== ph; i++) this.tick();
    if (this.s.phase !== ph) throw new Error(`never reached ${ph}, at ${this.s.phase}`);
  }
  promptId(): string { return (this.s.prompt as NonNullable<BluffState["prompt"]>).id; }
  submit(p: string, text: string): GameReduceResult<BluffState> {
    return this.dispatch({ type: "INTENT", intent: { type: "SUBMIT_LIE", text, promptId: this.promptId() }, by: P(p) });
  }
  truth(): string { return (this.s.prompt as NonNullable<BluffState["prompt"]>).truthText as string; }
  optionOf(text: string): string {
    const o = this.s.options.find((x) => x.text === text);
    if (!o) throw new Error(`no option "${text}" among ${this.s.options.map((x) => x.text).join(" | ")}`);
    return o.id;
  }
  truthOption(): string { return (this.s.options.find((o) => o.kind === "truth") as { id: string }).id; }
  vote(p: string, optionId: string): void { this.do({ type: "VOTE", optionId }, P(p)); }
  pub() { return definition.projectPublic(this.s, this.cat); }
  me(p: string) { return definition.projectMe(this.s, p, this.cat); }
  score(p: string): number { return (this.s.players.find((x) => x.id === p) as { score: number }).score; }
}

function walk(x: unknown, path: string[], onKey: (k: string, path: readonly string[]) => void, onLeaf: (v: unknown, path: readonly string[]) => void): void {
  if (Array.isArray(x)) x.forEach((v, i) => walk(v, [...path, String(i)], onKey, onLeaf));
  else if (x !== null && typeof x === "object") for (const [k, v] of Object.entries(x)) { onKey(k, path); walk(v, [...path, k], onKey, onLeaf); }
  else onLeaf(x, path);
}

export function viewsOf(s: BluffState): { label: string; viewer: string | null; view: unknown }[] {
  const pub = definition.projectPublic(s, {} as BluffCatalog);
  const out: { label: string; viewer: string | null; view: unknown }[] = [{ label: "tv", viewer: null, view: { game: { public: pub, me: null } } }];
  for (const p of s.players) {
    const inGame = !p.left;
    out.push({ label: `player ${p.id}`, viewer: inGame ? p.id : null, view: { game: { public: pub, me: inGame ? definition.projectMe(s, p.id, {} as BluffCatalog) : null } } });
  }
  return out;
}

/** The platform's generic leak checker, applied to Bluff alone. */
export function findLeaks(s: BluffState): string[] {
  const errs: string[] = [];
  const forbidden = new Set(definition.forbiddenKeys);
  for (const { label, viewer, view } of viewsOf(s)) {
    const secrets = new Set(definition.secretsFor(s, viewer));
    walk(view, [], (k, path) => {
      if (forbidden.has(k)) errs.push(`${label}: forbidden key "${k}" at ${path.join(".")}`);
    }, (v, path) => {
      if (secrets.has(v)) errs.push(`${label}: secret ${JSON.stringify(v)} at ${path.join(".")}`);
    });
    for (const e of definition.leakCheck(s, viewer, view)) errs.push(`${label}: ${e}`);
  }
  return errs;
}

/** Plays every connected player's lie (unique random-ish tokens) for the current prompt. */
export function lieFor(p: string, s: BluffState, salt = ""): string {
  const letters = "bcdfghjklmnpqrstvwxz";
  let h = 0;
  for (const ch of `${p}|${s.prompt?.id}|${salt}`) h = (Math.imul(h, 31) + ch.charCodeAt(0)) >>> 0;
  let w = "";
  for (let i = 0; i < 9; i++) { w += letters[h % letters.length]; h = Math.imul(h ^ (h >>> 13), 0x5bd1e995) >>> 0; }
  return `Fib ${w}`;
}
