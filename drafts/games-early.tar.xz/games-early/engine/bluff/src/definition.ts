// JAMAA-PLATFORM §2.2 / §2.10: Bluff behind the GameDefinition interface.
import { BIG_GROUP } from "./constants";
import { type BluffCatalog, contentCounts } from "./content";
import { join, memory, nextWakeAt, outcome, reduce, start, startBlocker } from "./engine";
import { assertInvariants } from "./invariants";
import { BLUFF_META } from "./meta";
import { FORBIDDEN_KEYS, leakCheck, projectMe, projectPublic, projectStatus, secretsFor } from "./projection";
import type { BluffExtras, BluffIntent, BluffMe, BluffPublic, BluffSettings, BluffState } from "./state";
import type { GameDefinition, Locale } from "./types";

const PACK_ID = /^[a-z0-9-]{1,35}$/;
const LENGTHS = ["short", "normal", "long"] as const;
const PACES = ["relaxed", "normal", "fast"] as const;
const validPackIds = (v: unknown): v is string[] =>
  Array.isArray(v) && v.length <= 50 && v.every((x) => typeof x === "string" && PACK_ID.test(x)) && new Set(v).size === v.length;
const isLength = (v: unknown): v is BluffSettings["length"] => (LENGTHS as readonly unknown[]).includes(v);
const isPace = (v: unknown): v is BluffSettings["pace"] => (PACES as readonly unknown[]).includes(v);
const packsIn = (cat: BluffCatalog, locale: Locale): Set<string> => new Set(cat.packs.filter((p) => p.playableIn.includes(locale)).map((p) => p.id));

export type BluffDefinition = GameDefinition<BluffState, BluffSettings, BluffIntent, BluffPublic, BluffMe, BluffCatalog, BluffExtras>;

export const definition: BluffDefinition = {
  meta: BLUFF_META,
  enabled: true,
  settings: {
    apply(s, patch, content, locale) {
      const next: BluffSettings = { packIds: [...s.packIds], length: s.length, pace: s.pace };
      for (const [k, v] of Object.entries(patch)) {
        if (k === "packIds") {
          if (!validPackIds(v)) return null;
          const ok = packsIn(content, locale);
          if (v.some((id) => !ok.has(id))) return null;
          next.packIds = [...v];
        } else if (k === "length") {
          if (!isLength(v)) return null;
          next.length = v;
        } else if (k === "pace") {
          if (!isPace(v)) return null;
          next.pace = v;
        } else return null;
      }
      return next;
    },
    normalize(raw) {
      const r = (raw !== null && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
      const d = BLUFF_META.settings.defaults;
      return {
        packIds: validPackIds(r.packIds) ? [...r.packIds] : [...d.packIds],
        length: isLength(r.length) ? r.length : d.length,
        pace: isPace(r.pace) ? r.pace : d.pace,
      };
    },
    restrict(s, a) {
      const kept = s.packIds.filter((id) => a.playableIds.has(id));
      return kept.length === s.packIds.length ? s : { ...s, packIds: kept };
    },
    packIds: (s) => s.packIds,
  },
  start,
  reduce,
  nextWakeAt,
  outcome,
  memory,
  join,
  startBlocker,
  projectSetup(s, roster, content, _access, locale) {
    const c = contentCounts(content, s.packIds, locale);
    return { gameId: "bluff", available: c.r1 + c.r2, bigGroup: roster.length >= BIG_GROUP };
  },
  projectPublic: (s) => projectPublic(s),
  projectMe: (s, id) => projectMe(s, id),
  projectStatus,
  assertInvariants,
  secretsFor,
  leakCheck,
  forbiddenKeys: FORBIDDEN_KEYS,
};
