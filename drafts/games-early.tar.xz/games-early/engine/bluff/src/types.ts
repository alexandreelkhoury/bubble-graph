// Platform contract, copied from docs/JAMAA-PLATFORM.md §2.2 (exact) so this draft compiles standalone.
// Only the definitions Bluff needs are here; the names and shapes match shared/src/games/types.ts.
// Note: the repo's shared/src/games/types.ts adds a trailing `memory: GameMemory` parameter to `projectSetup`
// (a JAMAA-GAP for Mish Ana!). Bluff's implementation takes the 5 documented parameters, which is assignable to both.

export const LOCALES = ["en", "fr", "ar", "es"] as const;
export type Locale = (typeof LOCALES)[number];

export const GAME_IDS = ["mishana", "bluff", "likely", "trivia"] as const;
export type GameId = (typeof GAME_IDS)[number];

export const WORLD_IDS = ["night-market", "hakawati-cafe", "rooftop", "quiz-studio"] as const;
export type WorldId = (typeof WORLD_IDS)[number];

/** §4.4: what the room may play. `packs` holds owned FAMILY ids. */
export interface RoomAccess { premium: boolean; packs: ReadonlySet<string> }

/** Platform codes Bluff uses (subset of protocol/errors.ts PLATFORM_ERROR_CODES). */
export const PLATFORM_CODES_USED = [
  "NOT_HOST", "WRONG_PHASE", "INVALID_TARGET", "NOT_ENOUGH_PLAYERS", "NOT_IN_GAME", "GAME_FULL",
  "NO_CONTENT_AVAILABLE", "ALREADY_JOINED", "BAD_MESSAGE",
] as const;
/** Bluff's own codes (games/bluff/errors.ts). CANNOT_VOTE_SPOT_ON is the draft-3 addition (GAME-BLUFF §5.1). */
export const BLUFF_ERRORS = [
  "LIE_EMPTY", "LIE_TOO_LONG", "LIE_TOO_CLOSE", "LIE_WRONG_SCRIPT", "LIE_BLOCKED_WORD", "TOO_MANY_EDITS",
  "CANNOT_VOTE_OWN", "CANNOT_VOTE_SPOT_ON", "CANNOT_HIDE", "STALE_PROMPT",
] as const;
export type ErrorCode = (typeof PLATFORM_CODES_USED)[number] | (typeof BLUFF_ERRORS)[number];

export class InvariantError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "InvariantError";
  }
}

// ---- §2.2 (exact) ----

export type GameActor = { kind: "tv" } | { kind: "player"; playerId: string };
export interface RosterEntry { id: string; seat: number; locale: Locale; connected: boolean; carryScore: number }

/** What the platform sends into a game. Intents are already zod-validated against the game's intent schema. */
export type GameAction<I> =
  | { type: "INTENT"; intent: I; by: GameActor }
  | { type: "TICK" }
  | { type: "PLAYER_AWAY"; playerId: string }
  | { type: "PLAYER_BACK"; playerId: string }
  | { type: "PLAYER_GONE"; playerId: string; cause: "LEAVE" | "KICK" };

/** isHost is the ONLY host test a game may use; the room computes it from room.hostPlayerId (TV always true). */
export interface GameCtx<C> { now: number; content: C; isHost: (actor: GameActor) => boolean; hostPlayerId: string | null }
export type GameReduceResult<S> = { ok: true; state: S } | { ok: false; error: ErrorCode; state: S };

export interface GameOutcome {
  points: Record<string, number>;
  ranking: string[][];
}
export interface GameMemory { usedKeys: string[] }

export type SettingField =
  | { key: string; kind: "stepper"; labelKey: string; bounds: { min: number; max: number; step: number; off?: 0 }; unitKey?: string }
  | { key: string; kind: "choice"; labelKey: string; options: readonly { value: string | number; labelKey: string }[] }
  | { key: string; kind: "toggle"; labelKey: string }
  | { key: string; kind: "packs"; labelKey: string; single: boolean };

export interface GameRules {
  titleKey: string; taglineKey: string;
  howToKeys: readonly string[];
  ruleSections: readonly { id: string; titleKey: string; bodyKey: string; phases: readonly string[] }[];
  durationMinutes: readonly [number, number];
  world: WorldId;
  pauseItems: readonly { id: string; labelKey: string; intent: string; phases: readonly string[]; confirm?: boolean }[];
}

export interface GameMeta<Settings> {
  id: GameId;
  minPlayers: number; maxPlayers: number;
  phases: readonly string[];
  rules: GameRules;
  carriesScore: boolean;
  VIEW_VERSION: number;
  SETTINGS_SCHEMA: number;
  settings: {
    defaults: Settings;
    basic: readonly SettingField[];
    advanced: readonly SettingField[];
    premiumKeys: readonly (keyof Settings)[];
  };
}

export interface GameDefinition<S, Settings, Intent, Pub, Me, C, Extras> {
  meta: GameMeta<Settings>;
  enabled: boolean;
  settings: {
    apply(s: Settings, patch: Partial<Settings>, content: C, locale: Locale): Settings | null;
    normalize(raw: unknown): Settings;
    restrict(s: Settings, a: { playableIds: ReadonlySet<string>; premium: boolean }, content: C, locale: Locale): Settings;
    packIds(s: Settings): readonly string[];
  };
  start(a: { roster: readonly RosterEntry[]; settings: Settings; locale: Locale; memory: GameMemory; seed: number; now: number; graceMs: number; content: C }): GameReduceResult<S>;
  reduce(s: S, a: GameAction<Intent>, ctx: GameCtx<C>): GameReduceResult<S>;
  nextWakeAt(s: S): number | null;
  outcome(s: S): GameOutcome | null;
  memory(s: S): GameMemory;
  join?(s: S, entry: RosterEntry): GameReduceResult<S>;
  startBlocker(roster: readonly RosterEntry[], s: Settings, content: C, locale: Locale): ErrorCode | null;
  projectSetup(s: Settings, roster: readonly RosterEntry[], content: C, access: RoomAccess, locale: Locale): Extras;
  projectPublic(s: S, content: C): Pub;
  projectMe(s: S, playerId: string, content: C): Me | null;
  projectStatus(s: S): { phase: string; doneIds: string[]; awaitedIds: string[] };
  assertInvariants(s: S): void;
  secretsFor(s: S, viewer: string | null): readonly unknown[];
  leakCheck(s: S, viewer: string | null, view: unknown): string[];
  forbiddenKeys: readonly string[];
}
