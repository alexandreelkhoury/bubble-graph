// JAMAA-PLATFORM §2.10 + GAME-BLUFF §2/§9/§10.2: Bluff's GameMeta (zod-free, engine-free).
import type { BluffSettings } from "./state";
import { PHASES } from "./state";
import type { GameMeta } from "./types";

const K = "game.bluff";
export const BLUFF_META: GameMeta<BluffSettings> = {
  id: "bluff",
  minPlayers: 3,
  maxPlayers: 12,
  phases: PHASES,
  rules: {
    titleKey: `${K}.title`,
    taglineKey: `${K}.tagline`,
    howToKeys: [`${K}.howto.1`, `${K}.howto.2`, `${K}.howto.3`, `${K}.howto.4`],
    ruleSections: [
      { id: "goal", titleKey: `${K}.rules.goal.title`, bodyKey: `${K}.rules.goal.body`, phases: [] },
      { id: "round1", titleKey: `${K}.rules.round1.title`, bodyKey: `${K}.rules.round1.body`, phases: ["ROUND_INTRO", "WRITING"] },
      { id: "round2", titleKey: `${K}.rules.round2.title`, bodyKey: `${K}.rules.round2.body`, phases: ["ROUND_INTRO", "WRITING"] },
      { id: "writing", titleKey: `${K}.rules.writing.title`, bodyKey: `${K}.rules.writing.body`, phases: ["WRITING"] },
      { id: "voting", titleKey: `${K}.rules.voting.title`, bodyKey: `${K}.rules.voting.body`, phases: ["VOTING"] },
      { id: "points", titleKey: `${K}.rules.points.title`, bodyKey: `${K}.rules.points.body`, phases: ["REVEAL", "SCORES"] },
      { id: "final", titleKey: `${K}.rules.final.title`, bodyKey: `${K}.rules.final.body`, phases: [] },
      { id: "house", titleKey: `${K}.rules.house.title`, bodyKey: `${K}.rules.house.body`, phases: ["VOTING", "REVEAL"] },
      { id: "same", titleKey: `${K}.rules.same.title`, bodyKey: `${K}.rules.same.body`, phases: ["REVEAL"] },
      { id: "host", titleKey: `${K}.rules.host.title`, bodyKey: `${K}.rules.host.body`, phases: ["HOLD"] },
    ],
    durationMinutes: [15, 20],
    world: "hakawati-cafe",
    pauseItems: [
      { id: "skipPrompt", labelKey: `${K}.pause.skipPrompt`, intent: "SKIP_PROMPT", phases: ["WRITING"] },
      { id: "hideOption", labelKey: `${K}.pause.hideOption`, intent: "HIDE_OPTION", phases: ["VOTING"] },
      { id: "next", labelKey: `${K}.pause.next`, intent: "HOST_ADVANCE", phases: ["ROUND_INTRO", "REVEAL", "SCORES", "AWARDS"] },
      { id: "endGame", labelKey: `${K}.pause.endGame`, intent: "END_GAME", phases: ["HOLD"], confirm: true },
    ],
  },
  carriesScore: false,
  VIEW_VERSION: 1,
  SETTINGS_SCHEMA: 1,
  settings: {
    defaults: { packIds: [], length: "normal", pace: "normal" },
    basic: [
      { key: "packIds", kind: "packs", labelKey: `${K}.settings.packs`, single: false },
      { key: "length", kind: "choice", labelKey: `${K}.settings.length`, options: [
        { value: "short", labelKey: `${K}.settings.length.short` }, { value: "normal", labelKey: `${K}.settings.length.normal` }, { value: "long", labelKey: `${K}.settings.length.long` },
      ] },
      { key: "pace", kind: "choice", labelKey: `${K}.settings.pace`, options: [
        { value: "relaxed", labelKey: `${K}.settings.pace.relaxed` }, { value: "normal", labelKey: `${K}.settings.pace.normal` }, { value: "fast", labelKey: `${K}.settings.pace.fast` },
      ] },
    ],
    advanced: [],
    premiumKeys: [],
  },
};
