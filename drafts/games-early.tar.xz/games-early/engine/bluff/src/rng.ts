// mulberry32, byte-identical to shared/src/room/rng.ts (JAMAA-PLATFORM §2.1): the state lives in BluffState.rngState.
export interface Rng { state: number; next(): number; int(n: number): number }   // int: 0..n-1
export function createRng(state: number): Rng {
  const r: Rng = {
    state: state >>> 0,
    next() {
      r.state = (r.state + 0x6D2B79F5) >>> 0;
      let t = r.state;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    },
    int(n) { return Math.floor(r.next() * n); },
  };
  return r;
}

/** Fisher–Yates, in place, driven by `rng`. */
export function shuffleInPlace<T>(rng: Rng, xs: T[]): T[] {
  for (let i = xs.length - 1; i > 0; i--) {
    const j = rng.int(i + 1);
    const t = xs[i] as T;
    xs[i] = xs[j] as T;
    xs[j] = t;
  }
  return xs;
}

/** 8 lowercase hex chars from the RNG (option and prompt ids: no order or kind information). */
export function hexId(rng: Rng): string {
  return Math.floor(rng.next() * 0x1_0000_0000).toString(16).padStart(8, "0");
}

/** Weighted pick (weights > 0). Returns the index. */
export function weightedIndex(rng: Rng, weights: readonly number[]): number {
  const total = weights.reduce((a, b) => a + b, 0);
  let x = rng.next() * total;
  for (let i = 0; i < weights.length; i++) {
    x -= weights[i] as number;
    if (x < 0) return i;
  }
  return weights.length - 1;
}
