// GAME-LIKELY §8.1 secrecy and §13.2 views. In secret-vote mode nothing projected may depend on the voter→target mapping
// beyond the per-card tallies (anonymity property, JAMAA-PLATFORM §2.11): no ballots, no deltas, scores pinned at 0,
// no Self-aware or Mind Reader award, and every list is ordered by seat or by tally, never by ballot order.
import { AGAIN_STREAK } from "./constants";
import { cardText, findCard, type LikelyCatalog } from "./content";
import type { AwardKind } from "./awards";
import { eligibleCards } from "./draw";
import { isAnonymous, isVoter, type LikelyState, type Phase } from "./engine";
import type { Locale, RoomAccess, RosterEntry } from "./platform";
import { withPercent, type DeltaReason } from "./result";
import { spicyAvailable, type LikelySettings } from "./settings";

export interface ProjectedCard { id: string; prompt: string; award: string; spicy: boolean; namedPlayerId: string | null; rerun: boolean }
export interface LikelyReveal {
  votesCast: number;
  counts: { playerId: string; count: number; percent: number }[];   // percent desc, then seat
  topIds: string[];
  unanimous: boolean;
  chaos: boolean;
  none: boolean;                                                     // nobody voted
  againId: string | null;                                            // "{name} AGAIN?!" (3 cards in a row)
  ballots: { voterId: string; targetId: string }[] | null;           // public mode only
  deltas: { playerId: string; points: number; reason: DeltaReason }[]; // [] in secret-vote mode
}
export interface ProjectedAward { kind: AwardKind; playerIds: string[]; card: { index: number; id: string; prompt: string; award: string; namedPlayerId: string | null } | null }
export interface LikelyPublic {
  schema: number;
  phase: Phase;
  cardIndex: number;
  cardCount: number;
  deadline: number | null;
  /** `prompt` is the raw template: JAMAA-GAP, the game never sees display names, so clients replace "{player}" with the
   *  name of `namedPlayerId` (and colour it, §8.2). */
  card: ProjectedCard | null;
  newIds: string[];
  votedIds: string[];
  reveal: LikelyReveal | null;
  scores: { playerId: string; score: number; scoreBefore: number }[];
  awards: ProjectedAward[] | null;
  showVoters: boolean;
  mode: "family" | "spicy";
}
export interface LikelyMe { myVote: string | null; waitingForNext: boolean }
export interface LikelyExtras { gameId: "likely"; available: number; spicyAvailable: boolean }

export const FORBIDDEN_KEYS = ["votes", "ballotsAll", "rngState", "usedKeys"] as const;

function projectCardRef(content: LikelyCatalog, locale: Locale, packId: string, cardId: string) {
  const f = findCard(content, packId, cardId);
  return { prompt: f ? cardText(f.card.prompt, locale) : "", award: f ? cardText(f.card.award, locale) : "" };
}

export function projectPublic(s: LikelyState, content: LikelyCatalog): LikelyPublic {
  const anon = isAnonymous(s);
  const cur = s.phase === "REVEAL" ? s.results[s.results.length - 1] : undefined;
  let reveal: LikelyReveal | null = null;
  if (cur) {
    let againId: string | null = null;
    const last = s.results.slice(-AGAIN_STREAK);
    if (last.length === AGAIN_STREAK) againId = cur.topIds.find((id) => last.every((r) => r.topIds.includes(id))) ?? null;
    reveal = {
      votesCast: cur.votesCast, counts: withPercent(cur), topIds: [...cur.topIds], unanimous: cur.unanimous, chaos: cur.chaos,
      none: cur.votesCast === 0, againId,
      ballots: anon ? null : cur.ballotsAll.map((b) => ({ voterId: b.voterId, targetId: b.targetId })),
      deltas: anon ? [] : cur.deltas.map((d) => ({ ...d })),
    };
  }
  const gained = new Map<string, number>();
  if (cur && !anon) for (const d of cur.deltas) gained.set(d.playerId, (gained.get(d.playerId) ?? 0) + d.points);
  const scores = s.players.map((p) => {
    const score = anon ? 0 : (s.scores[p.id] ?? 0);
    return { playerId: p.id, score, scoreBefore: score - (gained.get(p.id) ?? 0) };
  });
  const card = s.card ? { id: s.card.cardId, ...projectCardRef(content, s.locale, s.card.packId, s.card.cardId), spicy: s.card.spicy, namedPlayerId: s.card.namedPlayerId, rerun: s.card.rerun } : null;
  const awards = s.awards ? s.awards
    .filter((a) => !anon || (a.kind !== "selfAware" && a.kind !== "mindReader"))
    .map((a): ProjectedAward => {
      const r = a.cardIndex === null ? undefined : s.results[a.cardIndex];
      return { kind: a.kind, playerIds: [...a.playerIds], card: r ? { index: r.index, id: r.cardId, ...projectCardRef(content, s.locale, r.packId, r.cardId), namedPlayerId: r.namedPlayerId } : null };
    }) : null;
  return {
    schema: s.schema, phase: s.phase, cardIndex: s.cardIndex, cardCount: s.cardCount, deadline: s.deadline, card,
    newIds: s.card ? s.players.filter((p) => p.late && p.firstCard === s.cardIndex).map((p) => p.id) : [],
    votedIds: s.phase === "VOTING" ? s.players.filter((p) => s.votes[p.id] !== undefined).map((p) => p.id) : [],
    reveal, scores, awards, showVoters: s.settings.showVoters, mode: s.settings.mode,
  };
}

export function projectMe(s: LikelyState, playerId: string): LikelyMe | null {
  const p = s.players.find((x) => x.id === playerId);
  if (!p) return null;
  let myVote: string | null = null;
  if (s.phase === "VOTING") myVote = s.votes[playerId] ?? null;
  else if (s.phase === "REVEAL") myVote = s.results[s.results.length - 1]?.ballotsAll.find((b) => b.voterId === playerId)?.targetId ?? null;
  return { myVote, waitingForNext: p.waiting && !p.left };
}

export function projectStatus(s: LikelyState): { phase: string; doneIds: string[]; awaitedIds: string[] } {
  if (s.phase !== "VOTING") return { phase: s.phase, doneIds: [], awaitedIds: [] };
  return {
    phase: s.phase,
    doneIds: s.players.filter((p) => s.votes[p.id] !== undefined).map((p) => p.id),
    awaitedIds: s.players.filter((p) => isVoter(p) && p.connected && s.votes[p.id] === undefined).map((p) => p.id),
  };
}

export function projectSetup(settings: LikelySettings, _roster: readonly RosterEntry[], content: LikelyCatalog, _access: RoomAccess, locale: Locale): LikelyExtras {
  return { gameId: "likely", available: eligibleCards(content, settings, locale).length, spicyAvailable: spicyAvailable(content, locale) };
}

/** No leaf value is secret by itself here (player ids appear everywhere); Likely's secrets are structural → leakCheck. */
export function secretsFor(_s: LikelyState, _viewer: string | null): readonly unknown[] { return []; }

function walk(v: unknown, path: string, visit: (key: string, value: unknown, path: string) => void): void {
  if (Array.isArray(v)) v.forEach((x, i) => walk(x, `${path}[${i}]`, visit));
  else if (typeof v === "object" && v !== null) for (const [k, x] of Object.entries(v)) { visit(k, x, `${path}.${k}`); walk(x, `${path}.${k}`, visit); }
}

/** `view` is the TV's LikelyPublic (viewer null) or a phone's `{ pub, me }`. */
export function leakCheck(s: LikelyState, viewer: string | null, view: unknown): string[] {
  const out: string[] = [];
  const anon = isAnonymous(s);
  walk(view, "$", (k, v, path) => {
    if ((FORBIDDEN_KEYS as readonly string[]).includes(k)) out.push(`${path}: state-only key`);
    if (k === "ballots" && v !== null && (anon || s.phase !== "REVEAL")) out.push(`${path}: ballots ${anon ? "in secret-vote mode" : "before/after REVEAL"}`);
    if (k === "targetId" && (anon || s.phase !== "REVEAL")) out.push(`${path}: voter→target pair`);
    if (k === "reveal" && v !== null && s.phase !== "REVEAL") out.push(`${path}: reveal outside REVEAL`);
    if (anon && (k === "score" || k === "scoreBefore") && v !== 0) out.push(`${path}: score in secret-vote mode`);
    if (anon && k === "deltas" && Array.isArray(v) && v.length > 0) out.push(`${path}: deltas in secret-vote mode`);
    if (anon && k === "kind" && (v === "selfAware" || v === "mindReader")) out.push(`${path}: ${String(v)} award in secret-vote mode`);
    if (k === "myVote" && v !== null) {
      const own = viewer === null ? undefined : (projectMe(s, viewer)?.myVote ?? undefined);
      if (viewer === null || v !== own || !path.startsWith("$.me")) out.push(`${path}: a vote outside its owner's me`);
    }
  });
  return out;
}
