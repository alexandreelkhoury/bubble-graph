// games/likely/definition.ts shape (JAMAA-PLATFORM §2.2): the engine behind the GameDefinition contract.
// `createLikelyDefinition({ spicyEnabled })` exists so tests can exercise Spicy while the shipped definition keeps it
// compiled out (LIKELY_SPICY_ENABLED = false, GAME-LIKELY §9.1 rule 2).
import { LIKELY_SPICY_ENABLED, STATE_SCHEMA } from "./constants";
import type { LikelyCatalog } from "./content";
import { assertInvariants, join, memory, nextWakeAt, outcome, reduce, start, startBlocker, type EngineOptions, type LikelyIntent, type LikelyState } from "./engine";
import { LIKELY_META } from "./meta";
import type { GameAction, GameActor, GameCtx, GameMemory, Locale, RoomAccess, RosterEntry } from "./platform";
import { FORBIDDEN_KEYS, leakCheck, projectMe, projectPublic, projectSetup, projectStatus, secretsFor } from "./projection";
import { apply, normalize, packIdsOf, restrict, type LikelySettings, type LikelySettingsPatch } from "./settings";

export function createLikelyDefinition(opt: EngineOptions) {
  return {
    meta: LIKELY_META,
    enabled: true,
    stateSchema: STATE_SCHEMA,
    settings: {
      apply: (s: LikelySettings, patch: LikelySettingsPatch, content: LikelyCatalog, locale: Locale, by?: GameActor) => apply(s, patch, content, locale, by, opt),
      normalize,
      restrict,
      packIds: packIdsOf,
    },
    start: (a: { roster: readonly RosterEntry[]; settings: LikelySettings; locale: Locale; memory: GameMemory; seed: number; now: number; graceMs: number; content: LikelyCatalog }) => start(a, opt),
    reduce: (s: LikelyState, a: GameAction<LikelyIntent>, ctx: GameCtx<LikelyCatalog>) => reduce(s, a, ctx),
    nextWakeAt,
    outcome,
    memory,
    join,
    startBlocker: (roster: readonly RosterEntry[], s: LikelySettings, content: LikelyCatalog, locale: Locale) => startBlocker(roster, s, content, locale, opt),
    projectSetup: (s: LikelySettings, roster: readonly RosterEntry[], content: LikelyCatalog, access: RoomAccess, locale: Locale) => projectSetup(s, roster, content, access, locale),
    projectPublic: (s: LikelyState, content: LikelyCatalog) => projectPublic(s, content),
    projectMe: (s: LikelyState, playerId: string, _content?: LikelyCatalog) => projectMe(s, playerId),
    projectStatus,
    assertInvariants,
    secretsFor,
    leakCheck,
    forbiddenKeys: FORBIDDEN_KEYS,
  };
}

export const definition = createLikelyDefinition({ spicyEnabled: LIKELY_SPICY_ENABLED });
export type LikelyDefinition = typeof definition;
