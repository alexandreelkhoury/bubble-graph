// GAME-LIKELY §11.2 pack schema (hand-validated here; the repo version is zod, shared/src/games/likely/schema.ts) and the
// platform ContentAdapter (JAMAA-PLATFORM §5.2). The engine's content type C is the room's PLAYABLE catalog: tier
// filtering happened in `playable` before the engine ever sees a card.
import type { Locale } from "./platform";

export const TAGS = ["party", "food", "family", "travel", "habits", "lebanon", "tech", "music", "sport", "future", "romance"] as const;
export type Tag = (typeof TAGS)[number];

export interface L4 { en: string; fr: string; ar: string; es?: string }
export interface LikelyCard {
  id: string;
  tier: "free" | "pass";
  spice: 0 | 1 | 2;
  namesPlayer: boolean;
  tags: Tag[];
  prompt: L4;
  award: L4;
  review: { status: "draft" | "native-reviewed" };
}
export interface LikelyPack {
  schemaVersion: 1;
  id: string;
  game: "likely";
  title: L4;
  description: L4;
  locales: Locale[];
  ageRating: "all" | "teen" | "adult";
  cards: LikelyCard[];
}
/** The engine's `C`: packs already filtered by access (§5.2 playableContent). */
export interface LikelyCatalog { packs: readonly LikelyPack[] }

export const PLAYER_TOKEN = "{player}";

const CARD_ID = /^[a-z0-9-]{3,40}$/;
const PACK_ID = /^[a-z0-9-]{1,35}$/;
const MAX: Record<Locale, number> = { en: 60, fr: 70, ar: 60, es: 70 };

function isObj(v: unknown): v is Record<string, unknown> { return typeof v === "object" && v !== null && !Array.isArray(v); }
function graphemes(s: string): number { return [...new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(s)].length; }
function count(s: string, needle: string): number { return s.split(needle).length - 1; }

function parseL4(v: unknown, where: string, limit: boolean): L4 {
  if (!isObj(v)) throw new Error(`${where}: not an object`);
  const out: Partial<L4> = {};
  for (const k of Object.keys(v)) if (!["en", "fr", "ar", "es"].includes(k)) throw new Error(`${where}: unknown key ${k}`);
  for (const loc of ["en", "fr", "ar", "es"] as const) {
    const s = v[loc];
    if (s === undefined && loc === "es") continue;
    if (typeof s !== "string" || s.length === 0) throw new Error(`${where}.${loc}: missing`);
    if (limit && graphemes(s) > MAX[loc]) throw new Error(`${where}.${loc}: longer than ${MAX[loc]}`);
    out[loc] = s;
  }
  return out as L4;
}

/** Throws on an invalid pack. Covers the schema and the hard lint rules the engine relies on (§11.2). */
export function parsePack(raw: unknown): LikelyPack {
  if (!isObj(raw)) throw new Error("pack: not an object");
  if (raw.schemaVersion !== 1) throw new Error("pack: schemaVersion");
  if (typeof raw.id !== "string" || !PACK_ID.test(raw.id)) throw new Error("pack: id");
  if (raw.game !== "likely") throw new Error("pack: game");
  if (raw.ageRating !== "all" && raw.ageRating !== "teen" && raw.ageRating !== "adult") throw new Error("pack: ageRating");
  const locales = raw.locales === undefined ? ["en", "fr", "ar"] : raw.locales;
  if (!Array.isArray(locales) || locales.length < 3 || !locales.every((l) => ["en", "fr", "ar", "es"].includes(l as string))) throw new Error("pack: locales");
  if (!Array.isArray(raw.cards) || raw.cards.length < 30) throw new Error("pack: needs ≥ 30 cards");
  const ids = new Set<string>();
  const cards = raw.cards.map((c, i): LikelyCard => {
    const w = `cards[${i}]`;
    if (!isObj(c)) throw new Error(`${w}: not an object`);
    if (typeof c.id !== "string" || !CARD_ID.test(c.id)) throw new Error(`${w}: id`);
    if (ids.has(c.id)) throw new Error(`${w}: duplicate id ${c.id}`);
    ids.add(c.id);
    if (c.tier !== "free" && c.tier !== "pass") throw new Error(`${w}: tier`);
    if (c.spice !== 0 && c.spice !== 1 && c.spice !== 2) throw new Error(`${w}: spice`);
    const namesPlayer = c.namesPlayer === undefined ? false : c.namesPlayer;
    if (typeof namesPlayer !== "boolean") throw new Error(`${w}: namesPlayer`);
    if (!Array.isArray(c.tags) || c.tags.length < 1 || c.tags.length > 3 || !c.tags.every((t) => (TAGS as readonly string[]).includes(t as string))) throw new Error(`${w}: tags`);
    const prompt = parseL4(c.prompt, `${w}.prompt`, true);
    const award = parseL4(c.award, `${w}.award`, true);
    if (!isObj(c.review) || (c.review.status !== "draft" && c.review.status !== "native-reviewed")) throw new Error(`${w}: review`);
    // Hard rules the engine depends on (§11.2 lint): family packs stay family; {player} ⇔ namesPlayer.
    if (raw.ageRating === "all" && (c.spice !== 0 || namesPlayer)) throw new Error(`${w}: spice/named card in an "all" pack`);
    if (raw.ageRating === "adult" && c.spice === 0) throw new Error(`${w}: spice 0 in an adult pack`);
    if (namesPlayer && c.spice === 0) throw new Error(`${w}: named card with spice 0`);
    if ((c.tags as string[]).includes("romance") && c.spice === 0) throw new Error(`${w}: romance tag needs spice ≥ 1`);
    for (const loc of ["en", "fr", "ar", "es"] as const) {
      const p = prompt[loc];
      if (p === undefined) { if ((locales as string[]).includes(loc)) throw new Error(`${w}.prompt.${loc}: pack lists ${loc}`); continue; }
      if (count(p, PLAYER_TOKEN) !== (namesPlayer ? 1 : 0)) throw new Error(`${w}.prompt.${loc}: {player} count`);
      const a = award[loc];
      if (a === undefined) throw new Error(`${w}.award.${loc}: missing`);
      if (a.includes(PLAYER_TOKEN)) throw new Error(`${w}.award.${loc}: {player} in an award`);
    }
    return { id: c.id, tier: c.tier, spice: c.spice, namesPlayer, tags: c.tags as Tag[], prompt, award, review: { status: c.review.status } };
  });
  const L = (v: unknown, k: string): L4 => parseL4(v, `pack.${k}`, false);
  return { schemaVersion: 1, id: raw.id, game: "likely", title: L(raw.title, "title"), description: L(raw.description, "description"), locales: locales as Locale[], ageRating: raw.ageRating, cards };
}

export interface LikelyPackMeta {
  id: string; family: string; gameId: "likely"; languages: Locale[]; title: L4; ageRating: LikelyPack["ageRating"];
  tier: "free" | "premium" | "mixed"; itemCount: number; freeItemCount: number;
}

/** ContentAdapter<LikelyPack> (JAMAA-PLATFORM §5.2). */
export const content = {
  parse: parsePack,
  meta(p: LikelyPack): LikelyPackMeta {
    const free = p.cards.filter((c) => c.tier === "free").length;
    return {
      id: p.id, family: p.id, gameId: "likely", languages: [...p.locales], title: p.title, ageRating: p.ageRating,
      tier: free === p.cards.length ? "free" : free === 0 ? "premium" : "mixed", itemCount: p.cards.length, freeItemCount: free,
    };
  },
  /** Free room: only `tier:"free"` cards, and never an adult pack. Pass (or a bought family): the whole pack. */
  playable(p: LikelyPack, a: { premium: boolean; ownedFamilies: ReadonlySet<string> }): LikelyPack | null {
    if (a.premium || a.ownedFamilies.has(p.id)) return p;
    if (p.ageRating === "adult") return null;
    const cards = p.cards.filter((c) => c.tier === "free");
    if (cards.length === 0) return null;
    return cards.length === p.cards.length ? p : { ...p, cards };
  },
};

export function cardText(l: L4, locale: Locale): string { return l[locale] ?? l.en; }

export function findCard(c: LikelyCatalog, packId: string, cardId: string): { pack: LikelyPack; card: LikelyCard } | null {
  const pack = c.packs.find((p) => p.id === packId);
  const card = pack?.cards.find((x) => x.id === cardId);
  return pack && card ? { pack, card } : null;
}
