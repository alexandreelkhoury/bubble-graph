// GAME-LIKELY §3, §4.1, §6, §6.2, §12.2 numbers. One place, so the doc and the code can be diffed.

export const STATE_SCHEMA = 1;
export const SETTINGS_SCHEMA = 2; // GAME-LIKELY §9: `mode` added
export const VIEW_VERSION = 1;

/** GAME-LIKELY §9.1 rule 2: Spicy ships compiled out until `settings.apply` receives the actor (platform open item). */
export const LIKELY_SPICY_ENABLED = false;

export const MIN_PLAYERS = 3;
export const MAX_PLAYERS = 12;
export const MIN_CONNECTED = 3;            // HOLD below this at card start (§7)
export const NAMED_MIN_PLAYERS = 4;        // named cards need ≥ 4 players in game (§7, §11.3)

export const LENGTHS = { short: 8, normal: 12, long: 16 } as const;
export type LengthId = keyof typeof LENGTHS;

export const CARD_MS = 3_500;
export const EARLY_END_MS = 1_000;
export const votingMs = (n: number): number => Math.min(26_000, Math.max(18_000, 14_000 + 1_000 * n));
/** §12.2: 5 000 + 100 × votes + (unanimous ? 1 200 : 0) + (ties > 1 ? 600 : 0), max 9 500.
 *  §4.1 also says "6 000–9 500 ms"; the formula alone gives 5 000 with 0 votes, so the draft clamps to 6 000 (open issue). */
export const REVEAL_MIN_MS = 6_000;
export const REVEAL_MAX_MS = 9_500;
export const revealMs = (votes: number, unanimous: boolean, ties: number): number =>
  Math.min(REVEAL_MAX_MS, Math.max(REVEAL_MIN_MS, 5_000 + 100 * votes + (unanimous ? 1_200 : 0) + (ties > 1 ? 600 : 0)));
/** §4.1: 3 000 + 4 000 × ceil(players / 3) + 4 000 (the last 4 000 = Mind Reader, public mode only). */
export const awardsMs = (players: number, publicMode: boolean): number => 3_000 + 4_000 * Math.ceil(players / 3) + (publicMode ? 4_000 : 0);

// Scoring ("Read the Room", public mode only, §6)
export const AGREE_POINTS = 50;
export const AGREE_CAP = 300;
export const UNANIMOUS_BONUS = 100;
export const SELF_AWARE_BONUS = 100;
export const SELF_AWARE_MIN_OTHERS = 2;
export const RESULT_MIN_VOTES = 3;         // chaos and unanimous need ≥ 3 votes (§5.1)

// Awards (§6.2)
export const STAR_MIN_TOPS = 3;
export const SELF_AWARE_AWARD_MIN = 2;
export const AGAIN_STREAK = 3;             // "{name} AGAIN?!" after 3 cards in a row (§6.1)

export const OPENER_TAGS: readonly string[] = ["party", "habits"];
