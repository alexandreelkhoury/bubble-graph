// GAME-LIKELY §4–§7: the pure engine. No I/O, no Date.now(), no Math.random(); RNG state lives in the state.
// reduce never mutates its input and returns the SAME object when nothing changed.
import { awardsMs, CARD_MS, EARLY_END_MS, LENGTHS, MAX_PLAYERS, MIN_CONNECTED, revealMs, STATE_SCHEMA, votingMs } from "./constants";
import type { LikelyCatalog } from "./content";
import { computeAwards, type AwardEntry } from "./awards";
import { drawCard, eligibleCards, namedPool } from "./draw";
import { createRng, competitionRanking, InvariantError, MEMORY_MAX_KEYS, type ErrorCode, type GameAction, type GameActor, type GameCtx, type GameMemory, type GameOutcome, type GameReduceResult, type Locale, type RosterEntry } from "./platform";
import { scoreCard, tally, percentOf, type Ballot, type Delta } from "./result";
import type { LikelySettings } from "./settings";

export const PHASES = ["CARD", "VOTING", "REVEAL", "HOLD", "AWARDS", "RESULTS"] as const;
export type Phase = (typeof PHASES)[number];

export type LikelyIntent =
  | { a: "VOTE"; cardId: string; targetId: string }
  | { a: "SKIP_CARD"; cardId: string }
  | { a: "HOST_ADVANCE" }
  | { a: "END_GAME" };

export interface PlayerState {
  id: string; seat: number;
  connected: boolean; left: boolean;
  waiting: boolean;            // joined mid-game: watches until the next CARD (§7)
  late: boolean;               // joined mid-game (for the "New" ribbon)
  firstCard: number | null;    // cardIndex of the first card this player could vote on
  namedCount: number;          // Spicy named cards completed naming this player
}
export interface CurrentCard { cardId: string; packId: string; namedPlayerId: string | null; spicy: boolean; rerun: boolean; tags: string[] }
export interface CardResult {
  index: number; cardId: string; packId: string; namedPlayerId: string | null; tags: string[];
  votesCast: number; counts: { playerId: string; count: number }[]; topIds: string[]; unanimous: boolean; chaos: boolean;
  ballotsAll: Ballot[];        // voter seat order; STATE ONLY (projected only in public mode, REVEAL)
  deltas: Delta[];             // [] in secret-vote mode
}
export interface LikelyState {
  schema: typeof STATE_SCHEMA;
  phase: Phase;
  settings: LikelySettings;
  locale: Locale;
  players: PlayerState[];                 // seat order
  cardIndex: number;                      // 0-based index of the current card = completed cards
  cardCount: number;
  deadline: number | null;
  earlyEnd: boolean;                      // VOTING: the +1 s window has been set
  card: CurrentCard | null;
  votes: Record<string, string>;          // voter → target, current card; STATE ONLY
  results: CardResult[];
  scores: Record<string, number>;         // public mode only; all 0 in secret-vote mode
  drawnIds: string[];                     // every card drawn this game (skipped ones included)
  usedKeys: string[];                     // platform memory at start; STATE ONLY
  rngState: number;                       // STATE ONLY
  lastNamedId: string | null;
  awards: AwardEntry[] | null;
}

export interface EngineOptions { spicyEnabled: boolean }

const ok = <S>(state: S): GameReduceResult<S> => ({ ok: true, state });
const err = <S>(error: ErrorCode, state: S): GameReduceResult<S> => ({ ok: false, error, state });

export const isAnonymous = (s: LikelyState): boolean => !s.settings.showVoters;
const inGame = (s: LikelyState) => s.players.filter((p) => !p.left);
const connectedCount = (s: LikelyState): number => s.players.filter((p) => p.connected && !p.left).length;
/** Voters: non-left, dealt in (not waiting). Disconnected voters simply abstain. */
export const isVoter = (p: PlayerState): boolean => !p.left && !p.waiting;
/** Targets: non-left, dealt in, including yourself and disconnected players; never the card's named player. */
export function isTarget(s: LikelyState, id: string): boolean {
  const p = s.players.find((x) => x.id === id);
  return !!p && !p.left && !p.waiting && s.card?.namedPlayerId !== id;
}

// ─── start / startBlocker ──────────────────────────────────────────────────────────────────────────────────────────

export function startBlocker(roster: readonly RosterEntry[], settings: LikelySettings, content: LikelyCatalog, locale: Locale, opt: EngineOptions): ErrorCode | null {
  if (roster.filter((r) => r.connected).length < MIN_CONNECTED) return "NOT_ENOUGH_PLAYERS";
  if (settings.mode === "spicy" && !opt.spicyEnabled) return "NO_CONTENT_AVAILABLE";
  if (eligibleCards(content, settings, locale).filter((c) => !c.card.namesPlayer).length < LENGTHS[settings.length]) return "NO_CONTENT_AVAILABLE";
  return null;
}

export function start(a: { roster: readonly RosterEntry[]; settings: LikelySettings; locale: Locale; memory: GameMemory; seed: number; now: number; graceMs: number; content: LikelyCatalog }, opt: EngineOptions): GameReduceResult<LikelyState> {
  const roster = [...a.roster].sort((x, y) => x.seat - y.seat);
  const settings = a.settings;
  const s0: LikelyState = {
    schema: STATE_SCHEMA, phase: "CARD", settings, locale: a.locale,
    players: roster.map((r) => ({ id: r.id, seat: r.seat, connected: r.connected, left: false, waiting: false, late: false, firstCard: 0, namedCount: 0 })),
    cardIndex: 0, cardCount: LENGTHS[settings.length], deadline: null, earlyEnd: false, card: null, votes: {}, results: [],
    scores: Object.fromEntries(roster.map((r) => [r.id, 0])), drawnIds: [], usedKeys: a.memory.usedKeys.slice(-MEMORY_MAX_KEYS),
    rngState: a.seed >>> 0, lastNamedId: null, awards: null,
  };
  const blocker = startBlocker(roster, settings, a.content, a.locale, opt);
  if (blocker) return err(blocker, s0);
  const s1 = enterCard(s0, a.content, a.now, [], a.graceMs);
  return s1.phase === "CARD" ? ok(s1) : err("NO_CONTENT_AVAILABLE", s0);
}

// ─── transitions ───────────────────────────────────────────────────────────────────────────────────────────────────

/** Deals a new card into CARD (or HOLD when < 3 connected). Waiting players are dealt in here. */
function enterCard(s: LikelyState, content: LikelyCatalog, now: number, excludeIds: string[], graceMs = 0): LikelyState {
  const players = s.players.map((p) => (p.waiting && !p.left ? { ...p, waiting: false, firstCard: s.cardIndex } : p));
  const base: LikelyState = { ...s, players, votes: {}, earlyEnd: false };
  if (connectedCount(base) < MIN_CONNECTED) return { ...base, phase: "HOLD", card: null, deadline: null };
  const rng = createRng(base.rngState);
  const prev = base.results[base.results.length - 1];
  const pool = namedPool(base.players, base.lastNamedId);
  const d = drawCard({
    content, settings: base.settings, locale: base.locale, position: base.cardIndex, drawnIds: base.drawnIds, usedKeys: base.usedKeys,
    prevTags: prev ? prev.tags : null, namedHistory: base.results.map((r) => r.namedPlayerId !== null),
    playersInGame: inGame(base).length, namedCandidates: pool.length, excludeIds,
  }, rng);
  if (!d) return { ...base, phase: "HOLD", card: null, deadline: null }; // unreachable after startBlocker; HOLD is the safe place
  const namedPlayerId = d.namesPlayer ? (pool[rng.int(pool.length)] as string) : null;
  return {
    ...base, phase: "CARD", rngState: rng.state, drawnIds: [...base.drawnIds, d.cardId],
    card: { cardId: d.cardId, packId: d.packId, namedPlayerId, spicy: d.spicy, rerun: d.rerun, tags: d.tags },
    deadline: now + CARD_MS + graceMs,
  };
}

function toVoting(s: LikelyState, now: number): LikelyState {
  return maybeEarlyEnd({ ...s, phase: "VOTING", deadline: now + votingMs(inGame(s).length), votes: {}, earlyEnd: false }, now);
}

/** §4.1: once every connected voter has voted, the phase ends 1 s later (vote changes stay possible in that window). */
function maybeEarlyEnd(s: LikelyState, now: number): LikelyState {
  if (s.phase !== "VOTING" || s.earlyEnd) return s;
  const waitingOn = s.players.filter((p) => isVoter(p) && p.connected && s.votes[p.id] === undefined);
  if (waitingOn.length > 0) return s;
  return { ...s, earlyEnd: true, deadline: Math.min(s.deadline ?? Infinity, now + EARLY_END_MS) };
}

function toReveal(s: LikelyState, now: number): LikelyState {
  const card = s.card as CurrentCard;
  const seatOrder = s.players.map((p) => p.id);
  const ballotsAll: Ballot[] = s.players.filter((p) => s.votes[p.id] !== undefined).map((p) => ({ voterId: p.id, targetId: s.votes[p.id] as string }));
  const t = tally(ballotsAll, seatOrder);
  const deltas = isAnonymous(s) ? [] : scoreCard(ballotsAll, t, seatOrder);
  const scores = { ...s.scores };
  for (const d of deltas) scores[d.playerId] = (scores[d.playerId] ?? 0) + d.points;
  const result: CardResult = { index: s.cardIndex, cardId: card.cardId, packId: card.packId, namedPlayerId: card.namedPlayerId, tags: card.tags, ...t, ballotsAll, deltas };
  const players = card.namedPlayerId ? s.players.map((p) => (p.id === card.namedPlayerId ? { ...p, namedCount: p.namedCount + 1 } : p)) : s.players;
  return {
    ...s, phase: "REVEAL", players, scores, results: [...s.results, result], votes: {}, earlyEnd: false,
    lastNamedId: card.namedPlayerId ?? s.lastNamedId,
    deadline: now + revealMs(t.votesCast, t.unanimous, t.topIds.length),
  };
}

function toAwards(s: LikelyState, now: number): LikelyState {
  // Players still waiting for their first card never played this game: no award card (they watch the ceremony).
  const ids = s.players.filter((p) => !p.waiting).map((p) => p.id);
  const left = new Set(s.players.filter((p) => p.left).map((p) => p.id));
  const awards = computeAwards(ids, s.results, !isAnonymous(s), s.results.map((r) => r.deltas), s.scores, left);
  return { ...s, phase: "AWARDS", card: null, votes: {}, earlyEnd: false, awards, deadline: now + awardsMs(ids.length, !isAnonymous(s)) };
}

/** The phase's deadline passed, or the host pressed Next (HOST_ADVANCE expires the phase inline). */
function expire(s: LikelyState, content: LikelyCatalog, now: number): LikelyState {
  switch (s.phase) {
    case "CARD": return toVoting(s, now);
    case "VOTING": return toReveal(s, now);
    case "REVEAL": {
      const next = { ...s, cardIndex: s.cardIndex + 1, card: null };
      return next.cardIndex >= s.cardCount ? toAwards(next, now) : enterCard(next, content, now, []);
    }
    case "AWARDS": return { ...s, phase: "RESULTS", deadline: null };
    default: return s;
  }
}

/** SKIP_CARD, or the named player left: a new card, votes discarded, counter unchanged (§7). */
function voidCard(s: LikelyState, content: LikelyCatalog, now: number): LikelyState {
  const cur = s.card ? [s.card.cardId] : [];
  return enterCard({ ...s, card: null }, content, now, cur);
}

// ─── reduce ────────────────────────────────────────────────────────────────────────────────────────────────────────

export function reduce(s: LikelyState, a: GameAction<LikelyIntent>, ctx: GameCtx<LikelyCatalog>): GameReduceResult<LikelyState> {
  switch (a.type) {
    case "TICK": {
      if (s.phase === "HOLD") return ok(connectedCount(s) >= MIN_CONNECTED ? enterCard(s, ctx.content, ctx.now, []) : s);
      if (s.deadline === null || ctx.now < s.deadline) return ok(s);
      return ok(expire(s, ctx.content, ctx.now));
    }
    case "PLAYER_AWAY": {
      const p = s.players.find((x) => x.id === a.playerId);
      if (!p || !p.connected) return ok(s);
      const next = { ...s, players: s.players.map((x) => (x.id === a.playerId ? { ...x, connected: false } : x)) };
      return ok(maybeEarlyEnd(next, ctx.now));
    }
    case "PLAYER_BACK": {
      const p = s.players.find((x) => x.id === a.playerId);
      if (!p || p.connected || p.left) return ok(s);
      const next = { ...s, players: s.players.map((x) => (x.id === a.playerId ? { ...x, connected: true } : x)) };
      if (next.phase === "HOLD" && connectedCount(next) >= MIN_CONNECTED) return ok(enterCard(next, ctx.content, ctx.now, []));
      return ok(next);
    }
    case "PLAYER_GONE": {
      const p = s.players.find((x) => x.id === a.playerId);
      if (!p || p.left) return ok(s);
      let next: LikelyState = { ...s, players: s.players.map((x) => (x.id === a.playerId ? { ...x, left: true, connected: false } : x)) };
      if ((next.phase === "CARD" || next.phase === "VOTING") && next.card?.namedPlayerId === a.playerId) return ok(voidCard(next, ctx.content, ctx.now));
      if (next.phase === "VOTING") {
        // Their own vote stays; votes ON them are dropped (invariant 1: every target is non-left), those voters may re-vote.
        const votes = Object.fromEntries(Object.entries(next.votes).filter(([, t]) => t !== a.playerId));
        if (Object.keys(votes).length !== Object.keys(next.votes).length) next = { ...next, votes };
        next = maybeEarlyEnd(next, ctx.now);
      }
      return ok(next);
    }
    case "INTENT": return reduceIntent(s, a.intent, a.by, ctx);
  }
}

function reduceIntent(s: LikelyState, i: LikelyIntent, by: GameActor, ctx: GameCtx<LikelyCatalog>): GameReduceResult<LikelyState> {
  switch (i.a) {
    case "VOTE": {
      if (by.kind !== "player") return err("NOT_IN_GAME", s);
      const me = s.players.find((p) => p.id === by.playerId);
      if (!me || me.left) return err("NOT_IN_GAME", s);
      if (s.phase !== "VOTING" || me.waiting) return err("WRONG_PHASE", s);
      if (s.card?.cardId !== i.cardId) return err("STALE_CARD", s);
      if (!isTarget(s, i.targetId)) return err("INVALID_TARGET", s);
      if (s.votes[me.id] === i.targetId) return ok(s);
      return ok(maybeEarlyEnd({ ...s, votes: { ...s.votes, [me.id]: i.targetId } }, ctx.now));
    }
    case "SKIP_CARD": {
      if (!ctx.isHost(by)) return err("NOT_HOST", s);
      if (s.phase !== "CARD" && s.phase !== "VOTING") return err("WRONG_PHASE", s);
      if (s.card?.cardId !== i.cardId) return err("STALE_CARD", s);
      return ok(voidCard(s, ctx.content, ctx.now));
    }
    case "HOST_ADVANCE": {
      if (!ctx.isHost(by)) return err("NOT_HOST", s);
      if (s.phase === "VOTING") return ok(s); // ignored: nobody gets cut off by a remote press (§4.1)
      if (s.phase !== "CARD" && s.phase !== "REVEAL" && s.phase !== "AWARDS") return err("WRONG_PHASE", s);
      return ok(expire(s, ctx.content, ctx.now));
    }
    case "END_GAME": {
      if (!ctx.isHost(by)) return err("NOT_HOST", s);
      if (s.phase !== "HOLD") return err("WRONG_PHASE", s);
      return ok(toAwards(s, ctx.now));
    }
  }
}

// ─── join, wake, outcome, memory ───────────────────────────────────────────────────────────────────────────────────

/** Late joiner (§7): waits until the next CARD. JAMAA-GAP: `join` gets no `now`; when it completes a HOLD quorum,
 *  `nextWakeAt` returns 0 so the platform's next TICK deals the card. */
export function join(s: LikelyState, e: RosterEntry): GameReduceResult<LikelyState> {
  const existing = s.players.find((p) => p.id === e.id);
  if (existing) return existing.left ? err("NOT_IN_GAME", s) : ok(s);
  if (inGame(s).length >= MAX_PLAYERS) return err("GAME_FULL", s);
  const p: PlayerState = { id: e.id, seat: e.seat, connected: e.connected, left: false, waiting: true, late: true, firstCard: null, namedCount: 0 };
  const players = [...s.players, p].sort((x, y) => x.seat - y.seat);
  return ok({ ...s, players, scores: { ...s.scores, [e.id]: 0 } });
}

export function nextWakeAt(s: LikelyState): number | null {
  if (s.phase === "HOLD") return connectedCount(s) >= MIN_CONNECTED ? 0 : null;
  return s.deadline;
}

export function outcome(s: LikelyState): GameOutcome | null {
  if (s.phase !== "RESULTS") return null;
  const left = new Set(s.players.filter((p) => p.left).map((p) => p.id));
  const points = Object.fromEntries(s.players.map((p) => [p.id, isAnonymous(s) || p.left ? 0 : (s.scores[p.id] ?? 0)]));
  return { points, ranking: competitionRanking(points, s.players.map((p) => p.id), left) };
}

/** usedKeys at start + every card drawn this game (skips included, §7), oldest dropped beyond 300. */
export function memory(s: LikelyState): GameMemory {
  const drawn = new Set(s.drawnIds);
  const keys = [...s.usedKeys.filter((k) => !drawn.has(k)), ...s.drawnIds];
  return { usedKeys: keys.slice(-MEMORY_MAX_KEYS) };
}

// ─── invariants (GAME-LIKELY §13.3) ────────────────────────────────────────────────────────────────────────────────

export function assertInvariants(s: LikelyState): void {
  const fail = (m: string): never => { throw new InvariantError(`likely: ${m}`); };
  if (s.schema !== STATE_SCHEMA) fail("schema");
  if (!PHASES.includes(s.phase)) fail(`phase ${s.phase}`);
  const ids = new Set(s.players.map((p) => p.id));
  if (ids.size !== s.players.length) fail("duplicate player");
  for (let k = 1; k < s.players.length; k++) if ((s.players[k - 1] as PlayerState).seat >= (s.players[k] as PlayerState).seat) fail("seat order");
  // 1. one vote per voter, voters and targets non-left
  for (const [v, t] of Object.entries(s.votes)) {
    const pv = s.players.find((p) => p.id === v);
    // A voter who left after voting keeps the vote (§7 "Player leaves"), so "non-left" holds at the time of voting.
    if (!pv || pv.waiting) fail(`voter ${v}`);
    if (!isTarget(s, t)) fail(`target ${t}`);
  }
  if (s.phase !== "VOTING" && Object.keys(s.votes).length > 0) fail("votes outside VOTING");
  if ((s.phase === "CARD" || s.phase === "VOTING" || s.phase === "REVEAL") !== (s.card !== null)) fail("card presence");
  if ((s.phase === "HOLD" || s.phase === "RESULTS") !== (s.deadline === null)) fail("deadline presence");
  if (s.cardIndex > s.cardCount || s.results.length !== s.cardIndex + (s.phase === "REVEAL" ? 1 : 0)) fail("card counter");
  // 3. secret votes: no points, no deltas, no ballot-based awards
  if (isAnonymous(s)) {
    if (Object.values(s.scores).some((x) => x !== 0)) fail("anonymous score");
    if (s.results.some((r) => r.deltas.length > 0)) fail("anonymous delta");
    if (s.awards?.some((a) => a.kind === "selfAware" || a.kind === "mindReader")) fail("anonymous award");
  }
  for (const r of s.results) {
    // 4.
    if (r.chaos && r.topIds.length > 0) fail("chaos with top");
    if (r.unanimous && r.topIds.length !== 1) fail("unanimous top");
    // 7. counts agree with ballots (percent is derived from these at projection time)
    const t = tally(r.ballotsAll, s.players.map((p) => p.id));
    if (t.votesCast !== r.votesCast || JSON.stringify(t.counts) !== JSON.stringify(r.counts)) fail(`tally of card ${r.index}`);
    if (r.counts.reduce((m, c) => m + percentOf(c.count, r.votesCast), 0) > 100 + r.counts.length) fail("percent");
    // 5. per-card caps
    const per = new Map<string, number>();
    for (const d of r.deltas) {
      if (d.points <= 0) fail("non-positive delta");
      per.set(d.playerId, (per.get(d.playerId) ?? 0) + d.points);
    }
    for (const v of per.values()) if (v > 500) fail("per-card cap");
  }
  // 5. Σ deltas = Σ scores
  const sumD = s.results.reduce((m, r) => m + r.deltas.reduce((x, d) => x + d.points, 0), 0);
  const sumS = Object.values(s.scores).reduce((m, x) => m + x, 0);
  if (sumD !== sumS || Object.values(s.scores).some((x) => x < 0)) fail("score sum");
  // 6. family / named
  if (s.card) {
    if (s.settings.mode === "family" && (s.card.spicy || s.card.namedPlayerId !== null)) fail("spicy card in family mode");
    if (s.card.namedPlayerId !== null) {
      const np = s.players.find((p) => p.id === s.card!.namedPlayerId);
      if (!np || (np.left && s.phase !== "REVEAL")) fail("named player left"); // leaving in CARD/VOTING voids the card
      if (Object.values(s.votes).includes(s.card.namedPlayerId)) fail("vote on named player");
    }
  }
  const named = s.results.map((r) => r.namedPlayerId !== null);
  for (let k = 1; k < named.length; k++) if (named[k] && (named[k - 1] || named[k - 2])) fail("named spacing");
  for (const r of s.results) if (r.namedPlayerId !== null && r.ballotsAll.some((b) => b.targetId === r.namedPlayerId)) fail("ballot on named player");
  if (s.phase === "AWARDS" || s.phase === "RESULTS") {
    const sig = (s.awards ?? []).filter((a) => a.kind === "signature" || a.kind === "mystery");
    const awarded = sig.map((a) => a.playerIds[0]);
    const expected = s.players.filter((p) => awarded.includes(p.id) || !p.waiting).map((p) => p.id);
    if (sig.length !== expected.length || new Set(awarded).size !== awarded.length) fail("one signature award each");
  }
  if (s.phase === "RESULTS" || s.phase === "AWARDS") { if (s.awards === null) fail("awards missing"); } else if (s.awards !== null) fail("awards early");
}
