// shared/src/testing/bots/likely.ts draft: random but legal intents (sim + property tests).
import { isTarget, isVoter, type LikelyIntent, type LikelyState } from "./engine";
import type { GameActor, Rng } from "./platform";

export function botIntent(s: LikelyState, playerId: string, rng: Rng): LikelyIntent | null {
  const me = s.players.find((p) => p.id === playerId);
  if (!me || !isVoter(me) || !me.connected || s.phase !== "VOTING" || !s.card) return null;
  const targets = s.players.filter((p) => isTarget(s, p.id)).map((p) => p.id);
  if (targets.length === 0) return null;
  return { a: "VOTE", cardId: s.card.cardId, targetId: targets[rng.int(targets.length)] as string };
}

/** Host moves a bot may try (the TV actor). */
export function botHostIntent(s: LikelyState, rng: Rng): { intent: LikelyIntent; by: GameActor } | null {
  const by: GameActor = { kind: "tv" };
  const r = rng.next();
  if ((s.phase === "CARD" || s.phase === "VOTING") && s.card && r < 0.1) return { intent: { a: "SKIP_CARD", cardId: s.card.cardId }, by };
  if (s.phase === "HOLD" && r < 0.5) return { intent: { a: "END_GAME" }, by };
  if ((s.phase === "CARD" || s.phase === "REVEAL" || s.phase === "AWARDS") && r < 0.3) return { intent: { a: "HOST_ADVANCE" }, by };
  return null;
}
