// GAME-LIKELY §9 settings and the §9.1 Spicy 18+ gate.
import { LENGTHS, type LengthId } from "./constants";
import type { LikelyCatalog, LikelyPack } from "./content";
import type { GameActor, Locale } from "./platform";

export type LikelyMode = "family" | "spicy";
export interface LikelySettings { packIds: string[]; length: LengthId; showVoters: boolean; mode: LikelyMode }
/** The patch may carry `ageConfirmed` (never stored): required to move `mode` to "spicy" (§9.1 rule 2). */
export type LikelySettingsPatch = Partial<LikelySettings> & { ageConfirmed?: boolean };

export const DEFAULT_SETTINGS: LikelySettings = Object.freeze({ packIds: [], length: "normal", showVoters: true, mode: "family" }) as LikelySettings;

const PACK_ID = /^[a-z0-9-]{1,35}$/;

/** Packs a room may draw from for this mode and content language. Family: never an adult pack (§9.1 rule 5). */
export function packsForMode(content: LikelyCatalog, mode: LikelyMode, locale: Locale): LikelyPack[] {
  return content.packs.filter((p) => p.locales.includes(locale) && (mode === "spicy" || p.ageRating !== "adult"));
}
export function spicyAvailable(content: LikelyCatalog, locale: Locale): boolean {
  return content.packs.some((p) => p.ageRating === "adult" && p.locales.includes(locale) && p.cards.some((c) => c.spice > 0));
}

/** Any stored value → valid settings, per-key fallback to defaults. Old schema-1 values (no `mode`) come back as family. */
export function normalize(raw: unknown): LikelySettings {
  const r = typeof raw === "object" && raw !== null && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const packIds = Array.isArray(r.packIds) && r.packIds.length <= 50 && r.packIds.every((x) => typeof x === "string" && PACK_ID.test(x))
    ? [...new Set(r.packIds as string[])] : [];
  const length = typeof r.length === "string" && r.length in LENGTHS ? (r.length as LengthId) : DEFAULT_SETTINGS.length;
  const showVoters = typeof r.showVoters === "boolean" ? r.showVoters : DEFAULT_SETTINGS.showVoters;
  const mode: LikelyMode = r.mode === "spicy" ? "spicy" : "family";
  return { packIds, length, showVoters, mode };
}

export interface ApplyOptions { spicyEnabled: boolean }

/**
 * JAMAA-GAP (platform §2.2): `settings.apply` has no actor. This draft takes it as a 5th argument; until the platform
 * passes it, `by` is undefined and a move to "spicy" is always refused (fail closed). null = INVALID_SETTINGS.
 */
export function apply(s: LikelySettings, patch: LikelySettingsPatch, content: LikelyCatalog, locale: Locale, by: GameActor | undefined, opt: ApplyOptions): LikelySettings | null {
  for (const k of Object.keys(patch)) if (!["packIds", "length", "showVoters", "mode", "ageConfirmed"].includes(k)) return null;
  let mode = s.mode;
  let showVoters = s.showVoters;
  if (patch.mode !== undefined) {
    if (patch.mode !== "family" && patch.mode !== "spicy") return null;
    if (patch.mode === "spicy" && s.mode !== "spicy") {
      // §9.1 rule 1–2: TV only, explicit 18+ confirmation, asked every time; and only where a Spicy card is playable.
      if (!opt.spicyEnabled || by?.kind !== "tv" || patch.ageConfirmed !== true || !spicyAvailable(content, locale)) return null;
      showVoters = false; // §9.1 rule 4: secret votes suggested in the same patch (the host may switch it back later)
    }
    mode = patch.mode;
  }
  if (patch.showVoters !== undefined) {
    if (typeof patch.showVoters !== "boolean") return null;
    // The transition patch forces secret votes; a later patch may turn them back on.
    if (!(patch.mode === "spicy" && s.mode !== "spicy")) showVoters = patch.showVoters;
  }
  let length = s.length;
  if (patch.length !== undefined) {
    if (!(patch.length in LENGTHS)) return null;
    length = patch.length;
  }
  const allowed = new Set(packsForMode(content, mode, locale).map((p) => p.id));
  let packIds = s.packIds;
  if (patch.packIds !== undefined) {
    if (!Array.isArray(patch.packIds) || patch.packIds.length > 50) return null;
    if (!patch.packIds.every((id) => typeof id === "string" && allowed.has(id))) return null;
    packIds = [...new Set(patch.packIds)];
  } else if (mode !== s.mode) {
    packIds = packIds.filter((id) => allowed.has(id)); // leaving Spicy drops the adult pack from the selection
  }
  const next: LikelySettings = { packIds, length, showVoters, mode };
  return sameSettings(s, next) ? s : next;
}

function sameSettings(a: LikelySettings, b: LikelySettings): boolean {
  return a.length === b.length && a.showVoters === b.showVoters && a.mode === b.mode && a.packIds.length === b.packIds.length && a.packIds.every((x, i) => x === b.packIds[i]);
}

/** Access restriction: drop locked packs; Spicy falls back to family where no Spicy card is playable. Same object if unchanged. */
export function restrict(s: LikelySettings, a: { playableIds: ReadonlySet<string>; premium: boolean }, content: LikelyCatalog, locale: Locale): LikelySettings {
  const mode: LikelyMode = s.mode === "spicy" && !spicyAvailable(content, locale) ? "family" : s.mode;
  const allowed = new Set(packsForMode(content, mode, locale).map((p) => p.id));
  const packIds = s.packIds.filter((id) => a.playableIds.has(id) && allowed.has(id));
  const next = { ...s, mode, packIds };
  return sameSettings(s, next) ? s : next;
}

export function packIdsOf(s: LikelySettings): readonly string[] { return s.packIds; }
