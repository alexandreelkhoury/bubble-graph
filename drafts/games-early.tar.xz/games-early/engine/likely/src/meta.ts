// games/likely/meta.ts draft (zod-free, engine-free). Replaces the P stub: adds `mode` (SETTINGS_SCHEMA 2), rule sections.
import { SETTINGS_SCHEMA, VIEW_VERSION } from "./constants";
import { DEFAULT_SETTINGS, type LikelySettings } from "./settings";

const K = "game.likely";
const ALL = ["CARD", "VOTING", "REVEAL", "HOLD", "AWARDS", "RESULTS"] as const;

export const LIKELY_META = {
  id: "likely" as const,
  minPlayers: 3,
  maxPlayers: 12,
  phases: ALL,
  rules: {
    titleKey: `${K}.title`,
    taglineKey: `${K}.tagline`,
    howToKeys: [`${K}.howto.1`, `${K}.howto.2`, `${K}.howto.3`, `${K}.howto.4`],
    // GAME-LIKELY §10.2; the client picks `.anon` how-to variants when showVoters is false.
    ruleSections: [
      { id: "vote", titleKey: `${K}.rules.vote.title`, bodyKey: `${K}.rules.vote.body`, phases: ["CARD", "VOTING"] },
      { id: "points", titleKey: `${K}.rules.points.title`, bodyKey: `${K}.rules.points.body`, phases: ["REVEAL"] },
      { id: "chaos", titleKey: `${K}.rules.chaos.title`, bodyKey: `${K}.rules.chaos.body`, phases: ["REVEAL"] },
      { id: "awards", titleKey: `${K}.rules.awards.title`, bodyKey: `${K}.rules.awards.body`, phases: ["AWARDS", "RESULTS"] },
      { id: "secret", titleKey: `${K}.rules.secret.title`, bodyKey: `${K}.rules.secret.body`, phases: ["REVEAL"] },
      { id: "spicy", titleKey: `${K}.rules.spicy.title`, bodyKey: `${K}.rules.spicy.body`, phases: ["CARD", "VOTING"] },
    ],
    durationMinutes: [6, 10] as const,
    world: "rooftop" as const,
    pauseItems: [
      { id: "skipCard", labelKey: `${K}.pause.skipCard`, intent: "SKIP_CARD", phases: ["CARD", "VOTING"] },
      { id: "next", labelKey: `${K}.pause.next`, intent: "HOST_ADVANCE", phases: ["CARD", "REVEAL", "AWARDS"] },
      { id: "endGame", labelKey: `${K}.pause.endGame`, intent: "END_GAME", phases: ["HOLD"], confirm: true },
    ],
  },
  carriesScore: false,
  VIEW_VERSION,
  SETTINGS_SCHEMA,
  settings: {
    defaults: DEFAULT_SETTINGS as LikelySettings,
    basic: [
      { key: "packIds", kind: "packs", labelKey: `${K}.settings.packs`, single: false },
      { key: "length", kind: "choice", labelKey: `${K}.settings.length`, options: [
        { value: "short", labelKey: `${K}.settings.length.short` }, { value: "normal", labelKey: `${K}.settings.length.normal` }, { value: "long", labelKey: `${K}.settings.length.long` },
      ] },
      { key: "showVoters", kind: "toggle", labelKey: `${K}.settings.showVoters` },
      { key: "mode", kind: "choice", labelKey: `${K}.setup.mode`, options: [
        { value: "family", labelKey: `${K}.setup.mode.family` }, { value: "spicy", labelKey: `${K}.setup.mode.spicy` },
      ] },
    ],
    advanced: [],
    premiumKeys: [] as (keyof LikelySettings)[],
  },
};
