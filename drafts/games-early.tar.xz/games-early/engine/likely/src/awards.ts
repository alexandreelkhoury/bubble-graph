// GAME-LIKELY §6.2 awards. Signature, Mystery and Tonight's Star read per-card TALLIES only (safe in secret-vote mode);
// Self-aware and Mind Reader read ballots/points and exist only in public mode.
import { SELF_AWARE_AWARD_MIN, STAR_MIN_TOPS } from "./constants";
import type { Delta } from "./result";

export type AwardKind = "signature" | "mystery" | "star" | "selfAware" | "mindReader";
export interface AwardEntry {
  kind: AwardKind;
  playerIds: string[];          // seat order; one id for signature/mystery, ties share star/selfAware/mindReader
  cardIndex: number | null;     // signature only: the card it comes from
}
export interface CardTallyForAwards { index: number; votesCast: number; topIds: string[]; counts: { playerId: string; count: number }[] }

/** Every player (left ones included, greyed by the client) gets exactly one signature or mystery entry, in seat order. */
export function computeAwards(playerIds: readonly string[], results: readonly CardTallyForAwards[], publicMode: boolean, deltas: readonly (readonly Delta[])[], scores: Readonly<Record<string, number>>, left: ReadonlySet<string> = new Set()): AwardEntry[] {
  const out: AwardEntry[] = [];
  const tops = new Map<string, number>();
  for (const id of playerIds) {
    let best: { count: number; votesCast: number; index: number } | null = null;
    for (const r of results) {
      if (!r.topIds.includes(id)) continue;
      tops.set(id, (tops.get(id) ?? 0) + 1);
      const count = r.counts.find((x) => x.playerId === id)?.count ?? 0;
      // vote share count/votesCast compared exactly (cross-multiplied); tie → the later card
      const cmp = best === null ? 1 : count * best.votesCast - best.count * r.votesCast;
      if (best === null || cmp > 0 || (cmp === 0 && r.index > best.index)) best = { count, votesCast: r.votesCast, index: r.index };
    }
    out.push(best ? { kind: "signature", playerIds: [id], cardIndex: best.index } : { kind: "mystery", playerIds: [id], cardIndex: null });
  }
  // Extra awards go to players still in the game (a left player keeps only their greyed signature card).
  const active = playerIds.filter((id) => !left.has(id));
  const maxTops = Math.max(0, ...active.map((id) => tops.get(id) ?? 0));
  if (maxTops >= STAR_MIN_TOPS) out.push({ kind: "star", playerIds: active.filter((id) => tops.get(id) === maxTops), cardIndex: null });
  if (publicMode) {
    const self = new Map<string, number>();
    for (const card of deltas) for (const d of card) if (d.reason === "selfAware") self.set(d.playerId, (self.get(d.playerId) ?? 0) + 1);
    const maxSelf = Math.max(0, ...active.map((id) => self.get(id) ?? 0));
    if (maxSelf >= SELF_AWARE_AWARD_MIN) out.push({ kind: "selfAware", playerIds: active.filter((id) => self.get(id) === maxSelf), cardIndex: null });
    const maxPts = Math.max(0, ...active.map((id) => scores[id] ?? 0));
    if (maxPts > 0) out.push({ kind: "mindReader", playerIds: active.filter((id) => (scores[id] ?? 0) === maxPts), cardIndex: null });
  }
  return out;
}
