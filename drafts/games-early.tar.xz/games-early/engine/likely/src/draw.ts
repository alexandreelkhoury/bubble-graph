// GAME-LIKELY §11.3 card draw and §7 "Who gets named". Pure; randomness through the Rng passed in.
import { NAMED_MIN_PLAYERS, OPENER_TAGS } from "./constants";
import type { LikelyCard, LikelyCatalog, LikelyPack } from "./content";
import type { Locale, Rng } from "./platform";
import { packsForMode, type LikelySettings } from "./settings";

export interface Candidate { pack: LikelyPack; card: LikelyCard }
export interface Drawn { cardId: string; packId: string; spicy: boolean; namesPlayer: boolean; rerun: boolean; tags: string[] }

export interface DrawInput {
  content: LikelyCatalog;
  settings: LikelySettings;
  locale: Locale;
  position: number;                     // 0-based index of the card being drawn (skips do not advance it)
  drawnIds: readonly string[];          // every card drawn this game, skipped ones included
  usedKeys: readonly string[];          // platform memory at start, oldest first
  prevTags: readonly string[] | null;   // tags of the previous completed card
  namedHistory: readonly boolean[];     // per completed card: did it name a player?
  playersInGame: number;                // non-left players
  namedCandidates: number;              // how many players could be named right now
  excludeIds: readonly string[];        // the card being replaced (skip / void)
}

/** Every card the room could ever draw for these settings (mode, packs, language), ignoring history. */
export function eligibleCards(content: LikelyCatalog, s: LikelySettings, locale: Locale): Candidate[] {
  const packs = packsForMode(content, s.mode, locale).filter((p) => s.packIds.length === 0 || s.packIds.includes(p.id));
  const out: Candidate[] = [];
  for (const pack of packs) for (const card of pack.cards) {
    if (card.prompt[locale] === undefined || card.award[locale] === undefined) continue;
    if (s.mode === "family" && (card.spice !== 0 || card.namesPlayer)) continue; // §9.1 rule 5, whatever the packs say
    out.push({ pack, card });
  }
  return out;
}

/** Named cards: Spicy only, ≥ 4 players, never two in a row, ≤ 1 in any 3 consecutive cards, never the opener. */
export function namedAllowed(i: Pick<DrawInput, "settings" | "position" | "namedHistory" | "playersInGame" | "namedCandidates">): boolean {
  if (i.settings.mode !== "spicy" || i.position === 0 || i.playersInGame < NAMED_MIN_PLAYERS || i.namedCandidates < 1) return false;
  const h = i.namedHistory;
  return !h[h.length - 1] && !h[h.length - 2];
}

/** In Spicy mode, positions 3, 6, 9… (1-based) are Family breathers; the rest are Spicy (§11.3). */
export function wantsSpicy(s: LikelySettings, position: number): boolean | null {
  if (s.mode !== "spicy") return null;
  return (position + 1) % 3 !== 0;
}

function softFilter(list: Candidate[], i: DrawInput): Candidate[] {
  let cur = list;
  const keep = (f: (c: Candidate) => boolean): void => { const n = cur.filter(f); if (n.length > 0) cur = n; };
  const spicy = wantsSpicy(i.settings, i.position);
  if (spicy !== null) keep((c) => (c.card.spice > 0) === spicy);
  if (i.position === 0 && i.settings.mode === "family") keep((c) => c.card.tags.some((t) => OPENER_TAGS.includes(t)));
  if (i.prevTags) keep((c) => !c.card.tags.some((t) => i.prevTags!.includes(t)));
  return cur;
}

export function drawCard(i: DrawInput, rng: Rng): Drawn | null {
  const allowNamed = namedAllowed(i);
  const base = eligibleCards(i.content, i.settings, i.locale).filter((c) => !c.card.namesPlayer || allowNamed);
  const drawn = new Set(i.drawnIds);
  const exclude = new Set(i.excludeIds);
  // Hard: not drawn this game. Fallbacks (only after unlimited skips empty the pool): allow drawn cards, then the excluded one.
  let hard = base.filter((c) => !drawn.has(c.card.id) && !exclude.has(c.card.id));
  if (hard.length === 0) hard = base.filter((c) => !exclude.has(c.card.id));
  if (hard.length === 0) hard = base;
  if (hard.length === 0) return null;
  const used = new Map(i.usedKeys.map((k, idx) => [k, idx]));
  const fresh = hard.filter((c) => !used.has(c.card.id));
  let pick: Candidate;
  let rerun = false;
  if (fresh.length > 0) {
    const list = softFilter(fresh, i);
    pick = list[rng.int(list.length)] as Candidate;
  } else {
    // Least recently used first, tagged "Rerun!" (§7 Pool exhausted). Deterministic: the oldest key in memory.
    const list = softFilter(hard, i);
    pick = list.reduce((a, b) => ((used.get(a.card.id) ?? -1) <= (used.get(b.card.id) ?? -1) ? a : b));
    rerun = drawn.has(pick.card.id) || used.has(pick.card.id);
  }
  return { cardId: pick.card.id, packId: pick.pack.id, spicy: pick.card.spice > 0, namesPlayer: pick.card.namesPlayer, rerun, tags: [...pick.card.tags] };
}

/** §7: among connected non-left players named the fewest times, never the last named player; RNG picks. */
export function namedPool(players: readonly { id: string; connected: boolean; left: boolean; waiting: boolean; namedCount: number }[], lastNamed: string | null): string[] {
  const ok = players.filter((p) => p.connected && !p.left && !p.waiting && p.id !== lastNamed);
  const min = Math.min(...ok.map((p) => p.namedCount));
  return ok.filter((p) => p.namedCount === min).map((p) => p.id);
}
