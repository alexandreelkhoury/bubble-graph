import { describe, expect, it } from "vitest";
import { FORBIDDEN_KEYS } from "../src";
import { CATALOG, DEF, T0, playCard, startGame, tick, vote } from "./helpers";

const pub = (s: Parameters<typeof DEF.projectPublic>[0]) => DEF.projectPublic(s, CATALOG);

describe("projections and secrecy (§8.1, §13.2)", () => {
  it("CARD: card text in the content language, counter, no reveal", () => {
    const s = startGame(4, {}, { locale: "fr" });
    const v = pub(s);
    expect(v).toMatchObject({ phase: "CARD", cardIndex: 0, cardCount: 8, reveal: null, votedIds: [], awards: null, showVoters: true, mode: "family" });
    expect(v.card!.prompt.startsWith("de fr-")).toBe(true);
    expect(v.card!.award.startsWith("de fr-a")).toBe(true);
    expect(v.card!.namedPlayerId).toBeNull();
  });
  it("VOTING: only who voted; own vote only in own me; status lists done/awaited", () => {
    let s = tick(startGame(4));
    s = vote(s, "p3", "p1", T0 + 7_000);
    const v = pub(s);
    expect(v.votedIds).toEqual(["p3"]);
    expect(JSON.stringify(v)).not.toContain("targetId");
    expect(DEF.projectMe(s, "p3")).toEqual({ myVote: "p1", waitingForNext: false });
    expect(DEF.projectMe(s, "p2")).toEqual({ myVote: null, waitingForNext: false });
    expect(DEF.projectMe(s, "nobody")).toBeNull();
    expect(DEF.projectStatus(s)).toEqual({ phase: "VOTING", doneIds: ["p3"], awaitedIds: ["p1", "p2", "p4"] });
    expect(DEF.leakCheck(s, null, v)).toEqual([]);
    expect(DEF.leakCheck(s, "p3", { pub: v, me: DEF.projectMe(s, "p3") })).toEqual([]);
  });
  it("public REVEAL: ballots, deltas, scores with scoreBefore, percent", () => {
    const s = playCard(startGame(4), { p1: "p2", p2: "p2", p3: "p2", p4: "p1" });
    const v = pub(s);
    expect(v.reveal).toMatchObject({
      votesCast: 4, topIds: ["p2"], chaos: false, unanimous: false, none: false,
      counts: [{ playerId: "p2", count: 3, percent: 75 }, { playerId: "p1", count: 1, percent: 25 }],
    });
    expect(v.reveal!.ballots).toEqual([{ voterId: "p1", targetId: "p2" }, { voterId: "p2", targetId: "p2" }, { voterId: "p3", targetId: "p2" }, { voterId: "p4", targetId: "p1" }]);
    expect(v.scores.find((x) => x.playerId === "p2")).toEqual({ playerId: "p2", score: 200, scoreBefore: 0 });
    expect(v.reveal!.deltas).toContainEqual({ playerId: "p2", points: 100, reason: "selfAware" });
    expect(DEF.leakCheck(s, null, v)).toEqual([]);
  });
  it("secret-vote REVEAL: percentages only, no ballots, no deltas, scores pinned at 0; own vote only on own phone", () => {
    const s = playCard(startGame(4, { showVoters: false }), { p1: "p2", p2: "p2", p3: "p2", p4: "p2" });
    const v = pub(s);
    expect(v.reveal).toMatchObject({ ballots: null, deltas: [], unanimous: true, counts: [{ playerId: "p2", count: 4, percent: 100 }] });
    expect(v.scores.every((x) => x.score === 0 && x.scoreBefore === 0)).toBe(true);
    expect(s.scores).toEqual({ p1: 0, p2: 0, p3: 0, p4: 0 });
    expect(DEF.projectMe(s, "p1")!.myVote).toBe("p2");
    expect(DEF.leakCheck(s, "p1", { pub: v, me: DEF.projectMe(s, "p1") })).toEqual([]);
  });
  it("nobody voted / chaos / AGAIN streak", () => {
    let s = playCard(startGame(3), {});
    expect(pub(s).reveal).toMatchObject({ none: true, votesCast: 0, topIds: [] });
    s = playCard(tick(s), { p1: "p2", p2: "p3", p3: "p1" });
    expect(pub(s).reveal).toMatchObject({ chaos: true, topIds: [] });
    let g = startGame(3);
    for (let i = 0; i < 3; i++) g = playCard(i === 0 ? g : tick(g), { p1: "p3", p2: "p3" });
    expect(pub(g).reveal!.againId).toBe("p3");
  });
  it("AWARDS: one signature/mystery card per player with the card text; no ballot data", () => {
    let s = startGame(3, { showVoters: false });
    for (let i = 0; i < 8; i++) s = tick(playCard(s, { p1: "p1", p2: "p1", p3: "p2" }));
    const v = pub(s);
    expect(v.phase).toBe("AWARDS");
    expect(v.awards!.slice(0, 3).map((a) => a.kind)).toEqual(["signature", "mystery", "mystery"]);
    expect(v.awards![0]!.card).toMatchObject({ index: 7 });
    expect(v.awards![0]!.card!.prompt.startsWith("en-")).toBe(true);
    expect(v.awards!.find((a) => a.kind === "star")).toEqual({ kind: "star", playerIds: ["p1"], card: null });
    expect(DEF.leakCheck(s, null, v)).toEqual([]);
  });
  it("no state-only key ever appears in a view", () => {
    let s = startGame(5);
    for (let i = 0; i < 8; i++) {
      s = playCard(s, { p1: "p2", p3: "p2" });
      for (const view of [pub(s), DEF.projectMe(s, "p1")]) for (const k of FORBIDDEN_KEYS) expect(JSON.stringify(view)).not.toContain(`"${k}"`);
      s = tick(s);
    }
  });
  it("leakCheck catches planted leaks", () => {
    const anon = playCard(startGame(3, { showVoters: false }), { p1: "p2", p2: "p2" });
    const v = pub(anon);
    expect(DEF.leakCheck(anon, null, { ...v, reveal: { ...v.reveal!, ballots: [{ voterId: "p1", targetId: "p2" }] } }).length).toBeGreaterThan(0);
    expect(DEF.leakCheck(anon, null, { ...v, scores: [{ playerId: "p1", score: 50, scoreBefore: 0 }] }).length).toBeGreaterThan(0);
    expect(DEF.leakCheck(anon, null, { ...v, votes: {} }).length).toBeGreaterThan(0);
    expect(DEF.leakCheck(anon, "p3", { pub: v, me: { myVote: "p2", waitingForNext: false } }).length).toBeGreaterThan(0); // not p3's vote
    const voting = tick(startGame(3));
    expect(DEF.leakCheck(voting, null, { ...pub(voting), reveal: {} }).length).toBeGreaterThan(0);
    expect(DEF.secretsFor(voting, null)).toEqual([]);
  });
  it("spicy card: raw {player} template plus namedPlayerId; spicy flag", () => {
    let s = startGame(6, { mode: "spicy", showVoters: false }, { seed: 11 });
    let guard = 0;
    while (!(s.phase === "CARD" && s.card?.namedPlayerId)) { s = s.phase === "CARD" ? playCard(s, {}) : tick(s); if (++guard > 100) throw new Error("no named card"); }
    const v = pub(s);
    expect(v.mode).toBe("spicy");
    expect(v.card!.spicy).toBe(true);
    expect(v.card!.prompt).toContain("{player}");
    expect(v.card!.namedPlayerId).toBe(s.card!.namedPlayerId);
  });
});
