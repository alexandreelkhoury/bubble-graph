import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { drawCard, namedAllowed, namedPool, type DrawInput } from "../src";
import { createRng } from "../src/platform";
import { CATALOG, DEF, familyPack, playCard, roster, settings, startGame } from "./helpers";

const base = (p: Partial<DrawInput> = {}): DrawInput => ({
  content: CATALOG, settings: settings(), locale: "en", position: 1, drawnIds: [], usedKeys: [], prevTags: null,
  namedHistory: [], playersInGame: 6, namedCandidates: 5, excludeIds: [], ...p,
});
const card = (id: string) => CATALOG.packs.flatMap((p) => p.cards).find((c) => c.id === id)!;

describe("draw (§11.3)", () => {
  it("family mode never serves spice > 0 or a named card (10 000 draws, any packs)", () => {
    fc.assert(fc.property(fc.integer({ min: 0, max: 2 ** 32 - 1 }), fc.integer({ min: 0, max: 15 }), fc.constantFrom<string[]>([], ["syn-spicy"], ["syn-family", "syn-spicy"]), (seed, position, packIds) => {
      const d = drawCard(base({ position, settings: settings({ packIds }) }), createRng(seed));
      if (packIds.length === 1) return d === null; // only the adult pack selected: nothing playable in family
      return d !== null && card(d.cardId).spice === 0 && !d.namesPlayer;
    }), { numRuns: 10_000 });
  });
  it("first card of a family game is an opener (party or habits)", () => {
    for (let seed = 0; seed < 200; seed++) {
      const d = drawCard(base({ position: 0 }), createRng(seed))!;
      expect(d.tags.some((t) => t === "party" || t === "habits")).toBe(true);
    }
  });
  it("avoids the previous card's tag when it can", () => {
    for (let seed = 0; seed < 200; seed++) expect(drawCard(base({ prevTags: ["food"] }), createRng(seed))!.tags).not.toContain("food");
  });
  it("prefers cards not in memory.usedKeys, then the least recently used with a Rerun tag", () => {
    const fam = CATALOG.packs[0]!.cards.map((c) => c.id);
    const used = fam.slice(0, 39);
    for (let seed = 0; seed < 50; seed++) expect(drawCard(base({ usedKeys: used }), createRng(seed))).toMatchObject({ cardId: fam[39], rerun: false });
    const d = drawCard(base({ usedKeys: [...fam].reverse(), prevTags: null }), createRng(1))!;
    expect(d).toMatchObject({ cardId: fam[39], rerun: true }); // fam[39] is the oldest key in this memory
  });
  it("never redraws a card drawn this game while others remain", () => {
    const fam = CATALOG.packs[0]!.cards.map((c) => c.id);
    expect(drawCard(base({ drawnIds: fam.slice(1) }), createRng(3))!.cardId).toBe(fam[0]);
  });
  it("spicy mode: unnamed spicy opener, family breather at positions 3, 6, 9", () => {
    const sp = settings({ mode: "spicy" });
    for (let seed = 0; seed < 100; seed++) {
      const first = drawCard(base({ settings: sp, position: 0 }), createRng(seed))!;
      expect(first.spicy && !first.namesPlayer).toBe(true);
      expect(drawCard(base({ settings: sp, position: 2 }), createRng(seed))!.spicy).toBe(false);
      expect(drawCard(base({ settings: sp, position: 4 }), createRng(seed))!.spicy).toBe(true);
    }
  });
  it("named cards: ≥ 4 players, never two in a row, ≤ 1 in any 3", () => {
    const sp = settings({ mode: "spicy" });
    const ok = (p: Partial<DrawInput>) => namedAllowed({ ...base({ settings: sp }), ...p });
    expect(ok({})).toBe(true);
    expect(ok({ playersInGame: 3 })).toBe(false);
    expect(ok({ position: 0 })).toBe(false);
    expect(ok({ namedHistory: [false, true] })).toBe(false);
    expect(ok({ namedHistory: [true, false] })).toBe(false);
    expect(ok({ namedHistory: [true, false, false] })).toBe(true);
    expect(ok({ namedCandidates: 0 })).toBe(false);
    expect(namedAllowed({ ...base(), namedHistory: [] })).toBe(false); // family
  });
  it("named pool: fewest-named connected players, never the last named", () => {
    const P = (id: string, namedCount: number, connected = true) => ({ id, connected, left: false, waiting: false, namedCount });
    expect(namedPool([P("a", 1), P("b", 0), P("c", 0), P("d", 0, false)], "c")).toEqual(["b"]);
  });
  it("named fairness over a seeded spicy game: named counts differ by at most 1 among players always connected", () => {
    let s = startGame(6, { mode: "spicy", length: "long", showVoters: false }, { seed: 7 });
    while (s.phase !== "AWARDS") {
      if (s.phase === "CARD") s = playCard(s, {});
      else s = DEF.reduce(s, { type: "TICK" }, { now: s.deadline!, content: CATALOG, hostPlayerId: null, isHost: () => true }).state;
    }
    const counts = s.players.map((p) => p.namedCount);
    expect(Math.max(...counts) - Math.min(...counts)).toBeLessThanOrEqual(1);
    expect(s.results.filter((r) => r.namedPlayerId).length).toBeGreaterThan(0);
  });
  it("startBlocker: < 3 connected; fewer playable cards than the length", () => {
    expect(DEF.startBlocker(roster(2), settings(), CATALOG, "en")).toBe("NOT_ENOUGH_PLAYERS");
    const r = roster(3); r[0]!.connected = false;
    expect(DEF.startBlocker(r, settings(), CATALOG, "en")).toBe("NOT_ENOUGH_PLAYERS");
    const small = { packs: [{ ...familyPack(), cards: familyPack().cards.slice(0, 10) }] };
    expect(DEF.startBlocker(roster(3), settings({ length: "normal" }), small, "en")).toBe("NO_CONTENT_AVAILABLE");
    expect(DEF.startBlocker(roster(3), settings({ length: "short" }), small, "en")).toBeNull();
    const noEs = { packs: [familyPack(40, { es: false })] };
    expect(DEF.startBlocker(roster(3), settings(), noEs, "es")).toBe("NO_CONTENT_AVAILABLE");
  });
});
