import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { content, eligibleCards, parsePack } from "../src";
import { familyPack, settings, spicyPack } from "./helpers";

// The content drafts written next to this engine (games-early/content/likely), parsed with the engine's schema.
const DRAFTS = join(import.meta.dirname, "../../../content/likely");

describe("content schema and adapter (§11.2, platform §5.2)", () => {
  it("accepts the synthetic packs and rejects broken ones", () => {
    expect(parsePack(JSON.parse(JSON.stringify(familyPack())))).toEqual(familyPack());
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const bad = (mut: (p: any) => void) => { const p = JSON.parse(JSON.stringify(familyPack())); mut(p); return () => parsePack(p); };
    expect(bad((p) => { p.cards[0].spice = 1; })).toThrow(/all/);
    expect(bad((p) => { p.cards[1].id = p.cards[0].id; })).toThrow(/duplicate/);
    expect(bad((p) => { p.cards[0].prompt.en = "x".repeat(61); })).toThrow(/longer/);
    expect(bad((p) => { delete p.cards[0].prompt.es; })).toThrow(/pack lists es/);
    expect(bad((p) => { p.cards.length = 29; })).toThrow(/30/);
    const sp = JSON.parse(JSON.stringify(spicyPack()));
    sp.cards[0].prompt.fr = "de rien";
    expect(() => parsePack(sp)).toThrow(/\{player\}/);
  });
  it("playable: free rooms get free cards only and never the adult pack", () => {
    const fam = familyPack(40);
    const free = content.playable(fam, { premium: false, ownedFamilies: new Set() })!;
    expect(free.cards.every((c) => c.tier === "free")).toBe(true);
    expect(free.cards).toHaveLength(20);
    expect(content.playable(spicyPack(), { premium: false, ownedFamilies: new Set() })).toBeNull();
    expect(content.playable(fam, { premium: true, ownedFamilies: new Set() })).toBe(fam);
    expect(content.meta(fam)).toMatchObject({ tier: "mixed", itemCount: 40, freeItemCount: 20, languages: ["en", "fr", "ar", "es"] });
  });
  it.skipIf(!existsSync(DRAFTS))("the drafted packs parse and are playable in all 4 languages", () => {
    const packs = ["likely-family.json", "likely-spicy.json"].map((f) => parsePack(JSON.parse(readFileSync(join(DRAFTS, f), "utf8"))));
    for (const loc of ["en", "fr", "ar", "es"] as const) {
      expect(eligibleCards({ packs }, settings({ mode: "family" }), loc).length).toBeGreaterThanOrEqual(16);
      expect(eligibleCards({ packs }, settings({ mode: "spicy" }), loc).length).toBeGreaterThanOrEqual(16);
    }
    const freeFamily = content.playable(packs[0]!, { premium: false, ownedFamilies: new Set() })!;
    expect(freeFamily.cards.length).toBeGreaterThanOrEqual(32); // Long twice without reruns (§11.2)
  });
});
