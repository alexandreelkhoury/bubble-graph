import { describe, expect, it } from "vitest";
import { percentOf, scoreCard, tally, withPercent, type Ballot } from "../src";
import { ids } from "./helpers";

const B = (pairs: [string, string][]): Ballot[] => pairs.map(([voterId, targetId]) => ({ voterId, targetId }));
const sumBy = (d: ReturnType<typeof scoreCard>, id: string) => d.filter((x) => x.playerId === id).reduce((m, x) => m + x.points, 0);

describe("result of a card (§5.1)", () => {
  it("chaos: n = 3..12 everyone picks someone different", () => {
    for (let n = 3; n <= 12; n++) {
      const p = ids(n);
      const t = tally(B(p.map((v, i) => [v, p[(i + 1) % n]!])), p);
      expect(t).toMatchObject({ votesCast: n, chaos: true, unanimous: false, topIds: [] });
    }
  });
  it("unanimous: n = 3..12 all on one target", () => {
    for (let n = 3; n <= 12; n++) {
      const p = ids(n);
      const t = tally(B(p.map((v) => [v, "p2"])), p);
      expect(t).toMatchObject({ votesCast: n, chaos: false, unanimous: true, topIds: ["p2"] });
    }
  });
  it("ties share the top, in seat order", () => {
    const p = ids(6);
    const t = tally(B([["p1", "p4"], ["p2", "p4"], ["p3", "p2"], ["p4", "p2"], ["p5", "p6"], ["p6", "p1"]]), p);
    expect(t.topIds).toEqual(["p2", "p4"]);
    expect(t.chaos).toBe(false);
  });
  it("one vote: top with count 1, not chaos", () => {
    const t = tally(B([["p1", "p3"]]), ids(3));
    expect(t).toMatchObject({ votesCast: 1, topIds: ["p3"], chaos: false, unanimous: false });
  });
  it("two different votes are a tie, not chaos (chaos needs ≥ 3)", () => {
    const t = tally(B([["p1", "p3"], ["p2", "p1"]]), ids(3));
    expect(t).toMatchObject({ topIds: ["p1", "p3"], chaos: false });
  });
  it("no votes: nothing", () => {
    expect(tally([], ids(4))).toEqual({ votesCast: 0, counts: [], topIds: [], unanimous: false, chaos: false });
  });
  it("self-votes count like any vote", () => {
    const t = tally(B([["p1", "p1"], ["p2", "p1"], ["p3", "p1"]]), ids(3));
    expect(t).toMatchObject({ unanimous: true, topIds: ["p1"] });
  });
  it("is independent of ballot order", () => {
    const b = B([["p1", "p2"], ["p2", "p3"], ["p3", "p2"], ["p4", "p4"]]);
    expect(tally([...b].reverse(), ids(4))).toEqual(tally(b, ids(4)));
  });
});

describe("percentages (§5.1)", () => {
  it("round half up for 1..12 voters", () => {
    for (let v = 1; v <= 12; v++) for (let c = 0; c <= v; c++) {
      const exact = (100 * c) / v;
      const expected = exact - Math.floor(exact) >= 0.5 - 1e-9 ? Math.ceil(exact) : Math.floor(exact);
      expect(percentOf(c, v)).toBe(expected);
    }
    expect(percentOf(1, 8)).toBe(13); // 12.5 → 13
    expect(percentOf(1, 6)).toBe(17);
    expect(percentOf(0, 0)).toBe(0);
  });
  it("3 × 1 vote → 33/33/33 (sum 99, accepted)", () => {
    const t = tally(B([["p1", "p2"], ["p2", "p3"], ["p3", "p1"]]), ids(3));
    expect(withPercent(t).map((c) => c.percent)).toEqual([33, 33, 33]);
  });
  it("ordered by percent desc, then seat", () => {
    const t = tally(B([["p1", "p3"], ["p2", "p3"], ["p3", "p1"], ["p4", "p2"]]), ids(4));
    expect(withPercent(t)).toEqual([
      { playerId: "p3", count: 2, percent: 50 },
      { playerId: "p1", count: 1, percent: 25 },
      { playerId: "p2", count: 1, percent: 25 },
    ]);
  });
});

describe("Read the Room scoring (§6, public mode)", () => {
  it("+50 per other voter on the same target", () => {
    const p = ids(5);
    const b = B([["p1", "p3"], ["p2", "p3"], ["p3", "p3"], ["p4", "p5"], ["p5", "p1"]]);
    const d = scoreCard(b, tally(b, p), p);
    expect(sumBy(d, "p1")).toBe(100);
    expect(sumBy(d, "p2")).toBe(100);
    expect(sumBy(d, "p4")).toBe(0);
    expect(sumBy(d, "p5")).toBe(0);
    // p3 voted for themselves and 2 others picked them: Self-aware +100
    expect(d.filter((x) => x.playerId === "p3")).toEqual([{ playerId: "p3", points: 100, reason: "agree" }, { playerId: "p3", points: 100, reason: "selfAware" }]);
  });
  it("cap +300 per card", () => {
    const p = ids(12);
    // 8 on p1, 4 elsewhere: 7 others → 350 → capped 300
    const b = B(p.map((v, i) => [v, i < 8 ? "p1" : `p${i}`]));
    const d = scoreCard(b, tally(b, p), p);
    expect(sumBy(d, "p2")).toBe(300);
  });
  it("12 voters: a group of 6 pays +250, a pair +50", () => {
    const p = ids(12);
    const targets = ["p1", "p1", "p1", "p1", "p1", "p1", "p2", "p2", "p3", "p4", "p5", "p6"];
    const b = B(p.map((v, i) => [v, targets[i]!]));
    const d = scoreCard(b, tally(b, p), p);
    expect(sumBy(d, "p2")).toBe(250);
    expect(sumBy(d, "p7")).toBe(50);
  });
  it("unanimous = +300 cap + 100 bonus = +400 each", () => {
    const p = ids(4);
    const b = B(p.map((v) => [v, "p2"]));
    const d = scoreCard(b, tally(b, p), p);
    for (const id of ["p1", "p3", "p4"]) expect(sumBy(d, id)).toBe(400);
    expect(sumBy(d, "p2")).toBe(500); // + Self-aware: voted self, 3 others agreed
  });
  it("Self-aware needs ≥ 2 others", () => {
    const p = ids(4);
    const b = B([["p1", "p1"], ["p2", "p1"], ["p3", "p4"], ["p4", "p3"]]);
    const d = scoreCard(b, tally(b, p), p);
    expect(d.some((x) => x.reason === "selfAware")).toBe(false);
    expect(sumBy(d, "p1")).toBe(50);
  });
  it("chaos and lone votes pay 0", () => {
    const p = ids(5);
    const b = B(p.map((v, i) => [v, p[(i + 2) % 5]!]));
    expect(scoreCard(b, tally(b, p), p)).toEqual([]);
    const one = B([["p1", "p2"]]);
    expect(scoreCard(one, tally(one, p), p)).toEqual([]);
  });
  it("3-player pact earns at most +50 a card", () => {
    const p = ids(3);
    for (const third of p) {
      const b = B([["p1", "p3"], ["p2", "p3"], ["p3", third]]);
      const t = tally(b, p);
      if (t.unanimous) continue; // unanimity is the whole table agreeing, not a pact
      const d = scoreCard(b, t, p);
      expect(sumBy(d, "p1")).toBeLessThanOrEqual(50);
    }
  });
});
