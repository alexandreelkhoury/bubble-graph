// Synthetic unique-token catalog (shared/src/testing/catalogs/likely.ts draft) and test harness.
import { createLikelyDefinition, type LikelyCatalog, type LikelyCard, type LikelyIntent, type LikelyPack, type LikelySettings, type LikelyState, type Tag } from "../src";
import type { GameAction, GameActor, GameCtx, Locale, RosterEntry } from "../src/platform";

const FAMILY_TAGS: Tag[] = ["party", "food", "family", "travel", "habits", "lebanon", "tech", "music", "sport", "future"];

function l4(token: string, es = true) {
  return { en: `en-${token}`, fr: `de fr-${token}`, ar: `ar-${token}`, ...(es ? { es: `es-${token}` } : {}) };
}

export function familyPack(n = 40, opts: { id?: string; freeEvery?: number; es?: boolean } = {}): LikelyPack {
  const id = opts.id ?? "syn-family";
  const cards: LikelyCard[] = Array.from({ length: n }, (_, i) => ({
    id: `${id}-${String(i).padStart(3, "0")}`,
    tier: i % (opts.freeEvery ?? 2) === 0 ? "free" : "pass",
    spice: 0, namesPlayer: false,
    tags: [FAMILY_TAGS[i % FAMILY_TAGS.length] as Tag],
    prompt: l4(`p-${id}-${i}`, opts.es ?? true), award: l4(`a-${id}-${i}`, opts.es ?? true),
    review: { status: "draft" },
  }));
  return { schemaVersion: 1, id, game: "likely", title: l4("t"), description: l4("d"), locales: opts.es === false ? ["en", "fr", "ar"] : ["en", "fr", "ar", "es"], ageRating: "all", cards };
}

export function spicyPack(n = 30, namedEvery = 3, id = "syn-spicy"): LikelyPack {
  const cards: LikelyCard[] = Array.from({ length: n }, (_, i) => {
    const named = i % namedEvery === 0;
    const tok = (k: string) => (named ? { en: `en-${k} {player}`, fr: `de fr-${k} {player}`, ar: `ar-${k} {player}`, es: `es-${k} {player}` } : l4(k));
    return {
      id: `${id}-${String(i).padStart(3, "0")}`, tier: "pass", spice: (i % 2 === 0 ? 1 : 2) as 1 | 2, namesPlayer: named,
      tags: [i % 4 === 0 ? "party" : "romance"] as Tag[], prompt: tok(`p-${id}-${i}`), award: l4(`a-${id}-${i}`), review: { status: "draft" },
    };
  });
  return { schemaVersion: 1, id, game: "likely", title: l4("st"), description: l4("sd"), locales: ["en", "fr", "ar", "es"], ageRating: "adult", cards };
}

export const CATALOG: LikelyCatalog = { packs: [familyPack(), spicyPack()] };
export const FAMILY_ONLY: LikelyCatalog = { packs: [familyPack()] };

export const DEF = createLikelyDefinition({ spicyEnabled: true });
export const SHIPPED = createLikelyDefinition({ spicyEnabled: false });
export const GRACE = 2_500;
export const T0 = 1_000_000;

export const ids = (n: number): string[] => Array.from({ length: n }, (_, i) => `p${i + 1}`);
export function roster(n: number, locale: Locale = "en"): RosterEntry[] {
  return ids(n).map((id, i) => ({ id, seat: i, locale, connected: true, carryScore: 0 }));
}
export function settings(p: Partial<LikelySettings> = {}): LikelySettings {
  return { packIds: [], length: "short", showVoters: true, mode: "family", ...p };
}

export function startGame(n: number, s: Partial<LikelySettings> = {}, o: { content?: LikelyCatalog; seed?: number; usedKeys?: string[]; locale?: Locale } = {}): LikelyState {
  const r = DEF.start({ roster: roster(n, o.locale), settings: settings(s), locale: o.locale ?? "en", memory: { usedKeys: o.usedKeys ?? [] }, seed: o.seed ?? 42, now: T0, graceMs: GRACE, content: o.content ?? CATALOG });
  if (!r.ok) throw new Error(`start failed: ${r.error}`);
  DEF.assertInvariants(r.state);
  return r.state;
}

export function ctx(now: number, content: LikelyCatalog = CATALOG, host: string | null = "p1"): GameCtx<LikelyCatalog> {
  return { now, content, hostPlayerId: host, isHost: (a: GameActor) => a.kind === "tv" || (a.kind === "player" && a.playerId === host) };
}

/** Reduce and check invariants; throws on an engine error unless `allowError`. */
export function step(s: LikelyState, a: GameAction<LikelyIntent>, now: number, content: LikelyCatalog = CATALOG): LikelyState {
  const r = DEF.reduce(s, a, ctx(now, content));
  if (!r.ok) throw new Error(`reduce failed: ${r.error} for ${JSON.stringify(a)}`);
  DEF.assertInvariants(r.state);
  return r.state;
}
export const tick = (s: LikelyState, content: LikelyCatalog = CATALOG): LikelyState => step(s, { type: "TICK" }, s.deadline ?? T0, content);
export const vote = (s: LikelyState, voter: string, target: string, now: number): LikelyState =>
  step(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: target }, by: { kind: "player", playerId: voter } }, now);
export const tv: GameActor = { kind: "tv" };
export const host = (s: LikelyState, intent: LikelyIntent, now: number): LikelyState => step(s, { type: "INTENT", intent, by: tv }, now);

/** From CARD: open voting, cast `ballots` (voter → target), and reveal. */
export function playCard(s: LikelyState, ballots: Record<string, string>): LikelyState {
  if (s.phase !== "CARD") throw new Error(`playCard from ${s.phase}`);
  let x = tick(s);
  const now = x.deadline! - 10_000;
  for (const [v, t] of Object.entries(ballots)) x = vote(x, v, t, now);
  while (x.phase === "VOTING") x = tick(x);
  return x;
}
