import { describe, expect, it } from "vitest";
import { computeAwards, type CardTallyForAwards, type Delta } from "../src";
import { ids } from "./helpers";

const card = (index: number, votesCast: number, counts: [string, number][], topIds: string[]): CardTallyForAwards =>
  ({ index, votesCast, counts: counts.map(([playerId, count]) => ({ playerId, count })), topIds });

describe("awards (§6.2)", () => {
  const p = ids(4);
  it("signature = highest vote share; tie → later card; never top → mystery", () => {
    const results = [
      card(0, 4, [["p1", 3], ["p2", 1]], ["p1"]),        // p1 75 %
      card(1, 4, [["p1", 2], ["p3", 2]], ["p1", "p3"]),  // p1 50 %, p3 50 %
      card(2, 2, [["p3", 1], ["p2", 1]], ["p2", "p3"]),  // p3 50 % (later: wins the tie), p2 50 %
    ];
    const a = computeAwards(p, results, false, [], {});
    expect(a.slice(0, 4)).toEqual([
      { kind: "signature", playerIds: ["p1"], cardIndex: 0 },
      { kind: "signature", playerIds: ["p2"], cardIndex: 2 },
      { kind: "signature", playerIds: ["p3"], cardIndex: 2 },
      { kind: "mystery", playerIds: ["p4"], cardIndex: null },
    ]);
  });
  it("vote share is compared exactly (2/3 beats 3/5)", () => {
    const a = computeAwards(["p1"], [card(0, 3, [["p1", 2]], ["p1"]), card(1, 5, [["p1", 3]], ["p1"])], false, [], {});
    expect(a[0]).toEqual({ kind: "signature", playerIds: ["p1"], cardIndex: 0 });
  });
  it("Tonight's Star: most cards topped, ≥ 3, ties share", () => {
    const two = [0, 1].map((i) => card(i, 3, [["p1", 2]], ["p1"]));
    expect(computeAwards(p, two, false, [], {}).some((x) => x.kind === "star")).toBe(false);
    const three = [0, 1, 2].map((i) => card(i, 3, [["p1", 1], ["p2", 1]], ["p1", "p2"]));
    expect(computeAwards(p, three, false, [], {}).find((x) => x.kind === "star")).toEqual({ kind: "star", playerIds: ["p1", "p2"], cardIndex: null });
  });
  it("Self-aware (≥ 2) and Mind Reader exist in public mode only", () => {
    const self: Delta = { playerId: "p2", points: 100, reason: "selfAware" };
    const deltas = [[self], [self]];
    const scores = { p1: 300, p2: 500, p3: 500, p4: 0 };
    const pub = computeAwards(p, [], true, deltas, scores);
    expect(pub.find((x) => x.kind === "selfAware")).toEqual({ kind: "selfAware", playerIds: ["p2"], cardIndex: null });
    expect(pub.find((x) => x.kind === "mindReader")).toEqual({ kind: "mindReader", playerIds: ["p2", "p3"], cardIndex: null });
    const anon = computeAwards(p, [], false, deltas, scores);
    expect(anon.some((x) => x.kind === "selfAware" || x.kind === "mindReader")).toBe(false);
    expect(computeAwards(p, [], true, [[self]], scores).some((x) => x.kind === "selfAware")).toBe(false);
  });
  it("no Mind Reader when nobody scored", () => {
    expect(computeAwards(p, [], true, [], {}).some((x) => x.kind === "mindReader")).toBe(false);
  });
  it("left players keep their signature card but get no extra award", () => {
    const three = [0, 1, 2].map((i) => card(i, 3, [["p1", 3]], ["p1"]));
    const a = computeAwards(p, three, true, [], { p1: 900 }, new Set(["p1"]));
    expect(a[0]).toEqual({ kind: "signature", playerIds: ["p1"], cardIndex: 2 });
    expect(a.some((x) => x.kind === "star" || x.kind === "mindReader")).toBe(false);
  });
});
