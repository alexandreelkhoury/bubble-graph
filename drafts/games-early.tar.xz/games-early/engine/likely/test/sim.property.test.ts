// §2.8 game property: random rosters 3–12, random settings, bot votes, host moves, AWAY/BACK/GONE and late joins.
// Termination, invariants after every reduce, no leaks in any phase, determinism.
import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { botHostIntent, botIntent, type LikelySettings, type LikelyState } from "../src";
import { createRng } from "../src/platform";
import { CATALOG, DEF, T0, ctx, roster } from "./helpers";

function checkViews(s: LikelyState): void {
  const tv = DEF.projectPublic(s, CATALOG);
  const errs = DEF.leakCheck(s, null, tv);
  if (errs.length) throw new Error(`TV leak: ${errs.join("; ")}`);
  for (const p of s.players) {
    const view = { pub: tv, me: DEF.projectMe(s, p.id) };
    const e = DEF.leakCheck(s, p.id, view);
    if (e.length) throw new Error(`leak for ${p.id}: ${e.join("; ")}`);
    const json = JSON.stringify(view);
    for (const k of DEF.forbiddenKeys) if (json.includes(`"${k}"`)) throw new Error(`forbidden key ${k}`);
    for (const secret of DEF.secretsFor(s, p.id)) if (json.includes(JSON.stringify(secret))) throw new Error("secret leaf");
  }
}

function runGame(seed: number, n: number, st: LikelySettings): { final: LikelyState; trace: string } {
  const rng = createRng(seed ^ 0x9e3779b9);
  const r = DEF.start({ roster: roster(n), settings: st, locale: (["en", "fr", "ar", "es"] as const)[seed % 4]!, memory: { usedKeys: [] }, seed, now: T0, graceMs: 2_500, content: CATALOG });
  if (!r.ok) throw new Error(r.error);
  let s = r.state;
  let now = T0;
  let nextId = 100;
  const apply = (a: Parameters<typeof DEF.reduce>[1]) => {
    const res = DEF.reduce(s, a, ctx(now, CATALOG, "p1"));
    s = res.state;
    DEF.assertInvariants(s);
    checkViews(s);
  };
  for (let stepN = 0; stepN < 5_000 && s.phase !== "RESULTS"; stepN++) {
    const roll = rng.next();
    if (roll < 0.45) {
      const p = s.players[rng.int(s.players.length)]!;
      const i = botIntent(s, p.id, rng);
      if (i) apply({ type: "INTENT", intent: i, by: { kind: "player", playerId: p.id } });
    } else if (roll < 0.55) {
      const h = botHostIntent(s, rng);
      if (h) apply({ type: "INTENT", ...h });
    } else if (roll < 0.60) {
      const p = s.players[rng.int(s.players.length)]!;
      apply({ type: p.connected ? "PLAYER_AWAY" : "PLAYER_BACK", playerId: p.id });
    } else if (roll < 0.61) {
      const p = s.players[rng.int(s.players.length)]!;
      apply({ type: "PLAYER_GONE", playerId: p.id, cause: "LEAVE" });
    } else if (roll < 0.62 && s.players.filter((p) => !p.left).length < 12) {
      const res = DEF.join!(s, { id: `j${nextId}`, seat: nextId++, locale: "en", connected: true, carryScore: 0 });
      s = res.state;
      DEF.assertInvariants(s);
      checkViews(s);
    } else {
      const wake = DEF.nextWakeAt(s);
      if (wake !== null) now = Math.max(now, wake);
      else now += 1_000;
      apply({ type: "TICK" });
    }
    now += 50;
  }
  return { final: s, trace: JSON.stringify(s) };
}

describe("random games (sim property)", () => {
  it("terminate, keep invariants, never leak, are deterministic", () => {
    fc.assert(fc.property(
      fc.integer({ min: 0, max: 2 ** 31 }), fc.integer({ min: 3, max: 12 }),
      fc.record({ packIds: fc.constant([] as string[]), length: fc.constantFrom("short", "normal", "long"), showVoters: fc.boolean(), mode: fc.constantFrom("family", "spicy") }),
      (seed, n, st) => {
        const a = runGame(seed, n, st as LikelySettings);
        expect(a.final.phase).toBe("RESULTS");
        const o = DEF.outcome(a.final)!;
        if (!st.showVoters) expect(o.ranking).toEqual([]);
        for (const p of a.final.players.filter((x) => x.left)) expect(o.points[p.id]).toBe(0);
        expect(runGame(seed, n, st as LikelySettings).trace).toBe(a.trace);
      },
    ), { numRuns: Number(process.env.FC_RUNS ?? 120) });
  });
});
