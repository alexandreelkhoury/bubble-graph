import { describe, expect, it } from "vitest";
import { DEFAULT_SETTINGS, LIKELY_META, SETTINGS_SCHEMA, normalize, type LikelySettings } from "../src";
import { CATALOG, DEF, FAMILY_ONLY, SHIPPED, familyPack, roster, settings, spicyPack, tv } from "./helpers";

const vip = { kind: "player" as const, playerId: "p1" };
const apply = (s: LikelySettings, patch: Parameters<typeof DEF.settings.apply>[1], by?: typeof tv | typeof vip, content = CATALOG) => DEF.settings.apply(s, patch, content, "en", by);

describe("settings (§9)", () => {
  it("schema 2, mode defaults to family, 4 rows", () => {
    expect(SETTINGS_SCHEMA).toBe(2);
    expect(DEFAULT_SETTINGS).toEqual({ packIds: [], length: "normal", showVoters: true, mode: "family" });
    expect(LIKELY_META.settings.basic.map((f) => f.key)).toEqual(["packIds", "length", "showVoters", "mode"]);
    expect(LIKELY_META.settings.basic.length).toBeLessThanOrEqual(4);
  });
  it("normalize: missing, extra, wrong-typed keys; old schema-1 values → family", () => {
    expect(normalize(undefined)).toEqual(DEFAULT_SETTINGS);
    expect(normalize("x")).toEqual(DEFAULT_SETTINGS);
    expect(normalize({ packIds: ["BAD ID"], length: "huge", showVoters: "yes", mode: "wild", extra: 1 })).toEqual(DEFAULT_SETTINGS);
    expect(normalize({ packIds: ["a", "a", "b"], length: "long", showVoters: false })).toEqual({ packIds: ["a", "b"], length: "long", showVoters: false, mode: "family" });
    expect(normalize({ ...DEFAULT_SETTINGS, mode: "spicy" }).mode).toBe("spicy");
  });
  it("apply validates values and returns the same object when nothing changes", () => {
    const s = settings();
    expect(apply(s, { length: "short" })).toBe(s);
    expect(apply(s, { length: "xl" as never })).toBeNull();
    expect(apply(s, { packIds: ["nope"] })).toBeNull();
    expect(apply(s, { packIds: ["syn-spicy"] })).toBeNull(); // adult pack not selectable in family mode
    expect(apply(s, { packIds: ["syn-family"] })).toEqual({ ...s, packIds: ["syn-family"] });
    expect(apply(s, { showVoters: false }, vip)).toEqual({ ...s, showVoters: false });
    expect(apply(s, { foo: 1 } as never)).toBeNull();
  });
  it("restrict: drops locked packs; same object when nothing changes", () => {
    const s = settings({ packIds: ["syn-family"] });
    expect(DEF.settings.restrict(s, { playableIds: new Set(["syn-family"]), premium: false }, CATALOG, "en")).toBe(s);
    expect(DEF.settings.restrict(s, { playableIds: new Set(), premium: false }, CATALOG, "en")).toEqual({ ...s, packIds: [] });
  });
});

describe("Spicy 18+ gate (§9.1)", () => {
  const fam = settings();
  it("spicy needs the TV actor AND ageConfirmed: true", () => {
    expect(apply(fam, { mode: "spicy" }, tv)).toBeNull();
    expect(apply(fam, { mode: "spicy", ageConfirmed: false }, tv)).toBeNull();
    expect(apply(fam, { mode: "spicy", ageConfirmed: true }, vip)).toBeNull();
    expect(apply(fam, { mode: "spicy", ageConfirmed: true }, undefined)).toBeNull(); // platform without the actor: fail closed
    expect(apply(fam, { mode: "spicy", ageConfirmed: true }, tv)).toMatchObject({ mode: "spicy" });
  });
  it("switching to spicy sets showVoters:false in the same patch; the host may switch it back after", () => {
    const sp = apply(fam, { mode: "spicy", ageConfirmed: true }, tv)!;
    expect(sp.showVoters).toBe(false);
    expect(apply(fam, { mode: "spicy", ageConfirmed: true, showVoters: true }, tv)!.showVoters).toBe(false);
    expect(apply(sp, { showVoters: true }, vip)).toEqual({ ...sp, showVoters: true });
  });
  it("moving back to family is always allowed, from TV or VIP, and drops the adult pack", () => {
    const sp = { ...settings({ mode: "spicy", packIds: ["syn-spicy", "syn-family"] }) };
    expect(apply(sp, { mode: "family" }, vip)).toEqual({ ...sp, mode: "family", packIds: ["syn-family"] });
    expect(apply(sp, { mode: "family" }, tv)).toMatchObject({ mode: "family" });
  });
  it("re-confirmation is not needed for an unrelated patch while already spicy", () => {
    const sp = settings({ mode: "spicy", showVoters: false });
    expect(apply(sp, { length: "long" }, vip)).toEqual({ ...sp, length: "long" });
  });
  it("refused where no Spicy card is playable (free room) and in the shipped build (compiled out)", () => {
    expect(apply(fam, { mode: "spicy", ageConfirmed: true }, tv, FAMILY_ONLY)).toBeNull();
    expect(SHIPPED.settings.apply(fam, { mode: "spicy", ageConfirmed: true }, CATALOG, "en", tv)).toBeNull();
    expect(SHIPPED.startBlocker(roster(4), settings({ mode: "spicy" }), CATALOG, "en")).toBe("NO_CONTENT_AVAILABLE");
  });
  it("restrict falls back to family when the Spicy pack is not playable", () => {
    const sp = settings({ mode: "spicy", packIds: ["syn-spicy"] });
    expect(DEF.settings.restrict(sp, { playableIds: new Set(["syn-family"]), premium: false }, FAMILY_ONLY, "en")).toEqual({ ...sp, mode: "family", packIds: [] });
  });
  it("Spicy pack absent from a family room's setup count; present in spicy", () => {
    const access = { premium: true, playableIds: new Set(["syn-family", "syn-spicy"]) };
    expect(DEF.projectSetup(settings(), roster(4), CATALOG, access, "en")).toEqual({ gameId: "likely", available: 40, spicyAvailable: true });
    expect(DEF.projectSetup(settings({ mode: "spicy" }), roster(4), CATALOG, access, "en").available).toBe(70);
    expect(DEF.projectSetup(settings(), roster(4), { packs: [familyPack(), spicyPack(30, 3, "x-spicy")] }, access, "en").available).toBe(40);
  });
});
