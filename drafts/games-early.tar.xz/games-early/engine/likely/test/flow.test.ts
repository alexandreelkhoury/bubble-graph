import { describe, expect, it } from "vitest";
import { awardsMs, CARD_MS, revealMs, votingMs, type LikelyState } from "../src";
import { CATALOG, DEF, GRACE, T0, ctx, host, playCard, roster, settings, startGame, step, tick, tv, vote } from "./helpers";

const P = (id: string) => ({ kind: "player" as const, playerId: id });
const fail = (s: LikelyState, a: Parameters<typeof DEF.reduce>[1], now = T0, hostId: string | null = "p1") => {
  const r = DEF.reduce(s, a, ctx(now, CATALOG, hostId));
  expect(r.ok).toBe(false);
  expect(r.state).toBe(s);
  return r.ok ? null : r.error;
};

describe("flow (§4)", () => {
  it("first CARD deadline = 3 500 + ENTRANCE_GRACE_MS; later cards 3 500", () => {
    const s = startGame(4);
    expect(s.phase).toBe("CARD");
    expect(s.deadline).toBe(T0 + CARD_MS + GRACE);
    const r = playCard(s, {});
    const next = tick(r);
    expect(next.phase).toBe("CARD");
    expect(next.deadline).toBe(r.deadline! + CARD_MS);
  });
  it("VOTING duration = clamp(14 000 + 1 000 n, 18 000, 26 000)", () => {
    expect([3, 4, 5, 8, 12].map(votingMs)).toEqual([18_000, 18_000, 19_000, 22_000, 26_000]);
    const v = tick(startGame(5));
    expect(v.deadline! - (T0 + CARD_MS + GRACE)).toBe(19_000);
  });
  it("all connected voters voted → ends 1 s later; votes changeable in the window; HOST_ADVANCE ignored in VOTING", () => {
    let s = tick(startGame(3));
    const now = s.deadline! - 15_000;
    s = vote(s, "p1", "p2", now);
    s = vote(s, "p2", "p2", now);
    expect(host(s, { a: "HOST_ADVANCE" }, now)).toBe(s);
    s = vote(s, "p3", "p1", now);
    expect(s.deadline).toBe(now + 1_000);
    s = vote(s, "p3", "p2", now + 500); // change inside the window, deadline unchanged
    expect(s.deadline).toBe(now + 1_000);
    s = step(s, { type: "TICK" }, now + 1_000);
    expect(s.phase).toBe("REVEAL");
    expect(s.results[0]).toMatchObject({ unanimous: true, topIds: ["p2"] });
  });
  it("a disconnected voter abstains; their leaving the room can complete the quorum", () => {
    let s = tick(startGame(4));
    const now = s.deadline! - 15_000;
    for (const v of ["p1", "p2", "p3"]) s = vote(s, v, "p1", now);
    expect(s.earlyEnd).toBe(false);
    s = step(s, { type: "PLAYER_AWAY", playerId: "p4" }, now + 10);
    expect(s.deadline).toBe(now + 1_010);
  });
  it("same vote again returns the same object", () => {
    let s = tick(startGame(3));
    s = vote(s, "p1", "p2", T0 + 7_000);
    expect(DEF.reduce(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: "p2" }, by: P("p1") }, ctx(T0 + 7_100)).state).toBe(s);
  });
  it("intent errors", () => {
    const c = startGame(4);
    const id = c.card!.cardId;
    expect(fail(c, { type: "INTENT", intent: { a: "VOTE", cardId: id, targetId: "p2" }, by: P("p1") })).toBe("WRONG_PHASE");
    const v = tick(c);
    expect(fail(v, { type: "INTENT", intent: { a: "VOTE", cardId: "zzz", targetId: "p2" }, by: P("p1") })).toBe("STALE_CARD");
    expect(fail(v, { type: "INTENT", intent: { a: "VOTE", cardId: id, targetId: "nobody" }, by: P("p1") })).toBe("INVALID_TARGET");
    expect(fail(v, { type: "INTENT", intent: { a: "VOTE", cardId: id, targetId: "p2" }, by: tv })).toBe("NOT_IN_GAME");
    expect(fail(v, { type: "INTENT", intent: { a: "VOTE", cardId: id, targetId: "p2" }, by: P("ghost") })).toBe("NOT_IN_GAME");
    expect(fail(v, { type: "INTENT", intent: { a: "SKIP_CARD", cardId: id }, by: P("p2") })).toBe("NOT_HOST");
    expect(fail(v, { type: "INTENT", intent: { a: "SKIP_CARD", cardId: "zzz" }, by: tv })).toBe("STALE_CARD");
    expect(fail(v, { type: "INTENT", intent: { a: "END_GAME" }, by: tv })).toBe("WRONG_PHASE");
    expect(fail(v, { type: "INTENT", intent: { a: "HOST_ADVANCE" }, by: P("p3") })).toBe("NOT_HOST");
    const r = playCard(c, {});
    expect(fail(r, { type: "INTENT", intent: { a: "SKIP_CARD", cardId: id }, by: tv })).toBe("WRONG_PHASE");
  });
  it("the VIP phone is a host (ctx.isHost), and HOST_ADVANCE expires CARD/REVEAL/AWARDS inline", () => {
    const c = startGame(3);
    const v = step(c, { type: "INTENT", intent: { a: "HOST_ADVANCE" }, by: P("p1") }, T0 + 100);
    expect(v.phase).toBe("VOTING");
    expect(v.deadline).toBe(T0 + 100 + votingMs(3));
  });
  it("SKIP_CARD: new card, votes discarded, counter unchanged, skipped card in memory", () => {
    let s = tick(startGame(4));
    const first = s.card!.cardId;
    s = vote(s, "p1", "p2", T0 + 7_000);
    s = host(s, { a: "SKIP_CARD", cardId: first }, T0 + 7_100);
    expect(s.phase).toBe("CARD");
    expect(s.card!.cardId).not.toBe(first);
    expect(s.votes).toEqual({});
    expect(s.cardIndex).toBe(0);
    expect(s.deadline).toBe(T0 + 7_100 + CARD_MS);
    expect(DEF.memory(s).usedKeys).toContain(first);
  });
  it("REVEAL duration per §12.2 (clamped to 6 000–9 500)", () => {
    expect(revealMs(0, false, 0)).toBe(6_000);
    expect(revealMs(4, false, 1)).toBe(6_000);
    expect(revealMs(12, true, 1)).toBe(7_400);
    expect(revealMs(12, false, 3)).toBe(6_800);
    expect(revealMs(50, true, 2)).toBe(9_500);
  });
  it("plays a whole short game to RESULTS; AWARDS duration formula", () => {
    let s = startGame(3);
    for (let i = 0; i < 8; i++) { s = playCard(s, { p1: "p2", p2: "p2", p3: "p1" }); s = tick(s); }
    expect(s.phase).toBe("AWARDS");
    expect(s.deadline! - s.results.length * 0).toBeGreaterThan(0);
    expect(awardsMs(3, true)).toBe(3_000 + 4_000 + 4_000);
    expect(awardsMs(7, false)).toBe(3_000 + 12_000);
    const before = s;
    s = tick(s);
    expect(s.phase).toBe("RESULTS");
    expect(s.deadline).toBeNull();
    expect(DEF.nextWakeAt(s)).toBeNull();
    expect(DEF.outcome(before)).toBeNull();
    // p1 and p2 agree each card: +50 × 8; p3 never agrees
    expect(DEF.outcome(s)).toEqual({ points: { p1: 400, p2: 400, p3: 0 }, ranking: [["p1", "p2"]] });
    expect(s.awards!.find((a) => a.kind === "mindReader")!.playerIds).toEqual(["p1", "p2"]);
    expect(s.awards!.find((a) => a.kind === "star")!.playerIds).toEqual(["p2"]);
  });
  it("secret votes: no points at all, outcome all 0 and no ranking", () => {
    let s = startGame(3, { showVoters: false });
    for (let i = 0; i < 8; i++) { s = playCard(s, { p1: "p2", p2: "p2", p3: "p2" }); s = tick(s); }
    s = tick(s);
    expect(DEF.outcome(s)).toEqual({ points: { p1: 0, p2: 0, p3: 0 }, ranking: [] });
    expect(s.awards!.some((a) => a.kind === "mindReader" || a.kind === "selfAware")).toBe(false);
  });
  it("HOLD when < 3 connected at card start; resumes at 3; END_GAME → AWARDS", () => {
    let s = startGame(3);
    s = step(s, { type: "PLAYER_AWAY", playerId: "p3" }, T0 + 10);
    s = playCard(s, { p1: "p2", p2: "p1" });
    s = tick(s);
    expect(s.phase).toBe("HOLD");
    expect(s.card).toBeNull();
    expect(DEF.nextWakeAt(s)).toBeNull();
    const back = step(s, { type: "PLAYER_BACK", playerId: "p3" }, T0 + 90_000);
    expect(back.phase).toBe("CARD");
    expect(back.cardIndex).toBe(1);
    expect(back.deadline).toBe(T0 + 90_000 + CARD_MS);
    const ended = host(s, { a: "END_GAME" }, T0 + 90_000);
    expect(ended.phase).toBe("AWARDS");
    expect(ended.awards!.filter((a) => a.kind === "signature" || a.kind === "mystery")).toHaveLength(3);
  });
  it("late joiner: waits until the next CARD, then votes and can be voted for", () => {
    let s = tick(startGame(3));
    const j = DEF.join!(s, { id: "p9", seat: 9, locale: "en", connected: true, carryScore: 0 });
    expect(j.ok).toBe(true);
    s = j.state;
    DEF.assertInvariants(s);
    expect(DEF.projectMe(s, "p9")).toEqual({ myVote: null, waitingForNext: true });
    expect(DEF.reduce(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: "p1" }, by: P("p9") }, ctx(T0 + 7_000)).ok).toBe(false);
    expect(DEF.reduce(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: "p9" }, by: P("p1") }, ctx(T0 + 7_000))).toMatchObject({ ok: false, error: "INVALID_TARGET" });
    // the 3 dealt-in voters vote: quorum does not wait for the newcomer
    const now = s.deadline! - 15_000;
    for (const v of ["p1", "p2", "p3"]) s = vote(s, v, "p1", now);
    expect(s.earlyEnd).toBe(true);
    s = tick(tick(s));
    expect(s.phase).toBe("CARD");
    expect(DEF.projectMe(s, "p9")!.waitingForNext).toBe(false);
    expect(DEF.projectPublic(s, CATALOG).newIds).toEqual(["p9"]);
    s = playCard(s, { p9: "p9", p1: "p9" });
    expect(s.results[1]!.topIds).toEqual(["p9"]);
    expect(DEF.join!(s, { id: "p9", seat: 9, locale: "en", connected: true, carryScore: 0 }).state).toBe(s);
  });
  it("a join that completes a HOLD quorum wakes the game at once (nextWakeAt 0)", () => {
    let s = startGame(3);
    s = step(s, { type: "PLAYER_GONE", playerId: "p3", cause: "LEAVE" }, T0 + 10);
    s = tick(playCard(s, {}));
    expect(s.phase).toBe("HOLD");
    s = DEF.join!(s, { id: "p4", seat: 4, locale: "en", connected: true, carryScore: 0 }).state;
    expect(DEF.nextWakeAt(s)).toBe(0);
    s = step(s, { type: "TICK" }, T0 + 99_000);
    expect(s.phase).toBe("CARD");
    expect(DEF.projectMe(s, "p4")!.waitingForNext).toBe(false);
  });
  it("left player: no longer a target; votes on them dropped; their own vote stays; rejoin refused", () => {
    let s = tick(startGame(4));
    const now = s.deadline! - 15_000;
    s = vote(s, "p1", "p4", now);
    s = vote(s, "p4", "p2", now);
    s = step(s, { type: "PLAYER_GONE", playerId: "p4", cause: "KICK" }, now + 1);
    expect(s.votes).toEqual({ p4: "p2" });
    expect(DEF.reduce(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: "p4" }, by: P("p2") }, ctx(now + 2))).toMatchObject({ ok: false, error: "INVALID_TARGET" });
    expect(DEF.reduce(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: "p1" }, by: P("p4") }, ctx(now + 2))).toMatchObject({ ok: false, error: "NOT_IN_GAME" });
    expect(DEF.join!(s, { id: "p4", seat: 3, locale: "en", connected: true, carryScore: 0 })).toMatchObject({ ok: false, error: "NOT_IN_GAME" });
    s = vote(s, "p1", "p2", now + 3);
    s = vote(s, "p2", "p2", now + 3);
    s = vote(s, "p3", "p2", now + 3);
    s = tick(s);
    expect(s.results[0]!.votesCast).toBe(4);
    expect(step(s, { type: "PLAYER_GONE", playerId: "p4", cause: "LEAVE" }, now + 5)).toBe(s);
  });
  it("Spicy named card: named player is not a target; leaving voids the card; away keeps it", () => {
    let s = startGame(5, { mode: "spicy", showVoters: false }, { seed: 3 });
    let guard = 0;
    while (!(s.phase === "CARD" && s.card?.namedPlayerId)) {
      s = s.phase === "CARD" ? playCard(s, {}) : tick(s);
      if (++guard > 200 || s.phase === "AWARDS") throw new Error("no named card drawn");
    }
    const named = s.card!.namedPlayerId!;
    const voter = s.players.find((p) => p.id !== named)!.id;
    const away = step(s, { type: "PLAYER_AWAY", playerId: named }, s.deadline! - 100);
    expect(away.card).toEqual(s.card);
    const v = tick(s);
    expect(DEF.reduce(v, { type: "INTENT", intent: { a: "VOTE", cardId: v.card!.cardId, targetId: named }, by: P(voter) }, ctx(v.deadline! - 9_000))).toMatchObject({ ok: false, error: "INVALID_TARGET" });
    // the named player still votes
    const v2 = vote(v, named, voter, v.deadline! - 9_000);
    const gone = step(v2, { type: "PLAYER_GONE", playerId: named, cause: "LEAVE" }, v.deadline! - 8_000);
    expect(gone.phase).toBe("CARD");
    expect(gone.card!.cardId).not.toBe(v.card!.cardId);
    expect(gone.votes).toEqual({});
    expect(gone.cardIndex).toBe(v.cardIndex);
  });
  it("start fails cleanly", () => {
    const r = DEF.start({ roster: roster(2), settings: settings(), locale: "en", memory: { usedKeys: [] }, seed: 1, now: T0, graceMs: GRACE, content: CATALOG });
    expect(r).toMatchObject({ ok: false, error: "NOT_ENOUGH_PLAYERS" });
  });
  it("memory: usedKeys + every drawn card, oldest dropped beyond 300", () => {
    const old = Array.from({ length: 300 }, (_, i) => `old-${i}`);
    const s = startGame(3, {}, { usedKeys: old });
    const m = DEF.memory(s).usedKeys;
    expect(m).toHaveLength(300);
    expect(m[m.length - 1]).toBe(s.card!.cardId);
    expect(m[0]).toBe("old-1");
  });
  it("is deterministic: same seed and actions → equal states", () => {
    const run = () => { let s = startGame(5, {}, { seed: 99 }); for (let i = 0; i < 8; i++) s = tick(playCard(s, { p1: "p3", p2: "p3" })); return s; };
    expect(JSON.stringify(run())).toBe(JSON.stringify(run()));
  });
  it("TICK before the deadline and unknown AWAY/BACK return the same object", () => {
    const s = startGame(3);
    expect(step(s, { type: "TICK" }, T0 + 1)).toBe(s);
    expect(step(s, { type: "PLAYER_AWAY", playerId: "zz" }, T0 + 1)).toBe(s);
    expect(step(s, { type: "PLAYER_BACK", playerId: "p1" }, T0 + 1)).toBe(s);
  });
});
