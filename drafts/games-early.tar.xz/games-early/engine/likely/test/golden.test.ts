// §2.8: golden snapshot of one seeded game (public mode, 4 players, short).
import { describe, expect, it } from "vitest";
import { CATALOG, DEF, playCard, startGame, tick } from "./helpers";

const PLAN: Record<string, string>[] = [
  { p1: "p2", p2: "p2", p3: "p2", p4: "p2" },  // unanimous
  { p1: "p3", p2: "p4", p3: "p1", p4: "p2" },  // chaos
  { p1: "p1", p2: "p1", p3: "p1", p4: "p3" },  // self-aware p1
  { p1: "p4", p2: "p4", p3: "p3", p4: "p3" },  // tie
  { p1: "p2" },                                // one vote
  {},                                          // none
  { p1: "p3", p2: "p3", p3: "p2" },            // p4 abstains
  { p1: "p2", p2: "p2", p3: "p1", p4: "p1" },  // tie
];

describe("golden", () => {
  it("seeded public game", () => {
    let s = startGame(4, { length: "short" }, { seed: 2026 });
    const reveals: unknown[] = [];
    for (const b of PLAN) {
      s = playCard(s, b);
      const v = DEF.projectPublic(s, CATALOG);
      reveals.push({ card: v.card!.id, reveal: v.reveal, scores: v.scores });
      s = tick(s);
    }
    const awards = DEF.projectPublic(s, CATALOG).awards;
    s = tick(s);
    expect({ reveals, awards, outcome: DEF.outcome(s), memory: DEF.memory(s) }).toMatchSnapshot();
    expect(DEF.outcome(s)!.points).toEqual({ p1: 750, p2: 750, p3: 600, p4: 500 });
  });
});
