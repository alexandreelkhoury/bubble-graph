// JAMAA-PLATFORM §2.11 / GAME-LIKELY §8.1: for showVoters=false, two games with identical per-card tallies but a different
// voter→target mapping give byte-identical TV views, and byte-identical views for every phone whose own vote is the same
// in both games, in every phase including AWARDS and RESULTS.
import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { isTarget, type LikelyState } from "../src";
import { CATALOG, DEF, T0, ctx, ids, roster, settings } from "./helpers";

interface CardPlan { voters: boolean[]; targets: number[]; permKeys: number[]; decoysA: number[]; decoysB: number[]; skip: boolean }
const cardPlan = fc.record({
  voters: fc.array(fc.boolean(), { minLength: 12, maxLength: 12 }),
  targets: fc.array(fc.nat(11), { minLength: 12, maxLength: 12 }),
  permKeys: fc.array(fc.double({ noNaN: true }), { minLength: 12, maxLength: 12 }),
  decoysA: fc.array(fc.integer({ min: -1, max: 11 }), { minLength: 12, maxLength: 12 }),
  decoysB: fc.array(fc.integer({ min: -1, max: 11 }), { minLength: 12, maxLength: 12 }),
  skip: fc.boolean(),
});

function views(s: LikelyState) {
  return {
    tv: JSON.stringify(DEF.projectPublic(s, CATALOG)),
    status: JSON.stringify(DEF.projectStatus(s)),
    me: Object.fromEntries(s.players.map((p) => [p.id, DEF.projectMe(s, p.id)])),
  };
}

function compare(a: LikelyState, b: LikelyState, where: string, mismatch: { n: number }): void {
  const va = views(a), vb = views(b);
  expect(va.tv, `${where}: TV view`).toBe(vb.tv);
  expect(va.status, `${where}: status`).toBe(vb.status);
  for (const id of Object.keys(va.me)) {
    const ma = va.me[id]!, mb = vb.me[id]!;
    if (ma?.myVote !== mb?.myVote) { mismatch.n++; continue; }
    expect(JSON.stringify(ma), `${where}: me of ${id}`).toBe(JSON.stringify(mb));
  }
  for (const s of [a, b]) {
    expect(DEF.leakCheck(s, null, DEF.projectPublic(s, CATALOG))).toEqual([]);
    for (const p of s.players) expect(DEF.leakCheck(s, p.id, { pub: DEF.projectPublic(s, CATALOG), me: DEF.projectMe(s, p.id) })).toEqual([]);
  }
}

describe("anonymity differential property", () => {
  it("same tallies, different voter mapping → identical TV views and identical views for same-vote phones", () => {
    let differentMappings = 0;
    fc.assert(fc.property(
      fc.integer({ min: 3, max: 12 }), fc.integer({ min: 0, max: 2 ** 31 }), fc.constantFrom<"family" | "spicy">("family", "spicy"),
      fc.array(cardPlan, { minLength: 8, maxLength: 8 }),
      (n, seed, mode, plans: CardPlan[]) => {
        const start = () => {
          const r = DEF.start({ roster: roster(n), settings: settings({ showVoters: false, mode, length: "short" }), locale: "ar", memory: { usedKeys: [] }, seed, now: T0, graceMs: 2_500, content: CATALOG });
          if (!r.ok) throw new Error(r.error);
          return r.state;
        };
        let A = start(), B = start();
        const mismatch = { n: 0 };
        const both = (f: (s: LikelyState) => LikelyState, where: string) => { A = f(A); B = f(B); DEF.assertInvariants(A); DEF.assertInvariants(B); compare(A, B, where, mismatch); };
        const red = (s: LikelyState, a: Parameters<typeof DEF.reduce>[1], now: number) => DEF.reduce(s, a, ctx(now)).state;
        compare(A, B, "start", mismatch);
        let k = 0;
        let guard = 0;
        while (A.phase !== "RESULTS") {
          if (++guard > 200) throw new Error("did not terminate");
          if (A.phase !== "CARD") { both((s) => red(s, { type: "TICK" }, s.deadline ?? T0), `tick ${A.phase}`); continue; }
          const plan = plans[k++ % plans.length]!;
          if (plan.skip && k % 3 === 0) { both((s) => red(s, { type: "INTENT", intent: { a: "SKIP_CARD", cardId: s.card!.cardId }, by: { kind: "tv" } }, s.deadline! - 1), "skip"); continue; }
          both((s) => red(s, { type: "TICK" }, s.deadline!), "open voting");
          const now = A.deadline! - 17_000;
          const targets = A.players.filter((p) => isTarget(A, p.id)).map((p) => p.id);
          const voters = ids(n).filter((_, i) => plan.voters[i]);
          const final = voters.map((_, i) => targets[plan.targets[i]! % targets.length]!);
          // B: the same multiset of targets, assigned to the same voters in another order → identical tallies
          const order = voters.map((_, i) => i).sort((x, y) => plan.permKeys[x]! - plan.permKeys[y]! || x - y);
          const finalB = order.map((i) => final[i]!);
          if (finalB.some((t, i) => t !== final[i])) differentMappings++;
          const decoy = (d: number) => (d < 0 ? null : targets[d % targets.length]!);
          voters.forEach((v, i) => {
            const dA = decoy(plan.decoysA[i]!), dB = decoy(plan.decoysB[i]!);
            const by = { kind: "player" as const, playerId: v };
            const cardId = A.card!.cardId;
            if (dA) A = red(A, { type: "INTENT", intent: { a: "VOTE", cardId, targetId: dA }, by }, now + i);
            if (dB) B = red(B, { type: "INTENT", intent: { a: "VOTE", cardId, targetId: dB }, by }, now + i);
            A = red(A, { type: "INTENT", intent: { a: "VOTE", cardId, targetId: final[i]! }, by }, now + i);
            B = red(B, { type: "INTENT", intent: { a: "VOTE", cardId, targetId: finalB[i]! }, by }, now + i);
            DEF.assertInvariants(A); DEF.assertInvariants(B);
            compare(A, B, `vote ${v}`, mismatch);
          });
          while ((A as LikelyState).phase === "VOTING") both((s) => red(s, { type: "TICK" }, s.deadline!), "close voting");
        }
        // AWARDS and RESULTS were compared by the tick steps above; the phones' `me` there carries no vote.
        expect(DEF.outcome(A)).toEqual(DEF.outcome(B));
        expect(JSON.stringify(DEF.memory(A))).toBe(JSON.stringify(DEF.memory(B)));
      },
    ), { numRuns: Number(process.env.FC_RUNS ?? 120) });
    expect(differentMappings).toBeGreaterThan(50); // the property really exercised different mappings
  });

  it("control: in public mode a different mapping IS visible (the test above is sensitive)", () => {
    const play = (b: Record<string, string>) => {
      let s = DEF.start({ roster: roster(3), settings: settings({ showVoters: true }), locale: "en", memory: { usedKeys: [] }, seed: 5, now: T0, graceMs: 0, content: CATALOG }).state;
      s = DEF.reduce(s, { type: "TICK" }, ctx(s.deadline!)).state;
      for (const [v, t] of Object.entries(b)) s = DEF.reduce(s, { type: "INTENT", intent: { a: "VOTE", cardId: s.card!.cardId, targetId: t }, by: { kind: "player", playerId: v } }, ctx(T0 + 5_000)).state;
      s = DEF.reduce(s, { type: "TICK" }, ctx(s.deadline!)).state;
      return s;
    };
    const a = play({ p1: "p2", p2: "p3", p3: "p3" });
    const b = play({ p1: "p3", p2: "p3", p3: "p2" });
    expect(a.results[0]!.counts).toEqual(b.results[0]!.counts);
    expect(JSON.stringify(DEF.projectPublic(a, CATALOG))).not.toBe(JSON.stringify(DEF.projectPublic(b, CATALOG)));
  });
});
