// GAME-TRIVIA §8.1 secrecy and §13.2 view: TriviaPublic, TriviaMe, envelope status, setup extras, and the leak oracles.
// The correct position, per-option correctness and other players' choices exist in a view ONLY in REVEAL.
import { LENGTHS, VIEW_VERSION, type QuestionType } from "./constants";
import { quizCard, quizzesFor, resolveQuiz, type QuizCard, type Topic, type TriviaCatalog } from "./content";
import { awaited, canPlay, current, isFinalIndex, type Phase, type QuestionResult, type QuizInfo, type TriviaState } from "./engine";
import type { Locale, RoomAccess, RosterEntry } from "./platform";
import { rankRows } from "./scoring";
import type { TriviaSettings } from "./settings";

export interface RevealView {
  correct: number;                                   // displayed position of the right answer
  choices: { id: string; choice: number | null; correct: boolean; timeMs: number | null; points: number; streakBonus: number }[];
  fastestIds: string[]; onFireIds: string[];
  stumped: boolean; genius: boolean; tooSlow: boolean;
  explain: string | null;
  voided: boolean;
}
export interface ScoreRow {
  playerId: string; score: number; scoreBefore: number; streak: number;
  correctCount: number;                              // §13.2 calls it `correct`; renamed so a `correct` key never exists before REVEAL
  rank: number; bestStreak: number; fastestCount: number; left: boolean; isNew: boolean;
}
export interface TriviaPublic {
  schema: number;
  phase: Phase;
  quiz: Omit<QuizInfo, "packId">;
  index: number;                                     // 0-based; the TV shows index + 1 / total
  total: number;
  isFinal: boolean;
  deadline: number | null;
  question: { id: string; text: string; type: QuestionType; topic: Topic; difficulty: 1 | 2 | 3 } | null;
  options: string[];                                 // ANSWER and REVEAL only, displayed order (A..D / True, False)
  answeredIds: string[];
  reveal: RevealView | null;
  scores: ScoreRow[];
  rerun: boolean;
}
export interface TriviaMe { myChoice: number | null; myTimeMs: number | null; waitingForNext: boolean; isNew: boolean; rank: number | null }

const QUESTION_PHASES: readonly Phase[] = ["READ", "ANSWER", "REVEAL"];
const lastResult = (s: TriviaState): QuestionResult | undefined => s.results[s.results.length - 1];

export function scoreRows(s: TriviaState): ScoreRow[] {
  const r = s.phase === "REVEAL" || s.phase === "LEADERBOARD" ? lastResult(s) : undefined;
  const playing = QUESTION_PHASES.includes(s.phase);
  return rankRows(s.players).map((p) => ({
    playerId: p.id, score: p.score, scoreBefore: r?.before.find((b) => b.id === p.id)?.score ?? p.score, streak: p.streak,
    correctCount: p.correct, rank: p.rank, bestStreak: p.bestStreak, fastestCount: p.fastestCount, left: p.left,
    isNew: playing && p.joinedAt === s.index,
  }));
}

export function projectPublic(s: TriviaState, _content?: TriviaCatalog): TriviaPublic {
  const q = current(s);
  const showQ = q !== undefined && QUESTION_PHASES.includes(s.phase);
  const showOptions = q !== undefined && (s.phase === "ANSWER" || s.phase === "REVEAL");
  const r = s.phase === "REVEAL" ? lastResult(s) : undefined;
  const { packId: _p, ...quiz } = s.quiz;
  return {
    schema: VIEW_VERSION,
    phase: s.phase,
    quiz: { ...quiz, featuredTopics: [...quiz.featuredTopics] },
    index: s.index,
    total: s.questions.length,
    isFinal: s.phase === "FINAL_INTRO" || (QUESTION_PHASES.includes(s.phase) && isFinalIndex(s, s.index)),
    deadline: s.deadline,
    question: showQ ? { id: q.id, text: q.text, type: q.type, topic: q.topic, difficulty: q.difficulty } : null,
    options: showOptions ? [...q.options] : [],
    answeredIds: s.phase === "ANSWER" ? s.players.filter((p) => s.answers[p.id]).map((p) => p.id)
      : r ? r.choices.filter((c) => c.choice !== null).map((c) => c.id) : [],
    reveal: r ? {
      correct: r.correctIndex,
      choices: r.choices.map((c) => ({ ...c })),
      fastestIds: [...r.fastestIds], onFireIds: [...r.onFireIds],
      stumped: r.stumped, genius: r.genius, tooSlow: r.tooSlow,
      explain: s.questions[r.index]?.explain ?? null,
      voided: r.voided,
    } : null,
    scores: scoreRows(s),
    rerun: s.rerun,
  };
}

export function projectMe(s: TriviaState, playerId: string): TriviaMe | null {
  const p = s.players.find((x) => x.id === playerId);
  if (!p) return null;
  let myChoice: number | null = null;
  let myTimeMs: number | null = null;
  if (s.phase === "ANSWER") {
    const a = s.answers[p.id];
    if (a) { myChoice = a.choice; myTimeMs = a.timeMs; }
  } else if (s.phase === "REVEAL") {
    const c = lastResult(s)?.choices.find((x) => x.id === p.id);
    if (c) { myChoice = c.choice; myTimeMs = c.timeMs; }
  }
  const row = scoreRows(s).find((x) => x.playerId === p.id);
  return { myChoice, myTimeMs, waitingForNext: p.waiting, isNew: row?.isNew ?? false, rank: row?.rank ?? null };
}

/** Same secrecy as Pub: who answered, never what. */
export function projectStatus(s: TriviaState): { phase: string; doneIds: string[]; awaitedIds: string[] } {
  if (s.phase !== "ANSWER") return { phase: s.phase, doneIds: [], awaitedIds: [] };
  return { phase: s.phase, doneIds: s.players.filter((p) => s.answers[p.id]).map((p) => p.id), awaitedIds: awaited(s).map((p) => p.id) };
}

export interface TriviaSetupExtras {
  available: number;            // questions in the resolved quiz for the content language
  questionCount: number;        // what this length will actually play (capped)
  capped: boolean;              // "7 questions available"
  quiz: QuizCard | null;        // the summary card (one quiz) / the selected card
  quizzes: QuizCard[];          // ≥ 2 playable quizzes: the shelf/VIP list; [] when the quizId row is hidden
}
export function projectSetup(s: TriviaSettings, _roster: readonly RosterEntry[], content: TriviaCatalog, _access: RoomAccess, locale: Locale): TriviaSetupExtras {
  const pack = resolveQuiz(content, s.quizId, locale);
  const available = pack?.questions.length ?? 0;
  const all = quizzesFor(content, locale);
  return {
    available,
    questionCount: Math.min(LENGTHS[s.length], available),
    capped: available < LENGTHS[s.length],
    quiz: pack ? quizCard(pack) : null,
    quizzes: all.length >= 2 ? all.map(quizCard) : [],
  };
}

// ─── leak oracles ────────────────────────────────────────────────────────────────────────────────────────────────────

/** Platform forbidden keys: state-only names that never appear in any view. */
export const FORBIDDEN_KEYS = ["answers", "correctIndex", "order", "rngState", "usedKeys", "source"] as const;

/** Secret leaf values now: texts, options and explanations of questions not yet shown; the options of a question in READ;
 *  the explanation of the current question before REVEAL. Whole-leaf equality (use the synthetic unique-token catalog). */
export function secretsFor(s: TriviaState, _viewer: string | null): readonly unknown[] {
  if (s.phase === "RESULTS") return [];
  const out: unknown[] = [];
  const currentShown = s.phase !== "QUIZ_INTRO" && s.phase !== "HOLD";
  const currentRevealed = s.phase === "REVEAL" || s.phase === "LEADERBOARD" || s.phase === "FINAL_INTRO";
  s.questions.forEach((q, i) => {
    const shown = i < s.index || (i === s.index && currentShown);
    const revealed = i < s.index || (i === s.index && currentRevealed);
    if (!shown) out.push(q.text, ...q.options);
    else if (i === s.index && s.phase === "READ") out.push(...q.options);
    if (!revealed && q.explain) out.push(q.explain);
  });
  return out;
}

function walk(v: unknown, path: string, visit: (key: string, path: string, value: unknown) => void): void {
  if (Array.isArray(v)) { v.forEach((x, i) => walk(x, `${path}[${i}]`, visit)); return; }
  if (typeof v === "object" && v !== null) {
    for (const [k, x] of Object.entries(v)) { visit(k, `${path}.${k}`, x); walk(x, `${path}.${k}`, visit); }
  }
}

/**
 * Structural rules (§13.3 invariant 1). `view` is the TV's Pub, or a player's `{ pub, me }`.
 * Before REVEAL (READ, ANSWER): no `reveal`, no `correct`/`isCorrect` key anywhere, no `choice` key, and the only
 * choice present is the viewer's own `me.myChoice`. READ: no options. Outside REVEAL: `reveal` is null.
 */
export function leakCheck(s: TriviaState, viewer: string | null, view: unknown): string[] {
  const out: string[] = [];
  const v = view as Record<string, unknown> | null;
  const isPair = v !== null && typeof v === "object" && "pub" in v;
  const pub = (isPair ? v.pub : v) as Partial<TriviaPublic> | null;
  const me = (isPair ? v.me : undefined) as Partial<TriviaMe> | null | undefined;
  if (!pub) return ["no view"];
  if (s.phase !== "REVEAL" && pub.reveal !== null && pub.reveal !== undefined) out.push(`reveal present in ${s.phase}`);
  const secretPhase = s.phase === "READ" || s.phase === "ANSWER";
  if (secretPhase) {
    walk(view, "$", (k, path) => {
      if (k === "correct" || k === "isCorrect" || k === "correctIndex" || k === "answer") out.push(`${path} before REVEAL`);
      if (k === "choice" || k === "choices") out.push(`${path}: choices before REVEAL`);
      if (k === "myChoice" && path !== "$.me.myChoice") out.push(`${path}: misplaced myChoice`);
    });
    if (s.phase === "READ" && (pub.options?.length ?? 0) > 0) out.push("options in READ");
  }
  if (viewer === null && me !== undefined && me !== null) out.push("TV view carries a me");
  if (me && viewer !== null) {
    const own = s.phase === "ANSWER" ? s.answers[viewer]?.choice ?? null : me.myChoice;
    if (me.myChoice !== own) out.push(`me.myChoice is not ${viewer}'s own choice`);
    const p = s.players.find((x) => x.id === viewer);
    if (p && me.waitingForNext !== p.waiting) out.push("waitingForNext mismatch");
  }
  // answeredIds: only players who may answer, and never with what
  for (const id of pub.answeredIds ?? []) {
    const p = s.players.find((x) => x.id === id);
    if (!p || !canPlay(p) && s.phase === "ANSWER") out.push(`answeredIds has ${id}`);
  }
  return out;
}
