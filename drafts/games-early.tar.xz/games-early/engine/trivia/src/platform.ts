// Local mirror of the JAMAA-PLATFORM §2.2 contract (shared/src/games/types.ts), so this draft compiles on its own.
// When porting into the repo, delete this file and import the real types from "../types", "../../constants",
// "../../protocol/errors", "../../content/types" and "../ranking".

export type Locale = "en" | "fr" | "ar" | "es";
export const LOCALES: readonly Locale[] = ["en", "fr", "ar", "es"];

export type GameActor = { kind: "tv" } | { kind: "player"; playerId: string };
export interface RosterEntry { id: string; seat: number; locale: Locale; connected: boolean; carryScore: number }

export type GameAction<I> =
  | { type: "INTENT"; intent: I; by: GameActor }
  | { type: "TICK" }
  | { type: "PLAYER_AWAY"; playerId: string }
  | { type: "PLAYER_BACK"; playerId: string }
  | { type: "PLAYER_GONE"; playerId: string; cause: "LEAVE" | "KICK" };

export interface GameCtx<C> { now: number; content: C; isHost: (actor: GameActor) => boolean; hostPlayerId: string | null }

/** Platform codes used by this game plus Trivia's own (games/trivia/errors.ts: ANSWER_INVALID, ALREADY_ANSWERED). */
export type ErrorCode =
  | "WRONG_PHASE" | "NOT_HOST" | "NOT_ENOUGH_PLAYERS" | "NOT_IN_GAME" | "GAME_FULL" | "NO_CONTENT_AVAILABLE"
  | "INVALID_SETTINGS" | "ANSWER_INVALID" | "ALREADY_ANSWERED";

export type GameReduceResult<S> = { ok: true; state: S } | { ok: false; error: ErrorCode; state: S };

export interface GameOutcome { points: Record<string, number>; ranking: string[][] }
export interface GameMemory { usedKeys: string[] }
export const MEMORY_MAX_KEYS = 300;

export interface RoomAccess { premium: boolean; playableIds: ReadonlySet<string> }

export class InvariantError extends Error {
  constructor(message: string) { super(message); this.name = "InvariantError"; }
}

/** Same as shared/src/room/rng.ts (mulberry32). */
export interface Rng { state: number; next(): number; int(n: number): number }
export function createRng(state: number): Rng {
  const r: Rng = {
    state: state >>> 0,
    next() {
      r.state = (r.state + 0x6D2B79F5) >>> 0;
      let t = r.state;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    },
    int(n) { return Math.floor(r.next() * n); },
  };
  return r;
}

/** Same as shared/src/games/ranking.ts. */
export function competitionRanking(points: Readonly<Record<string, number>>, order: readonly string[], exclude: ReadonlySet<string> = new Set()): string[][] {
  const ids = order.filter((id) => !exclude.has(id) && (points[id] ?? 0) > 0);
  const scores = [...new Set(ids.map((id) => points[id] as number))].sort((a, b) => b - a);
  return scores.map((sc) => ids.filter((id) => points[id] === sc));
}
