// GAME-TRIVIA §3, §4, §4.1, §5, §9 numbers. One place, so the doc and the code can be diffed.

export const STATE_SCHEMA = 1;
export const SETTINGS_SCHEMA = 1;
export const VIEW_VERSION = 1;

export const MIN_PLAYERS = 1;
export const MAX_PLAYERS = 12;

/** §4: lengths, capped by the quiz pool. */
export const LENGTHS = { short: 7, normal: 10, long: 15 } as const;
export type LengthId = keyof typeof LENGTHS;

/** §4.1 / §9: ANSWER duration per pace for mc4; tf gets 2/3 of it; rounded to the second. */
export const PACE_MC4_MS = { relaxed: 20_000, normal: 15_000, fast: 10_000 } as const;
export type PaceId = keyof typeof PACE_MC4_MS;
const roundSecond = (ms: number): number => Math.round(ms / 1_000) * 1_000;
export function answerMs(type: QuestionType, pace: PaceId): number {
  const mc4 = PACE_MC4_MS[pace];
  return type === "mc4" ? mc4 : roundSecond((mc4 * 2) / 3);
}

export type QuestionType = "mc4" | "tf";

/** §4.1 phase durations. */
export const QUIZ_INTRO_MS = 4_000;           // + ENTRANCE_GRACE_MS (graceMs at start)
export const READ_BASE_MS = 2_500;
export const READ_PER_CHAR_MS = 40;
export const READ_MIN_MS = 3_000;
export const READ_MAX_MS = 7_000;
export const readMs = (questionChars: number): number =>
  Math.min(READ_MAX_MS, Math.max(READ_MIN_MS, READ_BASE_MS + READ_PER_CHAR_MS * questionChars));
export const EARLY_END_MS = 600;              // all answered → deadline = now + 600
export const REVEAL_MS = 6_000;
export const REVEAL_EXPLAIN_MS = 3_000;
export const LEADERBOARD_MS = 6_000;
export const FINAL_INTRO_MS = 4_000;

/** §5.1 / §5.2 scoring. */
export const GRACE_MS = 300;
export const BASE_POINTS: Record<QuestionType, number> = { mc4: 500, tf: 250 };
export const SPEED_MAX: Record<QuestionType, number> = { mc4: 500, tf: 250 };
export const FINAL_MULTIPLIER = 2;
export const STREAK_STEP = 100;
export const STREAK_CAP = 300;

/** §4: a LEADERBOARD interlude follows every 3rd question. */
export const LEADERBOARD_EVERY = 3;

/** §5.4 highlights. */
export const FASTEST_MIN_CORRECT = 2;
export const GENIUS_MIN_ANSWERS = 3;
export const ON_FIRE_MIN = 3;                 // 3, 5, 7…

/** §11.4 draw. */
export const EASY_ZONE = 0.3;                 // first 30 %
export const HARD_ZONE = 0.3;                 // last 30 %
