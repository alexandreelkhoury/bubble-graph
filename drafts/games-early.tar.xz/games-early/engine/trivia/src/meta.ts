// games/trivia/meta.ts draft (zod-free, engine-free). GAME-TRIVIA §2, §9, §10; platform §2.12.
import { MAX_PLAYERS, MIN_PLAYERS, SETTINGS_SCHEMA, VIEW_VERSION } from "./constants";
import { DEFAULT_SETTINGS, type TriviaSettings } from "./settings";

const K = "game.trivia";
const ALL = ["QUIZ_INTRO", "READ", "ANSWER", "REVEAL", "LEADERBOARD", "FINAL_INTRO", "HOLD", "RESULTS"] as const;

export const TRIVIA_META = {
  id: "trivia" as const,
  minPlayers: MIN_PLAYERS,
  maxPlayers: MAX_PLAYERS,
  phases: ALL,
  rules: {
    titleKey: `${K}.title`,
    taglineKey: `${K}.tagline`,
    howToKeys: [`${K}.howto.1`, `${K}.howto.2`, `${K}.howto.3`, `${K}.howto.4`],
    // GAME-TRIVIA §10.2
    ruleSections: [
      { id: "answer", titleKey: `${K}.rules.answer.title`, bodyKey: `${K}.rules.answer.body`, phases: ["READ", "ANSWER"] },
      { id: "points", titleKey: `${K}.rules.points.title`, bodyKey: `${K}.rules.points.body`, phases: ["ANSWER", "REVEAL"] },
      { id: "streaks", titleKey: `${K}.rules.streaks.title`, bodyKey: `${K}.rules.streaks.body`, phases: ["REVEAL", "LEADERBOARD"] },
      { id: "final", titleKey: `${K}.rules.final.title`, bodyKey: `${K}.rules.final.body`, phases: ["FINAL_INTRO"] },
      { id: "ties", titleKey: `${K}.rules.ties.title`, bodyKey: `${K}.rules.ties.body`, phases: ["LEADERBOARD", "RESULTS"] },
    ],
    durationMinutes: [5, 10] as const,
    world: "quiz-studio" as const,
    // §2 pause menu, in order
    pauseItems: [
      { id: "next", labelKey: `${K}.pause.next`, intent: "HOST_ADVANCE", phases: ["QUIZ_INTRO", "REVEAL", "LEADERBOARD", "FINAL_INTRO"] },
      { id: "void", labelKey: `${K}.pause.void`, intent: "VOID_QUESTION", phases: ["REVEAL"], confirm: true },
      { id: "endGame", labelKey: `${K}.pause.endGame`, intent: "END_GAME", phases: ["HOLD"], confirm: true },
    ],
  },
  carriesScore: false,
  VIEW_VERSION,
  SETTINGS_SCHEMA,
  settings: {
    defaults: DEFAULT_SETTINGS as TriviaSettings,
    basic: [
      // hidden by the platform while only one quiz is playable (a field with 1 possible value)
      { key: "quizId", kind: "packs", labelKey: `${K}.settings.quiz`, single: true },
      { key: "length", kind: "choice", labelKey: `${K}.settings.length`, options: [
        { value: "short", labelKey: `${K}.settings.length.short` }, { value: "normal", labelKey: `${K}.settings.length.normal` }, { value: "long", labelKey: `${K}.settings.length.long` },
      ] },
      { key: "pace", kind: "choice", labelKey: `${K}.settings.pace`, options: [
        { value: "relaxed", labelKey: `${K}.settings.pace.relaxed` }, { value: "normal", labelKey: `${K}.settings.pace.normal` }, { value: "fast", labelKey: `${K}.settings.pace.fast` },
      ] },
    ],
    advanced: [],
    premiumKeys: [] as (keyof TriviaSettings)[],
  },
};
