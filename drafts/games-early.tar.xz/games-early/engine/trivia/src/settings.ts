// GAME-TRIVIA §9 settings: quizId (a FAMILY id, or null = default quiz), length, pace. SETTINGS_SCHEMA = 1.
import { LENGTHS, PACE_MC4_MS, type LengthId, type PaceId } from "./constants";
import { packFor, type TriviaCatalog } from "./content";
import type { Locale } from "./platform";

export interface TriviaSettings { quizId: string | null; length: LengthId; pace: PaceId }
export type TriviaSettingsPatch = Partial<TriviaSettings>;

/** Static defaults (platform §2.2: never access-dependent); key order fixed. */
export const DEFAULT_SETTINGS: TriviaSettings = Object.freeze({ quizId: null, length: "normal", pace: "normal" }) as TriviaSettings;

const FAMILY = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const isFamily = (v: unknown): v is string => typeof v === "string" && v.length <= 35 && FAMILY.test(v);

export function normalize(raw: unknown): TriviaSettings {
  const r = typeof raw === "object" && raw !== null && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  return {
    quizId: isFamily(r.quizId) ? r.quizId : null,
    length: typeof r.length === "string" && Object.hasOwn(LENGTHS, r.length) ? (r.length as LengthId) : DEFAULT_SETTINGS.length,
    pace: typeof r.pace === "string" && Object.hasOwn(PACE_MC4_MS, r.pace) ? (r.pace as PaceId) : DEFAULT_SETTINGS.pace,
  };
}

const same = (a: TriviaSettings, b: TriviaSettings): boolean => a.quizId === b.quizId && a.length === b.length && a.pace === b.pace;

/** null = INVALID_SETTINGS. `quizId` must be a family playable in the content language (or null). Same object if unchanged. */
export function apply(s: TriviaSettings, patch: TriviaSettingsPatch, content: TriviaCatalog, locale: Locale): TriviaSettings | null {
  if (typeof patch !== "object" || patch === null) return null;
  for (const k of Object.keys(patch)) if (k !== "quizId" && k !== "length" && k !== "pace") return null;
  const next: TriviaSettings = { ...s };
  if (patch.quizId !== undefined) {
    if (patch.quizId !== null && (!isFamily(patch.quizId) || !packFor(content, patch.quizId, locale))) return null;
    next.quizId = patch.quizId;
  }
  if (patch.length !== undefined) {
    if (typeof patch.length !== "string" || !Object.hasOwn(LENGTHS, patch.length)) return null;
    next.length = patch.length;
  }
  if (patch.pace !== undefined) {
    if (typeof patch.pace !== "string" || !Object.hasOwn(PACE_MC4_MS, patch.pace)) return null;
    next.pace = patch.pace;
  }
  return same(s, next) ? s : next;
}

/**
 * Access restriction and content-language change: a quiz family that is locked (not in playableIds) or has no pack in
 * `locale` resets to null. A family that exists in the new locale is KEPT (GAME-TRIVIA §2). Same object if unchanged.
 */
export function restrict(s: TriviaSettings, a: { playableIds: ReadonlySet<string>; premium: boolean }, content: TriviaCatalog, locale: Locale): TriviaSettings {
  if (s.quizId === null) return s;
  if (a.playableIds.has(s.quizId) && packFor(content, s.quizId, locale)) return s;
  return { ...s, quizId: null };
}

/** Platform §4.4: the content filter as FAMILY ids. */
export function packIdsOf(s: TriviaSettings): readonly string[] { return s.quizId === null ? [] : [s.quizId]; }
