// GAME-TRIVIA §4–§7: the pure engine. No I/O, no Date.now(), no Math.random(); every time comes from ctx.now / start's
// `now`, the RNG state lives in the state. reduce never mutates its input and returns the SAME object when nothing changed.
import {
  answerMs, EARLY_END_MS, FINAL_INTRO_MS, LEADERBOARD_EVERY, LEADERBOARD_MS, MAX_PLAYERS, MIN_PLAYERS, QUIZ_INTRO_MS, readMs,
  REVEAL_EXPLAIN_MS, REVEAL_MS, STATE_SCHEMA, type QuestionType,
} from "./constants";
import { familyOf, graphemes, resolveQuiz, type Domain, type LocalizedTitle, type Topic, type TriviaCatalog } from "./content";
import { displayOrder, drawQuestions, memoryKey } from "./draw";
import { createRng, InvariantError, MEMORY_MAX_KEYS, type ErrorCode, type GameAction, type GameActor, type GameCtx, type GameMemory, type GameOutcome, type GameReduceResult, type Locale, type RosterEntry } from "./platform";
import { answerTime, highlights, isOnFire, rankGroups, scoreAnswer } from "./scoring";
import type { TriviaSettings } from "./settings";

export const PHASES = ["QUIZ_INTRO", "READ", "ANSWER", "REVEAL", "LEADERBOARD", "FINAL_INTRO", "HOLD", "RESULTS"] as const;
export type Phase = (typeof PHASES)[number];
/** Phases the host may end early with HOST_ADVANCE (§4.1; READ and ANSWER never: fairness). */
export const ADVANCEABLE: readonly Phase[] = ["QUIZ_INTRO", "REVEAL", "LEADERBOARD", "FINAL_INTRO"];

export type TriviaIntent =
  | { a: "ANSWER"; choice: number }
  | { a: "HOST_ADVANCE" }
  | { a: "VOID_QUESTION"; questionId: string }
  | { a: "END_GAME" };

export interface PlayerState {
  id: string; seat: number;
  connected: boolean; left: boolean;
  waiting: boolean;              // joined mid-game: watches until the next READ (§6)
  joinedAt: number | null;       // index of the first question a late joiner plays ("New" ribbon); null = dealt in at start
  score: number; streak: number; bestStreak: number;
  correct: number;               // correct answers (tie-break 1)
  timeSum: number;               // Σ t of correct answers, ms (tie-break 2)
  fastestCount: number;          // "Fastest finger" count (results stats)
}

/** A drawn question, frozen at start, options in DISPLAYED order. `correctIndex` is STATE ONLY until REVEAL. */
export interface QuestionSnap {
  id: string; type: QuestionType; text: string; options: string[];
  correctIndex: number; topic: Topic; difficulty: 1 | 2 | 3; explain: string | null;
  readMs: number; answerMs: number;
}
export interface QuizInfo {
  id: string;                    // family
  packId: string; title: LocalizedTitle; stars: 1 | 2 | 3; domain: Domain;
  featuredTopics: Topic[]; topicCount: number; questionCount: number;
}
export interface Answer { choice: number; timeMs: number }
export interface ChoiceResult { id: string; choice: number | null; correct: boolean; timeMs: number | null; points: number; streakBonus: number }
export interface Before { id: string; score: number; streak: number; bestStreak: number; correct: number; timeSum: number; fastestCount: number }
export interface QuestionResult {
  index: number; questionId: string; correctIndex: number;
  choices: ChoiceResult[];       // dealt-in, non-left players at reveal, seat order
  fastestIds: string[]; onFireIds: string[]; stumped: boolean; genius: boolean; tooSlow: boolean;
  voided: boolean;
  before: Before[];              // snapshot for VOID_QUESTION (§6)
}

export interface TriviaState {
  schema: typeof STATE_SCHEMA;
  phase: Phase;
  settings: TriviaSettings;
  locale: Locale;
  quiz: QuizInfo;
  questions: QuestionSnap[];
  index: number;                 // current question (READ/ANSWER/REVEAL), last revealed (LEADERBOARD/FINAL_INTRO), next (HOLD)
  shown: number;                 // questions that reached READ (memory)
  deadline: number | null;
  answerOpenAt: number | null;
  earlyEnd: boolean;
  holdAt: number | null;
  players: PlayerState[];        // seat order
  answers: Record<string, Answer>; // current question; STATE ONLY before REVEAL
  results: QuestionResult[];
  rerun: boolean;                // the quiz card shows "Rerun" (§6)
  voidedQuestionIds: string[];   // the content-review report (§6)
  usedKeys: string[];            // platform memory at start; STATE ONLY
  rngState: number;              // STATE ONLY
}

const ok = <S>(state: S): GameReduceResult<S> => ({ ok: true, state });
const err = <S>(error: ErrorCode, state: S): GameReduceResult<S> => ({ ok: false, error, state });
const clone = (s: TriviaState): TriviaState => structuredClone(s);

export const current = (s: TriviaState): QuestionSnap | undefined => s.questions[s.index];
export const total = (s: TriviaState): number => s.questions.length;
export const isFinalIndex = (s: TriviaState, i: number): boolean => i === s.questions.length - 1;
/** Who may answer the current question: dealt in and not left. */
export const canPlay = (p: PlayerState): boolean => !p.left && !p.waiting;
/** Who the early end waits for: connected players who may answer. */
export const awaited = (s: TriviaState): PlayerState[] => s.players.filter((p) => canPlay(p) && p.connected && !s.answers[p.id]);

// ─── start / startBlocker ──────────────────────────────────────────────────────────────────────────────────────────

export function startBlocker(roster: readonly RosterEntry[], settings: TriviaSettings, content: TriviaCatalog, locale: Locale): ErrorCode | null {
  if (roster.filter((r) => r.connected).length < MIN_PLAYERS) return "NOT_ENOUGH_PLAYERS";
  if (roster.length > MAX_PLAYERS) return "GAME_FULL";
  const quiz = resolveQuiz(content, settings.quizId, locale);
  if (!quiz || quiz.questions.length === 0) return "NO_CONTENT_AVAILABLE";
  return null;
}

export function start(a: { roster: readonly RosterEntry[]; settings: TriviaSettings; locale: Locale; memory: GameMemory; seed: number; now: number; graceMs: number; content: TriviaCatalog }): GameReduceResult<TriviaState | null> {
  const blocker = startBlocker(a.roster, a.settings, a.content, a.locale);
  if (blocker) return { ok: false, error: blocker, state: null };
  const pack = resolveQuiz(a.content, a.settings.quizId, a.locale)!;
  const rng = createRng(a.seed);
  const { questions, rerun } = drawQuestions(pack, a.settings.length, a.memory.usedKeys, a.locale, rng);
  const snaps: QuestionSnap[] = questions.map((q) => {
    const order = displayOrder(q, rng);
    return {
      id: q.id, type: q.type, text: q.text, options: order.map((i) => q.options[i] as string), correctIndex: order.indexOf(q.answer),
      topic: q.topic, difficulty: q.difficulty, explain: q.explain ?? null,
      readMs: readMs(graphemes(q.text)), answerMs: answerMs(q.type, a.settings.pace),
    };
  });
  const state: TriviaState = {
    schema: STATE_SCHEMA,
    phase: "QUIZ_INTRO",
    settings: { ...a.settings },
    locale: a.locale,
    quiz: {
      id: familyOf(pack), packId: pack.id, title: pack.title, stars: pack.stars, domain: pack.domain,
      featuredTopics: [...pack.featuredTopics], topicCount: pack.topics.length, questionCount: pack.questions.length,
    },
    questions: snaps,
    index: 0, shown: 0,
    deadline: a.now + a.graceMs + QUIZ_INTRO_MS,
    answerOpenAt: null, earlyEnd: false, holdAt: null,
    players: [...a.roster].sort((x, y) => x.seat - y.seat).map((r) => ({
      id: r.id, seat: r.seat, connected: r.connected, left: false, waiting: false, joinedAt: null,
      score: 0, streak: 0, bestStreak: 0, correct: 0, timeSum: 0, fastestCount: 0,
    })),
    answers: {},
    results: [],
    rerun,
    voidedQuestionIds: [],
    usedKeys: [...a.memory.usedKeys],
    rngState: rng.state,
  };
  return ok(state);
}

// ─── transitions (all on a draft) ────────────────────────────────────────────────────────────────────────────────────

function beginQuestion(d: TriviaState, i: number, now: number): void {
  d.index = i;
  d.answers = {};
  d.answerOpenAt = null;
  d.earlyEnd = false;
  if (!d.players.some((p) => !p.left && p.connected)) {
    d.phase = "HOLD";
    d.deadline = null;
    d.holdAt = now;
    return;
  }
  d.holdAt = null;
  for (const p of d.players) if (!p.left && p.waiting) { p.waiting = false; p.joinedAt = i; }
  d.phase = "READ";
  d.shown = Math.max(d.shown, i + 1);
  d.deadline = now + (d.questions[i] as QuestionSnap).readMs;
}

function openAnswer(d: TriviaState, now: number): void {
  d.phase = "ANSWER";
  d.answerOpenAt = now;
  d.earlyEnd = false;
  d.deadline = now + (current(d) as QuestionSnap).answerMs;
}

function maybeEarlyEnd(d: TriviaState, now: number): void {
  if (d.phase !== "ANSWER" || d.earlyEnd) return;
  const eligible = d.players.filter((p) => canPlay(p) && p.connected);
  if (eligible.length === 0 || eligible.some((p) => !d.answers[p.id])) return;
  d.earlyEnd = true;
  d.deadline = Math.min(d.deadline ?? Infinity, now + EARLY_END_MS);
}

function reveal(d: TriviaState, now: number): void {
  const q = current(d) as QuestionSnap;
  const isFinal = isFinalIndex(d, d.index);
  const before: Before[] = d.players.map((p) => ({ id: p.id, score: p.score, streak: p.streak, bestStreak: p.bestStreak, correct: p.correct, timeSum: p.timeSum, fastestCount: p.fastestCount }));
  const rows = d.players.filter(canPlay).map((p) => {
    const a = d.answers[p.id];
    const correct = !!a && a.choice === q.correctIndex;
    const sc = scoreAnswer({ correct, type: q.type, t: a ? a.timeMs : null, T: q.answerMs, isFinal, prevStreak: p.streak });
    return { p, a, correct, sc };
  });
  const choices: ChoiceResult[] = rows.map(({ p, a, correct, sc }) => ({ id: p.id, choice: a ? a.choice : null, correct, timeMs: a ? a.timeMs : null, points: sc.points, streakBonus: sc.streakBonus }));
  const h = highlights(choices);
  const onFireIds: string[] = [];
  for (const { p, a, correct, sc } of rows) {
    p.score += sc.points + sc.streakBonus;
    p.streak = sc.streak;
    p.bestStreak = Math.max(p.bestStreak, sc.streak);
    if (correct && a) { p.correct += 1; p.timeSum += a.timeMs; }
    if (h.fastestIds.includes(p.id)) p.fastestCount += 1;
    if (correct && isOnFire(sc.streak)) onFireIds.push(p.id);
  }
  d.results.push({ index: d.index, questionId: q.id, correctIndex: q.correctIndex, choices, fastestIds: h.fastestIds, onFireIds, stumped: h.stumped, genius: h.genius, tooSlow: h.tooSlow, voided: false, before });
  d.phase = "REVEAL";
  d.answers = {};               // the choices now live in the result
  d.earlyEnd = false;
  d.deadline = now + REVEAL_MS + (q.explain ? REVEAL_EXPLAIN_MS : 0);
}

/** §4: after REVEAL of question i (0-based), a LEADERBOARD follows every 3rd question and precedes the final (once ≥ 3 played). */
export function leaderboardDue(s: TriviaState, i: number): boolean {
  const played = i + 1;
  return played % LEADERBOARD_EVERY === 0 || (isFinalIndex(s, i + 1) && played >= LEADERBOARD_EVERY);
}

function toResults(d: TriviaState): void {
  d.phase = "RESULTS";
  d.deadline = null;
  d.holdAt = null;
  d.answers = {};
}

/** The phase's deadline passed (TICK) or the host advanced it (HOST_ADVANCE expires inline, platform §2.6). */
function expire(d: TriviaState, now: number): void {
  switch (d.phase) {
    case "QUIZ_INTRO": beginQuestion(d, 0, now); return;
    case "READ": openAnswer(d, now); return;
    case "ANSWER": reveal(d, now); return;
    case "REVEAL": {
      if (isFinalIndex(d, d.index)) { toResults(d); return; }
      if (leaderboardDue(d, d.index)) { d.phase = "LEADERBOARD"; d.deadline = now + LEADERBOARD_MS; return; }
      if (isFinalIndex(d, d.index + 1)) { d.phase = "FINAL_INTRO"; d.deadline = now + FINAL_INTRO_MS; return; }
      beginQuestion(d, d.index + 1, now);
      return;
    }
    case "LEADERBOARD":
      if (isFinalIndex(d, d.index + 1)) { d.phase = "FINAL_INTRO"; d.deadline = now + FINAL_INTRO_MS; return; }
      beginQuestion(d, d.index + 1, now);
      return;
    case "FINAL_INTRO": beginQuestion(d, d.index + 1, now); return;
    case "HOLD": beginQuestion(d, d.index, now); return;   // only reached once someone is connected
    case "RESULTS": return;
  }
}

// ─── reduce ──────────────────────────────────────────────────────────────────────────────────────────────────────────

export function reduce(s: TriviaState, a: GameAction<TriviaIntent>, ctx: GameCtx<TriviaCatalog>): GameReduceResult<TriviaState> {
  const now = ctx.now;
  switch (a.type) {
    case "TICK": {
      if (s.deadline === null || now < s.deadline) return ok(s);
      const d = clone(s);
      if (d.phase === "HOLD" && !d.players.some((p) => !p.left && p.connected)) { d.deadline = null; return ok(d); }
      expire(d, now);
      return ok(d);
    }
    case "PLAYER_AWAY": case "PLAYER_BACK": case "PLAYER_GONE": {
      const i = s.players.findIndex((p) => p.id === a.playerId);
      if (i < 0) return ok(s);
      const p = s.players[i] as PlayerState;
      if (p.left) return ok(s);
      const d = clone(s);
      const dp = d.players[i] as PlayerState;
      if (a.type === "PLAYER_AWAY") dp.connected = false;
      else if (a.type === "PLAYER_BACK") dp.connected = true;
      else { dp.left = true; dp.connected = false; delete d.answers[dp.id]; }
      if (d.phase === "HOLD" && a.type === "PLAYER_BACK") beginQuestion(d, d.index, now);
      maybeEarlyEnd(d, now);
      return ok(d);
    }
    case "INTENT": return intent(s, a.intent, a.by, ctx);
  }
}

function intent(s: TriviaState, i: TriviaIntent, by: GameActor, ctx: GameCtx<TriviaCatalog>): GameReduceResult<TriviaState> {
  const now = ctx.now;
  switch (i.a) {
    case "ANSWER": {
      if (s.phase !== "ANSWER") return err("WRONG_PHASE", s);
      if (by.kind !== "player") return err("NOT_IN_GAME", s);
      const p = s.players.find((x) => x.id === by.playerId);
      if (!p || p.left) return err("NOT_IN_GAME", s);
      if (p.waiting) return err("WRONG_PHASE", s);
      const q = current(s) as QuestionSnap;
      if (typeof i.choice !== "number" || !Number.isInteger(i.choice) || i.choice < 0 || i.choice >= q.options.length) return err("ANSWER_INVALID", s);
      if (s.answers[p.id]) return err("ALREADY_ANSWERED", s);
      const d = clone(s);
      // Server receipt time only (§5.1): the intent carries no client time.
      d.answers[p.id] = { choice: i.choice, timeMs: answerTime(now, d.answerOpenAt as number, q.answerMs) };
      maybeEarlyEnd(d, now);
      return ok(d);
    }
    case "HOST_ADVANCE": {
      if (!ctx.isHost(by)) return err("NOT_HOST", s);
      if (!ADVANCEABLE.includes(s.phase)) return err("WRONG_PHASE", s);
      const d = clone(s);
      expire(d, now);
      return ok(d);
    }
    case "VOID_QUESTION": {
      if (!ctx.isHost(by)) return err("NOT_HOST", s);
      if (s.phase !== "REVEAL") return err("WRONG_PHASE", s);
      const r = s.results[s.results.length - 1] as QuestionResult;
      if (i.questionId !== r.questionId) return err("WRONG_PHASE", s); // stale pause menu (open issue: no STALE code)
      if (r.voided) return ok(s);
      const d = clone(s);
      const dr = d.results[d.results.length - 1] as QuestionResult;
      for (const b of dr.before) {
        const p = d.players.find((x) => x.id === b.id);
        if (!p) continue;
        p.score = b.score; p.streak = b.streak; p.bestStreak = b.bestStreak; p.correct = b.correct; p.timeSum = b.timeSum; p.fastestCount = b.fastestCount;
      }
      dr.voided = true;
      for (const c of dr.choices) { c.points = 0; c.streakBonus = 0; }
      dr.fastestIds = []; dr.onFireIds = [];
      d.voidedQuestionIds.push(dr.questionId);
      return ok(d);
    }
    case "END_GAME": {
      if (!ctx.isHost(by)) return err("NOT_HOST", s);
      if (s.phase !== "HOLD") return err("WRONG_PHASE", s);
      const d = clone(s);
      toResults(d);
      return ok(d);
    }
  }
}

// ─── join / platform hooks ───────────────────────────────────────────────────────────────────────────────────────────

/** A member who joined while PLAYING: plays from the next READ with 0 points (§6). */
export function join(s: TriviaState, entry: RosterEntry): GameReduceResult<TriviaState> {
  if (s.players.some((p) => p.id === entry.id)) return ok(s);
  if (s.players.filter((p) => !p.left).length >= MAX_PLAYERS) return err("GAME_FULL", s);
  const d = clone(s);
  d.players.push({ id: entry.id, seat: entry.seat, connected: entry.connected, left: false, waiting: true, joinedAt: null, score: 0, streak: 0, bestStreak: 0, correct: 0, timeSum: 0, fastestCount: 0 });
  d.players.sort((x, y) => x.seat - y.seat);
  // join has no clock: in HOLD, wake at once (deadline already past) and let the TICK start the READ.
  if (d.phase === "HOLD" && entry.connected) d.deadline = d.holdAt;
  return ok(d);
}

export function nextWakeAt(s: TriviaState): number | null { return s.deadline; }

/** Non-null once in RESULTS. Ranking follows §5.3 (points → correct → time); left and 0-point players excluded. */
export function outcome(s: TriviaState): GameOutcome | null {
  if (s.phase !== "RESULTS") return null;
  const points: Record<string, number> = {};
  for (const p of s.players) points[p.id] = p.left ? 0 : p.score;
  return { points, ranking: rankGroups(s.players.filter((p) => !p.left && p.score > 0)) };
}

/** The questions shown in this instance (READ reached), appended to the room history; capped, oldest dropped. */
export function memory(s: TriviaState): GameMemory {
  const played = s.questions.slice(0, s.shown).map((q) => memoryKey(s.quiz.id, q.id));
  const set = new Set(played);
  const keys = [...s.usedKeys.filter((k) => !set.has(k)), ...played];
  return { usedKeys: keys.slice(Math.max(0, keys.length - MEMORY_MAX_KEYS)) };
}

// ─── invariants (§13.3) ──────────────────────────────────────────────────────────────────────────────────────────────

export function assertInvariants(s: TriviaState): void {
  const fail = (m: string): never => { throw new InvariantError(m); };
  if (s.schema !== STATE_SCHEMA) fail("schema");
  if (!PHASES.includes(s.phase)) fail(`phase ${s.phase}`);
  if (s.questions.length === 0) fail("no questions");
  if (s.index < 0 || s.index >= s.questions.length) fail(`index ${s.index}`);
  if (new Set(s.questions.map((q) => q.id)).size !== s.questions.length) fail("duplicate question");
  for (const q of s.questions) {
    if (q.options.length !== (q.type === "mc4" ? 4 : 2)) fail(`${q.id}: option count`);
    if (q.correctIndex < 0 || q.correctIndex >= q.options.length) fail(`${q.id}: correctIndex`);
    if (new Set(q.options).size !== q.options.length) fail(`${q.id}: options not unique`);
  }
  const timed: Phase[] = ["QUIZ_INTRO", "READ", "ANSWER", "REVEAL", "LEADERBOARD", "FINAL_INTRO"];
  if (timed.includes(s.phase) && s.deadline === null) fail(`${s.phase} without deadline`);
  if (s.phase === "RESULTS" && s.deadline !== null) fail("RESULTS with deadline");
  if (s.phase === "ANSWER" && s.answerOpenAt === null) fail("ANSWER without answerOpenAt");
  if (new Set(s.players.map((p) => p.id)).size !== s.players.length) fail("duplicate player");
  for (let i = 1; i < s.players.length; i++) if ((s.players[i] as PlayerState).seat <= (s.players[i - 1] as PlayerState).seat) fail("seat order");
  const q = s.questions[s.index] as QuestionSnap;
  for (const [id, a] of Object.entries(s.answers)) {
    const p = s.players.find((x) => x.id === id);
    if (!p || !canPlay(p)) fail(`answer from ${id}`);
    if (a.choice < 0 || a.choice >= q.options.length) fail("choice range");
    if (a.timeMs < 0 || a.timeMs > q.answerMs) fail("timeMs range");
  }
  if (s.phase !== "ANSWER" && Object.keys(s.answers).length > 0) fail(`answers kept in ${s.phase}`);
  if (s.results.length > s.questions.length) fail("too many results");
  s.results.forEach((r, k) => {
    if (r.index !== k) fail("result order");
    if (new Set(r.choices.map((c) => c.id)).size !== r.choices.length) fail("duplicate choice");
    for (const c of r.choices) {
      const qq = s.questions[r.index] as QuestionSnap;
      if (c.timeMs !== null && (c.timeMs < 0 || c.timeMs > qq.answerMs)) fail("result timeMs");
      if (c.points < 0 || c.streakBonus < 0) fail("negative points");
      if (!c.correct && (c.points > 0 || c.streakBonus > 0)) fail("points for a wrong answer");
    }
  });
  // Σ points of every non-voided question = each player's score (invariant 4)
  for (const p of s.players) {
    if (p.score < 0) fail("negative score");
    let sum = 0;
    let correct = 0;
    for (const r of s.results) {
      if (r.voided) continue;
      const c = r.choices.find((x) => x.id === p.id);
      if (c) { sum += c.points + c.streakBonus; if (c.correct) correct++; }
    }
    if (sum !== p.score) fail(`${p.id}: score ${p.score} ≠ Σ points ${sum}`);
    if (correct !== p.correct) fail(`${p.id}: correct count`);
    if (p.streak > p.bestStreak) fail(`${p.id}: streak > best`);
  }
  if (s.shown > s.questions.length) fail("shown");
}
