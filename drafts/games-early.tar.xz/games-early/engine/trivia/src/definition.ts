// games/trivia/definition.ts shape (JAMAA-PLATFORM §2.2, §2.12): the engine behind the GameDefinition contract.
import { STATE_SCHEMA } from "./constants";
import type { TriviaCatalog } from "./content";
import { assertInvariants, join, memory, nextWakeAt, outcome, reduce, start, startBlocker, type TriviaIntent, type TriviaState } from "./engine";
import { TRIVIA_META } from "./meta";
import type { GameAction, GameCtx, GameMemory, Locale, RoomAccess, RosterEntry } from "./platform";
import { FORBIDDEN_KEYS, leakCheck, projectMe, projectPublic, projectSetup, projectStatus, secretsFor } from "./projection";
import { apply, normalize, packIdsOf, restrict, type TriviaSettings, type TriviaSettingsPatch } from "./settings";

export const definition = {
  meta: TRIVIA_META,
  enabled: true,
  stateSchema: STATE_SCHEMA,
  settings: {
    apply: (s: TriviaSettings, patch: TriviaSettingsPatch, content: TriviaCatalog, locale: Locale) => apply(s, patch, content, locale),
    normalize,
    restrict,
    packIds: packIdsOf,
  },
  start: (a: { roster: readonly RosterEntry[]; settings: TriviaSettings; locale: Locale; memory: GameMemory; seed: number; now: number; graceMs: number; content: TriviaCatalog }) => start(a),
  reduce: (s: TriviaState, a: GameAction<TriviaIntent>, ctx: GameCtx<TriviaCatalog>) => reduce(s, a, ctx),
  nextWakeAt,
  outcome,
  memory,
  join,
  startBlocker,
  projectSetup: (s: TriviaSettings, roster: readonly RosterEntry[], content: TriviaCatalog, access: RoomAccess, locale: Locale) => projectSetup(s, roster, content, access, locale),
  projectPublic: (s: TriviaState, content?: TriviaCatalog) => projectPublic(s, content),
  projectMe: (s: TriviaState, playerId: string, _content?: TriviaCatalog) => projectMe(s, playerId),
  projectStatus,
  assertInvariants,
  secretsFor,
  leakCheck,
  forbiddenKeys: FORBIDDEN_KEYS,
};
export type TriviaDefinition = typeof definition;
