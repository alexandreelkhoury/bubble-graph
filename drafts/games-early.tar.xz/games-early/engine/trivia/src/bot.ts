// Bot players and host for the sim (tools/sim) and property tests: random answers, random host moves.
import { ADVANCEABLE, canPlay, current, type TriviaIntent, type TriviaState } from "./engine";
import type { Rng } from "./platform";

/** A random answer from a player who may still answer, else null. */
export function botIntent(s: TriviaState, playerId: string, rng: Rng): TriviaIntent | null {
  if (s.phase !== "ANSWER") return null;
  const p = s.players.find((x) => x.id === playerId);
  if (!p || !canPlay(p) || !p.connected || s.answers[p.id]) return null;
  return { a: "ANSWER", choice: rng.int(current(s)!.options.length) };
}

export function botHostIntent(s: TriviaState, rng: Rng): TriviaIntent | null {
  if (s.phase === "HOLD") return rng.next() < 0.5 ? { a: "END_GAME" } : null;
  if (s.phase === "REVEAL" && rng.next() < 0.1) return { a: "VOID_QUESTION", questionId: current(s)!.id };
  if (ADVANCEABLE.includes(s.phase) && rng.next() < 0.5) return { a: "HOST_ADVANCE" };
  return null;
}
