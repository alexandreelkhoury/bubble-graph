// GAME-TRIVIA §11.3 question schema on the JAMAA-PLATFORM §5.2 PackHeader (hand-validated here; the repo version is zod,
// shared/src/content/schema.ts + games/trivia/schema.ts), the §5.2 ContentAdapter, and quiz selection helpers
// (family resolution, quiz cards, the shelf rows, filters by stars / domain / topics; GAME-TRIVIA §9.1, platform §5.4).
// The engine's content type C is the room's PLAYABLE catalog: `playable` already removed locked packs.
import type { Locale } from "./platform";
import type { QuestionType } from "./constants";

export const DOMAINS = ["lebanon", "middle-east", "arab-world", "france", "world", "general"] as const;
export type Domain = (typeof DOMAINS)[number];
export const TOPICS = ["culture", "traditions", "music", "dance", "football", "sports", "food", "history", "geography", "places", "language", "cinema-tv", "celebrities", "science", "nature", "art"] as const;
export type Topic = (typeof TOPICS)[number];
export const REGIONS = ["beirut", "mount-lebanon", "north", "south", "bekaa"] as const;
export type Region = (typeof REGIONS)[number];
export const AGE_RATINGS = ["all", "teen", "adult"] as const;
export type AgeRating = (typeof AGE_RATINGS)[number];
export type PackLocale = Locale | "ar-LB";

export interface LocalizedTitle { en: string; fr: string; ar: string; es?: string }

export interface TriviaQuestion {
  id: string;
  type: QuestionType;
  text: string;
  options: string[];          // mc4: 4; tf: 2 = the localized [True, False] labels
  answer: number;             // AUTHORED index (the engine reshuffles mc4 for display)
  topic: Topic;
  difficulty: 1 | 2 | 3;
  easyIn: Locale[];
  region?: Region;
  explain?: string;
  source: string;             // never projected
}

export interface TriviaPack {
  id: string;
  family?: string;
  game: "trivia";
  version: number;
  locale: PackLocale;
  script: "Latn" | "Arab";
  title: LocalizedTitle;
  description?: LocalizedTitle;
  domain: Domain;
  topics: Topic[];
  featuredTopics: Topic[];
  stars: 1 | 2 | 3;
  ageRating: AgeRating;
  tier: "free" | "premium";
  license: string;
  source: string;
  status: "draft" | "reviewed";
  reviewedBy: string[];
  questions: TriviaQuestion[];
}

/** The engine's `C`: packs already filtered by access (platform §5.2 playableContent). */
export interface TriviaCatalog { packs: readonly TriviaPack[] }

const SLUG = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const QID = /^q\d{3,4}$/;
const PACK_LOCALES: readonly string[] = ["en", "fr", "ar", "ar-LB", "es"];
const LOCALES: readonly string[] = ["en", "fr", "ar", "es"];
export const MIN_QUESTIONS = 20;          // platform §5.2 table

function isObj(v: unknown): v is Record<string, unknown> { return typeof v === "object" && v !== null && !Array.isArray(v); }
export function graphemes(s: string): number { return [...new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(s)].length; }
function str(v: unknown, where: string, max = Infinity, min = 1): string {
  if (typeof v !== "string" || v.length < min) throw new Error(`${where}: string required`);
  if (graphemes(v) > max) throw new Error(`${where}: longer than ${max}`);
  return v;
}
function oneOf<T extends string>(v: unknown, list: readonly T[], where: string): T {
  if (typeof v !== "string" || !(list as readonly string[]).includes(v)) throw new Error(`${where}: not in ${list.join("|")}`);
  return v as T;
}
function strict(o: Record<string, unknown>, keys: readonly string[], where: string): void {
  for (const k of Object.keys(o)) if (!keys.includes(k)) throw new Error(`${where}: unknown key ${k}`);
}
function title(v: unknown, where: string, max = Infinity, min = 1): LocalizedTitle {
  if (!isObj(v)) throw new Error(`${where}: object required`);
  strict(v, ["en", "fr", "ar", "es"], where);
  const t: LocalizedTitle = { en: str(v.en, `${where}.en`, max, min), fr: str(v.fr, `${where}.fr`, max, min), ar: str(v.ar, `${where}.ar`, max, min) };
  if (v.es !== undefined) t.es = str(v.es, `${where}.es`, max, min);
  return t;
}

const Q_KEYS = ["id", "type", "text", "options", "answer", "topic", "difficulty", "easyIn", "region", "explain", "source"] as const;

function parseQuestion(v: unknown, where: string, topics: ReadonlySet<string>): TriviaQuestion {
  if (!isObj(v)) throw new Error(`${where}: object required`);
  strict(v, Q_KEYS, where);
  const id = str(v.id, `${where}.id`);
  if (!QID.test(id)) throw new Error(`${where}.id: must match q000`);
  const type = oneOf(v.type, ["mc4", "tf"] as const, `${where}.type`);
  const text = str(v.text, `${where}.text`, 160, 5);
  if (!Array.isArray(v.options) || v.options.length !== (type === "mc4" ? 4 : 2)) throw new Error(`${where}.options: ${type} needs ${type === "mc4" ? 4 : 2}`);
  const options = v.options.map((o, i) => str(o, `${where}.options[${i}]`, 48));
  if (new Set(options.map((o) => o.trim().toLowerCase())).size !== options.length) throw new Error(`${where}.options: not unique`);
  const answer = v.answer;
  if (typeof answer !== "number" || !Number.isInteger(answer) || answer < 0 || answer >= options.length) throw new Error(`${where}.answer: out of range`);
  const topic = oneOf(v.topic, TOPICS, `${where}.topic`);
  if (!topics.has(topic)) throw new Error(`${where}.topic: ${topic} not in the pack topics`);
  if (v.difficulty !== 1 && v.difficulty !== 2 && v.difficulty !== 3) throw new Error(`${where}.difficulty: 1|2|3`);
  const easyIn = v.easyIn === undefined ? [] : v.easyIn;
  if (!Array.isArray(easyIn)) throw new Error(`${where}.easyIn: array required`);
  const q: TriviaQuestion = {
    id, type, text, options, answer, topic, difficulty: v.difficulty,
    easyIn: easyIn.map((l, i) => oneOf(l, LOCALES as readonly Locale[], `${where}.easyIn[${i}]`)),
    source: str(v.source, `${where}.source`),
  };
  if (v.region !== undefined) q.region = oneOf(v.region, REGIONS, `${where}.region`);
  if (v.explain !== undefined) q.explain = str(v.explain, `${where}.explain`, 200);
  return q;
}

const PACK_KEYS = ["id", "family", "game", "version", "locale", "script", "title", "description", "domain", "topics", "featuredTopics", "stars", "ageRating", "tier", "license", "source", "status", "reviewedBy", "questions"] as const;

/** Throws on an invalid pack: the schema plus the hard rules the engine relies on (§11.3, platform §5.4). */
export function parsePack(raw: unknown): TriviaPack {
  if (!isObj(raw)) throw new Error("pack: object required");
  strict(raw, PACK_KEYS, "pack");
  const id = str(raw.id, "pack.id", 40);
  if (!SLUG.test(id)) throw new Error("pack.id: slug");
  let family: string | undefined;
  if (raw.family !== undefined) { family = str(raw.family, "pack.family", 35); if (!SLUG.test(family)) throw new Error("pack.family: slug"); }
  if (raw.game !== "trivia") throw new Error("pack.game: trivia");
  if (typeof raw.version !== "number" || !Number.isInteger(raw.version) || raw.version < 1) throw new Error("pack.version");
  const locale = oneOf(raw.locale, PACK_LOCALES as readonly PackLocale[], "pack.locale");
  const script = oneOf(raw.script, ["Latn", "Arab"] as const, "pack.script");
  if ((script === "Arab") !== (locale === "ar" || locale === "ar-LB")) throw new Error("pack.script: does not match locale");
  const domain = oneOf(raw.domain, DOMAINS, "pack.domain");
  if (!Array.isArray(raw.topics) || raw.topics.length === 0 || raw.topics.length > 16) throw new Error("pack.topics: non-empty");
  const topics = raw.topics.map((t, i) => oneOf(t, TOPICS, `pack.topics[${i}]`));
  if (!Array.isArray(raw.featuredTopics) || raw.featuredTopics.length < 1 || raw.featuredTopics.length > 3) throw new Error("pack.featuredTopics: 1–3");
  const featuredTopics = raw.featuredTopics.map((t, i) => oneOf(t, TOPICS, `pack.featuredTopics[${i}]`));
  if (!featuredTopics.every((t) => topics.includes(t))) throw new Error("pack.featuredTopics: must be ⊂ topics");
  if (raw.stars !== 1 && raw.stars !== 2 && raw.stars !== 3) throw new Error("pack.stars: required 1|2|3");
  const tier = raw.tier === undefined ? "premium" : oneOf(raw.tier, ["free", "premium"] as const, "pack.tier");
  if (!Array.isArray(raw.questions) || raw.questions.length < MIN_QUESTIONS) throw new Error(`pack.questions: ≥ ${MIN_QUESTIONS}`);
  const topicSet = new Set<string>(topics);
  const questions = raw.questions.map((q, i) => parseQuestion(q, `pack.questions[${i}]`, topicSet));
  if (new Set(questions.map((q) => q.id)).size !== questions.length) throw new Error("pack.questions: duplicate id");
  const used = new Set(questions.map((q) => q.topic));
  if (used.size !== topics.length) throw new Error("pack.topics: must be exactly the topics the questions use");
  const reviewedBy = raw.reviewedBy === undefined ? [] : raw.reviewedBy;
  if (!Array.isArray(reviewedBy) || !reviewedBy.every((x) => typeof x === "string")) throw new Error("pack.reviewedBy");
  const pack: TriviaPack = {
    id, game: "trivia", version: raw.version, locale, script, title: title(raw.title, "pack.title"),
    domain, topics, featuredTopics, stars: raw.stars, ageRating: oneOf(raw.ageRating, AGE_RATINGS, "pack.ageRating"), tier,
    license: str(raw.license, "pack.license"), source: str(raw.source, "pack.source"),
    status: oneOf(raw.status, ["draft", "reviewed"] as const, "pack.status"), reviewedBy: reviewedBy as string[], questions,
  };
  if (family !== undefined) pack.family = family;
  if (raw.description !== undefined) pack.description = title(raw.description, "pack.description", 140, 0);
  return pack;
}

// ─── families and locales ──────────────────────────────────────────────────────────────────────────────────────────

export const familyOf = (p: Pick<TriviaPack, "id" | "family">): string => p.family ?? p.id;
/** Platform §5.3: packs in ar-LB count as ar. */
export const languageOf = (p: Pick<TriviaPack, "locale">): Locale => (p.locale === "ar-LB" ? "ar" : p.locale);

/** Quizzes playable in a content language: adult packs are never served; one pack per family (first in catalog order). */
export function quizzesFor(content: TriviaCatalog, locale: Locale): TriviaPack[] {
  const seen = new Set<string>();
  const out: TriviaPack[] = [];
  for (const p of content.packs) {
    if (languageOf(p) !== locale || p.ageRating === "adult" || p.questions.length === 0) continue;
    const f = familyOf(p);
    if (seen.has(f)) continue;
    seen.add(f);
    out.push(p);
  }
  return out;
}

/** The pack of `family` in `locale`, or undefined. */
export function packFor(content: TriviaCatalog, family: string, locale: Locale): TriviaPack | undefined {
  return quizzesFor(content, locale).find((p) => familyOf(p) === family);
}

/**
 * GAME-TRIVIA §9: `quizId` null = "the first featured quiz playable in the content language". The header has no
 * `featured` flag yet (open issue), so the draft takes the first quiz in catalog order. A family without a pack in the
 * locale resolves to undefined (start fails NO_CONTENT_AVAILABLE; `restrict` resets it to null first).
 */
export function resolveQuiz(content: TriviaCatalog, quizId: string | null, locale: Locale): TriviaPack | undefined {
  return quizId === null ? quizzesFor(content, locale)[0] : packFor(content, quizId, locale);
}

// ─── quiz cards, shelf, filters (GAME-TRIVIA §9.1, platform §5.4) ─────────────────────────────────────────────────────

export interface QuizCard {
  id: string;                 // the FAMILY
  packId: string;
  title: LocalizedTitle;
  stars: 1 | 2 | 3;
  domain: Domain;
  featuredTopics: Topic[];    // author order, ≤ 3
  moreTopics: number;         // the "+n" chip
  topicCount: number;
  questionCount: number;
  tier: "free" | "premium";
}
export function quizCard(p: TriviaPack): QuizCard {
  return {
    id: familyOf(p), packId: p.id, title: p.title, stars: p.stars, domain: p.domain,
    featuredTopics: p.featuredTopics.slice(0, 3), moreTopics: Math.max(0, p.topics.length - Math.min(3, p.featuredTopics.length)),
    topicCount: p.topics.length, questionCount: p.questions.length, tier: p.tier,
  };
}

export interface QuizFilter { stars?: readonly (1 | 2 | 3)[]; domain?: Domain; topics?: readonly Topic[] }
/** Filter by stars (any of), domain (equal) and topics (the quiz covers ALL listed topics). Catalog order is kept. */
export function filterQuizzes(content: TriviaCatalog, locale: Locale, f: QuizFilter = {}): QuizCard[] {
  return quizzesFor(content, locale)
    .filter((p) => (f.stars === undefined || f.stars.includes(p.stars))
      && (f.domain === undefined || p.domain === f.domain)
      && (f.topics === undefined || f.topics.every((t) => p.topics.includes(t))))
    .map(quizCard);
}

/** The TV shelf: one row per domain in vocabulary order (empty rows dropped), cards in catalog order. */
export function quizShelf(content: TriviaCatalog, locale: Locale): { domain: Domain; cards: QuizCard[] }[] {
  const cards = quizzesFor(content, locale).map(quizCard);
  return DOMAINS.map((domain) => ({ domain, cards: cards.filter((c) => c.domain === domain) })).filter((r) => r.cards.length > 0);
}

// ─── platform ContentAdapter (§5.2) ──────────────────────────────────────────────────────────────────────────────────

export interface PackMeta {
  id: string; family: string; gameId: "trivia"; languages: Locale[];
  title: LocalizedTitle; ageRating: AgeRating; tier: "free" | "premium" | "mixed";
  itemCount: number; freeItemCount: number;
  stars: 1 | 2 | 3 | null; domain: Domain | null; topics: Topic[];
}
export const content = {
  parse: parsePack,
  meta(p: TriviaPack): PackMeta {
    return {
      id: p.id, family: familyOf(p), gameId: "trivia", languages: [languageOf(p)], title: p.title, ageRating: p.ageRating,
      tier: p.tier, itemCount: p.questions.length, freeItemCount: p.tier === "free" ? p.questions.length : 0,
      stars: p.stars, domain: p.domain, topics: p.topics,
    };
  },
  /** Pack-level tier only (GAME-TRIVIA §2): a premium quiz is playable with the Pass or a `pack_<family>` purchase. */
  playable(p: TriviaPack, a: { premium: boolean; ownedFamilies: ReadonlySet<string> }): TriviaPack | null {
    if (p.ageRating === "adult") return null;
    return p.tier === "free" || a.premium || a.ownedFamilies.has(familyOf(p)) ? p : null;
  },
};
