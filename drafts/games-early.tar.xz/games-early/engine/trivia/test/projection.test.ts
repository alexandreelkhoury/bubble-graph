// GAME-TRIVIA §8.1 secrecy table and §13.2 view, per phase.
import { describe, expect, it } from "vitest";
import { answer, CATALOG, DEF, playQuestion, right, startGame, step, tick, until } from "./helpers";

const json = (v: unknown) => JSON.stringify(v);

describe("per-phase view", () => {
  it("QUIZ_INTRO: the quiz card, no question", () => {
    const s = startGame(3);
    const pub = DEF.projectPublic(s);
    expect(pub).toMatchObject({ phase: "QUIZ_INTRO", question: null, options: [], reveal: null, answeredIds: [], index: 0, total: 10, isFinal: false });
    expect(pub.quiz).toEqual({ id: "syn-quiz", title: CATALOG.packs[0]!.title, stars: 2, domain: "lebanon", featuredTopics: ["music", "geography", "football"], topicCount: 6, questionCount: 40 });
    expect(json(pub)).not.toContain(s.questions[0]!.text);
  });

  it("READ: question only, no options; ANSWER: options in displayed order, no correctness", () => {
    let s = until(startGame(3), "READ");
    let pub = DEF.projectPublic(s);
    expect(pub.question).toEqual({ id: s.questions[0]!.id, text: s.questions[0]!.text, type: s.questions[0]!.type, topic: s.questions[0]!.topic, difficulty: s.questions[0]!.difficulty });
    expect(pub.options).toEqual([]);
    s = tick(s);
    pub = DEF.projectPublic(s);
    expect(pub.options).toEqual(s.questions[0]!.options);
    expect(pub.reveal).toBeNull();
    s = answer(s, "p2", right(s), s.answerOpenAt! + 1_000);
    pub = DEF.projectPublic(s);
    expect(pub.answeredIds).toEqual(["p2"]);
    expect(json(pub)).not.toMatch(/"correct"|"choice"/);
    expect(DEF.projectMe(s, "p2")).toMatchObject({ myChoice: right(s), myTimeMs: 700, waitingForNext: false });
    expect(DEF.projectMe(s, "p1")).toMatchObject({ myChoice: null, myTimeMs: null });
    expect(json(DEF.projectMe(s, "p1"))).not.toContain(`"myChoice":${right(s)}`);
    expect(DEF.projectStatus(s)).toEqual({ phase: "ANSWER", doneIds: ["p2"], awaitedIds: ["p1", "p3"] });
  });

  it("REVEAL: correct position, every choice, points, highlights, explain", () => {
    let s = until(startGame(3), "READ");
    s = playQuestion(s, { p1: { ok: true, after: 300 }, p2: { ok: false, after: 1_000 } });
    const pub = DEF.projectPublic(s);
    const q = s.questions[0]!;
    expect(pub.reveal).toEqual({
      correct: q.correctIndex,
      choices: [
        { id: "p1", choice: q.correctIndex, correct: true, timeMs: 0, points: 1000, streakBonus: 0 },
        { id: "p2", choice: (q.correctIndex + 1) % q.options.length, correct: false, timeMs: 700, points: 0, streakBonus: 0 },
        { id: "p3", choice: null, correct: false, timeMs: null, points: 0, streakBonus: 0 },
      ],
      fastestIds: [], onFireIds: [], stumped: false, genius: false, tooSlow: false, explain: q.explain, voided: false,
    });
    expect(pub.answeredIds).toEqual(["p1", "p2"]);
    expect(pub.scores[0]).toMatchObject({ playerId: "p1", score: 1000, scoreBefore: 0, rank: 1, correctCount: 1, streak: 1 });
    expect(pub.scores.slice(1).map((r) => r.rank)).toEqual([2, 2]);
    expect(DEF.projectMe(s, "p2")).toMatchObject({ myChoice: (q.correctIndex + 1) % q.options.length, rank: 2 });
    expect(DEF.projectStatus(s)).toEqual({ phase: "REVEAL", doneIds: [], awaitedIds: [] });
  });

  it("LEADERBOARD / FINAL_INTRO / RESULTS: no question, no reveal; isFinal on the final", () => {
    let s = until(startGame(2), "LEADERBOARD");
    expect(DEF.projectPublic(s)).toMatchObject({ question: null, options: [], reveal: null, isFinal: false });
    s = until(s, "FINAL_INTRO");
    expect(DEF.projectPublic(s)).toMatchObject({ isFinal: true, question: null });
    s = tick(s);
    expect(DEF.projectPublic(s)).toMatchObject({ phase: "READ", isFinal: true, index: 9 });
    s = until(s, "RESULTS");
    expect(DEF.projectPublic(s)).toMatchObject({ question: null, reveal: null, deadline: null });
  });

  it("projectMe: null for an unknown player; the TV view never carries a me", () => {
    const s = startGame(2);
    expect(DEF.projectMe(s, "nobody")).toBeNull();
    expect(DEF.leakCheck(s, null, { pub: DEF.projectPublic(s), me: DEF.projectMe(s, "p1") })).toContain("TV view carries a me");
  });
});

describe("leak oracles catch planted leaks", () => {
  it("leakCheck flags a correct key, others' choices and options in READ", () => {
    let s = until(startGame(2), "READ");
    const pub = DEF.projectPublic(s);
    expect(DEF.leakCheck(s, null, pub)).toEqual([]);
    expect(DEF.leakCheck(s, null, { ...pub, options: ["a"] })).toContain("options in READ");
    s = tick(s);
    s = answer(s, "p2", 1, s.answerOpenAt! + 500);
    const ok = { pub: DEF.projectPublic(s), me: DEF.projectMe(s, "p1") };
    expect(DEF.leakCheck(s, "p1", ok)).toEqual([]);
    expect(DEF.leakCheck(s, "p1", { ...ok, pub: { ...ok.pub, extra: { correct: 2 } } }).join()).toMatch(/before REVEAL/);
    expect(DEF.leakCheck(s, "p1", { ...ok, me: { ...ok.me, myChoice: 1 } }).join()).toMatch(/own choice/);
    expect(DEF.leakCheck(s, "p1", { ...ok, pub: { ...ok.pub, who: [{ id: "p2", choice: 1 }] } }).join()).toMatch(/choices before REVEAL/);
    expect(DEF.leakCheck(s, null, { ...ok.pub, reveal: { correct: 1 } }).join()).toMatch(/reveal present/);
  });

  it("secretsFor lists future questions, READ options and unrevealed explanations", () => {
    const s0 = startGame(2);
    const secrets = DEF.secretsFor(s0, null);
    for (const q of s0.questions) { expect(secrets).toContain(q.text); for (const o of q.options) expect(secrets).toContain(o); }
    const r = until(s0, "READ");
    expect(DEF.secretsFor(r, "p1")).not.toContain(r.questions[0]!.text);
    expect(DEF.secretsFor(r, "p1")).toContain(r.questions[0]!.options[0]);
    const a = tick(r);
    expect(DEF.secretsFor(a, "p1")).not.toContain(a.questions[0]!.options[0]);
    expect(DEF.secretsFor(until(a, "RESULTS"), "p1")).toEqual([]);
  });

  it("no forbidden key in any view of a full game", () => {
    let s = startGame(3);
    while (s.phase !== "RESULTS") {
      if (s.phase === "ANSWER") s = answer(s, "p1", 0, s.answerOpenAt! + 100);
      const views = [DEF.projectPublic(s), ...s.players.map((p) => DEF.projectMe(s, p.id)), DEF.projectStatus(s)];
      for (const k of DEF.forbiddenKeys) expect(json(views)).not.toContain(`"${k}"`);
      s = step(s, { type: "TICK" }, s.deadline!);
    }
  });
});
