// GAME-TRIVIA §4, §5, §6, §13.4 flow tests.
import { describe, expect, it } from "vitest";
import { EARLY_END_MS, FINAL_INTRO_MS, LEADERBOARD_MS, QUIZ_INTRO_MS, readMs, REVEAL_EXPLAIN_MS, REVEAL_MS, graphemes, type TriviaIntent, type TriviaState } from "../src";
import { answer, CATALOG, DEF, GRACE, host, player, playQuestion, right, roster, startGame, step, T0, tick, tryStep, tv, until, wrong } from "./helpers";

/** Phase sequence of a game where nobody answers. */
function phaseTrace(s0: TriviaState): string[] {
  const out: string[] = [s0.phase];
  let s = s0;
  while (s.phase !== "RESULTS") { s = tick(s); if (out[out.length - 1] !== s.phase) out.push(`${s.phase}${s.phase === "READ" ? s.index + 1 : ""}`); }
  return out;
}

describe("start and QUIZ_INTRO", () => {
  it("deadline = now + ENTRANCE_GRACE_MS + 4 000; the first phase is QUIZ_INTRO", () => {
    const s = startGame(3);
    expect(s.phase).toBe("QUIZ_INTRO");
    expect(s.deadline).toBe(T0 + GRACE + QUIZ_INTRO_MS);
    expect(DEF.nextWakeAt(s)).toBe(s.deadline);
    expect(s.questions).toHaveLength(10);
  });

  it("host HOST_ADVANCE expires QUIZ_INTRO inline; a non-host cannot", () => {
    const s = startGame(3);
    expect(tryStep(s, { type: "INTENT", intent: { a: "HOST_ADVANCE" }, by: player("p2") }, T0 + 10)).toMatchObject({ ok: false, error: "NOT_HOST" });
    const r = step(s, { type: "INTENT", intent: { a: "HOST_ADVANCE" }, by: player("p1") }, T0 + 10);
    expect(r.phase).toBe("READ");
    expect(r.deadline).toBe(T0 + 10 + readMs(graphemes(r.questions[0]!.text)));
  });

  it("start blockers: nobody connected, no quiz in the locale, unknown family", () => {
    const base = { settings: { quizId: null, length: "normal" as const, pace: "normal" as const }, memory: { usedKeys: [] }, seed: 1, now: T0, graceMs: GRACE, content: CATALOG };
    expect(DEF.start({ ...base, roster: roster(2).map((r) => ({ ...r, connected: false })), locale: "en" })).toMatchObject({ ok: false, error: "NOT_ENOUGH_PLAYERS" });
    expect(DEF.start({ ...base, roster: roster(2), locale: "en", content: { packs: CATALOG.packs.filter((p) => p.locale !== "en") } })).toMatchObject({ ok: false, error: "NO_CONTENT_AVAILABLE" });
    expect(DEF.start({ ...base, roster: roster(2), locale: "en", settings: { ...base.settings, quizId: "nope" } })).toMatchObject({ ok: false, error: "NO_CONTENT_AVAILABLE" });
    expect(DEF.startBlocker(roster(1), base.settings, CATALOG, "ar")).toBeNull(); // solo works
  });
});

describe("structure (§4)", () => {
  it("normal (10): leaderboards after q3, q6, q9 and before the final", () => {
    expect(phaseTrace(startGame(2))).toEqual([
      "QUIZ_INTRO", "READ1", "ANSWER", "REVEAL", "READ2", "ANSWER", "REVEAL", "READ3", "ANSWER", "REVEAL", "LEADERBOARD",
      "READ4", "ANSWER", "REVEAL", "READ5", "ANSWER", "REVEAL", "READ6", "ANSWER", "REVEAL", "LEADERBOARD",
      "READ7", "ANSWER", "REVEAL", "READ8", "ANSWER", "REVEAL", "READ9", "ANSWER", "REVEAL", "LEADERBOARD", "FINAL_INTRO",
      "READ10", "ANSWER", "REVEAL", "RESULTS",
    ]);
  });
  it("short (7): q6's leaderboard is also the one before the final", () => {
    const t = phaseTrace(startGame(2, { length: "short" }));
    expect(t.filter((p) => p === "LEADERBOARD")).toHaveLength(2);
    expect(t.slice(-6)).toEqual(["REVEAL", "LEADERBOARD", "FINAL_INTRO", "READ7", "ANSWER", "REVEAL", "RESULTS"].slice(-6));
  });
  it("long (15): leaderboards after 3, 6, 9, 12 and 14 (before the final)", () => {
    const t = phaseTrace(startGame(2, { length: "long" }));
    const lbAfter = t.flatMap((p, i) => (p === "LEADERBOARD" ? [t.slice(0, i).filter((x) => x.startsWith("READ")).length] : []));
    expect(lbAfter).toEqual([3, 6, 9, 12, 14]);
  });
  it("pool-capped short quiz (3 questions): REVEAL → FINAL_INTRO with no leaderboard", () => {
    const tiny = { packs: [{ ...CATALOG.packs[0]!, questions: CATALOG.packs[0]!.questions.slice(0, 3) }] };
    const s = DEF.start({ roster: roster(1), settings: { quizId: null, length: "short", pace: "normal" }, locale: "en", memory: { usedKeys: [] }, seed: 3, now: T0, graceMs: GRACE, content: tiny });
    expect(phaseTrace(s.state!)).toEqual(["QUIZ_INTRO", "READ1", "ANSWER", "REVEAL", "READ2", "ANSWER", "REVEAL", "FINAL_INTRO", "READ3", "ANSWER", "REVEAL", "RESULTS"]);
  });
  it("LEADERBOARD 6 s, FINAL_INTRO 4 s, from the expiring tick's now", () => {
    let x = until(startGame(2), "READ");
    const seen = new Set<string>();
    while (x.phase !== "RESULTS") {
      const now = x.deadline! + 37; // a late alarm: new deadlines count from ctx.now
      const y = step(x, { type: "TICK" }, now);
      if (y.phase === "LEADERBOARD") { expect(y.deadline! - now).toBe(LEADERBOARD_MS); seen.add("LB"); }
      if (y.phase === "FINAL_INTRO") { expect(y.deadline! - now).toBe(FINAL_INTRO_MS); seen.add("FI"); }
      if (y.phase === "ANSWER") expect(y.answerOpenAt).toBe(now);
      x = y;
    }
    expect([...seen].sort()).toEqual(["FI", "LB"]);
  });
  it("explain adds 3 s to REVEAL", () => {
    let s = startGame(2);
    let seen = { with: false, without: false };
    s = until(s, "READ");
    while (s.phase !== "RESULTS") {
      if (s.phase === "ANSWER") {
        const q = s.questions[s.index]!;
        const r = tick(s);
        expect(r.deadline! - s.deadline!).toBe(REVEAL_MS + (q.explain ? REVEAL_EXPLAIN_MS : 0));
        seen = q.explain ? { ...seen, with: true } : { ...seen, without: true };
        s = r;
      } else s = tick(s);
    }
    expect(seen).toEqual({ with: true, without: true });
  });
});

describe("READ and ANSWER", () => {
  it("READ is never skippable, even by the host; OK during READ/ANSWER is ignored", () => {
    const s = until(startGame(2), "READ");
    expect(tryStep(s, { type: "INTENT", intent: { a: "HOST_ADVANCE" }, by: tv }, s.deadline! - 1)).toMatchObject({ ok: false, error: "WRONG_PHASE" });
    expect(tryStep(s, { type: "TICK" }, s.deadline! - 1).state).toBe(s); // early tick: same object
    const a = tick(s);
    expect(tryStep(a, { type: "INTENT", intent: { a: "HOST_ADVANCE" }, by: tv }, a.answerOpenAt! + 5)).toMatchObject({ ok: false, error: "WRONG_PHASE" });
  });

  it("answer time comes from ctx.now; client-sent extra fields are ignored", () => {
    let s = tick(until(startGame(2), "READ"));
    const open = s.answerOpenAt!;
    const forged = { a: "ANSWER", choice: right(s), clientTime: 0, timeMs: 0 } as unknown as TriviaIntent;
    s = step(s, { type: "INTENT", intent: forged, by: player("p1") }, open + 5_300);
    expect(s.answers.p1!.timeMs).toBe(5_000);
  });

  it("first tap locks: ALREADY_ANSWERED; ANSWER_INVALID out of range and 2–3 on tf; WRONG_PHASE late", () => {
    let s = tick(until(startGame(2), "READ"));
    const open = s.answerOpenAt!;
    s = answer(s, "p1", 0, open + 1_000);
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: 1 }, by: player("p1") }, open + 1_100)).toMatchObject({ ok: false, error: "ALREADY_ANSWERED" });
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: 4 }, by: player("p2") }, open + 1_100)).toMatchObject({ ok: false, error: "ANSWER_INVALID" });
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: -1 }, by: player("p2") }, open + 1_100)).toMatchObject({ ok: false, error: "ANSWER_INVALID" });
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: 1.5 }, by: player("p2") }, open + 1_100)).toMatchObject({ ok: false, error: "ANSWER_INVALID" });
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: 0 }, by: tv }, open + 1_100)).toMatchObject({ ok: false, error: "NOT_IN_GAME" });
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: 0 }, by: player("zz") }, open + 1_100)).toMatchObject({ ok: false, error: "NOT_IN_GAME" });
    const revealed = tick(s);
    expect(tryStep(revealed, { type: "INTENT", intent: { a: "ANSWER", choice: 0 }, by: player("p2") }, revealed.deadline! - 1)).toMatchObject({ ok: false, error: "WRONG_PHASE" });

    // tf
    let seed = 1;
    while (!startGame(2, { length: "long" }, { seed }).questions.some((q) => q.type === "tf")) seed++;
    let t = until(startGame(2, { length: "long" }, { seed }), "READ");
    while (t.questions[t.index]!.type !== "tf" || t.phase !== "READ") t = tick(t);
    t = tick(t);
    expect(t.answerOpenAt! + 10_000).toBe(t.deadline); // tf pace normal = 10 s
    expect(tryStep(t, { type: "INTENT", intent: { a: "ANSWER", choice: 2 }, by: player("p1") }, t.answerOpenAt! + 1)).toMatchObject({ ok: false, error: "ANSWER_INVALID" });
    expect(tryStep(t, { type: "INTENT", intent: { a: "ANSWER", choice: 1 }, by: player("p1") }, t.answerOpenAt! + 1).ok).toBe(true);
  });

  it("an answer that arrives after the deadline but before the TICK counts with t = T", () => {
    let s = tick(until(startGame(2), "READ"));
    s = answer(s, "p1", right(s), s.deadline! + 2_000);
    expect(s.answers.p1!.timeMs).toBe(15_000);
  });

  it("all connected players answered → deadline = now + 600 (never later than the original)", () => {
    let s = tick(until(startGame(3), "READ"));
    const open = s.answerOpenAt!;
    s = answer(s, "p1", 0, open + 1_000);
    s = answer(s, "p2", 0, open + 2_000);
    expect(s.earlyEnd).toBe(false);
    s = answer(s, "p3", 0, open + 3_000);
    expect(s.earlyEnd).toBe(true);
    expect(s.deadline).toBe(open + 3_000 + EARLY_END_MS);
    // a disconnected player is not waited for
    let d = tick(until(startGame(3), "READ"));
    d = step(d, { type: "PLAYER_AWAY", playerId: "p3" }, d.answerOpenAt! + 10);
    d = answer(d, "p1", 0, d.answerOpenAt! + 500);
    d = answer(d, "p2", 0, d.answerOpenAt! + 900);
    expect(d.deadline).toBe(d.answerOpenAt! + 900 + EARLY_END_MS);
    // the last missing player leaving also triggers it
    let g = tick(until(startGame(3), "READ"));
    g = answer(g, "p1", 0, g.answerOpenAt! + 500);
    g = answer(g, "p2", 0, g.answerOpenAt! + 600);
    g = step(g, { type: "PLAYER_GONE", playerId: "p3", cause: "LEAVE" }, g.answerOpenAt! + 700);
    expect(g.deadline).toBe(g.answerOpenAt! + 700 + EARLY_END_MS);
  });

  it("reconnect mid-ANSWER keeps the original answerOpenAt (no advantage)", () => {
    let s = tick(until(startGame(2), "READ"));
    const open = s.answerOpenAt!;
    s = step(s, { type: "PLAYER_AWAY", playerId: "p2" }, open + 1_000);
    s = step(s, { type: "PLAYER_BACK", playerId: "p2" }, open + 6_000);
    expect(s.answerOpenAt).toBe(open);
    s = answer(s, "p2", 0, open + 6_300);
    expect(s.answers.p2!.timeMs).toBe(6_000);
  });
});

describe("scoring through the engine", () => {
  it("speed points, streaks capped at +300, final ×2, wrong resets", () => {
    let s = until(startGame(2, { length: "short" }), "READ");
    const log: number[] = [];
    while (s.phase !== "RESULTS") {
      if (s.phase === "READ") {
        const idx = s.index;
        // p1 always right at t = 0 (answers 300 ms after open = grace); p2 wrong on q3
        s = playQuestion(s, { p1: { ok: true, after: 300 }, p2: { ok: idx !== 2, after: 300 + 7_500 } });
        log.push(s.results[idx]!.choices.find((c) => c.id === "p1")!.points + s.results[idx]!.choices.find((c) => c.id === "p1")!.streakBonus);
      } else s = tick(s);
    }
    const maxOf = (i: number) => (s.questions[i]!.type === "mc4" ? 1000 : 500) * (i === 6 ? 2 : 1);
    const bonus = [0, 100, 200, 300, 300, 300, 300];
    expect(log).toEqual(s.questions.map((_, i) => maxOf(i) + bonus[i]!));
    const p2 = s.players.find((p) => p.id === "p2")!;
    expect(p2.bestStreak).toBe(4); // q4..q7 after the reset on q3
    expect(s.results[2]!.choices.find((c) => c.id === "p2")).toMatchObject({ correct: false, points: 0, streakBonus: 0 });
    expect(p2.streak).toBe(4);
    expect(DEF.outcome(s)!.ranking[0]).toEqual(["p1"]);
  });

  it("nobody answers: too slow, no points, streaks reset", () => {
    let s = until(startGame(2), "READ");
    s = playQuestion(s, { p1: { ok: true, after: 400 } });
    s = until(s, "READ");
    s = playQuestion(s, {});
    const r = s.results[1]!;
    expect(r).toMatchObject({ tooSlow: true, stumped: true, genius: false, fastestIds: [] });
    expect(s.players.every((p) => p.streak === 0)).toBe(true);
  });

  it("highlights: fastest finger, genius, on fire", () => {
    let s = until(startGame(3), "READ");
    for (let q = 0; q < 3; q++) {
      s = until(s, "READ");
      s = playQuestion(s, { p1: { ok: true, after: 500 }, p2: { ok: true, after: 900 }, p3: { ok: true, after: 500 } });
    }
    const r = s.results[2]!;
    expect(r.genius).toBe(true);
    expect(r.fastestIds).toEqual(["p1", "p3"]);
    expect(r.onFireIds).toEqual(["p1", "p2", "p3"]);
    expect(s.players.find((p) => p.id === "p1")!.fastestCount).toBe(3);
  });

  it("ties: same points → more correct → less time → shared place in the outcome", () => {
    let s = until(startGame(4, { length: "short" }), "READ");
    while (s.phase !== "RESULTS") {
      if (s.phase === "READ") s = playQuestion(s, { p1: { ok: true, after: 1_300 }, p2: { ok: true, after: 1_300 }, p3: { ok: s.index % 2 === 0, after: 300 } });
      else s = tick(s);
    }
    const o = DEF.outcome(s)!;
    expect(o.ranking[0]).toEqual(["p1", "p2"]);
    expect(o.points.p4).toBe(0);
    expect(o.ranking.flat()).not.toContain("p4"); // 0 points: no stars
    expect(DEF.projectPublic(s).scores.slice(0, 2).map((r) => r.rank)).toEqual([1, 1]);
  });
});

describe("HOLD", () => {
  it("nobody connected at question start → HOLD; a reconnect resumes READ at the same question", () => {
    let s = until(startGame(2), "REVEAL");
    s = step(s, { type: "PLAYER_AWAY", playerId: "p1" }, s.deadline! - 100);
    s = step(s, { type: "PLAYER_AWAY", playerId: "p2" }, s.deadline! - 50);
    s = tick(s);
    expect(s.phase).toBe("HOLD");
    expect(s.index).toBe(1);
    expect(DEF.nextWakeAt(s)).toBeNull();
    expect(tryStep(s, { type: "INTENT", intent: { a: "END_GAME" }, by: player("p2") }, T0 * 2)).toMatchObject({ ok: false, error: "NOT_HOST" });
    const back = step(s, { type: "PLAYER_BACK", playerId: "p2" }, T0 * 2);
    expect(back.phase).toBe("READ");
    expect(back.index).toBe(1);
    expect(back.deadline).toBe(T0 * 2 + back.questions[1]!.readMs);
    const ended = host(s, { a: "END_GAME" }, T0 * 2);
    expect(ended.phase).toBe("RESULTS");
    expect(DEF.outcome(ended)).not.toBeNull();
  });

  it("END_GAME outside HOLD is WRONG_PHASE", () => {
    const s = until(startGame(2), "REVEAL");
    expect(tryStep(s, { type: "INTENT", intent: { a: "END_GAME" }, by: tv }, s.deadline! - 1)).toMatchObject({ ok: false, error: "WRONG_PHASE" });
  });
});

describe("late joiners (join)", () => {
  it("wait until the next READ, then play from 0 with a New ribbon for one question", () => {
    let s = tick(until(startGame(2), "READ")); // ANSWER of q1
    const r = DEF.join!(s, { id: "p9", seat: 9, locale: "fr", connected: true, carryScore: 0 });
    expect(r.ok).toBe(true);
    s = r.state;
    DEF.assertInvariants(s);
    expect(DEF.projectMe(s, "p9")).toMatchObject({ waitingForNext: true, myChoice: null });
    expect(tryStep(s, { type: "INTENT", intent: { a: "ANSWER", choice: 0 }, by: player("p9") }, s.answerOpenAt! + 10)).toMatchObject({ ok: false, error: "WRONG_PHASE" });
    s = answer(s, "p1", 0, s.answerOpenAt! + 500);
    s = answer(s, "p2", 0, s.answerOpenAt! + 600); // p9 is not awaited
    expect(s.earlyEnd).toBe(true);
    s = until(s, "READ");
    expect(DEF.projectMe(s, "p9")).toMatchObject({ waitingForNext: false, isNew: true });
    s = playQuestion(s, { p9: { ok: true, after: 300 } });
    expect(s.players.find((p) => p.id === "p9")!.score).toBe(1000 + 0);
    s = until(s, "READ");
    expect(DEF.projectMe(s, "p9")!.isNew).toBe(false);
  });

  it("joining in HOLD wakes the game at once (join has no clock)", () => {
    let s = until(startGame(1), "REVEAL");
    s = step(s, { type: "PLAYER_AWAY", playerId: "p1" }, s.deadline! - 1);
    s = tick(s);
    expect(s.phase).toBe("HOLD");
    const j = DEF.join!(s, { id: "p5", seat: 5, locale: "en", connected: true, carryScore: 0 }).state;
    expect(DEF.nextWakeAt(j)).toBe(s.holdAt);
    const r = step(j, { type: "TICK" }, s.holdAt! + 5);
    expect(r.phase).toBe("READ");
    expect(DEF.projectMe(r, "p5")!.waitingForNext).toBe(false);
  });

  it("a known id is a no-op; the 13th active player is refused", () => {
    const s = startGame(12);
    expect(DEF.join!(s, { id: "p3", seat: 3, locale: "en", connected: true, carryScore: 0 }).state).toBe(s);
    expect(DEF.join!(s, { id: "p13", seat: 13, locale: "en", connected: true, carryScore: 0 })).toMatchObject({ ok: false, error: "GAME_FULL" });
  });
});

describe("leaving", () => {
  it("a left player's score is frozen, shown greyed, and excluded from the outcome", () => {
    let s = until(startGame(3, { length: "short" }), "READ");
    s = playQuestion(s, { p1: { ok: true, after: 300 }, p2: { ok: true, after: 300 }, p3: { ok: true, after: 300 } });
    s = step(s, { type: "PLAYER_GONE", playerId: "p2", cause: "KICK" }, s.deadline! - 1);
    expect(DEF.projectPublic(s).scores.find((r) => r.playerId === "p2")).toMatchObject({ score: 1000, left: true });
    s = until(s, "READ");
    s = playQuestion(s, { p1: { ok: true, after: 300 } });
    expect(s.results[1]!.choices.map((c) => c.id)).toEqual(["p1", "p3"]);
    s = until(s, "RESULTS");
    const o = DEF.outcome(s)!;
    expect(o.points.p2).toBe(0);
    expect(o.ranking.flat()).not.toContain("p2");
  });
});

describe("VOID_QUESTION", () => {
  it("restores scores and streaks, logs the id, idempotent; host only, REVEAL only, current id only", () => {
    let s = until(startGame(2), "READ");
    s = playQuestion(s, { p1: { ok: true, after: 300 }, p2: { ok: false, after: 300 } });
    s = until(s, "READ");
    s = playQuestion(s, { p1: { ok: true, after: 300 }, p2: { ok: true, after: 300 } });
    expect(s.players.map((p) => [p.score, p.streak])).toEqual([[2100, 2], [1000, 1]]);
    const qid = s.questions[1]!.id;
    expect(tryStep(s, { type: "INTENT", intent: { a: "VOID_QUESTION", questionId: qid }, by: player("p2") }, s.deadline! - 1)).toMatchObject({ ok: false, error: "NOT_HOST" });
    expect(tryStep(s, { type: "INTENT", intent: { a: "VOID_QUESTION", questionId: s.questions[0]!.id }, by: tv }, s.deadline! - 1)).toMatchObject({ ok: false, error: "WRONG_PHASE" });
    const v = host(s, { a: "VOID_QUESTION", questionId: qid }, s.deadline! - 1);
    expect(v.players.map((p) => [p.score, p.streak, p.correct])).toEqual([[1000, 1, 1], [0, 0, 0]]);
    expect(v.voidedQuestionIds).toEqual([qid]);
    expect(DEF.projectPublic(v).reveal).toMatchObject({ voided: true });
    expect(DEF.projectPublic(v).reveal!.choices.every((c) => c.points === 0)).toBe(true);
    expect(host(v, { a: "VOID_QUESTION", questionId: qid }, v.deadline! - 1)).toBe(v);
    const next = until(tick(v), "READ");
    expect(tryStep(next, { type: "INTENT", intent: { a: "VOID_QUESTION", questionId: qid }, by: tv }, next.deadline! - 1)).toMatchObject({ ok: false, error: "WRONG_PHASE" });
  });
});

describe("memory", () => {
  it("records only questions that reached READ, as family:id, oldest dropped at 300", () => {
    let s = startGame(1, {}, { usedKeys: ["old:q001", "syn-quiz:q002"] });
    expect(DEF.memory(s).usedKeys).toEqual(["old:q001", "syn-quiz:q002"]);
    s = until(s, "READ");
    s = until(tick(s), "READ");
    const m = DEF.memory(s).usedKeys;
    expect(m.slice(-2)).toEqual([`syn-quiz:${s.questions[0]!.id}`, `syn-quiz:${s.questions[1]!.id}`]);
    const big = Array.from({ length: 300 }, (_, i) => `x:q${i}`);
    const t = until(startGame(1, {}, { usedKeys: big }), "READ");
    const mm = DEF.memory(t).usedKeys;
    expect(mm).toHaveLength(300);
    expect(mm[0]).toBe("x:q1");
    expect(mm[299]).toBe(`syn-quiz:${t.questions[0]!.id}`);
  });
  it("a replay avoids the questions of the previous game", () => {
    const s1 = until(startGame(1), "RESULTS");
    const s2 = startGame(1, {}, { usedKeys: DEF.memory(s1).usedKeys, seed: 43 });
    const prev = new Set(s1.questions.map((q) => q.id));
    expect(s2.questions.filter((q) => prev.has(q.id))).toEqual([]);
    expect(s2.rerun).toBe(false);
  });
});

describe("determinism and purity", () => {
  it("same seed and inputs → same game; reduce never mutates its input", () => {
    const a = until(startGame(3, {}, { seed: 9 }), "RESULTS");
    const b = until(startGame(3, {}, { seed: 9 }), "RESULTS");
    expect(a).toEqual(b);
    const s = tick(until(startGame(2), "READ"));
    const snap = structuredClone(s);
    answer(s, "p1", 0, s.answerOpenAt! + 100);
    tick(s);
    expect(s).toEqual(snap);
  });
});

void wrong;
