// §2.8 / GAME-TRIVIA §13.4 property: random rosters 1–12, random settings and locales, bot answers with random latencies,
// host moves (advance, void, end), AWAY/BACK/GONE and late joins. After EVERY reduce: invariants, no leak in any view
// (structural leakCheck, forbidden keys, secret leaves), termination, determinism.
import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { botHostIntent, botIntent, type TriviaSettings, type TriviaState } from "../src";
import { createRng, type GameAction } from "../src/platform";
import { CATALOG, ctx, DEF, LOCALES, roster, T0 } from "./helpers";

function checkViews(s: TriviaState): void {
  const tv = DEF.projectPublic(s, CATALOG);
  const errs = DEF.leakCheck(s, null, tv);
  if (errs.length) throw new Error(`TV leak in ${s.phase}: ${errs.join("; ")}`);
  const tvJson = JSON.stringify(tv);
  for (const secret of DEF.secretsFor(s, null)) if (tvJson.includes(JSON.stringify(secret))) throw new Error(`TV secret leaf ${String(secret)} in ${s.phase}`);
  for (const k of DEF.forbiddenKeys) if (tvJson.includes(`"${k}"`)) throw new Error(`forbidden key ${k}`);
  const status = JSON.stringify(DEF.projectStatus(s));
  if (/"correct"|"choice"/.test(status)) throw new Error("status leak");
  for (const p of s.players) {
    const view = { pub: tv, me: DEF.projectMe(s, p.id) };
    const e = DEF.leakCheck(s, p.id, view);
    if (e.length) throw new Error(`leak for ${p.id} in ${s.phase}: ${e.join("; ")}`);
    const j = JSON.stringify(view);
    for (const k of DEF.forbiddenKeys) if (j.includes(`"${k}"`)) throw new Error(`forbidden key ${k}`);
    for (const secret of DEF.secretsFor(s, p.id)) if (j.includes(JSON.stringify(secret))) throw new Error(`secret leaf for ${p.id}`);
  }
}

function runGame(seed: number, n: number, st: TriviaSettings): { final: TriviaState; trace: string[] } {
  const rng = createRng(seed ^ 0x9e3779b9);
  const locale = LOCALES[seed % 4]!;
  const r = DEF.start({ roster: roster(n, locale), settings: st, locale, memory: { usedKeys: [] }, seed, now: T0, graceMs: 2_500, content: CATALOG });
  if (!r.ok || !r.state) throw new Error("start failed");
  let s = r.state;
  let now = T0;
  let nextId = 100;
  const trace: string[] = [];
  const apply = (a: GameAction<Parameters<typeof DEF.reduce>[1] extends GameAction<infer I> ? I : never>) => {
    const res = DEF.reduce(s, a, ctx(now, CATALOG, "p1"));
    if (!res.ok && res.state !== s) throw new Error("error must return the same state");
    s = res.state;
    DEF.assertInvariants(s);
    checkViews(s);
    trace.push(`${s.phase}:${s.index}`);
  };
  checkViews(s);
  for (let i = 0; i < 6_000 && s.phase !== "RESULTS"; i++) {
    const roll = rng.next();
    if (roll < 0.5) {
      const p = s.players[rng.int(s.players.length)]!;
      const intent = botIntent(s, p.id, rng) ?? { a: "ANSWER" as const, choice: rng.int(5) - 1 }; // also invalid / wrong-phase tries
      now += rng.int(1_500);
      apply({ type: "INTENT", intent, by: { kind: "player", playerId: p.id } });
    } else if (roll < 0.6) {
      const h = botHostIntent(s, rng);
      if (h) apply({ type: "INTENT", intent: h, by: rng.next() < 0.8 ? { kind: "tv" } : { kind: "player", playerId: "p2" } });
    } else if (roll < 0.68) {
      const p = s.players[rng.int(s.players.length)]!;
      const t = rng.next();
      apply(t < 0.45 ? { type: "PLAYER_AWAY", playerId: p.id } : t < 0.93 ? { type: "PLAYER_BACK", playerId: p.id } : { type: "PLAYER_GONE", playerId: p.id, cause: "LEAVE" });
    } else if (roll < 0.7 && s.players.length < 12) {
      const res = DEF.join!(s, { id: `j${nextId++}`, seat: 50 + nextId, locale, connected: rng.next() < 0.8, carryScore: 0 });
      s = res.state;
      DEF.assertInvariants(s);
      checkViews(s);
    } else {
      const wake = DEF.nextWakeAt(s);
      if (wake === null) {
        // HOLD with nobody: bring someone back (or the host ends it)
        const p = s.players.find((x) => !x.left);
        if (p) apply({ type: "PLAYER_BACK", playerId: p.id });
        else apply({ type: "INTENT", intent: { a: "END_GAME" }, by: { kind: "tv" } });
      } else {
        now = Math.max(now, wake + rng.int(200));
        apply({ type: "TICK" });
      }
    }
  }
  return { final: s, trace };
}

const settingsArb = fc.record({
  quizId: fc.constant(null),
  length: fc.constantFrom("short" as const, "normal" as const, "long" as const),
  pace: fc.constantFrom("relaxed" as const, "normal" as const, "fast" as const),
});

describe("random games", () => {
  it("terminate, keep invariants and never leak before REVEAL", () => {
    fc.assert(fc.property(fc.integer({ min: 1, max: 2 ** 31 - 1 }), fc.integer({ min: 1, max: 12 }), settingsArb, (seed, n, st) => {
      const { final } = runGame(seed, n, st);
      expect(final.phase).toBe("RESULTS");
      const o = DEF.outcome(final)!;
      for (const g of o.ranking) for (const id of g) expect(o.points[id]).toBeGreaterThan(0);
    }), { numRuns: 150 });
  });

  it("is deterministic", () => {
    for (const seed of [1, 99, 12345]) {
      const st: TriviaSettings = { quizId: null, length: "normal", pace: "fast" };
      expect(runGame(seed, 6, st).trace).toEqual(runGame(seed, 6, st).trace);
    }
  });
});
