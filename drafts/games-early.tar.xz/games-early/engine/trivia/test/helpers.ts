// Synthetic unique-token catalog (shared/src/testing/catalogs/trivia.ts draft) and the test harness.
import { definition as DEF, type TriviaCatalog, type TriviaIntent, type TriviaPack, type TriviaQuestion, type TriviaSettings, type TriviaState, type Topic, type Domain } from "../src";
import type { GameAction, GameActor, GameCtx, Locale, RosterEntry } from "../src/platform";

export { DEF };
const TOPIC_CYCLE: Topic[] = ["music", "geography", "football", "food", "history", "dance"];

export interface PackOpts {
  family?: string; locale?: Locale; n?: number; stars?: 1 | 2 | 3; domain?: Domain; tier?: "free" | "premium";
  /** difficulty of question i (default: 1,2,2,3,1,2,3,2 cycle → mean ≈ 2) */
  diff?: (i: number) => 1 | 2 | 3;
  /** tf every k questions (0 = none) */
  tfEvery?: number;
  easyIn?: (i: number) => Locale[];
  explainEvery?: number;
  topics?: Topic[];
}
const DIFF: (1 | 2 | 3)[] = [1, 2, 2, 3, 1, 2, 3, 2];

export function synthPack(o: PackOpts = {}): TriviaPack {
  const family = o.family ?? "syn-quiz";
  const locale = o.locale ?? "en";
  const n = o.n ?? 40;
  const topicsCycle = o.topics ?? TOPIC_CYCLE;
  const tok = (k: string) => `${family}-${locale}-${k}`;
  const questions: TriviaQuestion[] = Array.from({ length: n }, (_, i) => {
    const tf = (o.tfEvery ?? 8) > 0 && i % (o.tfEvery ?? 8) === 7 % (o.tfEvery ?? 8);
    const q: TriviaQuestion = {
      id: `q${String(i + 1).padStart(3, "0")}`,
      type: tf ? "tf" : "mc4",
      text: tok(`text-${i}`),
      options: tf ? [tok(`true-${i}`), tok(`false-${i}`)] : [0, 1, 2, 3].map((k) => tok(`opt-${i}-${k}`)),
      answer: tf ? i % 2 : i % 4,
      topic: topicsCycle[i % topicsCycle.length] as Topic,
      difficulty: o.diff ? o.diff(i) : (DIFF[i % DIFF.length] as 1 | 2 | 3),
      easyIn: o.easyIn ? o.easyIn(i) : [],
      source: tok(`src-${i}`),
    };
    if (o.explainEvery && i % o.explainEvery === 0) q.explain = tok(`explain-${i}`);
    return q;
  });
  return {
    id: `${family}-${locale}`, family, game: "trivia", version: 1, locale, script: locale === "ar" ? "Arab" : "Latn",
    title: { en: `${family} en`, fr: `${family} fr`, ar: `${family} ar`, es: `${family} es` },
    domain: o.domain ?? "lebanon", topics: [...new Set(questions.map((q) => q.topic))],
    featuredTopics: topicsCycle.slice(0, 3), stars: o.stars ?? 2, ageRating: "all", tier: o.tier ?? "free",
    license: "test", source: "synthetic", status: "draft", reviewedBy: [], questions,
  };
}

export const LOCALES: Locale[] = ["en", "fr", "ar", "es"];
export const CATALOG: TriviaCatalog = { packs: LOCALES.map((locale) => synthPack({ locale, explainEvery: 3 })) };

export const GRACE = 2_500;
export const T0 = 1_000_000;
export const ids = (n: number): string[] => Array.from({ length: n }, (_, i) => `p${i + 1}`);
export function roster(n: number, locale: Locale = "en"): RosterEntry[] {
  return ids(n).map((id, i) => ({ id, seat: i, locale, connected: true, carryScore: 0 }));
}
export function settings(p: Partial<TriviaSettings> = {}): TriviaSettings {
  return { quizId: null, length: "normal", pace: "normal", ...p };
}

export function startGame(n: number, s: Partial<TriviaSettings> = {}, o: { content?: TriviaCatalog; seed?: number; usedKeys?: string[]; locale?: Locale; roster?: RosterEntry[] } = {}): TriviaState {
  const r = DEF.start({ roster: o.roster ?? roster(n, o.locale), settings: settings(s), locale: o.locale ?? "en", memory: { usedKeys: o.usedKeys ?? [] }, seed: o.seed ?? 42, now: T0, graceMs: GRACE, content: o.content ?? CATALOG });
  if (!r.ok || !r.state) throw new Error(`start failed: ${r.ok ? "" : r.error}`);
  DEF.assertInvariants(r.state);
  return r.state;
}

export function ctx(now: number, content: TriviaCatalog = CATALOG, host: string | null = "p1"): GameCtx<TriviaCatalog> {
  return { now, content, hostPlayerId: host, isHost: (a: GameActor) => a.kind === "tv" || (a.kind === "player" && a.playerId === host) };
}

export function step(s: TriviaState, a: GameAction<TriviaIntent>, now: number): TriviaState {
  const r = DEF.reduce(s, a, ctx(now));
  if (!r.ok) throw new Error(`reduce failed: ${r.error} for ${JSON.stringify(a)}`);
  DEF.assertInvariants(r.state);
  return r.state;
}
export function tryStep(s: TriviaState, a: GameAction<TriviaIntent>, now: number) { return DEF.reduce(s, a, ctx(now)); }
export function tick(s: TriviaState, late = 0): TriviaState {
  if (s.deadline === null) throw new Error(`tick without deadline in ${s.phase}`);
  return step(s, { type: "TICK" }, s.deadline + late);
}
export const tv: GameActor = { kind: "tv" };
export const player = (id: string): GameActor => ({ kind: "player", playerId: id });
export const host = (s: TriviaState, intent: TriviaIntent, now: number): TriviaState => step(s, { type: "INTENT", intent, by: tv }, now);
export const answer = (s: TriviaState, id: string, choice: number, now: number): TriviaState =>
  step(s, { type: "INTENT", intent: { a: "ANSWER", choice }, by: player(id) }, now);

/** The displayed position of the right answer (test-only peek into state). */
export const right = (s: TriviaState): number => s.questions[s.index]!.correctIndex;
export const wrong = (s: TriviaState): number => (right(s) + 1) % s.questions[s.index]!.options.length;

/** Ticks until `phase` (max 200 steps). */
export function until(s: TriviaState, phase: TriviaState["phase"]): TriviaState {
  let x = s;
  for (let i = 0; i < 200 && x.phase !== phase; i++) x = tick(x);
  if (x.phase !== phase) throw new Error(`never reached ${phase} (at ${x.phase})`);
  return x;
}

/** From READ: open the answer window, apply `plan` (player → {right|wrong, delayMs after open}), reveal. */
export function playQuestion(s: TriviaState, plan: Record<string, { ok: boolean; after: number }>): TriviaState {
  if (s.phase !== "READ") throw new Error(`playQuestion from ${s.phase}`);
  let x = tick(s);
  const open = x.answerOpenAt as number;
  const entries = Object.entries(plan).sort((a, b) => a[1].after - b[1].after);
  for (const [id, p] of entries) if (x.phase === "ANSWER") x = answer(x, id, p.ok ? right(x) : wrong(x), open + p.after);
  if (x.phase === "ANSWER") x = tick(x);
  return x;
}
