// GAME-TRIVIA §13.4: scoring table, streak cap, ranking tie-breaks, highlights.
import { describe, expect, it } from "vitest";
import { answerMs, answerPoints, answerTime, highlights, isOnFire, rankGroups, rankRows, readMs, scoreAnswer, speedBonus, streakBonus } from "../src";

const T = 15_000;

describe("answer time (§5.1)", () => {
  it("subtracts the 300 ms grace and clamps to [0, T]", () => {
    const open = 10_000;
    expect(answerTime(open, open, T)).toBe(0);
    expect(answerTime(open + 299, open, T)).toBe(0);
    expect(answerTime(open + 300, open, T)).toBe(0);
    expect(answerTime(open + 301, open, T)).toBe(1);
    expect(answerTime(open + 7_800, open, T)).toBe(7_500);
    expect(answerTime(open + T + 300, open, T)).toBe(T);
    expect(answerTime(open + T + 5_000, open, T)).toBe(T);
    expect(answerTime(open - 50, open, T)).toBe(0);
  });
});

describe("points (§5.2)", () => {
  it.each([
    ["mc4", 0, 1000], ["mc4", T / 2, 750], ["mc4", T, 500],
    ["mc4", 150, 1000],   // 495 → 500 (half up)
    ["mc4", 450, 990],    // 485 → 490
    ["mc4", 14_999, 500], // 0.33 → 0
  ] as const)("%s at t=%d → %d", (type, t, pts) => {
    expect(answerPoints(type, t, T)).toBe(pts);
  });

  it("tf scores half: 250..500 on its own T", () => {
    const Ttf = 10_000;
    expect(answerPoints("tf", 0, Ttf)).toBe(500);
    expect(answerPoints("tf", Ttf, Ttf)).toBe(250);
    expect(answerPoints("tf", Ttf / 2, Ttf)).toBe(380); // 125 → 130 (round half up)
  });

  it("round10 is exact at every millisecond (no float drift)", () => {
    for (let t = 0; t <= T; t += 7) {
      const exact = 500 * (1 - t / T);
      const want = Math.floor(exact / 10 + 0.5 + 1e-9) * 10;
      expect(speedBonus("mc4", t, T)).toBe(want);
      expect(speedBonus("mc4", t, T) % 10).toBe(0);
    }
  });

  it("final ×2 doubles base + speed, not the streak bonus", () => {
    expect(scoreAnswer({ correct: true, type: "mc4", t: 0, T, isFinal: true, prevStreak: 0 })).toEqual({ points: 2000, streakBonus: 0, streak: 1 });
    expect(scoreAnswer({ correct: true, type: "mc4", t: T, T, isFinal: true, prevStreak: 5 })).toEqual({ points: 1000, streakBonus: 300, streak: 6 });
    expect(scoreAnswer({ correct: true, type: "tf", t: 0, T: 10_000, isFinal: true, prevStreak: 1 })).toEqual({ points: 1000, streakBonus: 100, streak: 2 });
  });

  it("streak 1..8 with the +300 cap", () => {
    expect([1, 2, 3, 4, 5, 6, 7, 8].map(streakBonus)).toEqual([0, 100, 200, 300, 300, 300, 300, 300]);
  });

  it("wrong or no answer: 0 points and the streak resets", () => {
    expect(scoreAnswer({ correct: false, type: "mc4", t: 0, T, isFinal: false, prevStreak: 7 })).toEqual({ points: 0, streakBonus: 0, streak: 0 });
    expect(scoreAnswer({ correct: true, type: "mc4", t: null, T, isFinal: false, prevStreak: 7 })).toEqual({ points: 0, streakBonus: 0, streak: 0 });
  });

  it("correct-but-slow always beats wrong-but-fast and is at least half the fastest", () => {
    expect(answerPoints("mc4", T, T)).toBeGreaterThanOrEqual(answerPoints("mc4", 0, T) / 2);
    expect(answerPoints("tf", 10_000, 10_000)).toBeGreaterThanOrEqual(answerPoints("tf", 0, 10_000) / 2);
  });

  it("on fire at 3, 5, 7…", () => {
    expect([1, 2, 3, 4, 5, 6, 7, 9].map(isOnFire)).toEqual([false, false, true, false, true, false, true, true]);
  });
});

describe("durations (§4.1, §9)", () => {
  it("READ = clamp(2 500 + 40 × chars, 3 000, 7 000)", () => {
    expect(readMs(0)).toBe(3_000);
    expect(readMs(12)).toBe(3_000);
    expect(readMs(13)).toBe(3_020);
    expect(readMs(50)).toBe(4_500);
    expect(readMs(112)).toBe(6_980);
    expect(readMs(160)).toBe(7_000);
  });
  it("pace: mc4 20/15/10 s, tf 2/3 rounded to the second", () => {
    expect([answerMs("mc4", "relaxed"), answerMs("mc4", "normal"), answerMs("mc4", "fast")]).toEqual([20_000, 15_000, 10_000]);
    expect([answerMs("tf", "relaxed"), answerMs("tf", "normal"), answerMs("tf", "fast")]).toEqual([13_000, 10_000, 7_000]);
  });
});

describe("ranking (§5.3)", () => {
  const row = (id: string, seat: number, score: number, correct: number, timeSum: number) => ({ id, seat, score, correct, timeSum });
  it("points ↓, then correct ↓, then time ↑, then shared place", () => {
    const rows = [
      row("a", 0, 1000, 2, 3000),
      row("b", 1, 1500, 2, 9000),
      row("c", 2, 1000, 3, 9000),
      row("d", 3, 1000, 2, 2000),
      row("e", 4, 1000, 2, 2000),
      row("f", 5, 0, 0, 0),
    ];
    const ranked = rankRows(rows);
    expect(ranked.map((r) => [r.id, r.rank])).toEqual([["b", 1], ["c", 2], ["d", 3], ["e", 3], ["a", 5], ["f", 6]]);
    expect(rankGroups(rows)).toEqual([["b"], ["c"], ["d", "e"], ["a"], ["f"]]);
  });
  it("a tie at the top is a shared first place", () => {
    expect(rankGroups([row("a", 0, 900, 1, 100), row("b", 1, 900, 1, 100)])).toEqual([["a", "b"]]);
  });
});

describe("highlights (§5.4)", () => {
  const c = (id: string, choice: number | null, correct: boolean, timeMs: number | null) => ({ id, choice, correct, timeMs });
  it("fastest finger needs ≥ 2 correct; ties are all fastest", () => {
    expect(highlights([c("a", 0, true, 100)]).fastestIds).toEqual([]);
    expect(highlights([c("a", 0, true, 100), c("b", 0, true, 50), c("x", 1, false, 10)]).fastestIds).toEqual(["b"]);
    expect(highlights([c("a", 0, true, 50), c("b", 0, true, 50)]).fastestIds).toEqual(["a", "b"]);
  });
  it("stumped, genius (≥ 3 answers), too slow", () => {
    expect(highlights([c("a", 1, false, 1), c("b", null, false, null)])).toMatchObject({ stumped: true, genius: false, tooSlow: false });
    expect(highlights([c("a", 0, true, 1), c("b", 0, true, 2), c("d", 0, true, 3), c("e", null, false, null)])).toMatchObject({ genius: true, stumped: false });
    expect(highlights([c("a", 0, true, 1), c("b", 0, true, 2)]).genius).toBe(false);
    expect(highlights([c("a", null, false, null)])).toMatchObject({ tooSlow: true, stumped: true });
  });
});
