// GAME-TRIVIA §11.4 draw: curve, easyIn, final from difficulty 2, topic spread, tf ≤ 1 in 4, LRU, capping, shuffles.
import { describe, expect, it } from "vitest";
import { bandsFor, displayOrder, drawQuestions, effectiveDifficulty, memoryKey, zones, type TriviaQuestion } from "../src";
import { createRng } from "../src/platform";
import { synthPack } from "./helpers";

const SEEDS = Array.from({ length: 200 }, (_, i) => i * 7919 + 1);

function checkSpread(qs: readonly TriviaQuestion[]): void {
  for (let i = 2; i < qs.length; i++) {
    expect(qs[i]!.topic === qs[i - 1]!.topic && qs[i]!.topic === qs[i - 2]!.topic, `3 in a row at ${i}`).toBe(false);
  }
  for (let i = 0; i + 4 <= qs.length; i++) {
    expect(qs.slice(i, i + 4).filter((q) => q.type === "tf").length, `tf window at ${i}`).toBeLessThanOrEqual(1);
  }
}

describe("zones", () => {
  it("30 / 40 / 30 by length", () => {
    expect(zones(10)).toEqual({ length: 10, easyEnd: 3, hardStart: 7 });
    expect(zones(7)).toEqual({ length: 7, easyEnd: 2, hardStart: 5 });
    expect(zones(15)).toEqual({ length: 15, easyEnd: 5, hardStart: 10 });
    expect(bandsFor(9, zones(10))).toEqual([2, 3, 1]);
    expect(bandsFor(0, zones(10))).toEqual([1, 2, 3]);
    expect(bandsFor(8, zones(10))).toEqual([3, 2, 1]);
  });
});

describe("drawQuestions", () => {
  const pack = synthPack({ n: 80 });

  it.each(["short", "normal", "long"] as const)("%s: curve, final from difficulty 2, spread, across seeds", (length) => {
    for (const seed of SEEDS) {
      const { questions: qs } = drawQuestions(pack, length, [], "en", createRng(seed));
      const z = zones(qs.length);
      expect(new Set(qs.map((q) => q.id)).size).toBe(qs.length);
      expect(qs[qs.length - 1]!.difficulty).toBe(2);
      qs.forEach((q, i) => {
        if (i === qs.length - 1) return;
        if (i < z.easyEnd) expect(q.difficulty).toBe(1);
        else if (i >= z.hardStart) expect(q.difficulty).toBe(3);
        else expect(q.difficulty).toBe(2);
      });
      checkSpread(qs);
    }
  });

  it("easyIn lowers effective difficulty and is never in the last 30 %", () => {
    // every 3rd question is "easy in ar" although authored difficulty 3
    const p = synthPack({ n: 80, diff: (i) => (i % 3 === 0 ? 3 : ([1, 2, 3, 2] as const)[i % 4]!), easyIn: (i) => (i % 3 === 0 ? ["ar"] : []) });
    const q0 = p.questions[0]!;
    expect(effectiveDifficulty(q0, "ar")).toBe(1);
    expect(effectiveDifficulty(q0, "en")).toBe(3);
    let easyInUsedEarly = 0;
    for (const seed of SEEDS) {
      const { questions: qs } = drawQuestions(p, "long", [], "ar", createRng(seed));
      const z = zones(qs.length);
      qs.forEach((q, i) => {
        if (i >= z.hardStart) expect(q.easyIn.includes("ar"), `easyIn at slot ${i}`).toBe(false);
        if (i < z.easyEnd && q.easyIn.includes("ar")) easyInUsedEarly++;
      });
    }
    expect(easyInUsedEarly).toBeGreaterThan(0); // they do serve as easy questions
  });

  it("prefers unused questions, then least recently used first; flags a rerun", () => {
    const fam = pack.family!;
    const allButTen = pack.questions.slice(10).map((q) => memoryKey(fam, q.id));
    const r1 = drawQuestions(pack, "normal", allButTen, "en", createRng(1));
    // 10 fresh questions exist but their difficulties may not fit the curve: freshness beats the band order
    expect(r1.questions.map((q) => q.id).sort()).toEqual(pack.questions.slice(0, 10).map((q) => q.id).sort());
    expect(r1.rerun).toBe(false);

    const everything = pack.questions.map((q) => memoryKey(fam, q.id)); // oldest first
    const r2 = drawQuestions(pack, "short", everything, "en", createRng(1));
    expect(r2.rerun).toBe(true);
    // all used: picks come from the oldest part of the history
    const pos = r2.questions.map((q) => everything.indexOf(memoryKey(fam, q.id)));
    expect(Math.max(...pos)).toBeLessThan(40);
  });

  it("memory keys of another quiz do not count", () => {
    const other = pack.questions.map((q) => memoryKey("other-quiz", q.id));
    expect(drawQuestions(pack, "normal", other, "en", createRng(3)).rerun).toBe(false);
  });

  it("caps the length to the pool", () => {
    const small = synthPack({ n: 6 });
    const { questions } = drawQuestions(small, "long", [], "en", createRng(5));
    expect(questions).toHaveLength(6);
  });

  it("still fills every slot when the bands are lopsided (fallbacks)", () => {
    const allHard = synthPack({ n: 20, diff: () => 3, tfEvery: 0 });
    for (const seed of SEEDS.slice(0, 30)) {
      const { questions } = drawQuestions(allHard, "long", [], "en", createRng(seed));
      expect(questions).toHaveLength(15);
      expect(new Set(questions.map((q) => q.id)).size).toBe(15);
    }
    const oneTopic = synthPack({ n: 20, topics: ["music"] });
    expect(drawQuestions(oneTopic, "normal", [], "en", createRng(9)).questions).toHaveLength(10); // spread relaxed
  });

  it("is deterministic for a seed", () => {
    const a = drawQuestions(pack, "normal", [], "en", createRng(77)).questions.map((q) => q.id);
    const b = drawQuestions(pack, "normal", [], "en", createRng(77)).questions.map((q) => q.id);
    expect(a).toEqual(b);
  });
});

describe("displayOrder", () => {
  it("shuffles mc4 so the correct position is spread; tf stays True, False", () => {
    const p = synthPack({ n: 16 });
    const mc4 = p.questions.find((q) => q.type === "mc4")!;
    const tf = p.questions.find((q) => q.type === "tf")!;
    const counts = [0, 0, 0, 0];
    const rng = createRng(11);
    for (let i = 0; i < 4_000; i++) {
      const order = displayOrder(mc4, rng);
      expect([...order].sort()).toEqual([0, 1, 2, 3]);
      counts[order.indexOf(mc4.answer)]! += 1;
      expect(displayOrder(tf, rng)).toEqual([0, 1]);
    }
    for (const c of counts) expect(c).toBeGreaterThan(850); // ≈ 1000 each
  });
});
