// GAME-TRIVIA §9 settings, platform §2.12 family semantics, projectSetup extras, meta shape.
import { describe, expect, it } from "vitest";
import { DEFAULT_SETTINGS, TRIVIA_META, type TriviaCatalog } from "../src";
import { DEF, roster, synthPack } from "./helpers";

const lb = (locale: "en" | "fr" | "ar" | "es") => synthPack({ family: "lb-quiz-01", locale, n: 24 });
const world = (locale: "en" | "fr" | "ar" | "es") => synthPack({ family: "world-mix-01", locale, domain: "world", stars: 1, n: 30, tier: "premium" });
const TWO: TriviaCatalog = { packs: [lb("en"), lb("fr"), lb("ar"), lb("es"), world("en"), world("fr")] };
const access = (ids: string[], premium = false) => ({ playableIds: new Set(ids), premium });

describe("normalize", () => {
  it("maps garbage and missing keys to defaults", () => {
    expect(DEF.settings.normalize(undefined)).toEqual(DEFAULT_SETTINGS);
    expect(DEF.settings.normalize([1, 2])).toEqual(DEFAULT_SETTINGS);
    expect(DEF.settings.normalize({ quizId: "Bad Id!", length: "huge", pace: 3, extra: 1 })).toEqual(DEFAULT_SETTINGS);
    expect(DEF.settings.normalize({ quizId: "lb-quiz-01", length: "long", pace: "fast" })).toEqual({ quizId: "lb-quiz-01", length: "long", pace: "fast" });
    expect(DEF.settings.normalize({ length: "toString" }).length).toBe("normal"); // no prototype keys
  });
});

describe("apply", () => {
  it("accepts a playable family in the content language, rejects others and unknown keys", () => {
    const s = DEFAULT_SETTINGS;
    expect(DEF.settings.apply(s, { quizId: "world-mix-01" }, TWO, "fr")).toEqual({ ...s, quizId: "world-mix-01" });
    expect(DEF.settings.apply(s, { quizId: "world-mix-01" }, TWO, "ar")).toBeNull();     // no ar pack
    expect(DEF.settings.apply(s, { quizId: "lb-quiz-01-en" }, TWO, "en")).toBeNull();   // a pack id, not a family
    expect(DEF.settings.apply(s, { length: "long", pace: "relaxed" }, TWO, "en")).toEqual({ quizId: null, length: "long", pace: "relaxed" });
    expect(DEF.settings.apply(s, { length: "xl" as never }, TWO, "en")).toBeNull();
    expect(DEF.settings.apply(s, { foo: 1 } as never, TWO, "en")).toBeNull();
    expect(DEF.settings.apply(s, { length: "normal" }, TWO, "en")).toBe(s);              // unchanged → same object
  });
});

describe("restrict and the content-language change", () => {
  it("keeps the family when it exists in the new locale; resets locked or missing ones to null", () => {
    const s = { ...DEFAULT_SETTINGS, quizId: "lb-quiz-01" };
    expect(DEF.settings.restrict(s, access(["lb-quiz-01"]), TWO, "ar")).toBe(s);
    const w = { ...DEFAULT_SETTINGS, quizId: "world-mix-01" };
    expect(DEF.settings.restrict(w, access(["lb-quiz-01", "world-mix-01"]), TWO, "fr")).toBe(w);
    expect(DEF.settings.restrict(w, access(["lb-quiz-01", "world-mix-01"]), TWO, "es").quizId).toBeNull(); // no es pack
    expect(DEF.settings.restrict(w, access(["lb-quiz-01"]), TWO, "en").quizId).toBeNull();                 // locked
    expect(DEF.settings.restrict(DEFAULT_SETTINGS, access([]), TWO, "en")).toBe(DEFAULT_SETTINGS);
  });
  it("packIds returns the family", () => {
    expect(DEF.settings.packIds(DEFAULT_SETTINGS)).toEqual([]);
    expect(DEF.settings.packIds({ ...DEFAULT_SETTINGS, quizId: "lb-quiz-01" })).toEqual(["lb-quiz-01"]);
  });
  it("a started game resolves the family to the pack of the content language", () => {
    for (const locale of ["en", "fr", "ar", "es"] as const) {
      const r = DEF.start({ roster: roster(2), settings: { ...DEFAULT_SETTINGS, quizId: "lb-quiz-01" }, locale, memory: { usedKeys: [] }, seed: 1, now: 0, graceMs: 0, content: TWO });
      expect(r.ok && r.state!.quiz).toMatchObject({ id: "lb-quiz-01", packId: `lb-quiz-01-${locale}` });
    }
  });
});

describe("projectSetup", () => {
  it("one quiz: summary card, no shelf; pool capping shows 'n questions available'", () => {
    const one: TriviaCatalog = { packs: [synthPack({ family: "lb-quiz-01", n: 24 })] };
    const x = DEF.projectSetup({ ...DEFAULT_SETTINGS, length: "long" }, roster(2), one, access(["lb-quiz-01"]), "en");
    expect(x).toMatchObject({ available: 24, questionCount: 15, capped: false, quizzes: [] });
    expect(x.quiz).toMatchObject({ id: "lb-quiz-01", stars: 2, domain: "lebanon", featuredTopics: ["music", "geography", "football"], moreTopics: 3, questionCount: 24 });
    const small: TriviaCatalog = { packs: [{ ...one.packs[0]!, questions: one.packs[0]!.questions.slice(0, 7) }] };
    expect(DEF.projectSetup({ ...DEFAULT_SETTINGS, length: "normal" }, roster(2), small, access([]), "en")).toMatchObject({ available: 7, questionCount: 7, capped: true });
  });
  it("two quizzes: the list for the shelf; none in the locale → nulls", () => {
    expect(DEF.projectSetup(DEFAULT_SETTINGS, roster(2), TWO, access([]), "en").quizzes.map((q) => q.id)).toEqual(["lb-quiz-01", "world-mix-01"]);
    expect(DEF.projectSetup(DEFAULT_SETTINGS, roster(2), TWO, access([]), "ar").quizzes).toEqual([]);
    expect(DEF.projectSetup(DEFAULT_SETTINGS, roster(2), { packs: [] }, access([]), "en")).toMatchObject({ available: 0, quiz: null });
  });
});

describe("meta", () => {
  it("matches GAME-TRIVIA §2 / platform §2.12", () => {
    expect(TRIVIA_META).toMatchObject({ id: "trivia", minPlayers: 1, maxPlayers: 12, carriesScore: false, SETTINGS_SCHEMA: 1 });
    expect(TRIVIA_META.rules.world).toBe("quiz-studio");
    expect(TRIVIA_META.rules.pauseItems.map((p) => p.intent)).toEqual(["HOST_ADVANCE", "VOID_QUESTION", "END_GAME"]);
    expect(TRIVIA_META.settings.basic.map((f) => f.key)).toEqual(["quizId", "length", "pace"]);
    expect(Object.keys(TRIVIA_META.settings.defaults)).toEqual(["quizId", "length", "pace"]);
    expect(TRIVIA_META.settings.premiumKeys).toEqual([]);
  });
});
