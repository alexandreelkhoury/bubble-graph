// Pack parsing, the ContentAdapter, quiz selection (stars / domain / topics, shelf rows), and the drafted packs in
// games-early/content/trivia (skipped when absent) parsed by this engine's schema and played end to end.
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { content, familyOf, filterQuizzes, parsePack, quizShelf, resolveQuiz, type TriviaCatalog, type TriviaPack } from "../src";
import { DEF, roster, synthPack } from "./helpers";

const clone = <T>(x: T): T => structuredClone(x);

describe("parsePack", () => {
  it("accepts a valid pack and keeps defaults", () => {
    const raw = clone(synthPack()) as unknown as Record<string, unknown>;
    delete raw.reviewedBy;
    const p = parsePack(raw);
    expect(p.reviewedBy).toEqual([]);
    expect(p.questions[0]!.easyIn).toEqual([]);
  });

  it.each([
    ["unknown key", (p: any) => { p.extra = 1; }],
    ["game", (p: any) => { p.game = "bluff"; }],
    ["script/locale mismatch", (p: any) => { p.script = "Arab"; }],
    ["stars missing", (p: any) => { delete p.stars; }],
    ["featured ⊄ topics", (p: any) => { p.featuredTopics = ["science"]; }],
    ["topics ≠ used topics", (p: any) => { p.topics = [...p.topics, "art"]; }],
    ["too few questions", (p: any) => { p.questions = p.questions.slice(0, 19); }],
    ["duplicate id", (p: any) => { p.questions[1].id = p.questions[0].id; }],
    ["bad id", (p: any) => { p.questions[0].id = "x1"; }],
    ["mc4 with 3 options", (p: any) => { p.questions[0].options.pop(); }],
    ["duplicate options", (p: any) => { p.questions[0].options[1] = p.questions[0].options[0]; }],
    ["answer out of range", (p: any) => { p.questions[0].answer = 4; }],
    ["tf answer 2", (p: any) => { const q = p.questions.find((x: any) => x.type === "tf"); q.answer = 2; }],
    ["option too long", (p: any) => { p.questions[0].options[0] = "x".repeat(49); }],
    ["text too long", (p: any) => { p.questions[0].text = "x".repeat(161); }],
    ["explain too long", (p: any) => { p.questions[0].explain = "x".repeat(201); }],
    ["missing source", (p: any) => { delete p.questions[0].source; }],
    ["unknown topic", (p: any) => { p.questions[0].topic = "politics"; }],
    ["bad region", (p: any) => { p.questions[0].region = "east"; }],
  ])("rejects: %s", (_name, mutate) => {
    const raw = clone(synthPack());
    mutate(raw);
    expect(() => parsePack(raw)).toThrow();
  });
});

describe("ContentAdapter", () => {
  it("meta and pack-level tiers", () => {
    const free = synthPack({ family: "f" });
    const prem = synthPack({ family: "p", tier: "premium" });
    expect(content.meta(free)).toMatchObject({ id: "f-en", family: "f", gameId: "trivia", languages: ["en"], tier: "free", itemCount: 40, freeItemCount: 40, stars: 2, domain: "lebanon" });
    expect(content.meta({ ...free, locale: "ar-LB", script: "Arab" }).languages).toEqual(["ar"]);
    expect(content.playable(free, { premium: false, ownedFamilies: new Set() })).toBe(free);
    expect(content.playable(prem, { premium: false, ownedFamilies: new Set() })).toBeNull();
    expect(content.playable(prem, { premium: true, ownedFamilies: new Set() })).toBe(prem);
    expect(content.playable(prem, { premium: false, ownedFamilies: new Set(["p"]) })).toBe(prem);
    expect(content.playable({ ...free, ageRating: "adult" }, { premium: true, ownedFamilies: new Set() })).toBeNull();
  });
});

describe("quiz selection", () => {
  const cat: TriviaCatalog = { packs: [
    synthPack({ family: "lb-a", stars: 2, domain: "lebanon" }),
    synthPack({ family: "w-easy", stars: 1, domain: "world", topics: ["geography", "nature", "science"] }),
    synthPack({ family: "lb-hard", stars: 3, domain: "lebanon", topics: ["history", "music", "art"] }),
    synthPack({ family: "fr-only", stars: 2, domain: "france", locale: "fr" }),
    { ...synthPack({ family: "adult" }), ageRating: "adult" as const },
  ] };
  it("filters by stars, domain and topics (all listed topics covered)", () => {
    expect(filterQuizzes(cat, "en").map((q) => q.id)).toEqual(["lb-a", "w-easy", "lb-hard"]);
    expect(filterQuizzes(cat, "en", { stars: [1] }).map((q) => q.id)).toEqual(["w-easy"]);
    expect(filterQuizzes(cat, "en", { stars: [2, 3], domain: "lebanon" }).map((q) => q.id)).toEqual(["lb-a", "lb-hard"]);
    expect(filterQuizzes(cat, "en", { topics: ["music"] }).map((q) => q.id)).toEqual(["lb-a", "lb-hard"]);
    expect(filterQuizzes(cat, "en", { topics: ["music", "art"] }).map((q) => q.id)).toEqual(["lb-hard"]);
    expect(filterQuizzes(cat, "fr").map((q) => q.id)).toEqual(["fr-only"]);
  });
  it("shelf rows by domain in vocabulary order; adult never served", () => {
    expect(quizShelf(cat, "en").map((r) => [r.domain, r.cards.map((c) => c.id)])).toEqual([["lebanon", ["lb-a", "lb-hard"]], ["world", ["w-easy"]]]);
  });
  it("null quizId resolves to the first quiz playable in the locale", () => {
    expect(familyOf(resolveQuiz(cat, null, "en")!)).toBe("lb-a");
    expect(familyOf(resolveQuiz(cat, null, "fr")!)).toBe("fr-only");
    expect(resolveQuiz(cat, null, "ar")).toBeUndefined();
  });
});

// ─── drafted content (sibling lane output; optional) ─────────────────────────────────────────────────────────────────

const DRAFT_DIR = join(__dirname, "../../../content/trivia");
const draftFiles = existsSync(DRAFT_DIR)
  ? readdirSync(DRAFT_DIR).flatMap((loc) => readdirSync(join(DRAFT_DIR, loc)).filter((f) => f.endsWith(".json")).map((f) => join(DRAFT_DIR, loc, f)))
  : [];

describe.skipIf(draftFiles.length === 0)("drafted packs in games-early/content/trivia", () => {
  const packs: TriviaPack[] = draftFiles.map((f) => parsePack(JSON.parse(readFileSync(f, "utf8"))));

  it("every pack parses and families agree across locales on ids, type, answer, topic, difficulty, easyIn, region", () => {
    const fams = new Map<string, TriviaPack[]>();
    for (const p of packs) fams.set(familyOf(p), [...(fams.get(familyOf(p)) ?? []), p]);
    for (const [, ps] of fams) {
      const [ref, ...rest] = ps;
      for (const p of rest) {
        expect(p.questions.map((q) => q.id)).toEqual(ref!.questions.map((q) => q.id));
        p.questions.forEach((q, i) => {
          const r = ref!.questions[i]!;
          expect({ t: q.type, a: q.answer, to: q.topic, d: q.difficulty, e: q.easyIn, rg: q.region }).toEqual({ t: r.type, a: r.answer, to: r.topic, d: r.difficulty, e: r.easyIn, rg: r.region });
        });
      }
    }
  });

  it("every pack plays a long game end to end in its locale", () => {
    const cat: TriviaCatalog = { packs };
    for (const p of packs) {
      const locale = p.locale === "ar-LB" ? "ar" : p.locale;
      const r = DEF.start({ roster: roster(3, locale), settings: { quizId: familyOf(p), length: "long", pace: "normal" }, locale, memory: { usedKeys: [] }, seed: 7, now: 0, graceMs: 2_500, content: cat });
      expect(r.ok).toBe(true);
      let s = r.state!;
      expect(s.questions).toHaveLength(15);
      expect(s.questions[14]!.difficulty).toBe(2);
      while (s.phase !== "RESULTS") s = DEF.reduce(s, { type: "TICK" }, { now: s.deadline!, content: cat, hostPlayerId: null, isHost: () => false }).state;
      DEF.assertInvariants(s);
    }
  });
});
