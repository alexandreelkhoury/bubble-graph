#!/usr/bin/env python3
"""Build Bluff content packs (GAME-BLUFF §11.3 schema) from the compact source files in this folder.

Usage: python3 -I build.py <out_dir>

Source formats
  multi  (*.multi.txt): header lines "key: value", then item blocks:
      @ <id> <difficulty 1-3> <F|-> <knownIn csv|->
      <loc>> prompt | truth | alt;alt | lie;lie;lie | note
      tr> transliteration            (optional, AR-sourced items)
      src> source hint
    For no truth: truth and alts empty.
  single (*.single.txt): header, then lines
      d|F|K|prompt|truth|alts|lies|note|src            (proverb_end, one locale)
  nt     (*.nt.txt): header, then lines
      d|F|prompt|answers                                (no_truth, one locale)
"""
import json, os, re, sys, unicodedata

SRC = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1]
TASHKEEL = re.compile("[ً-ٰٟـ]")
QMAP = str.maketrans({"«": "", "»": "", "“": "", "”": "", "„": "", "‘": "'", "’": "'"})
LOCS = ["en", "fr", "ar", "es"]
problems = []


def clean(s: str) -> str:
    s = unicodedata.normalize("NFC", s.strip()).translate(QMAP)
    s = TASHKEEL.sub("", s)
    s = re.sub(r"\s+", " ", s).strip().lstrip("…").strip().rstrip(".!…").strip()
    if s and s[0].isalpha() and s[0].islower():
        s = s[0].upper() + s[1:]
    return s


def norm(s: str) -> str:
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^\w]+", " ", s).strip()


def split_list(s: str):
    return [clean(x) for x in s.split(";") if x.strip()]


def check_item(pid, it, playable):
    for loc in playable:
        lies = it["houseLies"].get(loc, [])
        if len(lies) < 3:
            problems.append(f"{pid}/{it['id']}: {loc} has {len(lies)} house lies")
        texts = list(it["truth"].get(loc, []) and [it["truth"][loc]]) + lies
        for t in texts + it["truthAlt"].get(loc, []):
            if len(t) > 60:
                problems.append(f"{pid}/{it['id']}: {loc} text > 60: {t}")
        if it["type"] != "no_truth":
            if loc not in it["truth"]:
                problems.append(f"{pid}/{it['id']}: missing truth {loc}")
            tn = norm(it["truth"].get(loc, ""))
            for l in lies:
                if norm(l) == tn:
                    problems.append(f"{pid}/{it['id']}: lie equals truth {loc}: {l}")
        if len({norm(l) for l in lies}) != len(lies):
            problems.append(f"{pid}/{it['id']}: duplicate house lies {loc}")
        if loc == "ar":
            for t in texts:
                if not re.search("[؀-ۿ]", t):
                    problems.append(f"{pid}/{it['id']}: ar text without Arabic letter: {t}")
    for loc, n in it["note"].items():
        if len(n) > 140:
            problems.append(f"{pid}/{it['id']}: note {loc} > 140 ({len(n)})")


def read_header(lines):
    head, body = {}, []
    in_body = False
    for ln in lines:
        if not in_body and re.match(r"^[a-zA-Z_.]+: ", ln):
            k, v = ln.split(": ", 1)
            head[k] = v.strip()
        elif ln.strip() == "---":
            in_body = True
        elif in_body:
            body.append(ln)
    return head, body


def pack_shell(h):
    def tri(prefix):
        return {l: h[f"{prefix}.{l}"] for l in LOCS if f"{prefix}.{l}" in h}
    pack = {
        "schemaVersion": 1,
        "id": h["id"],
        "game": "bluff",
        "title": tri("title"),
        "description": tri("description"),
        "sourceLocale": h["sourceLocale"],
        "playableIn": h["playableIn"].split(","),
        "ageRating": "all",
        "fallbackHouseLies": {},
        "items": [],
    }
    fb = {l: split_list(h[f"fallback.{l}"]) for l in LOCS if f"fallback.{l}" in h}
    if fb:
        pack["fallbackHouseLies"][h["type"]] = fb
    return pack


def build_multi(path):
    h, body = read_header(open(path, encoding="utf-8").read().splitlines())
    pack = pack_shell(h)
    typ, srcloc = h["type"], h["sourceLocale"]
    cur = None
    for ln in body:
        if not ln.strip() or ln.startswith("#"):
            continue
        if ln.startswith("@ "):
            _, iid, d, f, k = ln.split()
            cur = {"id": iid, "type": typ, "tier": "free" if f == "F" else "pass", "difficulty": int(d),
                   "knownIn": [] if k == "-" else k.split(","),
                   "prompt": {"original": "", "translit": None, "display": {}},
                   "truth": {}, "truthAlt": {}, "houseLies": {}, "note": {},
                   "review": {"status": "draft", "source": None}}
            pack["items"].append(cur)
            continue
        m = re.match(r"^(en|fr|ar|es|tr|src)> ?(.*)$", ln)
        if not m:
            problems.append(f"{path}: unparsed line: {ln}")
            continue
        key, val = m.groups()
        if key == "tr":
            cur["prompt"]["translit"] = val.strip()
        elif key == "src":
            cur["review"]["source"] = val.strip()
        else:
            parts = [p.strip() for p in val.split("|")]
            while len(parts) < 5:
                parts.append("")
            prompt, truth, alts, lies, note = parts[:5]
            if key == srcloc:
                cur["prompt"]["original"] = prompt.strip()
            else:
                cur["prompt"]["display"][key] = prompt.strip()
            if truth:
                cur["truth"][key] = clean(truth)
            if alts:
                cur["truthAlt"][key] = split_list(alts)
            if lies:
                cur["houseLies"][key] = split_list(lies)
            if note:
                cur["note"][key] = note.strip()
    return pack


def build_single(path):
    h, body = read_header(open(path, encoding="utf-8").read().splitlines())
    pack = pack_shell(h)
    loc = h["sourceLocale"]
    n = 0
    for ln in body:
        if not ln.strip() or ln.startswith("#"):
            continue
        p = [x.strip() for x in ln.split("|")]
        if len(p) != 9:
            problems.append(f"{path}: bad line ({len(p)} fields): {ln}")
            continue
        d, f, k, prompt, truth, alts, lies, note, src = p
        n += 1
        pr = prompt.strip()
        if not pr.endswith("…"):
            pr += "…"
        pack["items"].append({
            "id": f"{h['prefix']}-{n:03d}", "type": "proverb_end", "tier": "free" if f == "F" else "pass",
            "difficulty": int(d), "knownIn": [loc] if k == "K" else [],
            "prompt": {"original": pr, "translit": None, "display": {}},
            "truth": {loc: clean(truth)}, "truthAlt": {loc: split_list(alts)} if alts else {},
            "houseLies": {loc: split_list(lies)}, "note": {loc: note},
            "review": {"status": "draft", "source": src}})
    return pack


def build_nt(path):
    h, body = read_header(open(path, encoding="utf-8").read().splitlines())
    pack = pack_shell(h)
    loc = h["sourceLocale"]
    n = 0
    for ln in body:
        if not ln.strip() or ln.startswith("#"):
            continue
        p = [x.strip() for x in ln.split("|")]
        if len(p) != 4:
            problems.append(f"{path}: bad line: {ln}")
            continue
        d, f, prompt, ans = p
        n += 1
        pack["items"].append({
            "id": f"{h['prefix']}-{n:03d}", "type": "no_truth", "tier": "free" if f == "F" else "pass",
            "difficulty": int(d), "knownIn": [],
            "prompt": {"original": prompt, "translit": None, "display": {}},
            "truth": {}, "truthAlt": {}, "houseLies": {loc: split_list(ans)},
            "note": {loc: h.get("note", "")} if h.get("note") else {},
            "review": {"status": "draft", "source": None}})
    return pack


def main():
    os.makedirs(OUT, exist_ok=True)
    ids = set()
    report = []
    for fn in sorted(os.listdir(SRC)):
        path = os.path.join(SRC, fn)
        if fn.endswith(".multi.txt"):
            pack = build_multi(path)
        elif fn.endswith(".single.txt"):
            pack = build_single(path)
        elif fn.endswith(".nt.txt"):
            pack = build_nt(path)
        else:
            continue
        for it in pack["items"]:
            if it["id"] in ids:
                problems.append(f"duplicate id {it['id']}")
            ids.add(it["id"])
            if not re.match(r"^[a-z0-9-]{3,40}$", it["id"]):
                problems.append(f"bad id {it['id']}")
            check_item(pack["id"], it, pack["playableIn"])
        free = sum(1 for it in pack["items"] if it["tier"] == "free")
        n = len(pack["items"])
        if free / n < 0.3:
            problems.append(f"{pack['id']}: only {free}/{n} free")
        with open(os.path.join(OUT, pack["id"] + ".json"), "w", encoding="utf-8") as fh:
            json.dump(pack, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
        report.append(f"{pack['id']}: {n} items ({free} free), playableIn={','.join(pack['playableIn'])}")
    print("\n".join(report))
    print(f"\n{len(problems)} problems")
    print("\n".join(problems))


main()
