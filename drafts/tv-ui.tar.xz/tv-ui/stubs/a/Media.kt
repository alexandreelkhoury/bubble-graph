package android.media
class AudioAttributes { class Builder { fun setUsage(u: Int) = this; fun setContentType(c: Int) = this; fun build() = AudioAttributes() }
  companion object { const val USAGE_GAME = 14; const val USAGE_MEDIA = 1; const val CONTENT_TYPE_SONIFICATION = 4 } }
class SoundPool { class Builder { fun setMaxStreams(n: Int) = this; fun setAudioAttributes(a: AudioAttributes) = this; fun build() = SoundPool() }
  fun load(c: android.content.Context, resId: Int, priority: Int): Int = 0
  fun play(soundId: Int, l: Float, r: Float, priority: Int, loop: Int, rate: Float): Int = 0
  fun stop(streamId: Int) {}; fun release() {}; fun autoPause() {}; fun autoResume() {}
  fun setOnLoadCompleteListener(l: OnLoadCompleteListener?) {}
  fun interface OnLoadCompleteListener { fun onLoadComplete(p: SoundPool, sampleId: Int, status: Int) } }
