package android.view
class KeyEvent { val keyCode: Int get() = 0; val repeatCount: Int get() = 0
  companion object { const val KEYCODE_INFO = 165; const val KEYCODE_MENU = 82; const val KEYCODE_PROG_RED = 183; const val KEYCODE_PROG_GREEN = 184; const val KEYCODE_PROG_YELLOW = 185; const val KEYCODE_PROG_BLUE = 186; const val KEYCODE_GUIDE = 172; const val KEYCODE_BACK = 4 } }
