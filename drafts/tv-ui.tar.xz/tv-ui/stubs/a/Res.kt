package android.content.res
class Resources { val configuration: Configuration = Configuration(); fun getQuantityString(id: Int, q: Int, vararg a: Any?): String = ""; fun getString(id: Int, vararg a: Any?): String = "" }
class Configuration { val locales: android.os.LocaleList = android.os.LocaleList(); var fontScale: Float = 1f; var screenWidthDp: Int = 0; var screenHeightDp: Int = 0; fun getLayoutDirection(): Int = 0 }
