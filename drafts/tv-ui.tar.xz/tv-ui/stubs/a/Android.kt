// Minimal android.* surface used by tv-app (signatures mirror the platform SDK).
@file:Suppress("unused", "UNUSED_PARAMETER")
package android.content
import android.content.res.Resources
open class Context {
    open val applicationContext: Context get() = this
    open val resources: Resources get() = Resources()
    open val contentResolver: ContentResolver get() = ContentResolver()
    open val packageName: String get() = ""
    open fun getSharedPreferences(name: String, mode: Int): SharedPreferences = TODO()
    fun getString(resId: Int): String = ""
    fun getString(resId: Int, vararg formatArgs: Any?): String = ""
    open fun getSystemService(name: String): Any? = null
    open fun startActivity(intent: Intent) {}
    companion object { const val MODE_PRIVATE = 0; const val ACTIVITY_SERVICE = "activity" }
}
open class ContextWrapper(val baseContext: Context) : Context()
class ContentResolver
open class ActivityNotFoundException : RuntimeException()
class Intent(action: String?, uri: android.net.Uri?) {
    fun addFlags(flags: Int): Intent = this
    companion object { const val ACTION_VIEW = "android.intent.action.VIEW"; const val FLAG_ACTIVITY_NEW_TASK = 0x10000000 }
}
interface SharedPreferences {
    fun getString(k: String, d: String?): String?
    fun getLong(k: String, d: Long): Long
    fun getInt(k: String, d: Int): Int
    fun getBoolean(k: String, d: Boolean): Boolean
    fun getFloat(k: String, d: Float): Float
    fun getStringSet(k: String, d: Set<String>?): Set<String>?
    fun contains(k: String): Boolean
    val all: Map<String, *>
    fun edit(): Editor
    interface Editor {
        fun putString(k: String, v: String?): Editor
        fun putLong(k: String, v: Long): Editor
        fun putInt(k: String, v: Int): Editor
        fun putFloat(k: String, v: Float): Editor
        fun putBoolean(k: String, v: Boolean): Editor
        fun putStringSet(k: String, v: Set<String>?): Editor
        fun remove(k: String): Editor
        fun clear(): Editor
        fun apply()
        fun commit(): Boolean
    }
}
