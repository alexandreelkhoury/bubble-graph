package android.provider
class Settings { object Global { const val ANIMATOR_DURATION_SCALE = "animator_duration_scale"; @JvmStatic fun getFloat(cr: android.content.ContentResolver, name: String, def: Float): Float = def } }
