package android.app
open class Activity : android.content.Context() { open fun finish() {}; val isFinishing: Boolean get() = false; open val application: Application get() = Application(); open fun moveTaskToBack(nonRoot: Boolean): Boolean = true }
open class Application : android.content.Context()
class ActivityManager { val isLowRamDevice: Boolean get() = false; val memoryClass: Int get() = 256 }
