package android.os
class Bundle
class LocaleList { fun get(i: Int): java.util.Locale = java.util.Locale.ROOT; fun isEmpty(): Boolean = true; fun size(): Int = 0; fun toLanguageTags(): String = "" }
class Looper { companion object { fun getMainLooper(): Looper = Looper(); fun myLooper(): Looper? = null } }
open class Handler(looper: Looper) { fun post(r: Runnable): Boolean = true; fun postDelayed(r: Runnable, ms: Long): Boolean = true; fun removeCallbacksAndMessages(t: Any?) {} }
object SystemClock { @JvmStatic fun uptimeMillis(): Long = 0; @JvmStatic fun elapsedRealtime(): Long = 0 }
object Build { object VERSION { const val SDK_INT = 34 } }
