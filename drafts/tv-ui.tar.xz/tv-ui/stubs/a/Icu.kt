package android.icu.text
class ListFormatter { enum class Type { AND, OR, UNITS }; enum class Width { WIDE, SHORT, NARROW }
  fun format(items: Collection<*>): String = ""
  companion object { @JvmStatic fun getInstance(l: java.util.Locale): ListFormatter = ListFormatter(); @JvmStatic fun getInstance(l: java.util.Locale, t: Type, w: Width): ListFormatter = ListFormatter() } }
