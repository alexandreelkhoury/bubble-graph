// Signatures mirror androidx.tv:tv-material 1.x (only what tv-app uses).
package androidx.tv.material3
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp

val LocalTextStyle = staticCompositionLocalOf { TextStyle.Default }
val LocalContentColor = staticCompositionLocalOf { Color.Black }

@Composable fun Text(
    text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified, fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null, fontWeight: FontWeight? = null, fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified, textDecoration: TextDecoration? = null, textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified, overflow: TextOverflow = TextOverflow.Clip, softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE, minLines: Int = 1, onTextLayout: (TextLayoutResult) -> Unit = {}, style: TextStyle = LocalTextStyle.current,
) {}
@Composable fun Text(
    text: AnnotatedString, modifier: Modifier = Modifier, color: Color = Color.Unspecified, fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null, fontWeight: FontWeight? = null, fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified, textDecoration: TextDecoration? = null, textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified, overflow: TextOverflow = TextOverflow.Clip, softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE, minLines: Int = 1,
    inlineContent: Map<String, androidx.compose.foundation.text.InlineTextContent> = mapOf(),
    onTextLayout: (TextLayoutResult) -> Unit = {}, style: TextStyle = LocalTextStyle.current,
) {}
@Composable fun Icon(imageVector: ImageVector, contentDescription: String?, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current) {}
@Composable fun Icon(painter: Painter, contentDescription: String?, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current) {}

class Border(val border: BorderStroke, val inset: Dp = 0.dp, val shape: Shape = RoundedCornerShape(8.dp)) { companion object { val None = Border(BorderStroke(0.dp, Color.Transparent), 0.dp, RectangleShape) } }
class Glow(val elevationColor: Color, val elevation: Dp) { companion object { val None = Glow(Color.Transparent, 0.dp) } }
class ClickableSurfaceShape internal constructor()
class ClickableSurfaceColors internal constructor()
class ClickableSurfaceScale internal constructor()
class ClickableSurfaceBorder internal constructor()
class ClickableSurfaceGlow internal constructor()
class SurfaceColors internal constructor()
object ClickableSurfaceDefaults {
    fun shape(shape: Shape = RoundedCornerShape(8.dp), focusedShape: Shape = shape, pressedShape: Shape = shape, disabledShape: Shape = shape, focusedDisabledShape: Shape = disabledShape) = ClickableSurfaceShape()
    @Composable fun colors(
        containerColor: Color = Color.Unspecified, contentColor: Color = Color.Unspecified, focusedContainerColor: Color = Color.Unspecified,
        focusedContentColor: Color = Color.Unspecified, pressedContainerColor: Color = focusedContainerColor, pressedContentColor: Color = focusedContentColor,
        disabledContainerColor: Color = Color.Unspecified, disabledContentColor: Color = contentColor,
    ) = ClickableSurfaceColors()
    fun scale(scale: Float = 1f, focusedScale: Float = 1.1f, pressedScale: Float = scale, disabledScale: Float = scale, focusedDisabledScale: Float = disabledScale) = ClickableSurfaceScale()
    @Composable fun border(border: Border = Border.None, focusedBorder: Border = border, pressedBorder: Border = focusedBorder, disabledBorder: Border = border, focusedDisabledBorder: Border = Border.None) = ClickableSurfaceBorder()
    fun glow(glow: Glow = Glow.None, focusedGlow: Glow = glow, pressedGlow: Glow = glow) = ClickableSurfaceGlow()
}
object SurfaceDefaults {
    val shape: Shape = RectangleShape
    @Composable fun colors(containerColor: Color = Color.Unspecified, contentColor: Color = Color.Unspecified) = SurfaceColors()
}
@Composable fun Surface(
    onClick: () -> Unit, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null, enabled: Boolean = true,
    tonalElevation: Dp = 0.dp, shape: ClickableSurfaceShape = ClickableSurfaceDefaults.shape(), colors: ClickableSurfaceColors = ClickableSurfaceDefaults.colors(),
    scale: ClickableSurfaceScale = ClickableSurfaceDefaults.scale(), border: ClickableSurfaceBorder = ClickableSurfaceDefaults.border(),
    glow: ClickableSurfaceGlow = ClickableSurfaceDefaults.glow(), interactionSource: MutableInteractionSource? = null,
    content: @Composable BoxScope.() -> Unit,
) {}
@Composable fun Surface(
    modifier: Modifier = Modifier, tonalElevation: Dp = 0.dp, shape: Shape = SurfaceDefaults.shape, colors: SurfaceColors = SurfaceDefaults.colors(),
    border: Border = Border.None, glow: Glow = Glow.None, content: @Composable BoxScope.() -> Unit,
) {}
class ColorScheme internal constructor()
fun darkColorScheme(
    primary: Color = Color.Unspecified, onPrimary: Color = Color.Unspecified, primaryContainer: Color = Color.Unspecified, onPrimaryContainer: Color = Color.Unspecified,
    inversePrimary: Color = Color.Unspecified, secondary: Color = Color.Unspecified, onSecondary: Color = Color.Unspecified,
    secondaryContainer: Color = Color.Unspecified, onSecondaryContainer: Color = Color.Unspecified, tertiary: Color = Color.Unspecified,
    onTertiary: Color = Color.Unspecified, tertiaryContainer: Color = Color.Unspecified, onTertiaryContainer: Color = Color.Unspecified,
    background: Color = Color.Unspecified, onBackground: Color = Color.Unspecified, surface: Color = Color.Unspecified, onSurface: Color = Color.Unspecified,
    surfaceVariant: Color = Color.Unspecified, onSurfaceVariant: Color = Color.Unspecified, surfaceTint: Color = primary,
    inverseSurface: Color = Color.Unspecified, inverseOnSurface: Color = Color.Unspecified, error: Color = Color.Unspecified,
    onError: Color = Color.Unspecified, errorContainer: Color = Color.Unspecified, onErrorContainer: Color = Color.Unspecified,
    border: Color = Color.Unspecified, borderVariant: Color = Color.Unspecified, scrim: Color = Color.Unspecified,
) = ColorScheme()
class Typography(
    val displayLarge: TextStyle = TextStyle.Default, val displayMedium: TextStyle = TextStyle.Default, val displaySmall: TextStyle = TextStyle.Default,
    val headlineLarge: TextStyle = TextStyle.Default, val headlineMedium: TextStyle = TextStyle.Default, val headlineSmall: TextStyle = TextStyle.Default,
    val titleLarge: TextStyle = TextStyle.Default, val titleMedium: TextStyle = TextStyle.Default, val titleSmall: TextStyle = TextStyle.Default,
    val bodyLarge: TextStyle = TextStyle.Default, val bodyMedium: TextStyle = TextStyle.Default, val bodySmall: TextStyle = TextStyle.Default,
    val labelLarge: TextStyle = TextStyle.Default, val labelMedium: TextStyle = TextStyle.Default, val labelSmall: TextStyle = TextStyle.Default,
)
class Shapes
@Composable fun MaterialTheme(colorScheme: ColorScheme = darkColorScheme(), shapes: Shapes = Shapes(), typography: Typography = Typography(), content: @Composable () -> Unit) {}
