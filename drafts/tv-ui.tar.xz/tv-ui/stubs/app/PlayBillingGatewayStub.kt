package app.jamaa.tv.billing
/** Stand-in for PlayBillingGateway.kt (Play Billing is Google Maven only; that file is not type-checked here). */
class PlayBillingGateway(context: android.content.Context) : BillingGateway by TODO()
