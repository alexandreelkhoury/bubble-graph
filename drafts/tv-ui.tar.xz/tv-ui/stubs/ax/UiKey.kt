package androidx.compose.ui.input.key
/** Android: `KeyEvent.nativeKeyEvent: android.view.KeyEvent` (renamed by run.sh: desktop's is a java.awt event). */
val KeyEvent.nativeKeyEventA: android.view.KeyEvent get() = TODO()
