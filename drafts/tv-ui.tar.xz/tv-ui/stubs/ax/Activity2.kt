package androidx.activity
open class ComponentActivity : android.app.Activity() { protected open fun onCreate(savedInstanceState: android.os.Bundle?) {}; protected open fun onStart() {}; protected open fun onResume() {}; protected open fun onStop() {}; protected open fun onDestroy() {} }
inline fun <reified VM : androidx.lifecycle.ViewModel> ComponentActivity.viewModels(): Lazy<VM> = TODO()
