package androidx.lifecycle
import kotlinx.coroutines.CoroutineScope
abstract class ViewModel { protected open fun onCleared() {} }
open class AndroidViewModel(val app: android.app.Application) : ViewModel() { fun <T : android.app.Application> getApplication(): T = TODO() }
val ViewModel.viewModelScope: CoroutineScope get() = TODO()
