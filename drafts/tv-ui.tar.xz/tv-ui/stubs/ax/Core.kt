package androidx.core.os
class LocaleListCompat { val isEmpty: Boolean get() = true; fun get(i: Int): java.util.Locale? = null; fun toLanguageTags(): String = ""; fun size(): Int = 0
  companion object { @JvmStatic fun forLanguageTags(s: String?): LocaleListCompat = LocaleListCompat(); @JvmStatic fun getEmptyLocaleList() = LocaleListCompat() } }
