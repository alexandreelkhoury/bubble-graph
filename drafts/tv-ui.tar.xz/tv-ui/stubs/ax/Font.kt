package androidx.compose.ui.text.font
/** Android `Font(resId, weight, style)` (desktop has only the file/identity overloads). */
fun Font(resId: Int, weight: FontWeight = FontWeight.Normal, style: FontStyle = FontStyle.Normal): Font = TODO()
