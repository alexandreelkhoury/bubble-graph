package androidx.appcompat.app
open class AppCompatActivity : androidx.activity.ComponentActivity()
object AppCompatDelegate { @JvmStatic fun setApplicationLocales(l: androidx.core.os.LocaleListCompat) {}; @JvmStatic fun getApplicationLocales(): androidx.core.os.LocaleListCompat = androidx.core.os.LocaleListCompat() }
