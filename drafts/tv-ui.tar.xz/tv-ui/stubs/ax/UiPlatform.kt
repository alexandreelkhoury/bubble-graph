package androidx.compose.ui.platform
import androidx.compose.runtime.staticCompositionLocalOf
val LocalContext = staticCompositionLocalOf<android.content.Context> { TODO() }
val LocalConfiguration = staticCompositionLocalOf<android.content.res.Configuration> { TODO() }
