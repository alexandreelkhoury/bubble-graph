package androidx.activity.compose
import androidx.compose.runtime.Composable
@Composable fun BackHandler(enabled: Boolean = true, onBack: () -> Unit) {}
fun androidx.activity.ComponentActivity.setContent(parent: androidx.compose.runtime.CompositionContext? = null, content: @Composable () -> Unit) {}
