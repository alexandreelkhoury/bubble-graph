// The android-only parts of androidx.compose.ui (resources, LocalContext, LocalConfiguration, native key events).
package androidx.compose.ui.res
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.painter.Painter
@androidx.compose.runtime.ReadOnlyComposable @Composable fun stringResource(id: Int): String = ""
@androidx.compose.runtime.ReadOnlyComposable @Composable fun stringResource(id: Int, vararg formatArgs: Any): String = ""
@androidx.compose.runtime.ReadOnlyComposable @Composable fun pluralStringResource(id: Int, count: Int): String = ""
@androidx.compose.runtime.ReadOnlyComposable @Composable fun pluralStringResource(id: Int, count: Int, vararg formatArgs: Any): String = ""
@Composable fun painterResource(id: Int): Painter = TODO()
