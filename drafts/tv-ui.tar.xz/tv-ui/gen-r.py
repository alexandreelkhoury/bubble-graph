import os, re, sys, glob
repo, out = sys.argv[1], sys.argv[2]
res = os.path.join(repo, "tv-app/app/src/main/res")
names = {"string": set(), "plurals": set()}
for f in glob.glob(os.path.join(res, "values/*.xml")):
    for kind, n in re.findall(r'<(string|plurals)\s+name="([^"]+)"', open(f, encoding="utf-8").read()):
        names[kind].add(n)
for d in ("font", "drawable", "raw", "mipmap", "xml"):
    s = set()
    for p in glob.glob(os.path.join(res, d + "*/*")):
        s.add(os.path.basename(p).split(".")[0])
    names[d] = s
lines = ["package app.jamaa.tv", "object R {"]
base = 0x7f000000
for k, kind in enumerate(names):
    lines.append(f"    object {kind} {{")
    for i, n in enumerate(sorted(names[kind])):
        lines.append(f"        const val {n} = {base + (k << 16) + i}")
    lines.append("    }")
lines.append("}")
open(os.path.join(out, "R.kt"), "w").write("\n".join(lines) + "\n")
