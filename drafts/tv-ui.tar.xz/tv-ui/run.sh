#!/usr/bin/env bash
# Usage: run.sh — copies tv-app sources into build/src (Android-only seams rewritten), generates R/BuildConfig, compiles.
set -euo pipefail
H="$(cd "$(dirname "$0")" && pwd)"
REPO="${REPO:-/home/user/bubble-graph}"
SRC="$REPO/tv-app/app/src"
rm -rf "$H/build/src"; mkdir -p "$H/build/src"
cp -r "$SRC/main/java/." "$H/build/src/"
cp -r "$SRC/debug/java/." "$H/build/src/"
rm -f "$H/build/src/app/jamaa/tv/billing/PlayBillingGateway.kt"
# Desktop's KeyEvent.nativeKeyEvent is a java.awt event: point it at the android.view.KeyEvent stub.
grep -rl nativeKeyEvent "$H/build/src" | xargs -r sed -i 's/nativeKeyEvent\b/nativeKeyEventA/g'
python3 -I "$H/gen-r.py" "$REPO" "$H/build/src/app/jamaa/tv"
VER="$(sed -n 's/.*versionName = "\(.*\)".*/\1/p' "$REPO/tv-app/app/build.gradle.kts" | head -1)"
printf 'package app.jamaa.tv\nobject BuildConfig {\n    const val DEBUG = true\n    const val SERVER_URL = "https://example.invalid"\n    const val VERSION_NAME = "%s"\n    const val BILLING_ENABLED = true\n}\n' "$VER" > "$H/build/src/app/jamaa/tv/BuildConfig.kt"
cd "$H"
set +e
gradle --no-daemon -q --offline compileKotlin > build/compile.log 2>&1; rc=$?
grep -v JAVA_TOOL build/compile.log
[ $rc -eq 0 ] && echo "UI type-check OK" || echo "UI type-check FAILED"
exit $rc
