// UI type-check for tv-app (Google Maven blocked): every tv-app Kotlin file compiled against Compose Multiplatform
// desktop (same androidx.compose.* packages) + hand stubs for android.*, androidx.tv.material3, activity, lifecycle.
plugins {
    kotlin("jvm") version "2.4.20"
    kotlin("plugin.serialization") version "2.4.20"
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.20"
}
val cmp = "1.8.2"
kotlin { jvmToolchain(21); compilerOptions { freeCompilerArgs.add("-nowarn") } }
sourceSets { main { kotlin { srcDir("build/src"); srcDir("stubs") } } }
dependencies {
    implementation("org.jetbrains.compose.runtime:runtime-desktop:$cmp")
    implementation("org.jetbrains.compose.foundation:foundation-desktop:$cmp")
    implementation("org.jetbrains.compose.animation:animation-desktop:$cmp")
    implementation("org.jetbrains.compose.ui:ui-desktop:$cmp")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.11.0")
    implementation("com.squareup.okhttp3:okhttp:5.5.0")
    implementation("com.google.zxing:core:3.5.4")
}
// Google-Maven-only androidx.* modules (savedstate, lifecycle, annotation, collection…) are not reachable here.
configurations.all {
    exclude(group = "androidx.savedstate"); exclude(group = "androidx.lifecycle"); exclude(group = "androidx.annotation")
    exclude(group = "androidx.collection"); exclude(group = "androidx.arch.core")
}
