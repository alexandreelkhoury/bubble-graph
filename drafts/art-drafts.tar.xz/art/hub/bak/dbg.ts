import { thing } from './kit.ts';
const d = 'M10 10 C11 11 13 12 14 12 C13 11 11 9 10 10Z M20 10 C21 11 23 12 24 12 C23 11 21 9 20 10Z ';
console.log(thing(d, { fill: '#0f0', ink: '#000', w: 0.3, amp: 0.08, wave: [2, 5] })[0].slice(0, 300));
