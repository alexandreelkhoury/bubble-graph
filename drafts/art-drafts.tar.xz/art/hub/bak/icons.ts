// icons.ts — 12 icons for settings / rules / sound / players in the house hand.
// 24 × 24 grid, ~2 px ink, single colour (currentColor). Same glyph meanings as DESIGN §5.1.
// The hand is turned down for controls: pressure ±15 %, slow bows only, closed shapes overshoot their start
// like a pen loop. They still read as buttons at 24–32 dp, but sit next to the illustrations without clashing.
import { type F3, type Item, writePiece, calmThing, calmStroke, circleD, ellipseD, P, r2 } from './kit.ts';

const C = 'currentColor';
const line = (d: string, seed: string, w = 2) => calmStroke(d, C, { w, amp: 0.1, seed, wave: [10, 30] }, 2);
const loop = (d: string, seed: string, w = 2) => calmThing(d, { ink: C, w, amp: 0.12, seed, pressure: 0.15, overshoot: 1.8, wave: [10, 30] }, 1);
const dot = (x: number, y: number, r: number, seed: string) => calmThing(circleD(x, y, r), { fill: C, seed, amp: 0.04, w: 0.01, noInk: true }, 1);

function gear(): Item[] {
  const pts: number[][] = [];
  const n = 6, R = 9.2, r = 6.9;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2 + 0.05;
    const t = 0.2;
    for (const [da, rad] of [[-0.42, r], [-t, R], [t, R], [0.42, r]] as const) pts.push([12 + Math.cos(a + da) * rad, 12 + Math.sin(a + da) * rad]);
  }
  return [loop(P(pts), 'gear'), loop(circleD(12, 12, 2.9), 'gearc', 1.9)];
}
const icons: Record<string, () => Item[]> = {
  settings: gear,
  rules: () => [
    loop('M12 6.4 C9.6 5 6.6 4.7 3.4 5.4 L3.4 18.6 C6.6 17.9 9.6 18.2 12 19.6 C14.4 18.2 17.4 17.9 20.6 18.6 L20.6 5.4 C17.4 4.7 14.4 5 12 6.4 Z', 'book'),
    line('M12 6.6 L12 19.2', 'spine', 1.8),
    line('M6 9.2 L9.4 9.8 M6 12.4 L9.2 12.9', 'lines', 1.5),
  ],
  'sound-on': () => [
    loop('M3.6 9.4 L7.2 9.4 L11.6 5.4 L11.6 18.6 L7.2 14.6 L3.6 14.6 Z', 'spk'),
    line('M15 9.2 C16.2 10.6 16.2 13.4 15 14.8', 'w1'),
    line('M17.8 6.6 C20.4 9.4 20.4 14.6 17.8 17.4', 'w2'),
  ],
  'sound-off': () => [
    loop('M3.6 9.4 L7.2 9.4 L11.6 5.4 L11.6 18.6 L7.2 14.6 L3.6 14.6 Z', 'spk'),
    line('M15.2 9.4 L20.4 14.6', 'x1'), line('M20.4 9.4 L15.2 14.6', 'x2'),
  ],
  music: () => [
    loop(ellipseD(6.6, 17.4, 2.6, 2.1), 'n1', 1.9), loop(ellipseD(16.8, 15.6, 2.6, 2.1), 'n2', 1.9),
    line('M9.2 17.2 L9.2 6.2 L19.4 4.2 L19.4 15.4', 'stem'),
    line('M9.2 9.6 L19.4 7.6', 'beam', 1.8),
  ],
  players: () => [
    loop(circleD(8.8, 8.4, 3.2), 'h1'), line('M2.8 19.6 C3.2 15.6 5.6 13.6 8.8 13.6 C12 13.6 14.4 15.6 14.8 19.6', 'b1'),
    loop('M15.8 5.6 C18.2 5.4 19.6 7 19.4 9 C19.2 10.8 17.6 11.8 15.8 11.4', 'h2', 1.9), line('M16.6 14 C19.4 14.2 21 16.4 21.2 19.6', 'b2', 1.9),
  ],
  'player-add': () => [
    loop(circleD(9.4, 8.4, 3.3), 'h'), line('M3 19.6 C3.4 15.6 6 13.6 9.4 13.6 C12.8 13.6 15.4 15.6 15.8 19.6', 'b'),
    line('M18.6 8.2 L18.7 14.6', 'p1'), line('M15.5 11.5 L21.8 11.3', 'p2'),
  ],
  'player-kick': () => [
    loop(circleD(9.4, 8.4, 3.3), 'h'), line('M3 19.6 C3.4 15.6 6 13.6 9.4 13.6 C12.8 13.6 15.4 15.6 15.8 19.6', 'b'),
    line('M16.4 8.8 L21 13.4', 'k1'), line('M21 8.8 L16.4 13.4', 'k2'),
  ],
  host: () => [
    loop('M3.8 17.6 L3 7.6 L8.2 11.6 L12 4.8 L15.8 11.4 L21 7.4 L20.2 17.6 Z', 'crown'),
    line('M4.4 20.2 L19.8 20.0', 'band', 1.8),
    dot(12, 13.8, 1.2, 'gem'),
  ],
  language: () => [
    loop('M4.6 4.4 L14.4 4.6 C15.6 4.6 16.4 5.4 16.4 6.6 L16.4 11 C16.4 12.2 15.6 13 14.4 13 L9 13 L5.6 15.8 L6 13 L4.6 13 C3.6 13 2.8 12.2 2.8 11.2 L2.8 6.4 C2.8 5.2 3.6 4.4 4.6 4.4 Z', 'b1', 1.9),
    loop('M19.6 9.6 C20.6 9.6 21.3 10.4 21.3 11.4 L21.3 15.6 C21.3 16.6 20.6 17.4 19.6 17.4 L18.6 17.4 L19 20 L15.8 17.4 L12.6 17.4 C11.6 17.4 10.8 16.6 10.8 15.6 L10.8 15.4', 'b2', 1.8),
    line('M6.6 10.6 L8.4 6.8 L10.2 10.6 M7.2 9.4 L9.6 9.4', 'A', 1.5),
  ],
  timer: () => [
    loop(circleD(12, 13.6, 7.4), 'face'),
    line('M12 13.6 L12 9.4', 'hand1', 1.9), line('M12 13.6 L14.8 15.2', 'hand2', 1.8),
    line('M9.6 3.4 L14.4 3.4', 'top', 1.9), line('M12 3.6 L12 6.2', 'stem', 1.9), line('M18.2 6.6 L19.6 5.2', 'btn', 1.8),
  ],
  info: () => [loop(circleD(12, 12, 9), 'ring'), line('M12 11.2 L12.1 16.8', 'i', 2.1), dot(12, 7.8, 1.35, 'idot')],
};

export function buildIcons() {
  for (const [name, fn] of Object.entries(icons)) {
    const items = fn();
    writePiece('icons', { name: 'icon-' + name, vbW: 24, vbH: 24, pxW: 96, pxH: 96, items: [`<g color="#FFF7EC">`, ...items, `</g>`], defs: [], bg: '#3A2266' });
  }
  // a strip at real UI sizes (24 / 32 / 48 px) on the hub surface, and a TV-distance check
  // handled by the sheet; ink variant: same files with color set by the host (currentColor).
}
