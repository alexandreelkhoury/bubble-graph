// build.ts — tsx src/build.ts [bg|wordmark|ornaments|scenes|icons|sheet ...]
import { runShots } from './kit.ts';
const only = process.argv.slice(2);
const want = (k: string) => !only.length || only.includes(k);
if (want('bg')) { const m = await import('./bg.ts'); m.buildBg(); if (want('mock')) m.mockups(); }
if (want('wordmark')) (await import('./wordmark.ts')).buildWordmarks();
if (want('ornaments')) (await import('./ornaments.ts')).buildOrnaments();
if (want('scenes')) (await import('./scenes.ts')).buildScenes();
if (want('icons')) (await import('./icons.ts')).buildIcons();
runShots();
if (want('sheet')) (await import('./sheet.ts')).buildSheets();
