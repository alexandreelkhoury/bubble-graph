import fs from 'node:fs';
const src = fs.readFileSync('src/wordmark.ts', 'utf8');
const m = src.match(/const AR_JAMAA = \[([\s\S]*?)\n\];/)!;
const strokes = [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1]);
const word = process.argv[2] || 'جماعة';
let grid = '';
for (let x = -4; x <= 30; x++) grid += `<line x1="${x}" y1="-14" x2="${x}" y2="6" stroke="#ccc" stroke-width="0.04"/>`;
for (let y = -14; y <= 6; y++) grid += `<line x1="-4" y1="${y}" x2="30" y2="${y}" stroke="${y === 0 || y === -10 ? '#f88' : '#ccc'}" stroke-width="0.05"/>`;
const html = `<html><head><style>@font-face{font-family:C;src:url(/home/user/bubble-graph/growth/marketing/play-store/src/fonts/cairo_black.ttf)}</style></head><body style="margin:0;background:#fff">
<svg viewBox="-4 -14 34 20" width="1360" height="800">${grid}
<text x="${process.argv[3] || 26}" y="0" font-family="C" font-size="${process.argv[4] || 15}" direction="rtl" fill="#000" opacity="0.18">${word}</text>
${strokes.map((s) => `<path d="${s}" fill="none" stroke="#e00" stroke-width="0.15"/>`).join('')}
<circle cx="21" cy="-3.5" r="1.32" fill="none" stroke="#e90" stroke-width="0.15"/>
</svg></body></html>`;
fs.writeFileSync('tmp/ar.html', html);
