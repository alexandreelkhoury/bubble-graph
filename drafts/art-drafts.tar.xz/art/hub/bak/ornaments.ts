// ornaments.ts — UI ornaments in the house hand: confetti, sparkles, speech bubbles, arrows, stars, frames, dividers.
// Every piece is a *thing* (cut paper, a brush mark, a painted sign), never stock filler (ART-DIRECTION §4.2, §9.4, §9.7).
// Units: element viewBoxes in "prop units" (1 unit = 4 px at 1x).
import {
  type F3, type Item, HUB, TEXT, PLAYER, writePiece, thing, flat, stroke, blob, shadow, cat, g, uid, r2, rng, hashSeed,
  circleD, ellipseD, P, PL, rect, rr, archD, wire, glow, polyToD, calmThing, calmStroke,
} from './kit.ts';
import { SHAPES } from '../../tech/handmade/src/shapes.ts';

const W = HUB;
const DIR = 'ornaments';
const BG = '#2B1650';
const el = (name: string, vbW: number, vbH: number, items: Item[], scale = 4, defs: string[] = [], label?: string) =>
  writePiece(DIR, { name, vbW, vbH, pxW: Math.round(vbW * scale), pxH: Math.round(vbH * scale), items, defs, bg: BG, label });

// ------------------------------------------------------------- confetti ----
/** One confetti piece: a body silhouette cut from coloured paper, lifted off the page by a 1-unit ink shadow. */
export function confettiPiece(shapeId: string, cx: number, cy: number, size: number, rot: number, seed: string, flip = 1): Item[] {
  const sh = SHAPES.find((s) => s.id === shapeId)!;
  const k = size / 24;
  // paper: scissored facets from the body outline, a seeded wonk; flipped pieces show the paler back of the paper
  const tf = `translate(${r2(cx)} ${r2(cy)}) rotate(${r2(rot)}) scale(${r2(k * flip)} ${r2(k)}) translate(-12 -12)`;
  const back = flip < 0.6;
  const col = back ? mix(sh.color, '#FFF1DC', 0.35) : sh.color;
  return [
    g(`transform="translate(${r2(0.9)} ${r2(1.1)}) ${tf}"`, flat(sh.d, W.ink, { op: 0.42, amp: 0.35, seed: seed + 'sh', boil: true })),
    g(`transform="${tf}"`, flat(sh.d, col, { amp: 0.45, seed, boil: true })),
  ];
}
function mix(a: string, b: string, t: number) {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const A = p(a), B = p(b);
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join('');
}

// ------------------------------------------------------------- sparkles ----
/** A four-point twinkle with pinched, slightly unequal arms (no perfect symmetry). */
const twinkleD = (cx: number, cy: number, s: number, pinch = 0.16) =>
  `M${cx} ${cy - s} Q${cx + pinch * s} ${cy - pinch * s} ${cx + s * 0.88} ${cy - 0.04 * s} Q${cx + pinch * s} ${cy + pinch * s} ${cx + 0.05 * s} ${cy + s * 1.05} Q${cx - pinch * s} ${cy + pinch * s} ${cx - s * 0.92} ${cy + 0.03 * s} Q${cx - pinch * s} ${cy - pinch * s} ${cx} ${cy - s}Z`;
export function sparkleTwinkle(cx: number, cy: number, s: number, seed: string, color = '#FFE2A6'): Item[] {
  return [
    thing(twinkleD(cx, cy, s), { fill: color, ink: W.ink, w: 0.12 * s, amp: 0.05 * s, seed, mis: [-0.05 * s, 0.05 * s], wave: [s * 0.6, s * 2] }),
    stroke(`M${cx - s * 0.08} ${cy - s * 0.55} L${cx - s * 0.04} ${cy - s * 0.2}`, '#FFF4D6', { w: 0.1 * s, seed: seed + 'h', op: 0.9 }),
  ];
}
/** A burst: 7 tapered brush rays of different lengths (the "ta-da" mark of a sign painter). */
export function sparkleBurst(cx: number, cy: number, s: number, seed: string, color = '#FFC94D'): Item[] {
  const r = rng(hashSeed(seed));
  let d = '';
  const n = 7;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + (r() - 0.5) * 0.25 - Math.PI / 2;
    const r0 = s * (0.38 + r() * 0.1), r1 = s * (0.8 + r() * 0.35);
    d += `M${r2(cx + Math.cos(a) * r0)} ${r2(cy + Math.sin(a) * r0)} L${r2(cx + Math.cos(a) * r1)} ${r2(cy + Math.sin(a) * r1)} `;
  }
  return [calmStroke(d, color, { w: 0.2 * s, amp: 0.005 * s, seed, wave: [s, 3 * s] })];
}
/** "pop": three dashes flicking out from a corner (for a badge that just landed). */
export function sparklePop(x: number, y: number, s: number, seed: string, color = TEXT, dir = 1): Item[] {
  const d = `M${x} ${y - s * 0.35} L${x + dir * s * 0.1} ${y - s} M${x + dir * s * 0.32} ${y - s * 0.2} L${x + dir * s * 0.86} ${y - s * 0.62} M${x + dir * s * 0.4} ${y + s * 0.12} L${x + dir * s * 1.0} ${y + s * 0.02}`;
  return [calmStroke(d, color, { w: 0.15 * s, amp: 0.005 * s, seed, wave: [s, 3 * s] })];
}

// ------------------------------------------------------- speech bubbles ----
/** The brand bubble: a fat rounded speech bubble, tail at the start-bottom (mirrors in RTL). */
export function bubbleTalk(x: number, y: number, w: number, h: number, seed: string, fill: string = W.paper): Item[] {
  const r = h * 0.48;
  const d = `M${x + r} ${y} C${x + w * 0.45} ${y - 0.6} ${x + w - r * 1.1} ${y - 0.2} ${x + w - r * 0.4} ${y + h * 0.08} C${x + w + 0.4} ${y + h * 0.3} ${x + w + 0.2} ${y + h * 0.8} ${x + w - r * 0.6} ${y + h * 0.97} C${x + w * 0.6} ${y + h + 0.4} ${x + w * 0.4} ${y + h + 0.2} ${x + w * 0.3} ${y + h * 1.0} L${x + w * 0.12} ${y + h * 1.32} C${x + w * 0.13} ${y + h * 1.2} ${x + w * 0.16} ${y + h * 1.06} ${x + w * 0.17} ${y + h * 0.96} C${x + 0.4} ${y + h * 0.86} ${x - 0.5} ${y + h * 0.45} ${x + r * 0.35} ${y + h * 0.14} C${x + r * 0.6} ${y + 0.4} ${x + r * 0.8} ${y + 0.1} ${x + r} ${y} Z`;
  return [
    flat(d, W.ink, { op: 0.45, seed: seed + 'sh', amp: 0.3 }).map((s) => `<g transform="translate(1.2 1.4)">${s}</g>`),
    thing(d, { fill, ink: W.ink, w: 1.0, amp: 0.35, mis: W.mis, seed, pressure: 0.4 }),
  ];
}
/** Shout bubble: a hand-cut zigzag edge (scissors, not a star polygon), uneven spikes. */
export function bubbleShout(cx: number, cy: number, rx: number, ry: number, seed: string, fill: string = W.paper): Item[] {
  const r = rng(hashSeed(seed));
  const pts: number[][] = [];
  const n = 13;
  for (let i = 0; i < n * 2; i++) {
    const a = (i / (n * 2)) * Math.PI * 2 + (r() - 0.5) * 0.08;
    const out = i % 2 === 0;
    const k = out ? 1 + 0.18 + r() * 0.22 : 0.86 + r() * 0.05;
    pts.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
  }
  // one longer spike at the start-bottom: the tail
  pts[Math.round(n * 2 * 0.36)] = [cx - rx * 0.75, cy + ry * 1.75];
  const d = P(pts);
  return [
    flat(d, W.ink, { op: 0.45, seed: seed + 'sh', amp: 0.2 }).map((s) => `<g transform="translate(1.2 1.4)">${s}</g>`),
    thing(d, { fill, ink: W.ink, w: 1.0, amp: 0.25, mis: W.mis, seed, pressure: 0.45 }),
  ];
}
/** Thought bubble: a cloud edge of uneven scallops and two trailing puffs. */
export function bubbleThink(cx: number, cy: number, rx: number, ry: number, seed: string, fill: string = W.paper): Item[] {
  const r = rng(hashSeed(seed));
  const n = 9;
  let d = '';
  const pts: number[][] = [];
  for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 + (r() - 0.5) * 0.15; pts.push([cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]); }
  d = `M${r2(pts[0][0])} ${r2(pts[0][1])}`;
  for (let i = 0; i < n; i++) {
    const a = pts[i], b = pts[(i + 1) % n];
    const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
    const ox = mx - cx, oy = my - cy, l = Math.hypot(ox, oy);
    const bulge = 0.34 + r() * 0.2;
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    d += ` Q${r2(mx + (ox / l) * len * bulge * 1.4)} ${r2(my + (oy / l) * len * bulge * 1.4)} ${r2(b[0])} ${r2(b[1])}`;
  }
  d += 'Z';
  const p1 = ellipseD(cx - rx * 0.8, cy + ry * 1.45, rx * 0.17, ry * 0.15), p2 = ellipseD(cx - rx * 1.05, cy + ry * 1.85, rx * 0.1, ry * 0.09);
  return [
    flat(d + p1 + p2, W.ink, { op: 0.45, seed: seed + 'sh', amp: 0.2 }).map((s) => `<g transform="translate(1.2 1.4)">${s}</g>`),
    thing(d, { fill, ink: W.ink, w: 0.95, amp: 0.3, mis: W.mis, seed, pressure: 0.45 }),
    thing(p1, { fill, ink: W.ink, w: 0.7, amp: 0.1, mis: W.mis, seed: seed + 'p1' }),
    thing(p2, { fill, ink: W.ink, w: 0.6, amp: 0.06, mis: W.mis, seed: seed + 'p2' }),
  ];
}
/** Whisper bubble: dashed hand line (each dash its own stroke), for "psst" moments. */
export function bubbleWhisper(x: number, y: number, w: number, h: number, seed: string): Item[] {
  const out: Item[] = [];
  const R = h * 0.45;
  out.push(flat(rr(x, y, w, h, R), W.paper, { op: 0.14, seed: seed + 'f', amp: 0.2 }));
  // walk the rounded-rect perimeter; every other piece is a dash, lengths a little uneven
  const pts: number[][] = [];
  const seg = (x0: number, y0: number, x1: number, y1: number) => { const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 0.5); for (let i = 0; i < n; i++) pts.push([x0 + ((x1 - x0) * i) / n, y0 + ((y1 - y0) * i) / n]); };
  const arc = (cx: number, cy: number, a0: number) => { for (let i = 0; i < 12; i++) { const a = a0 + (i / 12) * Math.PI / 2; pts.push([cx + Math.cos(a) * R, cy + Math.sin(a) * R]); } };
  seg(x + R, y, x + w - R, y); arc(x + w - R, y + R, -Math.PI / 2); seg(x + w, y + R, x + w, y + h - R); arc(x + w - R, y + h - R, 0);
  seg(x + w - R, y + h, x + R, y + h); arc(x + R, y + h - R, Math.PI / 2); seg(x, y + h - R, x, y + R); arc(x + R, y + R, Math.PI);
  const r = rng(hashSeed(seed));
  let i = 0, k = 0;
  while (i < pts.length - 2) {
    const len = 4 + Math.floor(r() * 3), gap = 3;
    const a = pts[i], b = pts[Math.min(pts.length - 1, i + len)];
    out.push(stroke(`M${r2(a[0])} ${r2(a[1])} L${r2(b[0])} ${r2(b[1])}`, W.paper, { w: 0.85, amp: 0.04, seed: seed + k++ }));
    i += len + gap;
  }
  out.push(stroke(`M${x + w * 0.2} ${y + h + 0.8} Q${x + w * 0.14} ${y + h + 2.6} ${x + w * 0.04} ${y + h + 3.8}`, W.paper, { w: 0.8, seed: seed + 't' }));
  return out;
}

// ---------------------------------------------------------------- arrows ----
/** A marker arrow along a centreline, with a two-stroke head (each barb its own flick). */
export function arrow(d: string, tip: [number, number], dirDeg: number, s: number, seed: string, color = TEXT, w = 1.1): Item[] {
  const a = (dirDeg * Math.PI) / 180, b1 = a + Math.PI * 0.8, b2 = a - Math.PI * 0.78;
  const head = `M${r2(tip[0] + Math.cos(b1) * s)} ${r2(tip[1] + Math.sin(b1) * s)} L${tip[0]} ${tip[1]} M${tip[0]} ${tip[1]} L${r2(tip[0] + Math.cos(b2) * s * 0.92)} ${r2(tip[1] + Math.sin(b2) * s * 0.92)}`;
  return [
    calmStroke(d, W.ink, { w: w + 0.9, amp: 0.1, seed: seed + 'k', op: 0.6, wave: [14, 40] }).map((x) => `<g transform="translate(0.6 0.8)">${x}</g>`),
    stroke(head, W.ink, { w: w + 0.9, amp: 0.05, seed: seed + 'hk', op: 0.6 }).map((x) => `<g transform="translate(0.6 0.8)">${x}</g>`),
    calmStroke(d, color, { w, amp: 0.1, seed, wave: [14, 40] }),
    stroke(head, color, { w: w * 1.05, amp: 0.05, seed: seed + 'h' }),
  ];
}

// ----------------------------------------------------------------- stars ----
const starD = (cx: number, cy: number, R: number, r: number, rot = -90, wonk = 0.06, seed = 's') => {
  const rr_ = rng(hashSeed(seed));
  const pts: number[][] = [];
  for (let i = 0; i < 10; i++) { const a = ((rot + i * 36) * Math.PI) / 180; const k = (i % 2 ? r : R) * (1 + (rr_() - 0.5) * wonk * 2); pts.push([cx + Math.cos(a) * k, cy + Math.sin(a) * k]); }
  return P(pts);
};
export function starFull(cx: number, cy: number, R: number, seed: string, fill = '#FFC94D'): Item[] {
  const d = starD(cx, cy, R, R * 0.47, -92, 0.07, seed);
  return [
    flat(d, W.ink, { op: 0.45, seed: seed + 'sh', amp: 0.12 * R }).map((s) => `<g transform="translate(${r2(R * 0.09)} ${r2(R * 0.11)})">${s}</g>`),
    thing(d, { fill, ink: W.ink, w: R * 0.11, amp: R * 0.025, mis: [-R * 0.04, R * 0.04], seed, wave: [R * 0.6, R * 2], hatch: false }),
    stroke(`M${r2(cx - R * 0.42)} ${r2(cy - R * 0.08)} L${r2(cx - R * 0.18)} ${r2(cy - R * 0.1)}`, '#FFF4D6', { w: R * 0.08, op: 0.9, seed: seed + 'hl' }),
  ];
}
export function starEmpty(cx: number, cy: number, R: number, seed: string, color = MUTED_INK): Item[] {
  const d = starD(cx, cy, R, R * 0.47, -88, 0.07, seed);
  return [thing(d, { ink: color, w: R * 0.12, amp: R * 0.025, seed, wave: [R * 0.6, R * 2] })];
}
const MUTED_INK = '#B8A8D6';
export function starHalf(cx: number, cy: number, R: number, seed: string): Item[] {
  const d = starD(cx, cy, R, R * 0.47, -90, 0.07, seed);
  const id = uid('hs');
  return [
    `<clipPath id="${id}"><path d="M${cx - R * 1.3} ${cy - R * 1.3}L${cx + R * 0.05} ${cy - R * 1.3}L${cx - R * 0.08} ${cy + R * 1.3}L${cx - R * 1.3} ${cy + R * 1.3}Z"/></clipPath>`,
    g(`clip-path="url(#${id})"`, flat(d, '#FFC94D', { seed: seed + 'f', amp: R * 0.02 })),
    thing(d, { ink: W.paper, w: R * 0.11, amp: R * 0.025, seed, wave: [R * 0.6, R * 2] }),
  ];
}

// ---------------------------------------------------------------- frames ----
/** Bab arch frame: a painted double line, slightly asymmetric, a keystone dot in amber. */
export function archFrame(x: number, y: number, w: number, h: number, seed: string, color = W.paper): Item[] {
  const outer = archD(x, y, w, h, 0.8), inner = archD(x + 2.2, y + 2.2, w - 4.4, h - 2.2, 0.6);
  return [
    calmThing(outer, { ink: W.ink, w: 2.4, amp: 0.2, seed: seed + 'k', pressure: 0.25, wave: [16, 44] }).map((s) => `<g transform="translate(0.7 0.9)" opacity="0.6">${s}</g>`),
    calmThing(outer, { ink: color, w: 1.15, amp: 0.2, seed, pressure: 0.35, wave: [16, 44] }),
    calmThing(inner, { ink: color, w: 0.55, amp: 0.18, seed: seed + 'i', pressure: 0.3, wave: [14, 40] }),
    blob(circleD(x + w / 2 + 0.8, y - 0.2, 1.5), '#FFC94D', { seed: seed + 'dot', amp: 0.08 }),
  ];
}
/** A cement-tile border frame: a band of alternating petals and dots between two painted lines (thick white edge). */
export function tileFrame(x: number, y: number, w: number, h: number, seed: string): Item[] {
  const out: Item[] = [];
  const band = 4.2;
  out.push(calmThing(rr(x, y, w, h, 1.4), { ink: W.paper, w: 0.9, amp: 0.16, seed: seed + 'o', wave: [16, 44] }));
  out.push(calmThing(rr(x + band, y + band, w - band * 2, h - band * 2, 0.8), { ink: W.paper, w: 0.6, amp: 0.14, seed: seed + 'i', wave: [14, 40] }));
  // motifs along the band: petal pairs (rust) and saffron dots, spaced on an irregular step
  const r = rng(hashSeed(seed));
  let petals = '', dots = '';
  const along = (x0: number, y0: number, x1: number, y1: number) => {
    const L = Math.hypot(x1 - x0, y1 - y0), n = Math.max(2, Math.round(L / 6.5));
    for (let i = 0; i <= n; i++) {
      const t = i / n, px = x0 + (x1 - x0) * t + (r() - 0.5) * 0.3, py = y0 + (y1 - y0) * t + (r() - 0.5) * 0.3;
      if (i % 2 === 0) { const q = 1.5; petals += `M${r2(px)} ${r2(py - q)} Q${r2(px + q * 0.75)} ${r2(py)} ${r2(px)} ${r2(py + q)} Q${r2(px - q * 0.75)} ${r2(py)} ${r2(px)} ${r2(py - q)}Z M${r2(px - q)} ${r2(py)} Q${r2(px)} ${r2(py - q * 0.7)} ${r2(px + q)} ${r2(py)} Q${r2(px)} ${r2(py + q * 0.7)} ${r2(px - q)} ${r2(py)}Z `; }
      else dots += circleD(px, py, 0.65) + ' ';
    }
  };
  const m = band / 2;
  along(x + m, y + m, x + w - m, y + m); along(x + w - m, y + m, x + w - m, y + h - m); along(x + w - m, y + h - m, x + m, y + h - m); along(x + m, y + h - m, x + m, y + m);
  out.push(blob(petals, '#C8553D', { seed: seed + 'p', amp: 0.06 }));
  out.push(blob(dots, '#E8A33A', { seed: seed + 'd', amp: 0.05 }));
  return out;
}
/** Cut-paper ticket: a card with notched corners and a perforation line (the room-code ticket frame). */
export function ticketFrame(x: number, y: number, w: number, h: number, seed: string, fill = '#3A2266'): Item[] {
  const n = 2.4;
  const d = `M${x + n} ${y} L${x + w - n} ${y + 0.1} A${n} ${n} 0 0 0 ${x + w} ${y + n} L${x + w + 0.1} ${y + h * 0.62 - n} A${n} ${n} 0 0 0 ${x + w} ${y + h * 0.62 + n} L${x + w - 0.1} ${y + h - n} A${n} ${n} 0 0 0 ${x + w - n} ${y + h} L${x + n} ${y + h + 0.1} A${n} ${n} 0 0 0 ${x} ${y + h - n} L${x - 0.1} ${y + h * 0.62 + n} A${n} ${n} 0 0 0 ${x} ${y + h * 0.62 - n} L${x + 0.1} ${y + n} A${n} ${n} 0 0 0 ${x + n} ${y} Z`;
  let perf = '';
  for (let px = x + n + 1.6; px < x + w - n - 1; px += 2.3) perf += `M${r2(px)} ${r2(y + h * 0.62)} L${r2(px + 1)} ${r2(y + h * 0.62 + 0.05)} `;
  return [
    flat(d, W.ink, { op: 0.5, seed: seed + 'sh', amp: 0.3 }).map((s) => `<g transform="translate(1 1.3)">${s}</g>`),
    calmThing(d, { fill, ink: W.paper, w: 0.7, amp: 0.14, seed, pressure: 0.3, wave: [14, 40] }),
    stroke(perf, W.paper, { w: 0.5, op: 0.7, seed: seed + 'pf', amp: 0.05 }),
  ];
}
// -------------------------------------------------------------- dividers ----
export function dividerBrush(x: number, y: number, w: number, seed: string, color = '#E8A33A'): Item[] {
  // one confident brush pull: lands heavy, lifts thin, a dry-brush split near the end
  return [
    calmStroke(`M${x} ${y + 0.4} C${x + w * 0.3} ${y - 0.6} ${x + w * 0.6} ${y + 0.6} ${x + w} ${y - 0.4}`, color, { w: 1.8, amp: 0.12, seed, wave: [20, 60] }),
    calmStroke(`M${x + w * 0.62} ${y + 1.0} C${x + w * 0.75} ${y + 0.8} ${x + w * 0.86} ${y + 0.6} ${x + w * 0.96} ${y + 0.3}`, color, { w: 0.5, amp: 0.05, seed: seed + 'dry', op: 0.8, wave: [20, 60] }),
  ];
}
export function dividerBulbs(x: number, y: number, w: number, seed: string, defs: string[]): Item[] {
  const out: Item[] = [stroke(wire(x, y, x + w, y + 0.6, 3), W.ink, { w: 0.45, seed: seed + 'w', amp: 0.1 })];
  const n = Math.round(w / 6);
  const cols = ['#FFE2A6', '#FFC94D', '#FF9C6B'];
  for (let i = 1; i < n; i++) {
    const t = i / n, bx = x + w * t, by = (1 - t) * (1 - t) * y + 2 * (1 - t) * t * (y + 3 + 0.3) + t * t * (y + 0.6);
    const tilt = ((i * 37) % 11) - 5;
    out.push(glow(bx, by + 1.6, 4, 4, '#FFC94D', defs, 0.3));
    out.push(g(`transform="rotate(${tilt} ${r2(bx)} ${r2(by)})"`,
      thing(rect(bx - 0.6, by - 0.2, 1.2, 1.0), { fill: '#6B5A86', ink: W.ink, w: 0.25, amp: 0.03, seed: seed + 'cap' + i }),
      thing(`M${bx - 0.75} ${by + 0.8} C${bx - 1.3} ${by + 1.6} ${bx - 0.9} ${by + 2.9} ${bx} ${by + 3.0} C${bx + 0.9} ${by + 2.9} ${bx + 1.3} ${by + 1.6} ${bx + 0.75} ${by + 0.8} Z`, { fill: cols[i % 3], ink: W.ink, w: 0.3, amp: 0.05, seed: seed + 'b' + i }),
    ));
  }
  return out;
}
export function dividerTiles(x: number, y: number, w: number, seed: string): Item[] {
  // a row of small cement-tile squares, alternating two motifs, with the old white edge
  const out: Item[] = [];
  const s = 4.4, n = Math.floor(w / s);
  let base = '', mot = '', dots = '';
  const r = rng(hashSeed(seed));
  for (let i = 0; i < n; i++) {
    const tx = x + i * s + (r() - 0.5) * 0.15, cx = tx + s / 2, cy = y + s / 2;
    base += P([[tx + 0.2, y + 0.2], [tx + s - 0.2, y + 0.25], [tx + s - 0.25, y + s - 0.2], [tx + 0.2, y + s - 0.25]]) + ' ';
    if (i % 2) mot += P([[cx, cy - 1.5], [cx + 1.5, cy], [cx, cy + 1.5], [cx - 1.5, cy]]) + ' ';
    else { dots += circleD(cx, cy, 0.7) + ' '; mot += `M${tx + 0.3} ${y + 0.3} L${tx + 1.6} ${y + 0.3} L${tx + 0.3} ${y + 1.6} Z M${tx + s - 0.3} ${y + s - 0.3} L${tx + s - 1.6} ${y + s - 0.3} L${tx + s - 0.3} ${y + s - 1.6} Z `; }
  }
  out.push(flat(base, '#2F5DA8', { amp: 0.06, seed: seed + 'b' }));
  out.push(flat(mot, '#FFF1DC', { amp: 0.05, seed: seed + 'm', op: 0.9 }));
  out.push(flat(dots, '#C8553D', { amp: 0.04, seed: seed + 'd' }));
  return out;
}
/** Corner flourish: a small cut-paper petal cluster (for "New" badges, the cup sheet). */
export function cornerFlourish(x: number, y: number, s: number, seed: string): Item[] {
  const petal = (cx: number, cy: number, a: number, L: number, wd: number) => {
    const ex = cx + Math.cos(a) * L, ey = cy + Math.sin(a) * L, nx = -Math.sin(a) * wd, ny = Math.cos(a) * wd;
    return `M${r2(cx)} ${r2(cy)} C${r2(cx + nx + Math.cos(a) * L * 0.3)} ${r2(cy + ny + Math.sin(a) * L * 0.3)} ${r2(ex + nx * 0.4)} ${r2(ey + ny * 0.4)} ${r2(ex)} ${r2(ey)} C${r2(ex - nx * 0.4)} ${r2(ey - ny * 0.4)} ${r2(cx - nx + Math.cos(a) * L * 0.3)} ${r2(cy - ny + Math.sin(a) * L * 0.3)} ${r2(cx)} ${r2(cy)}Z`;
  };
  const p1 = petal(x, y, 0.08, 7 * s, 1.9 * s), p2 = petal(x, y, Math.PI / 2 - 0.1, 6.4 * s, 1.8 * s), p3 = petal(x, y, Math.PI / 4, 5 * s, 1.6 * s);
  return [
    flat(p1 + p2 + p3, W.ink, { op: 0.45, seed: seed + 'sh', amp: 0.2 }).map((q) => `<g transform="translate(${0.6 * s} ${0.8 * s})">${q}</g>`),
    thing(p1, { fill: '#C8553D', ink: W.ink, w: 0.45 * s, amp: 0.1 * s, seed: seed + '1' }),
    thing(p2, { fill: '#2F5DA8', ink: W.ink, w: 0.45 * s, amp: 0.1 * s, seed: seed + '2' }),
    thing(p3, { fill: '#E8A33A', ink: W.ink, w: 0.45 * s, amp: 0.1 * s, seed: seed + '3' }),
    blob(circleD(x + 0.6 * s, y + 0.6 * s, 1.2 * s), '#FFC94D', { seed: seed + 'c' }),
  ];
}

// ----------------------------------------------------------------- build ----
export function buildOrnaments() {
  // confetti: 12 shapes × 3 sizes (4, 6, 9 units), one sheet + one burst layout
  {
    const its: Item[] = [];
    const r = rng(hashSeed('conf'));
    SHAPES.forEach((s, i) => [4, 6, 9].forEach((sz, j) => {
      its.push(...confettiPiece(s.id, 8 + i * 13.5, 9 + j * 13, sz * 1.25, (r() - 0.5) * 70, 'cf' + i + j, j === 1 && i % 3 === 0 ? 0.45 : 1));
    }));
    el('confetti-set', 166, 42, its, 5, [], '12 shapes × 3 sizes, cut paper, flipped pieces show the paler back');
  }
  {
    const its: Item[] = [];
    const r = rng(hashSeed('fall'));
    for (let i = 0; i < 46; i++) {
      const s = SHAPES[i % 12];
      const x = 4 + r() * 152, y = 4 + r() * 82, sz = [4, 6, 9][Math.floor(r() * 3)] * 1.2;
      its.push(...confettiPiece(s.id, x, y, sz, r() * 360, 'fl' + i, r() < 0.25 ? 0.3 + r() * 0.3 : 1));
    }
    el('confetti-fall', 160, 90, its, 6, [], 'confetti rain layout (each piece flutters on the 12 fps drawing clock)');
  }
  el('sparkle-twinkle', 24, 24, [...sparkleTwinkle(12, 12, 9, 'tw1')], 6);
  el('sparkle-burst', 24, 24, [...sparkleBurst(12, 12, 10, 'bu1')], 6);
  el('sparkle-pop', 24, 24, [...sparklePop(7, 15, 12, 'pp1')], 6);
  el('sparkle-cluster', 40, 28, [...sparkleTwinkle(14, 15, 9, 'tc1'), ...sparkleTwinkle(29, 7, 4.2, 'tc2', '#FFF1DC'), ...sparkleTwinkle(33, 20, 2.8, 'tc3', '#FFC94D')], 6);
  el('bubble-talk', 52, 40, bubbleTalk(5, 5, 42, 24, 'bt1'), 5);
  el('bubble-shout', 56, 50, bubbleShout(28, 22, 17, 13, 'bs1', '#FFC94D'), 5);
  el('bubble-think', 56, 48, bubbleThink(30, 19, 18, 11, 'bk1'), 5);
  el('bubble-whisper', 52, 40, bubbleWhisper(5, 6, 42, 22, 'bw1'), 5);
  el('arrow-curl', 56, 40, arrow('M6 30 C10 14 26 8 30 18 C33 26 22 30 22 22 C22 12 38 8 48 12', [48, 12], -20, 5.5, 'ac1'), 5);
  el('arrow-straight', 56, 24, arrow('M5 13 C18 11.4 32 12.6 49 11.6', [49, 11.6], -3, 5.5, 'as1', '#FFC94D', 1.4), 5);
  el('arrow-bend', 48, 48, arrow('M8 8 C9 22 14 34 36 38', [36, 38], 12, 5.2, 'ab1', '#FF96C5'), 5);
  el('star-full', 28, 28, starFull(14, 14.5, 11, 'sf1'), 6);
  el('star-empty', 28, 28, starEmpty(14, 14.5, 11, 'se1'), 6);
  el('star-half', 28, 28, starHalf(14, 14.5, 11, 'sh1'), 6);
  el('star-rating', 76, 26, [...starFull(13, 13.5, 10, 'sr1'), ...starFull(38, 12.8, 10.4, 'sr2'), ...starEmpty(63, 13.4, 9.8, 'sr3')], 5);
  el('frame-arch-tall', 60, 80, archFrame(8, 6, 44, 70, 'fa1'), 4);
  el('frame-arch-wide', 90, 60, archFrame(8, 6, 74, 50, 'fa2', '#FFC94D'), 4);
  el('frame-tile', 100, 64, tileFrame(4, 4, 92, 56, 'ft1'), 4);
  el('frame-ticket', 64, 88, ticketFrame(6, 5, 52, 78, 'tk1'), 4);
  { const defs: string[] = []; el('divider-bulbs', 120, 14, dividerBulbs(2, 3, 116, 'db1', defs), 5, defs); }
  el('divider-brush', 120, 10, dividerBrush(4, 5, 112, 'dbr'), 5);
  el('divider-tiles', 120, 8, dividerTiles(2, 1.5, 116, 'dt1'), 5);
  el('corner-flourish', 28, 28, cornerFlourish(5, 5, 2.4, 'cf1'), 6);
}
