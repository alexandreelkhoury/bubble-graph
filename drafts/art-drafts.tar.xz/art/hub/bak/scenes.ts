// scenes.ts — empty states (ART-DIRECTION §9.6) and celebrations (§9.7): tiny scenes with one or a few
// shilleh acting, never a stock "person with a laptop". Canvas 160 × 120 units (4 px/unit at 1x), transparent,
// so they sit on a card or on the hub stage.
import {
  type F3, type Item, HUB, TEXT, PLAYER, writePiece, thing, flat, stroke, blob, shadow, character, cat, g, uid, r2, rng, hashSeed,
  circleD, ellipseD, P, rect, rr, archD, wire, glow, cone, calmThing, calmStroke, LATIN, placeLatin, signPaint, mapPath, bboxOf, shapeById,
} from './kit.ts';
import { confettiPiece, sparkleTwinkle, sparklePop, bubbleTalk, starFull } from './ornaments.ts';
import { T } from './room.ts';

const W = HUB;
const DIR = 'scenes';
const sc = (name: string, items: Item[], defs: string[], label: string, vbW = 160, vbH = 120) =>
  writePiece(DIR, { name, vbW, vbH, pxW: vbW * 4, pxH: vbH * 4, items, defs, bg: '#3A2266', label });

// extra sign-painter glyphs (cap-10 centrelines), same hand as the house LATIN set
Object.assign(LATIN, {
  C: { w: 6.6, s: ['M6.0 -8.4 C5.3 -9.7 4.2 -10.2 3.2 -10.0 C1.1 -9.6 0.4 -7.0 0.4 -4.9 C0.4 -1.9 1.8 0.1 3.7 0.1 C4.9 0.0 5.8 -0.7 6.3 -1.9'] },
  P: { w: 6.4, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.3 -9.0 6.0 -6.9 C5.7 -5.0 3.6 -4.4 1.2 -4.6'] },
  R: { w: 6.6, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.3 -9.0 6.0 -7.0 C5.7 -5.2 3.6 -4.6 1.2 -4.8', 'M3.0 -4.9 C4.0 -3.2 5.0 -1.6 6.2 0.1'] },
  '2': { w: 6.6, s: ['M0.8 -7.8 C1.2 -9.6 2.6 -10.2 3.6 -10.1 C5.2 -10.0 6.0 -8.8 5.8 -7.4 C5.5 -5.4 2.8 -3.0 0.6 0.0 C2.4 -0.1 4.2 0.0 6.2 -0.2'] },
  '7': { w: 6.4, s: ['M0.5 -9.9 C2.4 -10.0 4.3 -10.1 6.2 -10.2 C4.6 -6.8 3.2 -3.4 2.2 0.1'] },
  '?': { w: 6.0, s: ['M0.6 -7.8 C0.8 -9.6 2.2 -10.2 3.3 -10.1 C4.8 -10.0 5.7 -8.9 5.5 -7.5 C5.3 -6.0 3.2 -5.4 3.0 -3.4', 'M2.9 -0.8 L3.0 -0.2'] },
});
const word = (text: string, size: number, x: number, y: number, fill: string, shade: string, seed: string, align: 'left' | 'center' | 'right' = 'center') => {
  const L = placeLatin(text, size, x, y, { seed, track: 0.9 }, align);
  return signPaint(L.strokes, size / 10, { fill, shade, shadeOff: [size * 0.07, size * 0.09] }, false, seed);
};
/** where a character's pointing nub ends, in scene units (no lean) */
function nubTip(shapeId: string, x: number, y: number, s: number, nub: 1 | -1, L = 6.5) {
  const sh = shapeById(shapeId), bb = bboxOf(sh.d);
  const yA = bb.y0 + bb.h * 0.6;
  // span at yA (sample the outline)
  let lo = 1e9, hi = -1e9;
  const pts = sh.d; void pts;
  for (let px = bb.x0; px <= bb.x1; px += 0.1) { /* rough: assume symmetric glyph */ }
  lo = bb.x0; hi = bb.x1;
  const ax = nub > 0 ? hi - 1.4 : lo + 1.4;
  const lx = ax + nub * L, cx = (bb.x0 + bb.x1) / 2;
  return { x: x + (lx - cx) * s, y: y + (yA - bb.y1 - 0.4) * s };
}
const ground = (cx: number, y: number, w: number) => shadow(`M${cx - w} ${y + 0.4} C${cx - w * 0.9} ${y - 1.6} ${cx + w * 0.95} ${y - 1.7} ${cx + w} ${y + 0.2} C${cx + w * 0.9} ${y + 2} ${cx - w * 0.85} ${y + 2.1} ${cx - w} ${y + 0.4} Z`, W, 0.3);

// ------------------------------------------------- waiting for players ----
function waiting() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  // the front door, held open: warm light pours onto the floor (light may be soft)
  const dx = 98, dw = 40, dh = 78;
  it.push(ground(110, gy + 1, 36));
  it.push(calmThing(archD(dx - 3, gy - dh - 3, dw + 6, dh + 3, 0.5), { fill: T.woodLo, ink: W.ink, w: 1.0, amp: 0.3, seed: 'wdf' }));
  it.push(flat(archD(dx, gy - dh, dw, dh, 0.5), '#FFD98A', { seed: 'wdl', amp: 0.2 }));
  it.push(glow(dx + dw / 2, gy - dh * 0.4, 36, 46, '#FFC94D', defs, 0.35));
  it.push(cone([[dx, gy], [dx + dw, gy], [dx + dw - 6, gy + 14], [dx - 30, gy + 14]], '#FFC94D', defs, 0.32));
  // the door leaf swung inward (we see its edge and a bit of panel), with a brass handle
  it.push(calmThing(P([[dx - 2, gy - dh + 6], [dx + 10, gy - dh + 12], [dx + 10, gy + 2], [dx - 2, gy]]), { fill: '#7A4630', ink: W.ink, w: 1.0, amp: 0.25, mis: W.mis, seed: 'wleaf', hatch: true, hatchColor: W.ink, hatchOp: 0.25 }));
  it.push(thing(rr(dx + 1.2, gy - dh * 0.42, 6.4, 3.0, 1.3), { fill: T.brass, ink: W.ink, w: 0.5, amp: 0.05, seed: 'whdl' }));
  // the welcome mat (a striped cement-tile rug)
  it.push(thing(P([[dx + 2, gy - 1], [dx + dw - 2, gy - 1.3], [dx + dw + 2, gy + 4], [dx - 3, gy + 4.3]]), { fill: T.rust, ink: W.ink, w: 0.7, amp: 0.15, seed: 'wmat' }));
  it.push(calmStroke(`M${dx + 3} ${gy + 1.6} L${dx + dw - 1} ${gy + 1.4}`, '#E8A33A', { w: 0.8, seed: 'wms' }));
  // host: coral circle beside the door, happy, the nub sweeping toward the doorway: "tfaddalo"
  it.push(character('circle', { x: 66, y: gy, s: 2.1, expr: 'happy', world: W, nub: 1, nubLen: 7, lean: 6, seed: 'host' }));
  it.push(sparklePop(84, 54, 9, 'wpop', TEXT, 1));
  // two empty floor cushions waiting (the gang isn't here yet)
  for (const [cx, col, s] of [[18, T.blue, 1.6], [40, T.saffron, 1.4]] as const) it.push(thing(`M${cx - 8 * s} ${gy} C${cx - 9 * s} ${gy - 5 * s} ${cx + 9 * s} ${gy - 5.4 * s} ${cx + 8.4 * s} ${gy - 0.2} C${cx + 4 * s} ${gy + 1.4} ${cx - 4 * s} ${gy + 1.4} ${cx - 8 * s} ${gy} Z`, { fill: col, ink: W.ink, w: 0.8, amp: 0.2, mis: W.mis, seed: 'wcu' + cx }));
  return sc('empty-waiting-for-players', it, defs, 'Waiting for players: the host holds the door open, tfaddalo');
}

// -------------------------------------------------------- wrong door ----
function wrongDoor() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  it.push(ground(112, gy + 1, 30));
  const dx = 92, dw = 40, dh = 82;
  it.push(calmThing(rect(dx - 3, gy - dh - 3, dw + 6, dh + 3), { fill: T.woodLo, ink: W.ink, w: 1.0, amp: 0.3, seed: 'rdf' }));
  it.push(calmThing(rect(dx, gy - dh, dw, dh), { fill: T.curtain, ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'rdoor', hatch: true, hatchColor: W.ink, hatchOp: 0.22 }));
  for (const [py, ph] of [[gy - dh + 7, 30], [gy - dh + 44, 30]]) it.push(calmThing(rect(dx + 6, py, dw - 12, ph), { ink: W.ink, w: 0.6, amp: 0.2, seed: 'rpan' + py }));
  it.push(thing(circleD(dx + dw - 6, gy - dh * 0.46, 1.8), { fill: T.brass, ink: W.ink, w: 0.5, amp: 0.05, seed: 'rknob' }));
  // the number plate on the door says 27 (enamel plate, a little crooked)
  it.push(g(`transform="rotate(-4 ${dx + dw / 2} ${gy - dh + 22})"`,
    thing(rr(dx + 9, gy - dh + 14, 22, 15, 2), { fill: W.paper, ink: W.ink, w: 0.7, amp: 0.12, seed: 'rplate' }),
    word('27', 10, dx + 20, gy - dh + 26.5, HUB.c, '#00000000', 'r27'),
  ));
  // azure square checks the note in its nub: it says 72. Thinking face, looking from note to door.
  const cx = 52, s = 2.1;
  it.push(character('square', { x: cx, y: gy, s, expr: 'think', world: W, nub: 1, nubLen: 5.5, look: [0.6, -0.2], seed: 'guest' }));
  const tp = nubTip('square', cx, gy, s, 1, 5.5);
  it.push(g(`transform="rotate(8 ${r2(tp.x)} ${r2(tp.y)})"`,
    thing(P([[tp.x - 2, tp.y - 15], [tp.x + 15, tp.y - 16], [tp.x + 16, tp.y - 1], [tp.x - 1, tp.y]]), { fill: '#FFF7EC', ink: W.ink, w: 0.6, amp: 0.15, seed: 'rnote' }),
    word('72', 8, tp.x + 7, tp.y - 4.2, HUB.a, '#00000000', 'r72'),
  ));
  it.push(word('?', 12, 70, 30, '#FFC94D', W.ink, 'rq1'), word('?', 8, 80, 22, TEXT, W.ink, 'rq2'));
  return sc('empty-room-not-found', it, defs, 'Room not found: the note says 72, the door says 27');
}

// ------------------------------------------------------ reconnecting ----
function reconnecting() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 106;
  // the old TV on its little table, screen showing snow-lines
  const tx = 18, tw = 46, th = 34, ty = gy - 16 - th;
  it.push(ground(tx + tw / 2, gy + 1, 26));
  for (const lx of [tx + 6, tx + tw - 8]) it.push(thing(P([[lx, gy - 16], [lx + 2, gy - 16], [lx + 3.4, gy], [lx + 1.4, gy]]), { fill: T.woodLo, ink: W.ink, w: 0.6, amp: 0.08, seed: 'tl' + lx }));
  it.push(calmThing(rect(tx - 2, gy - 18, tw + 4, 3), { fill: T.wood, ink: W.ink, w: 0.8, amp: 0.2, seed: 'ttop' }));
  it.push(calmThing(rr(tx, ty, tw, th, 5), { fill: '#7A4630', ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'tv' }));
  it.push(calmThing(rr(tx + 4, ty + 4, tw - 15, th - 8, 4), { fill: '#3B4A7A', ink: W.ink, w: 0.8, amp: 0.2, seed: 'scr' }));
  let snow = '';
  const r = rng(hashSeed('snow'));
  for (let i = 0; i < 9; i++) { const yy = ty + 7 + i * 2.4; const x0 = tx + 7 + r() * 6; snow += `M${r2(x0)} ${r2(yy)} L${r2(x0 + 6 + r() * 12)} ${r2(yy + 0.1)} `; }
  it.push(stroke(snow, '#B8C6F0', { w: 0.6, op: 0.7, seed: 'snowl' }));
  it.push(blob(circleD(tx + tw - 6, ty + 10, 1.8) + circleD(tx + tw - 6, ty + 17, 1.8), '#3A1E12', { seed: 'tvk' }));
  // jade triangle standing on tiptoe, holding the rabbit-ear antenna up as high as it goes
  const cx = 116, s = 2.0;
  it.push(character('triangle', { x: cx, y: gy, s, expr: 'shock', world: W, squash: 1.06, look: [-0.4, -0.6], seed: 'ant' }));
  const top = { x: cx + 0.3, y: gy - 37.5 };
  it.push(calmStroke(`M${top.x} ${top.y} L${top.x - 13} ${top.y - 24} M${top.x} ${top.y} L${top.x + 11} ${top.y - 25}`, '#C9C2D8', { w: 1.1, seed: 'ears' }));
  it.push(blob(circleD(top.x - 13, top.y - 24, 1.4) + circleD(top.x + 11, top.y - 25, 1.4), '#C9C2D8', { seed: 'earb' }));
  it.push(thing(`M${top.x - 6} ${top.y + 3} C${top.x - 6} ${top.y - 3} ${top.x + 6} ${top.y - 3} ${top.x + 6} ${top.y + 3} Z`, { fill: '#3A2558', ink: W.ink, w: 0.6, amp: 0.08, seed: 'abase' }));
  // the cable sagging back to the TV
  it.push(calmStroke(`M${top.x + 4} ${top.y + 2.5} C${top.x + 30} ${top.y + 40} ${tx + tw + 20} ${gy + 6} ${tx + tw - 2} ${ty + th - 4}`, W.ink, { w: 0.7, seed: 'cable' }));
  // signal: three little hand-drawn arcs, the last one dashed (still trying)
  for (let i = 0; i < 3; i++) {
    const R = 5 + i * 4.5;
    it.push(calmStroke(`M${top.x + 12 - R * 0.2} ${top.y - 28 - R * 0.85} Q${top.x + 12 + R * 0.7} ${top.y - 28 - R * 0.5} ${top.x + 12 + R * 0.85} ${top.y - 28 + R * 0.2}`, i === 2 ? '#FFC94D' : TEXT, { w: 1.0, op: i === 2 ? 0.55 : 0.9, seed: 'sig' + i }));
  }
  return sc('empty-reconnecting', it, defs, 'Reconnecting: balancing the antenna on its head (boils at 12 fps)');
}

// ------------------------------------------------- no packs in language ----
function noPacks() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  // rose drop with a phrasebook too big for it, confused
  const cx = 70, s = 2.2;
  it.push(character('drop', { x: cx, y: gy, s, expr: 'think', world: W, look: [0.7, 0.6], brows: true, seed: 'phr' }));
  // the open book, held in front (it hides the lower body: the drop reads it)
  const bx = cx + 8, by = gy - 12;
  it.push(g(`transform="rotate(-8 ${bx} ${by})"`,
    calmThing(`M${bx - 20} ${by - 2} C${bx - 12} ${by - 5} ${bx - 4} ${by - 4} ${bx} ${by} C${bx + 4} ${by - 4} ${bx + 12} ${by - 5} ${bx + 20} ${by - 2} L${bx + 20} ${by + 14} C${bx + 12} ${by + 11} ${bx + 4} ${by + 12} ${bx} ${by + 16} C${bx - 4} ${by + 12} ${bx - 12} ${by + 11} ${bx - 20} ${by + 14} Z`, { fill: W.paper, ink: W.ink, w: 0.9, amp: 0.2, mis: W.mis, seed: 'book' }),
    calmThing(`M${bx - 21} ${by + 13} L${bx - 21.5} ${by + 16} C${bx - 12} ${by + 13} ${bx - 4} ${by + 14} ${bx} ${by + 18} C${bx + 4} ${by + 14} ${bx + 12} ${by + 13} ${bx + 21.5} ${by + 16} L${bx + 21} ${by + 13}`, { ink: W.ink, w: 0.7, amp: 0.1, seed: 'cover' }),
    // scribbled lines on the pages: left page "Latin", right page squiggles (both unreadable on purpose)
    stroke(`M${bx - 17} ${by + 2} L${bx - 4} ${by + 3} M${bx - 17} ${by + 5.5} L${bx - 6} ${by + 6.3} M${bx - 17} ${by + 9} L${bx - 3} ${by + 9.6}`, W.ink, { w: 0.5, op: 0.6, seed: 'bl' }),
    stroke(`M${bx + 4} ${by + 3} q1.5 -1.4 3 0 t3 0 t3 0 t3 0 M${bx + 4} ${by + 6.6} q1.5 -1.4 3 0 t3 0 t3 0 M${bx + 4} ${by + 10.2} q1.5 -1.4 3 0 t3 0 t3 0 t3 0`, HUB.a, { w: 0.5, op: 0.8, seed: 'br' }),
  ));
  // the language tags floating around: three cut-paper speech bubbles with letters A / ع / ¿ (only marks, no copy)
  it.push(g('transform="translate(100 18) scale(0.55)"', ...bubbleTalk(0, 0, 36, 22, 'nb1')));
  it.push(word('A', 9, 110, 30, HUB.ink, '#00000000', 'nbA'));
  it.push(g('transform="translate(14 22) scale(0.45)"', ...bubbleTalk(0, 0, 36, 22, 'nb2', '#FFC94D')));
  it.push(word('?', 8, 22, 32, HUB.ink, '#00000000', 'nbq'));
  it.push(ground(cx, gy + 1, 20));
  return sc('empty-no-packs-language', it, defs, 'No packs in this language yet: a phrasebook, confused');
}

// ------------------------------------------------- game over / thanks ----
function thanks() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 98;
  // the balcony at night: the gang waves from behind the rail; the lamp inside has just gone off
  it.push(flat(rect(0, 0, 160, 120), '#00000000'));
  // wall + balcony door frame behind them
  it.push(calmThing(archD(18, 6, 124, 110, 0.6), { fill: T.sky, ink: W.ink, w: 1.0, amp: 0.3, seed: 'tbg' }));
  // a dark window (the lamp is off) with the last warm glow
  it.push(glow(80, 40, 50, 30, '#FFC94D', defs, 0.08));
  const gang: [string, number, number, number, 'happy' | 'cheer' | 'shy' | 'idle', number][] = [
    ['star', 36, gy, 1.55, 'happy', -6], ['arch', 62, gy - 1, 1.7, 'happy', 3], ['hexagon', 92, gy, 1.65, 'cheer', -2], ['plus', 120, gy - 1, 1.5, 'shy', 5],
  ];
  for (const [id, x, y, s, e, lean] of gang) it.push(character(id, { x, y, s, expr: e, world: W, lean, nub: lean > 0 ? 1 : -1, nubLen: 5, groundShadow: false, seed: 'th' + id }));
  // the rail in front of them (cuts them at the middle: they're behind it)
  const railY = gy - 5;
  let bars = '';
  for (let x = 22; x < 140; x += 6.5) bars += `M${x} ${railY + 1} L${x + 0.2} ${116} `;
  it.push(calmStroke(bars, W.ink, { w: 1.1, seed: 'tbars' }));
  it.push(calmThing(rect(16, railY - 1.6, 128, 3.2), { fill: '#3A2558', ink: W.ink, w: 0.8, amp: 0.2, seed: 'trail' }));
  // plant tin and the cat's tail hanging over
  it.push(thing(P([[128, railY - 8], [136, railY - 8.2], [135.6, railY - 1.6], [128.4, railY - 1.6]]), { fill: T.rust, ink: W.ink, w: 0.6, amp: 0.1, mis: W.mis, seed: 'ttin' }));
  it.push(stroke(`M130 ${railY - 8} q-2 -5 -4 -7 M132 ${railY - 8} q0 -6 2 -8 M134 ${railY - 8} q2 -4 5 -5`, T.leafHi, { w: 0.9, seed: 'tleaf' }));
  it.push(calmStroke(`M30 ${railY + 1.4} C32 ${railY + 6} 28 ${railY + 10} 31 ${railY + 15}`, '#120A20', { w: 1.5, amp: 0.4, seed: 'ttail' }));
  // a few stars over the city
  it.push(...sparkleTwinkle(52, 22, 2.2, 'ts1', '#FFF1DC'), ...sparkleTwinkle(112, 16, 1.6, 'ts2', '#FFF1DC'), ...sparkleTwinkle(86, 28, 1.2, 'ts3', '#FFC94D'));
  return sc('empty-game-ended-thanks', it, defs, 'Game ended / thanks: the gang waving from the balcony, lamp off');
}

// ---------------------------------------------------------- champion ----
// «البطل», Ruq'ah centrelines, alef height 10. [native review]
const AR_CHAMP = [
  'M24.2 -10.0 C24.1 -6.6 24.0 -3.3 23.9 0.1',
  'M20.8 -10.2 C20.7 -6.6 20.6 -3.2 20.5 -0.6 C20.4 0.1 19.8 0.1 18.6 0.1 C17.8 0.1 17.2 0.1 16.6 0.1',
  'M18.4 0.1 C18.3 -0.8 18.3 -1.6 18.5 -2.6', 'M18.2 2.5 L18.4 2.45',
  'M16.8 0.1 C16.4 -3.2 13.6 -3.8 12.6 -2.0 C12.0 -0.8 12.8 0.1 13.8 0.1 C12.4 0.1 11.2 0.1 9.6 0.1',
  'M13.4 -10.0 C13.3 -6.8 13.2 -4.6 13.1 -3.2',
  'M7.6 -10.2 C7.5 -6.6 7.4 -2.6 7.5 0.0 C7.6 2.6 6.2 4.0 4.4 4.0 C2.6 4.0 1.8 2.6 2.0 1.0',
];
function champion() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 108;
  it.push(glow(80, 70, 80, 50, '#FFC94D', defs, 0.22));
  // the yafta: a cloth banner hung on two strings, sagging, fringed ends
  const bx0 = 12, bx1 = 148, by = 10, bh = 24;
  it.push(calmStroke(`M${bx0 + 4} ${by} L${bx0 - 4} ${by - 12} M${bx1 - 4} ${by} L${bx1 + 4} ${by - 12}`, W.ink, { w: 0.6, seed: 'ystr' }));
  const cloth = `M${bx0} ${by} C${bx0 + 40} ${by + 5} ${bx1 - 40} ${by + 5} ${bx1} ${by} L${bx1 - 1} ${by + bh} C${bx1 - 40} ${by + bh + 5} ${bx0 + 40} ${by + bh + 5} ${bx0 + 1} ${by + bh} Z`;
  it.push(calmThing(cloth, { fill: '#C8553D', ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'yafta', hatch: true, hatchColor: W.ink, hatchOp: 0.18 }));
  let fringe = '';
  for (const fx of [bx0 + 0.5, bx1 - 0.5]) for (let i = 0; i < 6; i++) { const yy = by + 2 + i * 4; fringe += `M${fx} ${yy} l${fx < 80 ? -2.6 : 2.6} ${0.6} `; }
  it.push(stroke(fringe, '#E8A33A', { w: 0.7, seed: 'yfr' }));
  // lettering: CHAMPION (Latin) and «البطل» share the cloth as one composition, a brass dot between them
  const L = placeLatin('CHAMPION', 9.6, 20, by + 17.4, { seed: 'champ', track: 0.7, rot: 2.5 }, 'left');
  it.push(signPaint(L.strokes, 0.96, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, false, 'champ'));
  it.push(blob(circleD(20 + L.w + 5, by + 12, 1.5), '#FFC94D', { seed: 'ydot' }));
  const k = 1.15, arR = bx1 - 9;
  const ar = AR_CHAMP.map((d) => mapPath(d, (x, y) => [arR + (x - 24.4) * k, by + 15.4 + y * k]));
  it.push(signPaint(ar, k, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, true, 'albatal'));
  // the podium: a painted wooden crate with the number 1 in a tile
  it.push(ground(80, gy + 1, 30));
  it.push(calmThing(P([[56, gy - 24], [104, gy - 24.6], [105, gy], [55, gy]]), { fill: T.wood, ink: W.ink, w: 1.1, amp: 0.3, mis: W.mis, seed: 'pod', hatch: true, hatchColor: W.ink, hatchOp: 0.22 }));
  it.push(calmThing(rr(73, gy - 19, 14, 14, 1.5), { fill: '#2F5DA8', ink: W.ink, w: 0.7, amp: 0.15, seed: 'podt' }));
  it.push(calmStroke('M78.4 ' + (gy - 15.4) + ' L80.6 ' + (gy - 16.6) + ' L80.4 ' + (gy - 7.2), W.paper, { w: 1.5, seed: 'one' }));
  // the winner: lemon star, cheer, top of a hop (squash stretched), confetti cut from its own colour
  it.push(character('star', { x: 80, y: gy - 27, s: 2.5, expr: 'cheer', world: W, squash: 1.08, groundShadow: false, seed: 'winner' }));
  // the brass cup beside the podium (dented, one handle a bit lower)
  const cx = 124, cy = gy;
  it.push(ground(cx, cy + 1, 10));
  it.push(calmThing(`M${cx - 8} ${cy - 30} C${cx - 8} ${cy - 18} ${cx - 4} ${cy - 15} ${cx - 1.6} ${cy - 14} L${cx - 1.4} ${cy - 7} L${cx - 6} ${cy - 4.5} L${cx - 6.4} ${cy} L${cx + 6.6} ${cy} L${cx + 6.2} ${cy - 4.5} L${cx + 1.6} ${cy - 7} L${cx + 1.8} ${cy - 14} C${cx + 4.4} ${cy - 15} ${cx + 8.4} ${cy - 18} ${cx + 8.2} ${cy - 30.4} Z`, { fill: T.brass, ink: '#3A1E08', w: 0.9, amp: 0.15, mis: W.mis, seed: 'cup' }));
  it.push(calmStroke(`M${cx - 8} ${cy - 27} C${cx - 14} ${cy - 27} ${cx - 13} ${cy - 18} ${cx - 5} ${cy - 18.5} M${cx + 8.2} ${cy - 26} C${cx + 14} ${cy - 26} ${cx + 13.4} ${cy - 16.4} ${cx + 5} ${cy - 17.4}`, '#3A1E08', { w: 1.3, seed: 'cuph' }));
  it.push(stroke(`M${cx - 5.2} ${cy - 27} C${cx - 5.4} ${cy - 23} ${cx - 4.4} ${cy - 20} ${cx - 3} ${cy - 18.6}`, '#FFF4D6', { w: 0.8, op: 0.85, seed: 'cuphl' }));
  it.push(stroke(`M${cx + 3} ${cy - 25} l1.6 1.2 l-.6 1.6`, '#A86F2A', { w: 0.6, seed: 'dent' }));
  // left: a second-place shilleh clapping (coral, happy), smaller
  it.push(character('circle', { x: 32, y: gy, s: 1.5, expr: 'happy', world: W, lean: 5, seed: 'second' }));
  // confetti in the winner's lemon + the room's colours
  const r = rng(hashSeed('chconf'));
  for (let i = 0; i < 24; i++) {
    const ids = ['star', 'star', 'circle', 'square', 'triangle', 'crescent'];
    const x = 10 + r() * 140, y = 38 + r() * 40, sz = 3 + r() * 3, rot = r() * 360, fl = r() < 0.3 ? 0.4 : 1;
    if (x > 56 && x < 104 && y > 40) continue; // keep the winner's face clear
    it.push(...confettiPiece(ids[i % ids.length], x, y, sz, rot, 'cc' + i, fl));
  }
  it.push(...sparkleTwinkle(60, 50, 3.5, 'cs1'), ...sparkleTwinkle(104, 46, 2.6, 'cs2', '#FFF1DC'));
  return sc('celebration-champion', it, defs, 'Champion / البطل: yafta banner, podium, the brass cup, own-colour confetti');
}

// ------------------------------------------------------ confetti pop ----
function correct() {
  const defs: string[] = [], it: Item[] = [];
  // a party popper (paper cone) going off from the start-bottom, a burst of cut paper and one big star
  const px = 30, py = 100;
  it.push(glow(80, 50, 70, 50, '#FFC94D', defs, 0.15));
  const r = rng(hashSeed('pop'));
  for (let i = 0; i < 34; i++) {
    const a = -Math.PI * (0.12 + r() * 0.36), d = 30 + r() * 85;
    const s = SHAPE_IDS[i % SHAPE_IDS.length];
    it.push(...confettiPiece(s, px + Math.cos(a) * d, py + Math.sin(a) * d * 0.95, 3.5 + r() * 4, r() * 360, 'pp' + i, r() < 0.3 ? 0.35 : 1));
  }
  // streamers: two curling ribbons of paper
  it.push(calmStroke(`M${px + 6} ${py - 8} C${px + 20} ${py - 40} ${px + 40} ${py - 30} ${px + 46} ${py - 58} C${px + 50} ${py - 76} ${px + 66} ${py - 70} ${px + 70} ${py - 84}`, '#FF96C5', { w: 1.6, seed: 'str1' }));
  it.push(calmStroke(`M${px + 9} ${py - 5} C${px + 34} ${py - 22} ${px + 56} ${py - 12} ${px + 72} ${py - 34} C${px + 84} ${py - 50} ${px + 100} ${py - 40} ${px + 112} ${py - 54}`, '#7BFFF4', { w: 1.4, seed: 'str2' }));
  // the popper: a striped paper cone
  const cone_ = `M${px - 6} ${py + 8} L${px + 3} ${py - 13} L${px + 14} ${py - 4} Z`;
  it.push(calmThing(cone_, { fill: '#E8A33A', ink: W.ink, w: 0.9, amp: 0.12, mis: W.mis, seed: 'pcone' }));
  const cid = uid('pc');
  it.push(`<clipPath id="${cid}"><path d="${cone_}"/></clipPath>`, g(`clip-path="url(#${cid})"`, stroke(`M${px - 8} ${py - 4} L${px + 14} ${py + 6} M${px - 4} ${py - 10} L${px + 16} ${py - 1}`, '#C8553D', { w: 2.2, seed: 'pstr' })));
  it.push(...starFull(116, 40, 13, 'pstar'), ...sparklePop(132, 28, 10, 'pp2', TEXT, 1));
  return sc('celebration-confetti-pop', it, defs, 'Correct / round won: a paper popper, streamers and one big star');
}
const SHAPE_IDS = ['circle', 'square', 'star', 'triangle', 'diamond', 'hexagon', 'plus', 'drop', 'crescent', 'bolt', 'flower', 'arch'];

export function buildScenes() {
  waiting(); wrongDoor(); reconnecting(); noPacks(); thanks(); champion(); correct();
}
