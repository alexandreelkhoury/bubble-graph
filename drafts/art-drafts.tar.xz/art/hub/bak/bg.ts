// bg.ts — the hub background: TV (1920 × 1080, scene 240 × 135) and phone (390 × 844 → scene 120 × 260).
import fs from 'node:fs';
import path from 'node:path';
import { type Item, HUB, OUT, writePiece, shotJob, uid, glow, linear, shadow, stroke, flat, thing, rr, P, rect, stipple } from './kit.ts';
import { T, wall, balcony, curtain, rod, lamp, sofa, coffeeTable, tileStrip, radioCorner, photo, cushion } from './room.ts';

function veil(Wd: number, Ht: number, defs: string[], tv: boolean): Item[] {
  // the TV's own cool spill from the front (we are the TV): a very faint cool wash, bottom-centre
  const out: Item[] = [glow(Wd / 2, Ht * 1.05, Wd * 0.55, Ht * 0.45, '#8FA8FF', defs, 0.07)];
  // the top of the room falls off into shadow (behind the top bar): ink multiply band, hand-cut lower edge
  const id = uid('top');
  defs.push(linear(id, [[0, HUB.ink, 0.55], [1, HUB.ink, 0]]));
  out.push(`<rect x="-20" y="-20" width="${Wd + 40}" height="${tv ? 40 : 70}" fill="url(#${id})"/>`);
  return out;
}

const scaleAt = (x: number, y: number, k: number, xs: Item[]): Item[] => [`<g transform="translate(${x} ${y}) scale(${k}) translate(${-x} ${-y})">`, ...xs, '</g>'];
/** Two-tone wall, as in most Beirut flats: oil paint below, distemper above, a wobbly painted line between. */
function dado(Wd: number, y: number, floorY: number, seed: string): Item[] {
  return [
    flat(`M-6 ${y} L${Wd + 6} ${y - 0.8} L${Wd + 6} ${floorY} L-6 ${floorY} Z`, '#22113F', { op: 0.75, seed: seed + 'b', amp: 0.3 }),
    stroke(`M-6 ${y + 0.2} C${Wd * 0.3} ${y - 0.4} ${Wd * 0.6} ${y + 0.3} ${Wd + 6} ${y - 0.6}`, '#4A2E7A', { w: 0.7, op: 0.8, seed: seed + 'l', boil: false }),
  ];
}
/** A light switch by the door, its wire run along the wall in a crooked line (nobody hides wires). */
function switchWire(x: number, y: number, seed: string): Item[] {
  return [
    stroke(`M${x + 1.5} ${y - 2} C${x + 1.6} ${y - 20} ${x + 1.2} ${y - 40} ${x + 2} ${y - 60} L${x + 2.2} ${y - 80}`, HUB.ink, { w: 0.3, op: 0.9, seed: seed + 'w', boil: false }),
    thing(rr(x - 0.4, y - 2.4, 3.8, 5, 0.6), { fill: '#CDBFA6', ink: HUB.ink, w: 0.3, amp: 0.05, seed: seed + 'p', boil: false }),
    thing(rr(x + 0.8, y - 1.2, 1.4, 2.4, 0.4), { fill: '#EDE2CC', ink: HUB.ink, w: 0.2, amp: 0.03, seed: seed + 't', boil: false }),
  ];
}

export function hubTV() {
  const Wd = 240, Ht = 135, floorY = 113;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(...wall(Wd, Ht, floorY, defs));
  // wainscot line + skirting (mid, thin)
  it.push(stroke(`M-4 ${floorY - 1.2} L${Wd + 4} ${floorY - 1.6}`, HUB.ink, { w: 0.5, op: 0.9, seed: 'skirt', boil: false }));
  // floor
  it.push(`<rect x="-20" y="${floorY - 1.4}" width="${Wd + 40}" height="${Ht - floorY + 22}" fill="${T.floor}"/>`);
  it.push(...tileStrip(-6, Wd + 6, floorY + 3.2, 11, 2, 'tvtiles', 0.26));
  it.push(...dado(Wd, 80, floorY, 'tvdado'));
  it.push(...switchWire(113, 74, 'tvsw'));
  // old wall marks near the lamp (stipple, 3 sizes) — a damp corner every Beirut flat has
  it.push(stipple(8, 72, 12, 10, 7, HUB.ink, 0.25, 'damp1'), stipple(232, 40, 9, 8, 6, HUB.ink, 0.22, 'damp2'));
  // balcony doorway (centre-right) with curtains and rod
  const bx = 132, by = 15, bw = 56, bh = floorY - 1.4 - by;
  it.push(...balcony(bx, by, bw, bh, defs, 'tvbal'));
  it.push(...curtain(bx - 11, by - 4, 13, floorY - by + 2.6, 1, 64, 'cL'));
  it.push(...curtain(bx + bw - 2, by - 4, 13, floorY - by + 2.6, -1, 66, 'cR'));
  it.push(...rod(bx - 13, bx + bw + 13, by - 4.4, 'rod'));
  // the photo of the gang, crooked, above the sofa
  it.push(...photo(84, 50, 1.7, 'photo', -4));
  // sofa (left-centre) with cushions; the lamp beside it
  it.push(...sofa(34, floorY + 1, 82, 'sofa'));
  it.push(...cushion(48, floorY - 13.4, 1.05, T.blue, '#C9B48A', 'cu1', -8));
  it.push(...cushion(99, floorY - 13.2, 0.95, T.rust, '#E2B26A', 'cu2', 7));
  it.push(...lamp(19, floorY + 1.5, 42, defs, 'lamp', { glowR: 64 }));
  // coffee table in front of the balcony
  it.push(...scaleAt(156, floorY + 6, 1.4, coffeeTable(141, floorY + 6, 30, defs, 'table')));
  // the right corner: cabinet, radio, pothos
  it.push(...scaleAt(240, floorY + 1, 1.12, radioCorner(208, floorY + 1, 'radio')));
  it.push(...veil(Wd, Ht, defs, true));
  return { name: 'hub-bg-tv', vbW: Wd, vbH: Ht, pxW: 1920, pxH: 1080, items: it, defs, grain: 0.5, bg: '#1D1036' };
}

export function hubPhone() {
  const Wd = 120, Ht = 260, floorY = 228;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(...wall(Wd, Ht, floorY, defs));
  it.push(stroke(`M-4 ${floorY - 1.2} L${Wd + 4} ${floorY - 1.5}`, HUB.ink, { w: 0.5, op: 0.9, seed: 'pskirt', boil: false }));
  it.push(`<rect x="-20" y="${floorY - 1.4}" width="${Wd + 40}" height="${Ht - floorY + 22}" fill="${T.floor}"/>`);
  it.push(...tileStrip(-6, Wd + 6, floorY + 2.8, 10, 3, 'phtiles', 0.26));
  it.push(...dado(Wd, 190, floorY, 'phdado'));
  it.push(stipple(110, 120, 10, 8, 7, HUB.ink, 0.25, 'pdamp'));
  // the tall balcony door fills the upper half: the city is the hero on the phone
  const bx = 26, by = 70, bw = 62, bh = floorY - 1.4 - by;
  it.push(...balcony(bx, by, bw, bh, defs, 'phbal', { tins: 3 }));
  it.push(...curtain(bx - 10, by - 4, 12, floorY - by + 2.6, 1, 150, 'pcL'));
  it.push(...curtain(bx + bw - 2, by - 4, 12, floorY - by + 2.6, -1, 154, 'pcR'));
  it.push(...rod(bx - 12, bx + bw + 12, by - 4.4, 'prod'));
  // sofa across the bottom, the lamp at the end edge, the table in front
  it.push(...sofa(-8, floorY + 1, 92, 'psofa'));
  it.push(...cushion(14, floorY - 13.4, 1.0, T.blue, '#C9B48A', 'pcu1', -8));
  it.push(...cushion(62, floorY - 13.2, 0.95, T.rust, '#E2B26A', 'pcu2', 6));
  it.push(...lamp(105, floorY + 1.5, 150, defs, 'plamp', { glowR: 60 }));
  it.push(...scaleAt(44, floorY + 14, 1.3, coffeeTable(30, floorY + 14, 30, defs, 'ptable')));
  it.push(...veil(Wd, Ht, defs, false));
  return { name: 'hub-bg-phone', vbW: Wd, vbH: Ht, pxW: 390, pxH: 845, items: it, defs, grain: 0.5, bg: '#1D1036' };
}

/** Preview of the background behind mock hub cards (for checking it stays calm). Not an asset. */
export function mockups() {
  const dir = path.join(OUT, 'bg');
  const tv = `<html><body style="margin:0;background:#1D1036;font-family:sans-serif">
<div style="position:relative;width:1920px;height:1080px;overflow:hidden">
<img src="hub-bg-tv_A.svg" style="position:absolute;inset:0;width:1920px;height:1080px">
<div style="position:absolute;left:96px;top:54px;right:96px;height:96px;display:flex;align-items:center;justify-content:space-between;color:#FFF7EC;font-weight:900;font-size:44px">
<img src="../wordmark/wordmark-sign-latin_A.svg" style="height:84px"><div style="display:flex;gap:24px"><div style="width:80px;height:80px;border-radius:40px;background:#3A2266"></div><div style="width:80px;height:80px;border-radius:40px;background:#3A2266"></div></div></div>
<div style="position:absolute;left:96px;top:220px;width:440px;height:700px;border-radius:32px;background:#3A2266;box-shadow:0 16px 48px #0008"></div>
<div style="position:absolute;left:600px;top:220px;width:420px;height:580px;border-radius:24px;background:#4A2E7A;outline:6px solid #FFF7EC;box-shadow:0 0 40px #FF4F9A88"></div>
<div style="position:absolute;left:1060px;top:240px;width:380px;height:540px;border-radius:24px;background:#3A2266"></div>
<div style="position:absolute;left:1480px;top:240px;width:380px;height:540px;border-radius:24px;background:#3A2266"></div>
</div></body></html>`;
  fs.writeFileSync(path.join(dir, '.mock-tv.html'), tv);
  shotJob({ src: path.join(dir, '.mock-tv.html'), out: path.join(dir, 'preview-behind-cards-tv@1x.png'), w: 1920, h: 1080, scale: 1 });
  const ph = `<html><body style="margin:0;background:#1D1036;font-family:sans-serif">
<div style="position:relative;width:390px;height:845px;overflow:hidden">
<img src="hub-bg-phone_A.svg" style="position:absolute;inset:0;width:390px;height:845px">
<img src="../wordmark/wordmark-sign-latin_A.svg" style="position:absolute;left:20px;top:28px;height:44px">
<div style="position:absolute;left:20px;right:20px;top:300px;height:150px;border-radius:20px;background:#3A2266;box-shadow:0 8px 24px #0008"></div>
<div style="position:absolute;left:20px;right:20px;top:470px;height:150px;border-radius:20px;background:#3A2266;box-shadow:0 8px 24px #0008"></div>
<div style="position:absolute;left:20px;right:20px;bottom:40px;height:64px;border-radius:32px;background:#FF4F9A"></div>
</div></body></html>`;
  fs.writeFileSync(path.join(dir, '.mock-phone.html'), ph);
  shotJob({ src: path.join(dir, '.mock-phone.html'), out: path.join(dir, 'preview-behind-cards-phone@2x.png'), w: 390, h: 845, scale: 2 });
}

export function buildBg() {
  writePiece('bg', hubTV());
  writePiece('bg', hubPhone());
}
