import { createRequire } from 'node:module';
const require = createRequire('/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/art/tools/package.json');
const { chromium } = require('playwright-core');
import fs from 'node:fs';
const [,, html, out, w, h] = process.argv;
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome' });
const p = await b.newPage({ viewport: { width: +w, height: +h } });
await p.goto('file://' + html); await p.waitForTimeout(400);
await p.screenshot({ path: out }); await b.close();
