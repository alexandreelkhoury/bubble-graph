// bg.ts — the hub background: TV (1920 × 1080, scene 240 × 135) and phone (390 × 844 → scene 120 × 260).
import fs from 'node:fs';
import path from 'node:path';
import { type Item, HUB, OUT, writePiece, shotJob, uid, glow, linear, shadow, stroke, flat, thing, blob, rr, P, rect, stipple, cone, rng, hashSeed, r2, circleD, archD, calmThing } from './kit.ts';
import { ICONS } from './icons.ts';
import { ticketFrame } from './ornaments.ts';
import { T, wall, balcony, curtain, rod, lamp, sofa, coffeeTable, tileFloor, radioCorner, photo, cushion } from './room.ts';

function veil(Wd: number, Ht: number, defs: string[], tv: boolean): Item[] {
  // the TV's own cool spill from the front (we are the TV): a very faint cool wash, bottom-centre
  const out: Item[] = [glow(Wd / 2, Ht * 1.05, Wd * 0.55, Ht * 0.45, '#8FA8FF', defs, 0.07)];
  // the top of the room falls off into shadow (behind the top bar): ink multiply band, hand-cut lower edge
  const id = uid('top');
  defs.push(linear(id, [[0, HUB.ink, 0.55], [1, HUB.ink, 0]]));
  out.push(`<rect x="-20" y="-20" width="${Wd + 40}" height="${tv ? 40 : 70}" fill="url(#${id})"/>`);
  return out;
}

/** Two temperatures: the far wall goes cool (night blue), the lamp side stays warm. lampX = where the lamp stands. */
function coolFar(Wd: number, Ht: number, lampX: number, defs: string[]): Item[] {
  const id = uid('cool');
  const lampLeft = lampX < Wd / 2;
  const t0 = lampLeft ? 0.18 : 0.82, t1 = lampLeft ? 0.75 : 0.2;
  defs.push(`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${Wd * t0}" y1="0" x2="${Wd * t1}" y2="0"><stop offset="0" stop-color="#22306E" stop-opacity="0"/><stop offset="1" stop-color="#22306E" stop-opacity="0.55"/></linearGradient>`);
  return [`<rect x="-20" y="-20" width="${Wd + 40}" height="${Ht + 40}" fill="url(#${id})"/>`];
}
/** Lamp light on the sofa, cut to the sofa's own silhouette (no box of light floating over it), fading away from the lamp. */
function sofaWarm(x: number, fy: number, w: number, lampLeft: boolean, defs: string[], op = 0.5): Item[] {
  const backTop = fy - 21, seatY = fy - 10.5;
  const sil = P([[x - 0.4, fy - 1.2], [x - 0.3, seatY - 3.4], [x + 0.6, seatY - 6.2], [x + 1.4, backTop + 3], [x + 2.2, backTop + 0.3], [x + w * 0.33, backTop + 1.2], [x + w * 0.6, backTop - 0.2], [x + w - 2, backTop + 0.4], [x + w - 1, backTop + 3], [x + w + 0.2, seatY - 6], [x + w + 0.3, fy - 1.2]]);
  const id = uid('sw'), cp = uid('swc');
  const a = lampLeft ? 0 : 1, b = 1 - a;
  defs.push(`<clipPath id="${cp}"><path d="${sil}"/></clipPath>`);
  defs.push(`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${x + w * a}" y1="0" x2="${x + w * (a * 0.45 + b * 0.55)}" y2="0"><stop offset="0" stop-color="#FFB04A" stop-opacity="${op}"/><stop offset="0.35" stop-color="#FFB04A" stop-opacity="${op * 0.55}"/><stop offset="1" stop-color="#FFB04A" stop-opacity="0"/></linearGradient>`);
  return [`<rect x="${x - 2}" y="${backTop - 2}" width="${w + 4}" height="${fy - backTop + 2}" fill="url(#${id})" clip-path="url(#${cp})" style="mix-blend-mode:screen"/>`];
}
/** Warm lamp light landing on things: hand-cut patches (screen), fading away from the lamp. */
const warm = (pts: number[][], defs: string[], op: number, dir: [number, number, number, number]) => cone(pts, '#FFB04A', defs, op, dir);
const scaleAt = (x: number, y: number, k: number, xs: Item[]): Item[] => [`<g transform="translate(${x} ${y}) scale(${k}) translate(${-x} ${-y})">`, ...xs, '</g>'];
/** Two-tone wall, as in most Beirut flats: oil paint below, distemper above, a wobbly painted line between. */
function dado(Wd: number, y: number, floorY: number, seed: string): Item[] {
  return [
    flat(`M-6 ${y} L${Wd + 6} ${y - 0.8} L${Wd + 6} ${floorY} L-6 ${floorY} Z`, '#22113F', { op: 0.75, seed: seed + 'b', amp: 0.3 }),
    stroke(`M-6 ${y + 0.2} C${Wd * 0.3} ${y - 0.4} ${Wd * 0.6} ${y + 0.3} ${Wd + 6} ${y - 0.6}`, '#4A2E7A', { w: 0.7, op: 0.8, seed: seed + 'l', boil: false }),
  ];
}
/** A light switch by the balcony door: just the old porcelain plate and its toggle (AD note: the full-height
 *  wire read as a crack; the wiring is in the wall now). */
function lightSwitch(x: number, y: number, seed: string): Item[] {
  return [
    shadow(rr(x - 0.1, y - 2.0, 3.8, 5, 0.6), HUB, 0.3),
    thing(rr(x - 0.4, y - 2.4, 3.8, 5, 0.6), { fill: '#CDBFA6', ink: HUB.ink, w: 0.3, amp: 0.05, seed: seed + 'p', boil: false }),
    thing(rr(x + 0.8, y - 1.2, 1.4, 2.4, 0.4), { fill: '#EDE2CC', ink: HUB.ink, w: 0.2, amp: 0.03, seed: seed + 't', boil: false }),
  ];
}
/** The picture rail: a thin wooden moulding with a hand-stencilled tile frieze under it, painted by whoever
 *  did the flat in the 60s. Each stencil print is a little off (position, pressure), low contrast so cards sit
 *  over it calmly. Spans [xa, xb] pairs (skips the curtains). */
function pictureRail(spans: [number, number][], y: number, seed: string): Item[] {
  const r = rng(hashSeed(seed));
  let band = '', dots = '';
  for (const [xa, xb] of spans) {
    for (let x = xa + 2; x < xb - 3; x += 7.5) {
      const cx = x + (r() - 0.5) * 0.4, cy = y + 3.4 + (r() - 0.5) * 0.3, q = 1.9 + (r() - 0.5) * 0.2;
      // stencil: a four-petal flower (almonds) between two dots
      for (const [dx, dy] of [[0, -1], [1, 0], [0, 1], [-1, 0]]) {
        // each petal a small lozenge (the stencil's cut-out), pointing out from the centre
        const ex = cx + dx * q, ey = cy + dy * q, mx = cx + dx * q * 0.5, my = cy + dy * q * 0.5, nx = -dy * q * 0.3, ny = dx * q * 0.3;
        band += P([[cx + dx * 0.25, cy + dy * 0.25], [mx + nx, my + ny], [ex, ey], [mx - nx, my - ny]]);
      }
      dots += circleD(cx + 3.75, cy, 0.42);
    }
  }
  const out: Item[] = [];
  out.push(flat(band, '#7558A8', { op: 0.5, amp: 0.06, seed: seed + 'st', boil: false }));
  out.push(flat(dots, '#9A7A4E', { op: 0.35, amp: 0.03, seed: seed + 'sd', boil: false }));
  for (const [xa, xb] of spans) {
    out.push(flat(`M${xa} ${y + 0.1} L${xb} ${y - 0.2} L${xb} ${y + 1.3} L${xa} ${y + 1.5} Z`, T.woodLo, { op: 0.9, amp: 0.08, seed: seed + 'rl' + xa, boil: false }));
    out.push(stroke(`M${xa} ${y + 0.1} L${xb} ${y - 0.2}`, '#7A5262', { w: 0.3, op: 0.7, seed: seed + 'rh' + xa, boil: false }));
    out.push(stroke(`M${xa} ${y + 1.5} L${xb} ${y + 1.3}`, HUB.ink, { w: 0.35, op: 0.7, seed: seed + 'rb' + xa, boil: false }));
  }
  return out;
}
/** A cast shadow of the sofa on the tiles, away from the lamp (hand-cut, multiply). */
function sofaCast(x: number, fy: number, w: number, lampLeft: boolean): Item {
  const k = lampLeft ? 1 : -1, a = lampLeft ? x : x + w, b = lampLeft ? x + w : x;
  return shadow(`M${a + k * 4} ${fy + 0.6} L${b} ${fy + 0.4} L${b + k * 9} ${fy + 8.5} C${b + k * 2} ${fy + 9.6} ${a + k * 26} ${fy + 9.2} ${a + k * 14} ${fy + 6} Z`, HUB, 0.32);
}

export function hubTV() {
  const Wd = 240, Ht = 135, floorY = 113;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(...wall(Wd, Ht, floorY, defs));
  // wainscot line + skirting (mid, thin)
  it.push(stroke(`M-4 ${floorY - 1.2} L${Wd + 4} ${floorY - 1.6}`, HUB.ink, { w: 0.5, op: 0.9, seed: 'skirt', boil: false }));
  // floor
  it.push(`<rect x="-20" y="${floorY - 1.4}" width="${Wd + 40}" height="${Ht - floorY + 22}" fill="${T.floor}"/>`);
  it.push(...tileFloor(-6, Wd + 6, floorY + 0.4, Ht + 2, 'tvtiles', { horizon: 40, vpX: 150, U: 0.15 }));
  it.push(...dado(Wd, 80, floorY, 'tvdado'));
  it.push(...coolFar(Wd, Ht, 19, defs));
  it.push(...lightSwitch(117, 66, 'tvsw'));
  it.push(...pictureRail([[-6, 118], [202, Wd + 6]], 30, 'tvrail'));
  // the photo hangs from the rail: a brass hook and a cord
  it.push(stroke('M84 31.4 L84.2 39.2', HUB.ink, { w: 0.25, op: 0.8, seed: 'phcord', boil: false }), blob(circleD(84, 31.6, 0.5), T.brass, { seed: 'phhook', boil: false }));
  // old wall marks near the lamp (stipple, 3 sizes) — a damp corner every Beirut flat has
  it.push(stipple(8, 72, 12, 10, 7, HUB.ink, 0.25, 'damp1'), stipple(232, 40, 9, 8, 6, HUB.ink, 0.22, 'damp2'));
  // balcony doorway (centre-right) with curtains and rod
  const bx = 132, by = 15, bw = 56, bh = floorY - 1.4 - by;
  it.push(...balcony(bx, by, bw, bh, defs, 'tvbal'));
  it.push(...curtain(bx - 11, by - 4, 13, floorY - by + 2.6, 1, 64, 'cL'));
  it.push(...curtain(bx + bw - 2, by - 4, 13, floorY - by + 2.6, -1, 66, 'cR'));
  it.push(...rod(bx - 13, bx + bw + 13, by - 4.4, 'rod'));
  // the photo of the gang, crooked, above the sofa
  it.push(...photo(84, 50, 1.7, 'photo', -4));
  // sofa (left-centre) with cushions; the lamp beside it
  it.push(sofaCast(34, floorY + 1, 82, true));
  it.push(...sofa(34, floorY + 1, 82, 'sofa'));
  it.push(...cushion(48, floorY - 13.4, 1.05, T.blue, '#C9B48A', 'cu1', -8));
  it.push(...cushion(99, floorY - 13.2, 0.95, T.rust, '#E2B26A', 'cu2', 7));
  it.push(...lamp(19, floorY + 1.5, 42, defs, 'lamp', { glowR: 64 }));
  // where the lamp's light lands: the sofa's near arm and the start of its back, the floor, the near tiles
  it.push(...sofaWarm(34, floorY + 1, 82, true, defs, 0.5));
  it.push(warm([[-6, floorY + 0.2], [44, floorY - 0.2], [86, Ht + 2], [-6, Ht + 2]], defs, 0.34, [0, 0, 0.8, 1]));
  // coffee table in front of the balcony
  it.push(...scaleAt(156, floorY + 6, 1.4, coffeeTable(141, floorY + 6, 30, defs, 'table')));
  // the right corner: cabinet, radio, pothos
  it.push(...scaleAt(240, floorY + 1, 1.12, radioCorner(208, floorY + 1, 'radio')));
  it.push(...veil(Wd, Ht, defs, true));
  return { name: 'hub-bg-tv', vbW: Wd, vbH: Ht, pxW: 1920, pxH: 1080, items: it, defs, grain: 0.5, bg: '#1D1036' };
}

export function hubPhone() {
  const Wd = 120, Ht = 260, floorY = 228;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(...wall(Wd, Ht, floorY, defs));
  it.push(stroke(`M-4 ${floorY - 1.2} L${Wd + 4} ${floorY - 1.5}`, HUB.ink, { w: 0.5, op: 0.9, seed: 'pskirt', boil: false }));
  it.push(`<rect x="-20" y="${floorY - 1.4}" width="${Wd + 40}" height="${Ht - floorY + 22}" fill="${T.floor}"/>`);
  it.push(...tileFloor(-6, Wd + 6, floorY + 0.4, Ht + 2, 'phtiles', { horizon: floorY - 73, vpX: 60, U: 0.135 }));
  it.push(...dado(Wd, 190, floorY, 'phdado'));
  it.push(...coolFar(Wd, Ht, 103, defs));
  it.push(stipple(110, 120, 10, 8, 7, HUB.ink, 0.25, 'pdamp'));
  it.push(...pictureRail([[-6, Wd + 6]], 56, 'phrail'));
  // the tall balcony door fills the upper half: the city is the hero on the phone
  // the window moves to the start so the lamp gets its own floor space beside it (its cone stays off the glass)
  const bx = 13, by = 70, bw = 58, bh = floorY - 1.4 - by;
  it.push(...balcony(bx, by, bw, bh, defs, 'phbal', { tins: 3 }));
  it.push(...curtain(bx - 10, by - 4, 12, floorY - by + 2.6, 1, 150, 'pcL'));
  it.push(...curtain(bx + bw - 2, by - 4, 12, floorY - by + 2.6, -1, 154, 'pcR'));
  it.push(...rod(bx - 12, bx + bw + 12, by - 4.4, 'prod'));
  // sofa across the bottom, the lamp at the end edge, the table in front
  it.push(sofaCast(-8, floorY + 1, 90, false));
  it.push(...sofa(-8, floorY + 1, 90, 'psofa'));
  it.push(...cushion(14, floorY - 13.4, 1.0, T.blue, '#C9B48A', 'pcu1', -8));
  it.push(...cushion(62, floorY - 13.2, 0.95, T.rust, '#E2B26A', 'pcu2', 6));
  it.push(...lamp(103, floorY + 1.5, 146, defs, 'plamp', { glowR: 30 }));
  // its light lands on the sofa's near (end) arm, the floor and the near tiles
  it.push(...sofaWarm(-8, floorY + 1, 90, false, defs, 0.5));
  it.push(warm([[66, floorY + 0.2], [Wd + 6, floorY - 0.2], [Wd + 6, Ht + 2], [36, Ht + 2]], defs, 0.34, [1, 0, 0.2, 1]));
  it.push(...scaleAt(44, floorY + 14, 1.3, coffeeTable(30, floorY + 14, 30, defs, 'ptable')));
  it.push(...veil(Wd, Ht, defs, false));
  return { name: 'hub-bg-phone', vbW: Wd, vbH: Ht, pxW: 390, pxH: 845, items: it, defs, grain: 0.5, bg: '#1D1036' };
}

// ------------------------------------------------------- card frames ----
// AD note: no flat placeholder cards with a soft pink outer glow. The hub cards take their edges from the
// ornament set (bab arch for game cards, the ticket for the room-code panel), and FOCUS is a cream inked ring
// (DESIGN §4.6: 3 dp ring, 2 dp outside the card, scale 1.06, fill lifts to elevated) sitting on a hand-cut
// offset ink shadow instead of a blurred glow. 1 unit = 4 px = 2 dp on the 1920 canvas.
function archCardD(x: number, y: number, w: number, h: number, grow = 0) {
  // tall cards: the full bab arch. Wide, short cards (phone rows): the same arch flattened to a segmental top.
  if (h > w * 0.75) return archD(x - grow, y - grow, w + grow * 2, h + grow * 2, 0.6);
  const X = x - grow, Y = y - grow, W2 = w + grow * 2, H2 = h + grow * 2, rise = Math.min(7, H2 * 0.25);
  return `M${X} ${Y + H2} L${X + 0.2} ${Y + rise} C${X + W2 * 0.18} ${Y + 0.4} ${X + W2 * 0.4} ${Y - 0.1} ${X + W2 / 2 + 0.4} ${Y} C${X + W2 * 0.62} ${Y + 0.1} ${X + W2 * 0.84} ${Y + 0.5} ${X + W2} ${Y + rise + 0.2} L${X + W2 + 0.1} ${Y + H2} Z`;
}
function cardPiece(name: string, wU: number, hU: number, kind: 'arch' | 'ticket', focus: boolean) {
  const m = 5, x = m, y = m, items: Item[] = [], defs: string[] = [];
  const fill = focus ? '#4A2E7A' : '#3A2266';
  if (kind === 'arch') {
    const d = archCardD(x, y, wU, hU);
    // hand-cut offset shadow (paper lifted off the wall): bigger + further when focused
    const off = focus ? [2.2, 2.8] : [1.1, 1.4];
    items.push(flat(archCardD(x, y, wU, hU, focus ? 1.0 : 0), HUB.ink, { op: focus ? 0.62 : 0.5, amp: 0.35, seed: name + 'sh' }).map((q) => `<g transform="translate(${off[0]} ${off[1]})">${q}</g>`));
    items.push(calmThing(d, { fill, ink: HUB.ink, w: 0.9, amp: 0.2, seed: name, pressure: 0.3, wave: [16, 44] }));
    // the inner painted line of the bab arch frame (quiet when unfocused)
    items.push(calmThing(archCardD(x + 2.2, y + 2.2, wU - 4.4, hU - 4.4), { ink: HUB.paper, w: 0.45, amp: 0.15, seed: name + 'i', pressure: 0.3, wave: [14, 40] }).map((q) => `<g opacity="${focus ? 0.55 : 0.22}">${q}</g>`));
    if (focus) {
      // the focus ring: 3 dp (1.5 u) cream, 2 dp (1 u) outside the edge, inked with a little pressure, never blurred
      items.push(calmThing(archCardD(x, y, wU, hU, 1.75), { ink: '#FFF7EC', w: 1.5, amp: 0.16, seed: name + 'ring', pressure: 0.18, overshoot: 2.4, wave: [18, 50] }));
      items.push(blob(circleD(x + wU / 2 + 0.6, y - 1.9, 1.5), '#FFC94D', { seed: name + 'key', amp: 0.08 }));
    }
  } else {
    items.push(...ticketFrame(x, y, wU, hU, name, fill));
  }
  return writePiece('bg', { name, vbW: wU + m * 2 + 3, vbH: hU + m * 2 + 3, pxW: (wU + m * 2 + 3) * 4, pxH: (hU + m * 2 + 3) * 4, items, defs, bg: 'transparent', noPng: true });
}
const iconSvg = (n: string, px: number) => `<svg viewBox="0 0 24 24" width="${px}" height="${px}" style="color:#FFF7EC"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[n].join('')}</g></svg>`;
/** Round icon button, hand-cut: a surface disc with an inked edge (frame A only here). */
function iconButton(name: string) {
  const d = circleD(12, 12, 10);
  return writePiece('bg', { name, vbW: 26, vbH: 26, pxW: 104, pxH: 104, items: [flat(d, HUB.ink, { op: 0.5, amp: 0.25, seed: name + 'sh' }).map((q) => `<g transform="translate(0.9 1.1)">${q}</g>`), calmThing(d, { fill: '#3A2266', ink: HUB.ink, w: 0.7, amp: 0.15, seed: name, pressure: 0.3 })], defs: [], bg: 'transparent', noPng: true });
}

/** Preview of the background behind mock hub cards (for checking it stays calm). Not an asset. */
export function mockups() {
  const dir = path.join(OUT, 'bg');
  cardPiece('card-ticket', 104, 168, 'ticket', false);
  cardPiece('card-arch', 92, 132, 'arch', false);
  cardPiece('card-arch-focus', 92, 132, 'arch', true);
  cardPiece('card-ticket-phone', 78, 32, 'ticket', false);
  cardPiece('card-arch-phone', 78, 30, 'arch', false);
  iconButton('btn-round');
  // card SVGs are drawn with a 5-unit margin (20 px) + 3 units for the shadow
  const card = (src: string, left: number, top: number, wU: number, hU: number, scale = 1, inner = '') => `<div style="position:absolute;left:${left}px;top:${top}px;width:${(wU + 13) * 4}px;height:${(hU + 13) * 4}px;transform:scale(${scale});transform-origin:center"><img src="${src}_A.svg" style="position:absolute;inset:0;width:100%;height:100%">${inner}</div>`;
  const btn = (left: number, icon: string) => `<div style="position:absolute;left:${left}px;top:0;width:104px;height:104px"><img src="btn-round_A.svg" style="position:absolute;inset:0"><div style="position:absolute;left:28px;top:28px">${iconSvg(icon, 48)}</div></div>`;
  const title = (t: string, y: number) => `<div style="position:absolute;left:0;right:0;top:${y}px;text-align:center;font:800 34px system-ui;color:#FFF7EC">${t}</div>`;
  const tv = `<html><body style="margin:0;background:#1D1036;font-family:sans-serif">
<div style="position:relative;width:1920px;height:1080px;overflow:hidden">
<img src="hub-bg-tv_A.svg" style="position:absolute;inset:0;width:1920px;height:1080px">
<div style="position:absolute;left:96px;top:54px;right:96px;height:104px;display:flex;align-items:center;justify-content:space-between">
<img src="../wordmark/wordmark-sign-latin_A.svg" style="height:84px"><div style="position:relative;width:232px;height:104px">${btn(0, 'settings')}${btn(128, 'language')}</div></div>
${card('card-ticket', 76, 200, 104, 168, 1, `<div style="position:absolute;left:0;right:0;top:120px;text-align:center;font:600 26px system-ui;color:#B8A8D6">ROOM CODE</div><div style="position:absolute;left:0;right:0;top:160px;text-align:center;font:900 76px system-ui;letter-spacing:6px;color:#FFF7EC">KWZT</div>`)}
${card('card-arch-focus', 590, 236, 92, 132, 1.06, title('Mish Ana!', 330))}
${card('card-arch', 1040, 236, 92, 132, 1, title('Bluff', 330))}
${card('card-arch', 1460, 236, 92, 132, 1, title('Trivia', 330))}
</div></body></html>`;
  fs.writeFileSync(path.join(dir, '.mock-tv.html'), tv);
  shotJob({ src: path.join(dir, '.mock-tv.html'), out: path.join(dir, 'preview-behind-cards-tv@1x.png'), w: 1920, h: 1080, scale: 1 });
  const ph = `<html><body style="margin:0;background:#1D1036;font-family:sans-serif">
<div style="position:relative;width:390px;height:845px;overflow:hidden">
<img src="hub-bg-phone_A.svg" style="position:absolute;inset:0;width:390px;height:845px">
<img src="../wordmark/wordmark-sign-latin_A.svg" style="position:absolute;left:20px;top:28px;height:44px">
<div style="position:absolute;right:16px;top:22px;width:56px;height:56px"><img src="btn-round_A.svg" style="position:absolute;inset:0;width:56px"><div style="position:absolute;left:16px;top:16px">${iconSvg('settings', 24)}</div></div>
<div style="position:absolute;left:10px;top:290px;width:364px;height:180px"><img src="card-ticket-phone_A.svg" style="width:364px;height:180px"><div style="position:absolute;left:0;right:0;top:26px;text-align:center;font:600 13px system-ui;color:#B8A8D6">ROOM CODE</div><div style="position:absolute;left:0;right:0;top:42px;text-align:center;font:900 40px system-ui;letter-spacing:4px;color:#FFF7EC">KWZT</div></div>
<div style="position:absolute;left:10px;top:480px;width:364px;height:172px"><img src="card-arch-phone_A.svg" style="width:364px;height:172px"><div style="position:absolute;left:0;right:0;top:76px;text-align:center;font:800 22px system-ui;color:#FFF7EC">Mish Ana!</div></div>
<div style="position:absolute;left:20px;right:20px;bottom:40px;height:64px;border-radius:32px;background:#FF4F9A;box-shadow:3px 4px 0 #160B26"></div>
</div></body></html>`;
  fs.writeFileSync(path.join(dir, '.mock-phone.html'), ph);
  shotJob({ src: path.join(dir, '.mock-phone.html'), out: path.join(dir, 'preview-behind-cards-phone@2x.png'), w: 390, h: 845, scale: 2 });
}

export function buildBg() {
  writePiece('bg', hubTV());
  writePiece('bg', hubPhone());
}
