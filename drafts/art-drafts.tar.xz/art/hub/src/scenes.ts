// scenes.ts — empty states (ART-DIRECTION §9.6) and celebrations (§9.7): tiny scenes with one or a few
// shilleh acting, never a stock "person with a laptop". Canvas 160 × 120 units (4 px/unit at 1x), transparent,
// so they sit on a card or on the hub stage.
import {
  type F3, type Item, HUB, TEXT, PLAYER, writePiece, thing, flat, stroke, blob, shadow, character, cat, g, uid, r2, rng, hashSeed,
  circleD, ellipseD, P, rect, stipple, rr, archD, wire, glow, cone, calmThing, calmStroke, LATIN, placeLatin, signPaint, mapPath, bboxOf, shapeById, samplePath,
} from './kit.ts';
import { confettiPiece, sparkleTwinkle, sparklePop, bubbleTalk, starFull, tileLozenge } from './ornaments.ts';
import { T, curtain, rod } from './room.ts';

const W = HUB;
const DIR = 'scenes';
const sc = (name: string, items: Item[], defs: string[], label: string, vbW = 160, vbH = 120) =>
  writePiece(DIR, { name, vbW, vbH, pxW: vbW * 4, pxH: vbH * 4, items, defs, bg: '#3A2266', label });

// extra sign-painter glyphs (cap-10 centrelines), same hand as the house LATIN set
Object.assign(LATIN, {
  C: { w: 6.6, s: ['M6.0 -8.4 C5.3 -9.7 4.2 -10.2 3.2 -10.0 C1.1 -9.6 0.4 -7.0 0.4 -4.9 C0.4 -1.9 1.8 0.1 3.7 0.1 C4.9 0.0 5.8 -0.7 6.3 -1.9'] },
  P: { w: 6.4, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.3 -9.0 6.0 -6.9 C5.7 -5.0 3.6 -4.4 1.2 -4.6'] },
  R: { w: 6.6, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.3 -9.0 6.0 -7.0 C5.7 -5.2 3.6 -4.6 1.2 -4.8', 'M3.0 -4.9 C4.0 -3.2 5.0 -1.6 6.2 0.1'] },
  '2': { w: 6.6, s: ['M0.8 -7.8 C1.2 -9.6 2.6 -10.2 3.6 -10.1 C5.2 -10.0 6.0 -8.8 5.8 -7.4 C5.5 -5.4 2.8 -3.0 0.6 0.0 C2.4 -0.1 4.2 0.0 6.2 -0.2'] },
  '7': { w: 6.4, s: ['M0.5 -9.9 C2.4 -10.0 4.3 -10.1 6.2 -10.2 C4.6 -6.8 3.2 -3.4 2.2 0.1'] },
  '?': { w: 6.0, s: ['M0.6 -7.8 C0.8 -9.6 2.2 -10.2 3.3 -10.1 C4.8 -10.0 5.7 -8.9 5.5 -7.5 C5.3 -6.0 3.2 -5.4 3.0 -3.4', 'M2.9 -0.8 L3.0 -0.2'] },
});
const word = (text: string, size: number, x: number, y: number, fill: string, shade: string, seed: string, align: 'left' | 'center' | 'right' = 'center') => {
  const L = placeLatin(text, size, x, y, { seed, track: 0.9 }, align);
  return signPaint(L.strokes, size / 10, { fill, shade, shadeOff: [size * 0.07, size * 0.09] }, false, seed);
};
/** where a character's pointing nub ends, in scene units (no lean) */
function nubTip(shapeId: string, x: number, y: number, s: number, nub: 1 | -1, L = 6.5) {
  const sh = shapeById(shapeId), bb = bboxOf(sh.d);
  const yA = bb.y0 + bb.h * 0.6;
  // span at yA (sample the outline)
  let lo = 1e9, hi = -1e9;
  const pts = sh.d; void pts;
  for (let px = bb.x0; px <= bb.x1; px += 0.1) { /* rough: assume symmetric glyph */ }
  lo = bb.x0; hi = bb.x1;
  const ax = nub > 0 ? hi - 1.4 : lo + 1.4;
  const lx = ax + nub * L, cx = (bb.x0 + bb.x1) / 2;
  return { x: x + (lx - cx) * s, y: y + (yA - bb.y1 - 0.4) * s };
}
const ground = (cx: number, y: number, w: number) => shadow(`M${cx - w} ${y + 0.4} C${cx - w * 0.9} ${y - 1.6} ${cx + w * 0.95} ${y - 1.7} ${cx + w} ${y + 0.2} C${cx + w * 0.9} ${y + 2} ${cx - w * 0.85} ${y + 2.1} ${cx - w} ${y + 0.4} Z`, W, 0.3);

// ------------------------------------------------- waiting for players ----
/** One slipper in a low 3/4 view: a thick sole (footprint, foreshortened), a wide strap over the toe, the dark
 *  opening where the foot goes. dir = 1 toe to the right. */
function slipper(cx: number, cy: number, s: number, rot: number, dir: 1 | -1, seed: string): Item[] {
  const tf = `translate(${cx} ${cy}) rotate(${rot}) scale(${dir * s} ${s})`;
  const sole = 'M-7 0 C-7.2 -1.5 -3.4 -2.1 0 -2.2 C3.8 -2.5 7.2 -2.1 7.3 0 C7.3 2.0 4.0 2.5 0 2.2 C-3.4 2.1 -7.1 1.5 -7 0 Z';
  const edge = 'M-7 0 C-7.1 1.5 -3.4 2.1 0 2.2 C4.0 2.5 7.3 2.0 7.3 0 L7.2 1.3 C7.0 3.2 4.0 3.7 0 3.4 C-3.4 3.3 -6.9 2.7 -7 1.2 Z';
  const strap = 'M0.2 -1.6 C-0.1 -5.4 6.0 -6.0 6.6 -1.9 L6.5 1.4 C4.6 2.3 1.8 2.3 0.3 1.5 Z';
  return [
    g(`transform="translate(${cx} ${cy + 1.2}) scale(${s})"`, shadow('M-8.5 1 C-8 -1 8 -1.4 8.8 0.8 C8 3.4 -7.6 3.6 -8.5 1 Z', W, 0.35)),
    g(`transform="${tf}"`,
      thing(edge, { fill: '#8C5A3C', ink: W.ink, w: 0.45, amp: 0.08, seed: seed + 'e' }),
      thing(sole, { fill: '#E2C79A', ink: W.ink, w: 0.45, amp: 0.1, mis: [-0.2, 0.2], seed: seed + 's' }),
      blob(ellipseD(-3.2, 0.1, 2.6, 1.05), '#C7A574', { seed: seed + 'heel', amp: 0.04 }),
      thing(strap, { fill: '#2F5DA8', ink: W.ink, w: 0.5, amp: 0.1, mis: [-0.2, 0.2], seed: seed + 'st', hatch: true, hatchColor: W.ink, hatchOp: 0.25 }),
      blob(ellipseD(0.75, -0.1, 0.55, 1.5), '#160B26', { seed: seed + 'op', amp: 0.04 }),
      stroke('M1.6 -3.3 C2.6 -4.4 4.4 -4.6 5.3 -3.4', '#9DB4FF', { w: 0.35, op: 0.8, seed: seed + 'hl' }),
    ),
  ];
}
function waiting() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  // the front door, held open: warm light pours onto the floor (light may be soft)
  const dx = 98, dw = 40, dh = 78;
  it.push(ground(110, gy + 1, 36));
  it.push(calmThing(archD(dx - 3, gy - dh - 3, dw + 6, dh + 3, 0.5), { fill: T.woodLo, ink: W.ink, w: 1.0, amp: 0.3, seed: 'wdf' }));
  it.push(flat(archD(dx, gy - dh, dw, dh, 0.5), '#FFD98A', { seed: 'wdl', amp: 0.2 }));
  it.push(glow(dx + dw / 2, gy - dh * 0.4, 36, 46, '#FFC94D', defs, 0.35));
  it.push(cone([[dx, gy], [dx + dw, gy], [dx + dw - 6, gy + 14], [dx - 30, gy + 14]], '#FFC94D', defs, 0.32));
  // the door leaf swung inward (we see its edge and a bit of panel), with a brass handle
  it.push(calmThing(P([[dx - 2, gy - dh + 6], [dx + 10, gy - dh + 12], [dx + 10, gy + 2], [dx - 2, gy]]), { fill: '#7A4630', ink: W.ink, w: 1.0, amp: 0.25, mis: W.mis, seed: 'wleaf', hatch: true, hatchColor: W.ink, hatchOp: 0.25 }));
  it.push(thing(rr(dx + 1.2, gy - dh * 0.42, 6.4, 3.0, 1.3), { fill: T.brass, ink: W.ink, w: 0.5, amp: 0.05, seed: 'whdl' }));
  // the welcome mat (a striped cement-tile rug)
  it.push(thing(P([[dx + 2, gy - 1], [dx + dw - 2, gy - 1.3], [dx + dw + 2, gy + 4], [dx - 3, gy + 4.3]]), { fill: T.rust, ink: W.ink, w: 0.7, amp: 0.15, seed: 'wmat' }));
  it.push(calmStroke(`M${dx + 3} ${gy + 1.6} L${dx + dw - 1} ${gy + 1.4}`, '#E8A33A', { w: 0.8, seed: 'wms' }));
  // host: coral circle beside the door, happy, the nub sweeping toward the doorway: "tfaddalo"
  it.push(character('circle', { x: 66, y: gy, s: 2.1, expr: 'happy', world: W, nub: 1, nubLen: 7, lean: 6, seed: 'host' }));
  it.push(sparklePop(84, 54, 9, 'wpop', TEXT, 1));
  // the host's shahata (plastic slippers), kicked off on the mat by the door: a pair, one landed crooked
  it.push(...slipper(111, gy + 1.4, 1.55, -4, 1, 'sl1'), ...slipper(129, gy + 3.4, 1.55, 24, -1, 'sl2'));
  return sc('empty-waiting-for-players', it, defs, 'Waiting for players: the host holds the door open, tfaddalo');
}

// -------------------------------------------------------- wrong door ----
function wrongDoor() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  it.push(ground(112, gy + 1, 30));
  const dx = 92, dw = 40, dh = 82;
  it.push(calmThing(rect(dx - 3, gy - dh - 3, dw + 6, dh + 3), { fill: T.woodLo, ink: W.ink, w: 1.0, amp: 0.3, seed: 'rdf' }));
  it.push(calmThing(rect(dx, gy - dh, dw, dh), { fill: T.curtain, ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'rdoor', hatch: true, hatchColor: W.ink, hatchOp: 0.22 }));
  for (const [py, ph] of [[gy - dh + 7, 30], [gy - dh + 44, 30]]) it.push(calmThing(rect(dx + 6, py, dw - 12, ph), { ink: W.ink, w: 0.6, amp: 0.2, seed: 'rpan' + py }));
  it.push(thing(circleD(dx + dw - 6, gy - dh * 0.46, 1.8), { fill: T.brass, ink: W.ink, w: 0.5, amp: 0.05, seed: 'rknob' }));
  // the number plate on the door says 27 (enamel plate, a little crooked)
  it.push(g(`transform="rotate(-4 ${dx + dw / 2} ${gy - dh + 22})"`,
    thing(rr(dx + 9, gy - dh + 14, 22, 15, 2), { fill: W.paper, ink: W.ink, w: 0.7, amp: 0.12, seed: 'rplate' }),
    word('27', 10, dx + 20, gy - dh + 26.5, HUB.c, '#00000000', 'r27'),
  ));
  // azure square checks the note in its nub: it says 72. Thinking face, looking from note to door.
  const cx = 52, s = 2.1;
  it.push(character('square', { x: cx, y: gy, s, expr: 'think', world: W, nub: 1, nubLen: 5.5, look: [0.6, -0.2], seed: 'guest' }));
  const tp = nubTip('square', cx, gy, s, 1, 5.5);
  it.push(g(`transform="rotate(8 ${r2(tp.x)} ${r2(tp.y)})"`,
    thing(P([[tp.x - 2, tp.y - 15], [tp.x + 15, tp.y - 16], [tp.x + 16, tp.y - 1], [tp.x - 1, tp.y]]), { fill: '#FFF7EC', ink: W.ink, w: 0.6, amp: 0.15, seed: 'rnote' }),
    word('72', 8, tp.x + 7, tp.y - 4.2, HUB.a, '#00000000', 'r72'),
  ));
  it.push(word('?', 12, 70, 30, '#FFC94D', W.ink, 'rq1'), word('?', 8, 80, 22, TEXT, W.ink, 'rq2'));
  return sc('empty-room-not-found', it, defs, 'Room not found: the note says 72, the door says 27');
}

// ------------------------------------------------------ reconnecting ----
function reconnecting() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 106;
  // the old TV on its little table, screen showing snow-lines
  const tx = 18, tw = 46, th = 34, ty = gy - 16 - th;
  it.push(ground(tx + tw / 2, gy + 1, 26));
  for (const lx of [tx + 6, tx + tw - 8]) it.push(thing(P([[lx, gy - 16], [lx + 2, gy - 16], [lx + 3.4, gy], [lx + 1.4, gy]]), { fill: T.woodLo, ink: W.ink, w: 0.6, amp: 0.08, seed: 'tl' + lx }));
  it.push(calmThing(rect(tx - 2, gy - 18, tw + 4, 3), { fill: T.wood, ink: W.ink, w: 0.8, amp: 0.2, seed: 'ttop' }));
  it.push(calmThing(rr(tx, ty, tw, th, 5), { fill: '#7A4630', ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'tv' }));
  it.push(calmThing(rr(tx + 4, ty + 4, tw - 15, th - 8, 4), { fill: '#3B4A7A', ink: W.ink, w: 0.8, amp: 0.2, seed: 'scr' }));
  // scan lines: five broken brush pulls, each lifted once mid-stroke, uneven weight (no hairline raster)
  const r = rng(hashSeed('snow'));
  for (let i = 0; i < 5; i++) {
    const yy = ty + 8.5 + i * 4.2, x0 = tx + 7 + r() * 3, x1 = tx + tw - 13 - r() * 3, cut = x0 + (x1 - x0) * (0.3 + r() * 0.4);
    it.push(calmStroke(`M${r2(x0)} ${r2(yy)} L${r2(cut - 1.2)} ${r2(yy + 0.15)}`, '#B8C6F0', { w: 1.0 + r() * 0.5, op: 0.75, seed: 'sn' + i }));
    it.push(calmStroke(`M${r2(cut + 0.8)} ${r2(yy + 0.2)} L${r2(x1)} ${r2(yy - 0.1)}`, '#B8C6F0', { w: 0.8 + r() * 0.5, op: 0.6, seed: 'sm' + i }));
  }
  it.push(blob(circleD(tx + tw - 6, ty + 10, 1.8) + circleD(tx + tw - 6, ty + 17, 1.8), '#3A1E12', { seed: 'tvk' }));
  // jade triangle standing on tiptoe, holding the rabbit-ear antenna up as high as it goes
  const cx = 116, s = 2.0;
  it.push(character('triangle', { x: cx, y: gy, s, expr: 'shock', world: W, squash: 1.06, look: [-0.4, -0.6], seed: 'ant' }));
  const top = { x: cx + 0.3, y: gy - 37.5 };
  it.push(calmStroke(`M${top.x} ${top.y} L${top.x - 13} ${top.y - 24} M${top.x} ${top.y} L${top.x + 11} ${top.y - 25}`, '#C9C2D8', { w: 1.1, seed: 'ears' }));
  it.push(blob(circleD(top.x - 13, top.y - 24, 1.4) + circleD(top.x + 11, top.y - 25, 1.4), '#C9C2D8', { seed: 'earb' }));
  it.push(thing(`M${top.x - 6} ${top.y + 3} C${top.x - 6} ${top.y - 3} ${top.x + 6} ${top.y - 3} ${top.x + 6} ${top.y + 3} Z`, { fill: '#3A2558', ink: W.ink, w: 0.6, amp: 0.08, seed: 'abase' }));
  // the cable sagging back to the TV
  it.push(calmStroke(`M${top.x + 4} ${top.y + 2.5} C${top.x + 30} ${top.y + 40} ${tx + tw + 20} ${gy + 6} ${tx + tw - 2} ${ty + th - 4}`, W.ink, { w: 0.7, seed: 'cable' }));
  // signal: three little hand-drawn arcs, the last one dashed (still trying)
  for (let i = 0; i < 3; i++) {
    const R = 5 + i * 4.5;
    it.push(calmStroke(`M${top.x + 12 - R * 0.2} ${top.y - 28 - R * 0.85} Q${top.x + 12 + R * 0.7} ${top.y - 28 - R * 0.5} ${top.x + 12 + R * 0.85} ${top.y - 28 + R * 0.2}`, i === 2 ? '#FFC94D' : TEXT, { w: 1.0, op: i === 2 ? 0.55 : 0.9, seed: 'sig' + i }));
  }
  return sc('empty-reconnecting', it, defs, 'Reconnecting: balancing the antenna on its head (boils at 12 fps)');
}

// ------------------------------------------------- no packs in language ----
// isolated «ع», Ruq'ah centreline (alef height 10): an open cup on top, the big tail curling back right. [native review]
const AR_AIN = ['M6.0 -7.6 C4.8 -8.6 2.8 -8.4 2.3 -7.0 C1.8 -5.6 2.7 -4.5 4.0 -4.6 C4.8 -4.7 5.5 -5.0 6.2 -5.3', 'M5.8 -5.1 C3.4 -4.2 1.2 -2.6 1.1 -0.2 C1.0 2.2 3.0 3.4 6.4 3.0'];
const MUTEDK = '#8A79A8';
function noPacks() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  // rose drop with a phrasebook too big for it, confused
  const cx = 70, s = 2.2;
  it.push(character('drop', { x: cx, y: gy, s, expr: 'think', world: W, look: [0.7, 0.6], brows: true, seed: 'phr' }));
  // the open book, held in front (it hides the lower body: the drop reads it)
  const bx = cx + 8, by = gy - 12;
  it.push(g(`transform="rotate(-8 ${bx} ${by})"`,
    calmThing(`M${bx - 20} ${by - 2} C${bx - 12} ${by - 5} ${bx - 4} ${by - 4} ${bx} ${by} C${bx + 4} ${by - 4} ${bx + 12} ${by - 5} ${bx + 20} ${by - 2} L${bx + 20} ${by + 14} C${bx + 12} ${by + 11} ${bx + 4} ${by + 12} ${bx} ${by + 16} C${bx - 4} ${by + 12} ${bx - 12} ${by + 11} ${bx - 20} ${by + 14} Z`, { fill: W.paper, ink: W.ink, w: 0.9, amp: 0.2, mis: W.mis, seed: 'book' }),
    calmThing(`M${bx - 21} ${by + 13} L${bx - 21.5} ${by + 16} C${bx - 12} ${by + 13} ${bx - 4} ${by + 14} ${bx} ${by + 18} C${bx + 4} ${by + 14} ${bx + 12} ${by + 13} ${bx + 21.5} ${by + 16} L${bx + 21} ${by + 13}`, { ink: W.ink, w: 0.7, amp: 0.1, seed: 'cover' }),
    // scribbled lines on the pages: left page "Latin", right page squiggles (both unreadable on purpose)
    stroke(`M${bx - 17} ${by + 2} L${bx - 4} ${by + 3} M${bx - 17} ${by + 5.5} L${bx - 6} ${by + 6.3} M${bx - 17} ${by + 9} L${bx - 3} ${by + 9.6}`, W.ink, { w: 0.5, op: 0.6, seed: 'bl' }),
    stroke(`M${bx + 4} ${by + 3} q1.5 -1.4 3 0 t3 0 t3 0 t3 0 M${bx + 4} ${by + 6.6} q1.5 -1.4 3 0 t3 0 t3 0 M${bx + 4} ${by + 10.2} q1.5 -1.4 3 0 t3 0 t3 0 t3 0`, HUB.a, { w: 0.5, op: 0.8, seed: 'br' }),
  ));
  // one speech bubble, its tail on the drop's head: «ع / A» — which one? (marks only, no copy)
  it.push(...bubbleTalk(74, 14, 44, 24, 'nb1'));
  it.push(word('A', 11, 84, 32.5, HUB.ink, '#00000000', 'nbA'));
  it.push(calmStroke('M95.6 34 L98.6 20.8', MUTEDK, { w: 0.9, seed: 'nbsl' }));
  const ain = AR_AIN.map((d) => mapPath(d, (x, y) => [104 + x * 1.15, 30.5 + y * 1.15]));
  it.push(signPaint(ain, 1.15, { fill: HUB.ink, shade: '#00000000', shadeOff: [0, 0] }, true, 'nbain'));
  it.push(ground(cx, gy + 1, 20));
  return sc('empty-no-packs-language', it, defs, 'No packs in this language yet: a phrasebook, confused');
}

// ------------------------------------------------- game over / thanks ----
/** a raised waving nub drawn behind the body, with two motion ticks */
function waveNub(id: string, x: number, y: number, s: number, side: 1 | -1, seed: string): Item[] {
  const sh = shapeById(id), bb = bboxOf(sh.d);
  const h = bb.h * s, wdt = bb.w * s;
  const ax = x + side * wdt * 0.36, ay = y - h * 0.55;
  const tx = ax + side * 5.6 * s / 1.3, ty = ay - 8.5 * s / 1.3;
  const k = s / 1.3;
  const d = `M${ax - side * 1.6 * k} ${ay + 1.4 * k} C${ax + side * 1.6 * k} ${ay - 2 * k} ${tx - side * 2.4 * k} ${ty + 2.6 * k} ${tx - side * 1.4 * k} ${ty - 0.4 * k} C${tx - side * 0.4 * k} ${ty - 2.2 * k} ${tx + side * 2.0 * k} ${ty - 1.2 * k} ${tx + side * 1.4 * k} ${ty + 0.8 * k} C${tx + side * 0.6 * k} ${ty + 3.4 * k} ${ax + side * 3.6 * k} ${ay + 1.2 * k} ${ax + side * 1.8 * k} ${ay + 3.6 * k} Z`;
  return [
    thing(d, { seed: seed + 'wn', fill: sh.color, ink: W.ink, w: 0.8, amp: 0.12, mis: [-0.3, 0.3], rim: W.paper, rimW: 1.6 }),
    calmStroke(`M${tx + side * 3.4 * k} ${ty - 3.4 * k} q${side * 1.6 * k} ${1.4 * k} ${side * 1.8 * k} ${3.6 * k} M${tx + side * 4.6 * k} ${ty + 2.4 * k} q${side * 0.8 * k} ${1 * k} ${side * 0.8 * k} ${2.4 * k}`, TEXT, { w: 0.75, seed: seed + 'wt' }),
  ];
}
function thanks() {
  const defs: string[] = [], it: Item[] = [];
  // the hub's own window seen from the street side at closing time: shutters open, curtains tied back,
  // the room lamp still on inside, three of the gang waving goodbye over the sill (low segmental arch, never a dome)
  const x0 = 30, x1 = 130, top = 26, rise = 10, sill = 90;
  const win = `M${x0} ${sill} L${x0 + 0.3} ${top + rise} C${x0 + 22} ${top - 0.4} ${x1 - 24} ${top + 0.3} ${x1} ${top + rise + 0.4} L${x1 - 0.2} ${sill} Z`;
  // the house wall around the window (a plaster patch, hand-cut)
  it.push(flat('M8 10 L60 6 L150 8 L153 60 L151 112 L90 115 L10 113 L7 62 Z', '#4A2E7A', { seed: 'twall', amp: 0.4 }));
  it.push(stipple(18, 98, 10, 9, 6, W.ink, 0.3, 'tdamp'), stipple(142, 30, 8, 7, 6, W.ink, 0.25, 'tdamp2'));
  // inside: the lit room (lamp-warm wall, the sofa back and the photo frame as darker shapes)
  it.push(flat(win, '#E7A651', { seed: 'troom', amp: 0.2 }));
  it.push(flat(`M${x0} ${sill} L${x0} 74 C60 70 100 71 ${x1} 73 L${x1} ${sill} Z`, '#B8673E', { seed: 'tsofa', amp: 0.3 }));
  it.push(flat(rect(98, 44, 12, 9), '#B26A3A', { seed: 'tphoto', amp: 0.15 }));
  it.push(stroke('M30 40 L130 41', '#C9853E', { w: 0.5, op: 0.5, seed: 'tpicrail' }));
  // the lamp's shade at the left edge of the room: the light has a source
  it.push(thing('M40 50 C42 48.6 48 48.6 50 50 L52.6 59 C48 60.4 42 60.4 37.6 59 Z', { fill: '#FFE9B8', ink: '#7A4A1A', w: 0.45, amp: 0.1, seed: 'tshade' }));
  it.push(stroke('M45 60 L45.4 74', '#7A4A1A', { w: 0.5, seed: 'tpole' }));
  // curtains inside the frame, tied back (behind the gang)
  it.push(...curtain(x0 + 0.5, top + 7, 11, sill - top - 7, 1, 60, 'tcL'));
  it.push(...curtain(x1 - 11.5, top + 7, 11, sill - top - 7, -1, 62, 'tcR'));
  it.push(...rod(x0 - 1, x1 + 1, top + 7, 'trod'));
  // the gang, clear gaps between them, all waving
  const gang: [string, number, number, 'happy' | 'cheer', 1 | -1][] = [['circle', 49, 1.32, 'happy', -1], ['star', 80, 1.36, 'cheer', 1], ['square', 111, 1.26, 'happy', 1]];
  for (const [id, x, s, e, side] of gang) {
    it.push(...waveNub(id, x, sill + 2.5, s, side, 'th' + id));
    it.push(character(id, { x, y: sill + 2.5, s, expr: e, world: W, lean: side * 3, groundShadow: false, seed: 'th' + id }));
  }
  // the window frame (painted wood) drawn over them, then the sill in front
  it.push(calmStroke(win.replace(/Z$/, '') + ` L${x0} ${sill}`, T.wood, { w: 3.6, seed: 'tframe' }));
  it.push(calmThing(win, { ink: W.ink, w: 0.8, amp: 0.25, seed: 'tfi' }));
  const ow = `M${x0 - 3.4} ${sill} L${x0 - 3.2} ${top + rise - 1} C${x0 + 20} ${top - 4.4} ${x1 - 22} ${top - 3.6} ${x1 + 3.4} ${top + rise - 0.6} L${x1 + 3.4} ${sill} Z`;
  it.push(calmThing(ow, { ink: W.ink, w: 0.9, amp: 0.25, seed: 'tfo' }));
  it.push(calmThing(P([[x0 - 7, sill - 1.2], [x1 + 7, sill - 1.6], [x1 + 8, sill + 4], [x0 - 8, sill + 4.4]]), { fill: T.woodHi, ink: W.ink, w: 0.9, amp: 0.2, mis: W.mis, seed: 'tsill' }));
  it.push(shadow(P([[x0 - 6, sill + 4.4], [x1 + 7, sill + 4], [x1 + 4, sill + 8], [x0 - 4, sill + 8.4]]), W, 0.35));
  // the shutters, swung open against the wall (Levantine louvres, faded green)
  for (const side of [-1, 1] as const) {
    const sx0 = side < 0 ? x0 - 21 : x1 + 4, sx1 = side < 0 ? x0 - 4 : x1 + 21;
    const sd = side < 0
      ? `M${sx0} ${top + 14} C${sx0 + 6} ${top + 11} ${sx1 - 4} ${top + 9.4} ${sx1} ${top + 9} L${sx1} ${sill - 1} L${sx0 + 0.4} ${sill - 0.6} Z`
      : `M${sx0} ${top + 9} C${sx0 + 4} ${top + 9.4} ${sx1 - 6} ${top + 11} ${sx1} ${top + 14} L${sx1 - 0.4} ${sill - 0.6} L${sx0} ${sill - 1} Z`;
    it.push(calmThing(sd, { fill: '#3F6B57', ink: W.ink, w: 0.8, amp: 0.25, mis: W.mis, seed: 'tsh' + side, hatch: true, hatchColor: W.ink, hatchOp: 0.2 }));
    let lv = '';
    for (let y = top + 17; y < sill - 3; y += 4.2) lv += `M${sx0 + 2.4} ${r2(y)} L${sx1 - 2.4} ${r2(y + 1.1)} `;
    it.push(calmStroke(lv, '#2A4A3C', { w: 0.6, seed: 'tlv' + side }));
  }
  // a geranium tin on the sill, and the cat's tail hanging off it
  { const tx = 131; // the geranium tin stands on the sill's outer end, clear of the gang
  it.push(thing(P([[tx, sill - 8], [tx + 7, sill - 8.3], [tx + 6.5, sill - 1.3], [tx + 0.5, sill - 1.2]]), { fill: T.rust, ink: W.ink, w: 0.6, amp: 0.1, mis: W.mis, seed: 'ttin' }));
  it.push(stroke(`M${tx + 2} ${sill - 8} q-2 -5 -4 -7 M${tx + 3.5} ${sill - 8} q0 -6 2 -8 M${tx + 5} ${sill - 8} q2 -4 5 -5`, T.leafHi, { w: 0.9, seed: 'tleaf' }));
  it.push(blob(circleD(tx - 1.6, sill - 15.6, 1.4) + circleD(tx + 5.6, sill - 16.6, 1.5) + circleD(tx + 10, sill - 13.4, 1.2), '#F0183A', { seed: 'tger' })); }
  it.push(calmStroke(`M40 ${sill + 3.8} C42 ${sill + 8} 38 ${sill + 12} 41 ${sill + 17}`, '#120A20', { w: 1.5, amp: 0.4, seed: 'ttail' }));
  return sc('empty-game-ended-thanks', it, defs, 'Game ended / thanks: three of the gang wave goodbye from the hub window');
}

// ---------------------------------------------------------- champion ----
// «البطل», Ruq'ah centrelines, alef height 10. [native review]
const AR_CHAMP = [
  'M24.2 -10.0 C24.1 -6.6 24.0 -3.3 23.9 0.1',
  'M20.8 -10.2 C20.7 -6.6 20.6 -3.2 20.5 -0.6 C20.4 0.1 19.8 0.1 18.6 0.1 C17.8 0.1 17.2 0.1 16.6 0.1',
  'M18.4 0.1 C18.3 -0.8 18.3 -1.6 18.5 -2.6', 'M18.2 2.5 L18.4 2.45',
  'M16.8 0.1 C16.4 -3.2 13.6 -3.8 12.6 -2.0 C12.0 -0.8 12.8 0.1 13.8 0.1 C12.4 0.1 11.2 0.1 9.6 0.1',
  'M13.4 -10.0 C13.3 -6.8 13.2 -4.6 13.1 -3.2',
  'M7.6 -10.2 C7.5 -6.6 7.4 -2.6 7.5 0.0 C7.6 2.6 6.2 4.0 4.4 4.0 C2.6 4.0 1.8 2.6 2.0 1.0',
];
function champion() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 108;
  // light with a source: a little floor spotlight (a theatre can on a stand) at the start edge, aimed at the winner
  it.push(cone([[11, 87.6], [15.2, 94.6], [104, 76], [84, 40]], '#FFE2A6', defs, 0.32, [0, 1, 1, 0]));
  // the yafta: a cloth banner hung on two strings, sagging, fringed ends
  const bx0 = 12, bx1 = 148, by = 10, bh = 24;
  it.push(calmStroke(`M${bx0 + 4} ${by} L${bx0 - 4} ${by - 12} M${bx1 - 4} ${by} L${bx1 + 4} ${by - 12}`, W.ink, { w: 0.6, seed: 'ystr' }));
  const cloth = `M${bx0} ${by} C${bx0 + 40} ${by + 5} ${bx1 - 40} ${by + 5} ${bx1} ${by} L${bx1 - 1} ${by + bh} C${bx1 - 40} ${by + bh + 5} ${bx0 + 40} ${by + bh + 5} ${bx0 + 1} ${by + bh} Z`;
  it.push(calmThing(cloth, { fill: '#C8553D', ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'yafta', hatch: true, hatchColor: W.ink, hatchOp: 0.18 }));
  let fringe = '';
  for (const fx of [bx0 + 0.5, bx1 - 0.5]) for (let i = 0; i < 6; i++) { const yy = by + 2 + i * 4; fringe += `M${fx} ${yy} l${fx < 80 ? -2.6 : 2.6} ${0.6} `; }
  it.push(stroke(fringe, '#E8A33A', { w: 0.7, seed: 'yfr' }));
  // lettering: one bilingual composition, centred on the cloth: CHAMPION · tile lozenge · «البطل»,
  // equal cap/alef height, one baseline, one shade
  const capS = 9.0, k = 0.98, base = by + 17.6;
  const L0 = placeLatin('CHAMPION', capS, 0, 0, { seed: 'champ', track: 0.6, rot: 2 }, 'left');
  const arBB = bboxOf(AR_CHAMP.join('')), arW = arBB.w * k, gap = 15;
  const total = L0.w + gap + arW, lx = 80 - total / 2;
  const L = placeLatin('CHAMPION', capS, lx, base, { seed: 'champ', track: 0.6, rot: 2 }, 'left');
  it.push(signPaint(L.strokes, capS / 10, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, false, 'champ'));
  it.push(...tileLozenge(lx + L0.w + gap / 2, base - 4.6, 4.4, 'yorn'));
  const arL = lx + L0.w + gap;
  const ar = AR_CHAMP.map((d) => mapPath(d, (x, y) => [arL + (x - arBB.x0) * k, base + y * k]));
  it.push(signPaint(ar, k, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, true, 'albatal'));
  // the podium: a painted wooden crate with the number 1 in a tile
  it.push(ground(80, gy + 1, 30));
  it.push(calmThing(P([[56, gy - 24], [104, gy - 24.6], [105, gy], [55, gy]]), { fill: T.wood, ink: W.ink, w: 1.1, amp: 0.3, mis: W.mis, seed: 'pod', hatch: true, hatchColor: W.ink, hatchOp: 0.22 }));
  it.push(calmThing(rr(73, gy - 19, 14, 14, 1.5), { fill: '#2F5DA8', ink: W.ink, w: 0.7, amp: 0.15, seed: 'podt' }));
  it.push(calmStroke('M78.4 ' + (gy - 15.4) + ' L80.6 ' + (gy - 16.6) + ' L80.4 ' + (gy - 7.2), W.paper, { w: 1.5, seed: 'one' }));
  // the winner: lemon star, cheer, top of a hop (squash stretched), confetti cut from its own colour
  it.push(character('star', { x: 80, y: gy - 27, s: 2.5, expr: 'cheer', world: W, squash: 1.08, groundShadow: false, seed: 'winner' }));
  // the brass cup beside the podium (dented, one handle a bit lower)
  const cx = 124, cy = gy;
  it.push(ground(cx, cy + 1, 10));
  it.push(calmThing(`M${cx - 8} ${cy - 30} C${cx - 8} ${cy - 18} ${cx - 4} ${cy - 15} ${cx - 1.6} ${cy - 14} L${cx - 1.4} ${cy - 7} L${cx - 6} ${cy - 4.5} L${cx - 6.4} ${cy} L${cx + 6.6} ${cy} L${cx + 6.2} ${cy - 4.5} L${cx + 1.6} ${cy - 7} L${cx + 1.8} ${cy - 14} C${cx + 4.4} ${cy - 15} ${cx + 8.4} ${cy - 18} ${cx + 8.2} ${cy - 30.4} Z`, { fill: T.brass, ink: '#3A1E08', w: 0.9, amp: 0.15, mis: W.mis, seed: 'cup' }));
  it.push(calmStroke(`M${cx - 8} ${cy - 27} C${cx - 14} ${cy - 27} ${cx - 13} ${cy - 18} ${cx - 5} ${cy - 18.5} M${cx + 8.2} ${cy - 26} C${cx + 14} ${cy - 26} ${cx + 13.4} ${cy - 16.4} ${cx + 5} ${cy - 17.4}`, '#3A1E08', { w: 1.3, seed: 'cuph' }));
  it.push(stroke(`M${cx - 5.2} ${cy - 27} C${cx - 5.4} ${cy - 23} ${cx - 4.4} ${cy - 20} ${cx - 3} ${cy - 18.6}`, '#FFF4D6', { w: 0.8, op: 0.85, seed: 'cuphl' }));
  it.push(stroke(`M${cx + 3} ${cy - 25} l1.6 1.2 l-.6 1.6`, '#A86F2A', { w: 0.6, seed: 'dent' }));
  // left: a second-place shilleh clapping (coral, happy), smaller
  it.push(character('circle', { x: 35, y: gy, s: 1.5, expr: 'happy', world: W, lean: 5, seed: 'second' }));
  // confetti in the winner's lemon + the room's colours
  const r = rng(hashSeed('chconf'));
  for (let i = 0; i < 24; i++) {
    const ids = ['star', 'star', 'circle', 'square', 'triangle', 'crescent'];
    const x = 10 + r() * 140, y = 38 + r() * 40, sz = 3 + r() * 3, rot = r() * 360, fl = r() < 0.3 ? 0.4 : 1;
    if (x > 56 && x < 104 && y > 40) continue; // keep the winner's face clear
    it.push(...confettiPiece(ids[i % ids.length], x, y, sz, rot, 'cc' + i, fl));
  }
  it.push(...sparkleTwinkle(60, 50, 3.5, 'cs1'), ...sparkleTwinkle(104, 46, 2.6, 'cs2', '#FFF1DC'));
  // the spotlight itself: a theatre can in a U-yoke on a short stand, barn doors open, tilted up at the winner
  it.push(stroke(`M9 99 L5 ${gy} M9 99 L13.4 ${gy} M9 99 L9.2 ${gy}`, W.ink, { w: 0.7, seed: 'spleg' }));
  it.push(thing(rr(8.2, 95.6, 1.6, 4.2, 0.5), { fill: '#3A2558', ink: W.ink, w: 0.5, amp: 0.05, seed: 'sppost' }));
  it.push(g('transform="rotate(-27 9 93)"',
    thing('M3.6 90.6 C3.4 89 4.6 88.6 6 88.6 L12.6 89 L12.8 97 L6 97.4 C4.6 97.4 3.4 97 3.6 95.4 Z', { fill: '#2A1D40', ink: W.ink, w: 0.7, amp: 0.1, seed: 'spcan', hatch: true, hatchColor: '#000', hatchOp: 0.3 }),
    thing('M12.4 88.6 L16 86.4 L16.2 87.6 L12.8 89.8 Z', { fill: '#3A2558', ink: W.ink, w: 0.45, amp: 0.04, seed: 'spbd1' }),
    thing('M12.6 97.2 L16.2 99.6 L16.0 100.6 L12.4 98.4 Z', { fill: '#3A2558', ink: W.ink, w: 0.45, amp: 0.04, seed: 'spbd2' }),
    thing(ellipseD(12.9, 93, 1.3, 3.8), { fill: '#FFF4D6', ink: W.ink, w: 0.5, amp: 0.05, seed: 'splens' }),
    stroke('M5 92 L10.6 92.2 M5 94.4 L10.6 94.6', '#4A3866', { w: 0.4, seed: 'spvent' }),
    calmStroke('M8.4 97.4 C8.2 100 9.6 100.4 9.8 98.6 M8.4 88.6 C8.2 86.4 9.6 86 9.8 87.8', '#4A3866', { w: 0.8, seed: 'spyoke' }),
  ));
  return sc('celebration-champion', it, defs, 'Champion / البطل: yafta banner, podium, the brass cup, own-colour confetti');
}

// ------------------------------------------------------ confetti pop ----
function correct() {
  const defs: string[] = [], it: Item[] = [];
  // a party popper (paper cone) going off from the start-bottom, a burst of cut paper and one big star
  const px = 30, py = 100;
  const r = rng(hashSeed('pop'));
  for (let i = 0; i < 34; i++) {
    const a = -Math.PI * (0.12 + r() * 0.36), d = 30 + r() * 85;
    const s = SHAPE_IDS[i % SHAPE_IDS.length];
    it.push(...confettiPiece(s, px + Math.cos(a) * d, py + Math.sin(a) * d * 0.95, 3.5 + r() * 4, r() * 360, 'pp' + i, r() < 0.3 ? 0.35 : 1));
  }
  // streamers: cut paper ribbons in player colours, twisting (the width breathes as the paper turns),
  // inked with the thick-thin pen, V-cut ends from the scissors
  it.push(ribbon(`M${px + 6} ${py - 8} C${px + 20} ${py - 40} ${px + 40} ${py - 30} ${px + 46} ${py - 58} C${px + 50} ${py - 76} ${px + 66} ${py - 70} ${px + 70} ${py - 84}`, 2.6, 3.5, PLAYER.coral, 'str1'));
  it.push(ribbon(`M${px + 9} ${py - 5} C${px + 34} ${py - 22} ${px + 56} ${py - 12} ${px + 72} ${py - 34} C${px + 84} ${py - 50} ${px + 100} ${py - 40} ${px + 112} ${py - 54}`, 2.4, 4.2, PLAYER.azure, 'str2'));
  it.push(ribbon(`M${px + 8} ${py - 9} C${px + 12} ${py - 30} ${px + 4} ${py - 44} ${px + 14} ${py - 62}`, 2.0, 2.2, PLAYER.lemon, 'str3'));
  // the popper: a striped paper cone
  const cone_ = `M${px - 6} ${py + 8} L${px + 3} ${py - 13} L${px + 14} ${py - 4} Z`;
  it.push(calmThing(cone_, { fill: '#E8A33A', ink: W.ink, w: 0.9, amp: 0.12, mis: W.mis, seed: 'pcone' }));
  const cid = uid('pc');
  it.push(`<clipPath id="${cid}"><path d="${cone_}"/></clipPath>`, g(`clip-path="url(#${cid})"`, stroke(`M${px - 8} ${py - 4} L${px + 14} ${py + 6} M${px - 4} ${py - 10} L${px + 16} ${py - 1}`, '#C8553D', { w: 2.2, seed: 'pstr' })));
  it.push(...starFull(116, 40, 13, 'pstar'), ...sparklePop(132, 28, 10, 'pp2', TEXT, 1));
  return sc('celebration-confetti-pop', it, defs, 'Correct / round won: a paper popper, streamers and one big star');
}
/** A cut-paper streamer along a centreline: half-width w, `turns` twists, V-notched ends, inked thick-thin. */
function ribbon(d: string, w: number, turns: number, fill: string, seed: string) {
  const pts = samplePath(d, 0.5)[0];
  const n = pts.length, L: { x: number; y: number }[] = [], R: typeof L = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
    let tx = b.x - a.x, ty = b.y - a.y; const l = Math.hypot(tx, ty) || 1; tx /= l; ty /= l;
    const t = i / (n - 1);
    const ww = w * (0.18 + 0.82 * Math.abs(Math.cos(t * Math.PI * turns + 0.6)));
    // when the paper turns, the edge leans: offset the centre a touch toward one side
    const lean = w * 0.25 * Math.sin(t * Math.PI * turns + 0.6);
    const cx = pts[i].x - ty * lean, cy = pts[i].y + tx * lean;
    L.push({ x: cx - ty * ww, y: cy + tx * ww }); R.push({ x: cx + ty * ww, y: cy - tx * ww });
  }
  const notch = (i: number, j: number) => { const p = pts[i], q = pts[j]; return [p.x + (q.x - p.x) * 1.0, p.y + (q.y - p.y) * 1.0]; };
  const tail = notch(n - 1, n - 4), head = notch(0, 3);
  const poly = [...L.map((p) => [p.x, p.y]), tail, ...R.reverse().map((p) => [p.x, p.y]), head];
  return thing(P(poly), { fill, ink: W.ink, w: 0.7, amp: 0.15, mis: W.mis, seed, pressure: 0.55, overshoot: 0.6 });
}
const SHAPE_IDS = ['circle', 'square', 'star', 'triangle', 'diamond', 'hexagon', 'plus', 'drop', 'crescent', 'bolt', 'flower', 'arch'];

export function buildScenes() {
  waiting(); wrongDoor(); reconnecting(); noPacks(); thanks(); champion(); correct();
}
