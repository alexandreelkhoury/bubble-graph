// scenes.ts — empty states (ART-DIRECTION §9.6) and celebrations (§9.7): tiny scenes with one or a few
// shilleh acting, never a stock "person with a laptop". Canvas 160 × 120 units (4 px/unit at 1x), transparent,
// so they sit on a card or on the hub stage.
import fs from 'node:fs';
import path from 'node:path';
import {
  OUT, shotJob, type F3, type Item, HUB, TEXT, PLAYER, writePiece, thing, flat, stroke, blob, shadow, character, cat, g, uid, r2, rng, hashSeed,
  circleD, ellipseD, P, rect, stipple, rr, archD, wire, glow, cone, calmThing, calmStroke, LATIN, placeLatin, signPaint, mapPath, bboxOf, shapeById, samplePath,
} from './kit.ts';
import { confettiPiece, sparkleTwinkle, sparklePop, bubbleTalk, starFull, tileLozenge } from './ornaments.ts';
import { T, curtain, rod } from './room.ts';

const W = HUB;
const DIR = 'scenes';
const sc = (name: string, items: Item[], defs: string[], label: string, vbW = 160, vbH = 120) =>
  writePiece(DIR, { name, vbW, vbH, pxW: vbW * 4, pxH: vbH * 4, items, defs, bg: '#3A2266', label });

// extra sign-painter glyphs (cap-10 centrelines), same hand as the house LATIN set
Object.assign(LATIN, {
  C: { w: 6.6, s: ['M6.0 -8.4 C5.3 -9.7 4.2 -10.2 3.2 -10.0 C1.1 -9.6 0.4 -7.0 0.4 -4.9 C0.4 -1.9 1.8 0.1 3.7 0.1 C4.9 0.0 5.8 -0.7 6.3 -1.9'] },
  P: { w: 6.4, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.3 -9.0 6.0 -6.9 C5.7 -5.0 3.6 -4.4 1.2 -4.6'] },
  R: { w: 6.6, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.3 -9.0 6.0 -7.0 C5.7 -5.2 3.6 -4.6 1.2 -4.8', 'M3.0 -4.9 C4.0 -3.2 5.0 -1.6 6.2 0.1'] },
  '2': { w: 6.6, s: ['M0.8 -7.8 C1.2 -9.6 2.6 -10.2 3.6 -10.1 C5.2 -10.0 6.0 -8.8 5.8 -7.4 C5.5 -5.4 2.8 -3.0 0.6 0.0 C2.4 -0.1 4.2 0.0 6.2 -0.2'] },
  '7': { w: 6.4, s: ['M0.5 -9.9 C2.4 -10.0 4.3 -10.1 6.2 -10.2 C4.6 -6.8 3.2 -3.4 2.2 0.1'] },
  '?': { w: 6.0, s: ['M0.6 -7.8 C0.8 -9.6 2.2 -10.2 3.3 -10.1 C4.8 -10.0 5.7 -8.9 5.5 -7.5 C5.3 -6.0 3.2 -5.4 3.0 -3.4', 'M2.9 -0.8 L3.0 -0.2'] },
});
const word = (text: string, size: number, x: number, y: number, fill: string, shade: string, seed: string, align: 'left' | 'center' | 'right' = 'center') => {
  const L = placeLatin(text, size, x, y, { seed, track: 0.9 }, align);
  return signPaint(L.strokes, size / 10, { fill, shade, shadeOff: [size * 0.07, size * 0.09] }, false, seed);
};
/** where a character's pointing nub ends, in scene units (no lean) */
function nubTip(shapeId: string, x: number, y: number, s: number, nub: 1 | -1, L = 6.5) {
  const sh = shapeById(shapeId), bb = bboxOf(sh.d);
  const yA = bb.y0 + bb.h * 0.6;
  // span at yA (sample the outline)
  let lo = 1e9, hi = -1e9;
  const pts = sh.d; void pts;
  for (let px = bb.x0; px <= bb.x1; px += 0.1) { /* rough: assume symmetric glyph */ }
  lo = bb.x0; hi = bb.x1;
  const ax = nub > 0 ? hi - 1.4 : lo + 1.4;
  const lx = ax + nub * L, cx = (bb.x0 + bb.x1) / 2;
  return { x: x + (lx - cx) * s, y: y + (yA - bb.y1 - 0.4) * s };
}
/** A character's nub stretched into a reaching limb: tapered from the body (w0) to a round mitten (w1) at h, with a
 *  slight elbow bow. Same fill, ink and paper rim as the character nubs. Drawn BEFORE the body so the body cuts it. */
function limb(a: { x: number; y: number }, h: { x: number; y: number }, w0: number, w1: number, bow: number, fill: string, seed: string): Item {
  const L = Math.hypot(h.x - a.x, h.y - a.y), ux = (h.x - a.x) / L, uy = (h.y - a.y) / L, nx = -uy, ny = ux;
  const m = { x: (a.x + h.x) / 2 + nx * bow, y: (a.y + h.y) / 2 + ny * bow };
  const p = (q: { x: number; y: number }, o: number) => `${r2(q.x + nx * o)} ${r2(q.y + ny * o)}`;
  const tipX = h.x + ux * w1 * 1.05, tipY = h.y + uy * w1 * 1.05;
  const d = `M${p(a, w0)} Q${p(m, (w0 + w1) / 2)} ${p(h, w1)} C${r2(h.x + nx * w1 + ux * w1 * 0.9)} ${r2(h.y + ny * w1 + uy * w1 * 0.9)} ${r2(tipX + nx * w1 * 0.5)} ${r2(tipY + ny * w1 * 0.5)} ${r2(tipX)} ${r2(tipY)} C${r2(tipX - nx * w1 * 0.5)} ${r2(tipY - ny * w1 * 0.5)} ${r2(h.x - nx * w1 + ux * w1 * 0.9)} ${r2(h.y - ny * w1 + uy * w1 * 0.9)} ${p(h, -w1)} Q${p(m, -(w0 + w1) / 2)} ${p(a, -w0)} Z`;
  return thing(d, { seed, fill, ink: W.ink, w: 0.8, amp: 0.12, mis: [-0.3, 0.3], rim: W.paper, rimW: 1.6 });
}
/** the thumb that closes over whatever the hand holds (drawn AFTER the held object) */
const thumb = (x: number, y: number, r: number, rot: number, fill: string, seed: string): Item =>
  g(`transform="translate(${r2(x)} ${r2(y)}) rotate(${rot})"`, thing(`M${-r} ${0.2 * r} C${-r} ${-0.9 * r} ${0.2 * r} ${-1.2 * r} ${0.8 * r} ${-0.5 * r} C${1.2 * r} 0 ${0.6 * r} ${0.75 * r} ${-0.2 * r} ${0.7 * r} C${-0.7 * r} ${0.65 * r} ${-r} ${0.55 * r} ${-r} ${0.2 * r} Z`, { seed, fill, ink: W.ink, w: 0.7, amp: 0.06 }));
const ground = (cx: number, y: number, w: number) => shadow(`M${cx - w} ${y + 0.4} C${cx - w * 0.9} ${y - 1.6} ${cx + w * 0.95} ${y - 1.7} ${cx + w} ${y + 0.2} C${cx + w * 0.9} ${y + 2} ${cx - w * 0.85} ${y + 2.1} ${cx - w} ${y + 0.4} Z`, W, 0.3);

// ------------------------------------------------- waiting for players ----
/** One slipper in a low 3/4 view: a thick sole (footprint, foreshortened), a wide strap over the toe, the dark
 *  opening where the foot goes. dir = 1 toe to the right. */
function slipper(cx: number, cy: number, s: number, rot: number, dir: 1 | -1, seed: string): Item[] {
  const tf = `translate(${cx} ${cy}) rotate(${rot}) scale(${dir * s} ${s})`;
  const sole = 'M-7 0 C-7.2 -1.5 -3.4 -2.1 0 -2.2 C3.8 -2.5 7.2 -2.1 7.3 0 C7.3 2.0 4.0 2.5 0 2.2 C-3.4 2.1 -7.1 1.5 -7 0 Z';
  const edge = 'M-7 0 C-7.1 1.5 -3.4 2.1 0 2.2 C4.0 2.5 7.3 2.0 7.3 0 L7.2 1.3 C7.0 3.2 4.0 3.7 0 3.4 C-3.4 3.3 -6.9 2.7 -7 1.2 Z';
  const strap = 'M0.2 -1.6 C-0.1 -5.4 6.0 -6.0 6.6 -1.9 L6.5 1.4 C4.6 2.3 1.8 2.3 0.3 1.5 Z';
  return [
    g(`transform="translate(${cx} ${cy + 1.2}) scale(${s})"`, shadow('M-8.5 1 C-8 -1 8 -1.4 8.8 0.8 C8 3.4 -7.6 3.6 -8.5 1 Z', W, 0.35)),
    g(`transform="${tf}"`,
      thing(edge, { fill: '#8C5A3C', ink: W.ink, w: 0.45, amp: 0.08, seed: seed + 'e' }),
      thing(sole, { fill: '#E2C79A', ink: W.ink, w: 0.45, amp: 0.1, mis: [-0.2, 0.2], seed: seed + 's' }),
      blob(ellipseD(-3.2, 0.1, 2.6, 1.05), '#C7A574', { seed: seed + 'heel', amp: 0.04 }),
      thing(strap, { fill: '#2F5DA8', ink: W.ink, w: 0.5, amp: 0.1, mis: [-0.2, 0.2], seed: seed + 'st', hatch: true, hatchColor: W.ink, hatchOp: 0.25 }),
      blob(ellipseD(0.75, -0.1, 0.55, 1.5), '#160B26', { seed: seed + 'op', amp: 0.04 }),
      stroke('M1.6 -3.3 C2.6 -4.4 4.4 -4.6 5.3 -3.4', '#9DB4FF', { w: 0.35, op: 0.8, seed: seed + 'hl' }),
    ),
  ];
}
function waiting() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  // the front door, held open: warm light pours onto the floor (light may be soft)
  const dx = 98, dw = 40, dh = 78;
  it.push(ground(110, gy + 1, 36));
  it.push(calmThing(archD(dx - 3, gy - dh - 3, dw + 6, dh + 3, 0.5), { fill: T.woodLo, ink: W.ink, w: 1.0, amp: 0.3, seed: 'wdf' }));
  it.push(flat(archD(dx, gy - dh, dw, dh, 0.5), '#FFD98A', { seed: 'wdl', amp: 0.2 }));
  it.push(glow(dx + dw / 2, gy - dh * 0.4, 36, 46, '#FFC94D', defs, 0.35));
  it.push(cone([[dx, gy], [dx + dw, gy], [dx + dw - 6, gy + 14], [dx - 30, gy + 14]], '#FFC94D', defs, 0.32));
  // the door leaf swung inward (we see its edge and a bit of panel), with a brass handle
  it.push(calmThing(P([[dx - 2, gy - dh + 6], [dx + 10, gy - dh + 12], [dx + 10, gy + 2], [dx - 2, gy]]), { fill: '#7A4630', ink: W.ink, w: 1.0, amp: 0.25, mis: W.mis, seed: 'wleaf', hatch: true, hatchColor: W.ink, hatchOp: 0.25 }));
  it.push(thing(rr(dx + 1.2, gy - dh * 0.42, 6.4, 3.0, 1.3), { fill: T.brass, ink: W.ink, w: 0.5, amp: 0.05, seed: 'whdl' }));
  // the welcome mat (a striped cement-tile rug)
  it.push(thing(P([[dx + 2, gy - 1], [dx + dw - 2, gy - 1.3], [dx + dw + 2, gy + 4], [dx - 3, gy + 4.3]]), { fill: T.rust, ink: W.ink, w: 0.7, amp: 0.15, seed: 'wmat' }));
  it.push(calmStroke(`M${dx + 3} ${gy + 1.6} L${dx + dw - 1} ${gy + 1.4}`, '#E8A33A', { w: 0.8, seed: 'wms' }));
  // host: coral circle beside the door, happy, the nub sweeping toward the doorway: "tfaddalo"
  it.push(character('circle', { x: 66, y: gy, s: 2.1, expr: 'happy', world: W, nub: 1, nubLen: 7, lean: 6, seed: 'host' }));
  it.push(...sparklePop(84, 54, 9, 'wpop', 1));
  // the host's shahata (plastic slippers), kicked off on the mat by the door: a pair, one landed crooked
  it.push(...slipper(111, gy + 1.4, 1.55, -4, 1, 'sl1'), ...slipper(129, gy + 3.4, 1.55, 24, -1, 'sl2'));
  return sc('empty-waiting-for-players', it, defs, 'Waiting for players: the host holds the door open, tfaddalo');
}

// -------------------------------------------------------- wrong door ----
function wrongDoor() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  it.push(ground(112, gy + 1, 30));
  const dx = 92, dw = 40, dh = 82;
  it.push(calmThing(rect(dx - 3, gy - dh - 3, dw + 6, dh + 3), { fill: T.woodLo, ink: W.ink, w: 1.0, amp: 0.3, seed: 'rdf' }));
  it.push(calmThing(rect(dx, gy - dh, dw, dh), { fill: T.curtain, ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'rdoor', hatch: true, hatchColor: W.ink, hatchOp: 0.22 }));
  for (const [py, ph] of [[gy - dh + 7, 30], [gy - dh + 44, 30]]) it.push(calmThing(rect(dx + 6, py, dw - 12, ph), { ink: W.ink, w: 0.6, amp: 0.2, seed: 'rpan' + py }));
  it.push(thing(circleD(dx + dw - 6, gy - dh * 0.46, 1.8), { fill: T.brass, ink: W.ink, w: 0.5, amp: 0.05, seed: 'rknob' }));
  // the number plate on the door says 27 (enamel plate, a little crooked)
  it.push(g(`transform="rotate(-4 ${dx + dw / 2} ${gy - dh + 22})"`,
    thing(rr(dx + 9, gy - dh + 14, 22, 15, 2), { fill: W.paper, ink: W.ink, w: 0.7, amp: 0.12, seed: 'rplate' }),
    word('27', 10, dx + 20, gy - dh + 26.5, HUB.c, '#00000000', 'r27'),
  ));
  // azure square checks the note in its nub: it says 72. Thinking face, looking from note to door.
  const cx = 52, s = 2.1;
  it.push(character('square', { x: cx, y: gy, s, expr: 'think', world: W, nub: 1, nubLen: 5.5, look: [0.6, -0.2], seed: 'guest' }));
  const tp = nubTip('square', cx, gy, s, 1, 5.5);
  it.push(g(`transform="rotate(8 ${r2(tp.x)} ${r2(tp.y)})"`,
    thing(P([[tp.x - 2, tp.y - 15], [tp.x + 15, tp.y - 16], [tp.x + 16, tp.y - 1], [tp.x - 1, tp.y]]), { fill: '#FFF7EC', ink: W.ink, w: 0.6, amp: 0.15, seed: 'rnote' }),
    word('72', 8, tp.x + 7, tp.y - 4.2, HUB.a, '#00000000', 'r72'),
  ));
  it.push(word('?', 12, 70, 30, '#FFC94D', W.ink, 'rq1'), word('?', 8, 80, 22, TEXT, W.ink, 'rq2'));
  return sc('empty-room-not-found', it, defs, 'Room not found: the note says 72, the door says 27');
}

// ------------------------------------------------------ reconnecting ----
function reconnecting() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 106;
  // the old TV on its little table, screen showing snow-lines
  const tx = 18, tw = 46, th = 34, ty = gy - 16 - th;
  it.push(ground(tx + tw / 2, gy + 1, 26));
  for (const lx of [tx + 6, tx + tw - 8]) it.push(thing(P([[lx, gy - 16], [lx + 2, gy - 16], [lx + 3.4, gy], [lx + 1.4, gy]]), { fill: T.woodLo, ink: W.ink, w: 0.6, amp: 0.08, seed: 'tl' + lx }));
  it.push(calmThing(rect(tx - 2, gy - 18, tw + 4, 3), { fill: T.wood, ink: W.ink, w: 0.8, amp: 0.2, seed: 'ttop' }));
  it.push(calmThing(rr(tx, ty, tw, th, 5), { fill: '#7A4630', ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'tv' }));
  it.push(calmThing(rr(tx + 4, ty + 4, tw - 15, th - 8, 4), { fill: '#3B4A7A', ink: W.ink, w: 0.8, amp: 0.2, seed: 'scr' }));
  // scan lines: five broken brush pulls, each lifted once mid-stroke, uneven weight (no hairline raster)
  const r = rng(hashSeed('snow'));
  for (let i = 0; i < 5; i++) {
    const yy = ty + 8.5 + i * 4.2, x0 = tx + 7 + r() * 3, x1 = tx + tw - 13 - r() * 3, cut = x0 + (x1 - x0) * (0.3 + r() * 0.4);
    it.push(calmStroke(`M${r2(x0)} ${r2(yy)} L${r2(cut - 1.2)} ${r2(yy + 0.15)}`, '#B8C6F0', { w: 1.0 + r() * 0.5, op: 0.75, seed: 'sn' + i }));
    it.push(calmStroke(`M${r2(cut + 0.8)} ${r2(yy + 0.2)} L${r2(x1)} ${r2(yy - 0.1)}`, '#B8C6F0', { w: 0.8 + r() * 0.5, op: 0.6, seed: 'sm' + i }));
  }
  it.push(blob(circleD(tx + tw - 6, ty + 10, 1.8) + circleD(tx + tw - 6, ty + 17, 1.8), '#3A1E12', { seed: 'tvk' }));
  // jade triangle on tiptoe, one nub raised high, its hand GRIPPING a rabbit-ear antenna (§9.6): the antenna is a
  // separate object with a weighted base and a cable back to the TV, held up and away from the head.
  const cx = 110, s = 2.0;
  const hand = { x: cx + 19, y: gy - 47 };
  it.push(limb({ x: cx + 7, y: gy - 15 }, hand, 4.2, 3.6, 2.2, PLAYER.jade, 'antarm'));
  it.push(character('triangle', { x: cx, y: gy, s, expr: 'shock', world: W, squash: 1.06, look: [0.6, -0.7], lean: 3, seed: 'ant' }));
  // the antenna: a weighted dome base (held in the mitten) and two telescopic rods, one a little bent
  const top = { x: hand.x + 0.6, y: hand.y - 3.4 };
  it.push(thing(`M${top.x - 7.6} ${top.y + 3.2} C${top.x - 7.2} ${top.y - 3.6} ${top.x + 7.2} ${top.y - 3.6} ${top.x + 7.6} ${top.y + 3.2} Z`, { fill: '#3A2558', ink: W.ink, w: 0.8, amp: 0.08, seed: 'abase' }));
  it.push(calmStroke(`M${top.x - 1.2} ${top.y - 2} L${top.x - 11} ${top.y - 23} M${top.x + 1.2} ${top.y - 2} L${top.x + 5.4} ${top.y - 12} L${top.x + 11.5} ${top.y - 23.5}`, '#C9C2D8', { w: 1.1, seed: 'ears' }));
  it.push(blob(circleD(top.x - 11, top.y - 23, 1.3) + circleD(top.x + 11.5, top.y - 23.5, 1.3), '#C9C2D8', { seed: 'earb' }));
  it.push(thumb(hand.x - 2.6, hand.y - 1.2, 3.6, -14, PLAYER.jade, 'antthumb'));
  // the cable: out of the back of the base, a loop hanging, all the way back to the TV
  it.push(calmStroke(`M${top.x + 7} ${top.y + 2.5} C${top.x + 16} ${top.y + 8} ${top.x + 12} ${gy - 6} ${cx + 4} ${gy + 4} C${cx - 14} ${gy + 9} ${tx + tw + 14} ${gy + 4} ${tx + tw - 2} ${ty + th - 4}`, W.ink, { w: 0.7, seed: 'cable' }));
  // effort: two sweat ticks off the head, toward the start side (it's straining)
  it.push(calmStroke(`M${cx - 9} ${gy - 36} q-2 -1 -3.6 -0.6 M${cx - 10.4} ${gy - 31} q-2 0 -3.2 1`, TEXT, { w: 0.75, seed: 'antsw' }));
  // signal: three little hand-drawn arcs above the rods, the last one dashed amber (still trying)
  for (let i = 0; i < 3; i++) {
    const R = 4 + i * 4;
    const ox = top.x + 13, oy = top.y - 24;
    it.push(calmStroke(`M${ox - R * 0.2} ${oy - R * 0.85} Q${ox + R * 0.7} ${oy - R * 0.5} ${ox + R * 0.85} ${oy + R * 0.2}`, i === 2 ? '#FFC94D' : TEXT, { w: 1.0, op: i === 2 ? 0.55 : 0.9, seed: 'sig' + i }));
  }
  return writePiece(DIR, { name: 'empty-reconnecting', vbW: 160, vbH: 120, pxW: 640, pxH: 480, items: it, defs, bg: '#3A2266', label: 'Reconnecting: holding the rabbit-ear antenna up (boils at 12 fps)', fps: 12 });
}

// ------------------------------------------------- no packs in language ----
// isolated «ع», Ruq'ah centreline (alef height 10): an open cup on top, the big tail curling back right. [native review]
const AR_AIN = ['M6.0 -7.6 C4.8 -8.6 2.8 -8.4 2.3 -7.0 C1.8 -5.6 2.7 -4.5 4.0 -4.6 C4.8 -4.7 5.5 -5.0 6.2 -5.3', 'M5.8 -5.1 C3.4 -4.2 1.2 -2.6 1.1 -0.2 C1.0 2.2 3.0 3.4 6.4 3.0'];
const MUTEDK = '#8A79A8';
function noPacks() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 104;
  // rose drop with a phrasebook too big for it, confused
  const cx = 70, s = 2.2;
  it.push(character('drop', { x: cx, y: gy, s, expr: 'think', world: W, look: [0.7, 0.6], brows: true, seed: 'phr' }));
  // the open book, held in front (it hides the lower body: the drop reads it)
  const bx = cx + 8, by = gy - 12;
  it.push(g(`transform="rotate(-8 ${bx} ${by})"`,
    calmThing(`M${bx - 20} ${by - 2} C${bx - 12} ${by - 5} ${bx - 4} ${by - 4} ${bx} ${by} C${bx + 4} ${by - 4} ${bx + 12} ${by - 5} ${bx + 20} ${by - 2} L${bx + 20} ${by + 14} C${bx + 12} ${by + 11} ${bx + 4} ${by + 12} ${bx} ${by + 16} C${bx - 4} ${by + 12} ${bx - 12} ${by + 11} ${bx - 20} ${by + 14} Z`, { fill: W.paper, ink: W.ink, w: 0.9, amp: 0.2, mis: W.mis, seed: 'book' }),
    calmThing(`M${bx - 21} ${by + 13} L${bx - 21.5} ${by + 16} C${bx - 12} ${by + 13} ${bx - 4} ${by + 14} ${bx} ${by + 18} C${bx + 4} ${by + 14} ${bx + 12} ${by + 13} ${bx + 21.5} ${by + 16} L${bx + 21} ${by + 13}`, { ink: W.ink, w: 0.7, amp: 0.1, seed: 'cover' }),
    // scribbled lines on the pages: left page "Latin", right page squiggles (both unreadable on purpose)
    stroke(`M${bx - 17} ${by + 2} L${bx - 4} ${by + 3} M${bx - 17} ${by + 5.5} L${bx - 6} ${by + 6.3} M${bx - 17} ${by + 9} L${bx - 3} ${by + 9.6}`, W.ink, { w: 0.5, op: 0.6, seed: 'bl' }),
    stroke(`M${bx + 4} ${by + 3} q1.5 -1.4 3 0 t3 0 t3 0 t3 0 M${bx + 4} ${by + 6.6} q1.5 -1.4 3 0 t3 0 t3 0 M${bx + 4} ${by + 10.2} q1.5 -1.4 3 0 t3 0 t3 0 t3 0`, HUB.a, { w: 0.5, op: 0.8, seed: 'br' }),
  ));
  // one speech bubble, its tail on the drop's head: «ع / A» — which one? (marks only, no copy)
  it.push(...bubbleTalk(66, 24.5, 44, 24, 'nb1'));
  it.push(word('A', 11, 76, 42.5, HUB.ink, '#00000000', 'nbA'));
  it.push(calmStroke('M87.6 44 L90.6 30.8', MUTEDK, { w: 0.9, seed: 'nbsl' }));
  const ain = AR_AIN.map((d) => mapPath(d, (x, y) => [96 + x * 1.15, 40.5 + y * 1.15]));
  it.push(signPaint(ain, 1.15, { fill: HUB.ink, shade: '#00000000', shadeOff: [0, 0] }, true, 'nbain'));
  it.push(ground(cx, gy + 1, 20));
  return sc('empty-no-packs-language', it, defs, 'No packs in this language yet: a phrasebook, confused');
}

// ------------------------------------------------- game over / thanks ----
/** a raised waving nub drawn behind the body, with two motion ticks */
function waveNub(id: string, x: number, y: number, s: number, side: 1 | -1, seed: string): Item[] {
  const sh = shapeById(id), bb = bboxOf(sh.d);
  const h = bb.h * s, wdt = bb.w * s;
  const ax = x + side * wdt * 0.36, ay = y - h * 0.55;
  const tx = ax + side * 5.6 * s / 1.3, ty = ay - 8.5 * s / 1.3;
  const k = s / 1.3;
  const d = `M${ax - side * 1.6 * k} ${ay + 1.4 * k} C${ax + side * 1.6 * k} ${ay - 2 * k} ${tx - side * 2.4 * k} ${ty + 2.6 * k} ${tx - side * 1.4 * k} ${ty - 0.4 * k} C${tx - side * 0.4 * k} ${ty - 2.2 * k} ${tx + side * 2.0 * k} ${ty - 1.2 * k} ${tx + side * 1.4 * k} ${ty + 0.8 * k} C${tx + side * 0.6 * k} ${ty + 3.4 * k} ${ax + side * 3.6 * k} ${ay + 1.2 * k} ${ax + side * 1.8 * k} ${ay + 3.6 * k} Z`;
  return [
    thing(d, { seed: seed + 'wn', fill: sh.color, ink: W.ink, w: 0.8, amp: 0.12, mis: [-0.3, 0.3], rim: W.paper, rimW: 1.6 }),
    calmStroke(`M${tx + side * 3.4 * k} ${ty - 3.4 * k} q${side * 1.6 * k} ${1.4 * k} ${side * 1.8 * k} ${3.6 * k} M${tx + side * 4.6 * k} ${ty + 2.4 * k} q${side * 0.8 * k} ${1 * k} ${side * 0.8 * k} ${2.4 * k}`, TEXT, { w: 0.75, seed: seed + 'wt' }),
  ];
}
function thanks() {
  const defs: string[] = [], it: Item[] = [];
  // the hub's own window seen from the street side at closing time: shutters open, curtains tied back,
  // the room lamp still on inside, three of the gang waving goodbye over the sill (low segmental arch, never a dome)
  const x0 = 30, x1 = 130, top = 26, rise = 10, sill = 90;
  const win = `M${x0} ${sill} L${x0 + 0.3} ${top + rise} C${x0 + 22} ${top - 0.4} ${x1 - 24} ${top + 0.3} ${x1} ${top + rise + 0.4} L${x1 - 0.2} ${sill} Z`;
  // the house wall around the window (a plaster patch, hand-cut)
  it.push(flat('M8 10 L60 6 L150 8 L153 60 L151 112 L90 115 L10 113 L7 62 Z', '#4A2E7A', { seed: 'twall', amp: 0.4 }));
  it.push(stipple(18, 98, 10, 9, 6, W.ink, 0.3, 'tdamp'), stipple(142, 30, 8, 7, 6, W.ink, 0.25, 'tdamp2'));
  // inside: the lit room (lamp-warm wall, the sofa back and the photo frame as darker shapes)
  it.push(flat(win, '#E7A651', { seed: 'troom', amp: 0.2 }));
  it.push(flat(`M${x0} ${sill} L${x0} 74 C60 70 100 71 ${x1} 73 L${x1} ${sill} Z`, '#B8673E', { seed: 'tsofa', amp: 0.3 }));
  it.push(flat(rect(98, 44, 12, 9), '#B26A3A', { seed: 'tphoto', amp: 0.15 }));
  it.push(stroke('M30 40 L130 41', '#C9853E', { w: 0.5, op: 0.5, seed: 'tpicrail' }));
  // the lamp's shade at the left edge of the room: the light has a source
  it.push(thing('M40 50 C42 48.6 48 48.6 50 50 L52.6 59 C48 60.4 42 60.4 37.6 59 Z', { fill: '#FFE9B8', ink: '#7A4A1A', w: 0.45, amp: 0.1, seed: 'tshade' }));
  it.push(stroke('M45 60 L45.4 74', '#7A4A1A', { w: 0.5, seed: 'tpole' }));
  // curtains inside the frame, tied back (behind the gang)
  it.push(...curtain(x0 + 0.5, top + 7, 11, sill - top - 7, 1, 60, 'tcL'));
  it.push(...curtain(x1 - 11.5, top + 7, 11, sill - top - 7, -1, 62, 'tcR'));
  it.push(...rod(x0 - 1, x1 + 1, top + 7, 'trod'));
  // the gang, clear gaps between them, all waving
  const gang: [string, number, number, 'happy' | 'cheer', 1 | -1][] = [['circle', 49, 1.32, 'happy', -1], ['star', 80, 1.36, 'cheer', 1], ['square', 111, 1.26, 'happy', 1]];
  for (const [id, x, s, e, side] of gang) {
    it.push(...waveNub(id, x, sill + 2.5, s, side, 'th' + id));
    it.push(character(id, { x, y: sill + 2.5, s, expr: e, world: W, lean: side * 3, groundShadow: false, seed: 'th' + id }));
  }
  // the window frame (painted wood) drawn over them, then the sill in front
  it.push(calmStroke(win.replace(/Z$/, '') + ` L${x0} ${sill}`, T.wood, { w: 3.6, seed: 'tframe' }));
  it.push(calmThing(win, { ink: W.ink, w: 0.8, amp: 0.25, seed: 'tfi' }));
  const ow = `M${x0 - 3.4} ${sill} L${x0 - 3.2} ${top + rise - 1} C${x0 + 20} ${top - 4.4} ${x1 - 22} ${top - 3.6} ${x1 + 3.4} ${top + rise - 0.6} L${x1 + 3.4} ${sill} Z`;
  it.push(calmThing(ow, { ink: W.ink, w: 0.9, amp: 0.25, seed: 'tfo' }));
  it.push(calmThing(P([[x0 - 7, sill - 1.2], [x1 + 7, sill - 1.6], [x1 + 8, sill + 4], [x0 - 8, sill + 4.4]]), { fill: T.woodHi, ink: W.ink, w: 0.9, amp: 0.2, mis: W.mis, seed: 'tsill' }));
  it.push(shadow(P([[x0 - 6, sill + 4.4], [x1 + 7, sill + 4], [x1 + 4, sill + 8], [x0 - 4, sill + 8.4]]), W, 0.35));
  // the shutters, swung open against the wall (Levantine louvres, faded green)
  for (const side of [-1, 1] as const) {
    const sx0 = side < 0 ? x0 - 21 : x1 + 4, sx1 = side < 0 ? x0 - 4 : x1 + 21;
    const sd = side < 0
      ? `M${sx0} ${top + 14} C${sx0 + 6} ${top + 11} ${sx1 - 4} ${top + 9.4} ${sx1} ${top + 9} L${sx1} ${sill - 1} L${sx0 + 0.4} ${sill - 0.6} Z`
      : `M${sx0} ${top + 9} C${sx0 + 4} ${top + 9.4} ${sx1 - 6} ${top + 11} ${sx1} ${top + 14} L${sx1 - 0.4} ${sill - 0.6} L${sx0} ${sill - 1} Z`;
    it.push(calmThing(sd, { fill: '#3F6B57', ink: W.ink, w: 0.8, amp: 0.25, mis: W.mis, seed: 'tsh' + side, hatch: true, hatchColor: W.ink, hatchOp: 0.2 }));
    let lv = '';
    for (let y = top + 17; y < sill - 3; y += 4.2) lv += `M${sx0 + 2.4} ${r2(y)} L${sx1 - 2.4} ${r2(y + 1.1)} `;
    it.push(calmStroke(lv, '#2A4A3C', { w: 0.6, seed: 'tlv' + side }));
  }
  // a geranium tin on the sill
  { const tx = 131; // the geranium tin stands on the sill's outer end, clear of the gang
  it.push(thing(P([[tx, sill - 8], [tx + 7, sill - 8.3], [tx + 6.5, sill - 1.3], [tx + 0.5, sill - 1.2]]), { fill: T.rust, ink: W.ink, w: 0.6, amp: 0.1, mis: W.mis, seed: 'ttin' }));
  it.push(stroke(`M${tx + 2} ${sill - 8} q-2 -5 -4 -7 M${tx + 3.5} ${sill - 8} q0 -6 2 -8 M${tx + 5} ${sill - 8} q2 -4 5 -5`, T.leafHi, { w: 0.9, seed: 'tleaf' }));
  it.push(blob(circleD(tx - 1.6, sill - 15.6, 1.4) + circleD(tx + 5.6, sill - 16.6, 1.5) + circleD(tx + 10, sill - 13.4, 1.2), '#F0183A', { seed: 'tger' })); }
  // (no stray cat tail: with no cat in view it read as a crack)
  return sc('empty-game-ended-thanks', it, defs, 'Game ended / thanks: three of the gang wave goodbye from the hub window');
}

// ---------------------------------------------------------- champion ----
// «البطل», Ruq'ah centrelines, alef height 10, redrawn letter by letter against a Ruq'ah model (see _ar-review plate):
// ا stands alone (never joins left) · ل initial: stem down into the baseline · ب medial: a real tooth with its dot
// clearly below · ط medial: a closed oval bowl with the stem landing on its top · ل final: stem + bowl below the line.
// Every join overlaps the next letter's stroke (no gaps on the baseline). [native letterer review before shipping]
const AR_CHAMP = [
  'M25.4 -10.0 C25.3 -6.6 25.2 -3.3 25.1 0.1',
  'M21.8 -10.2 C21.7 -6.6 21.6 -3.2 21.5 -0.8 C21.4 0.1 20.8 0.15 19.6 0.15 L16.4 0.15',
  'M19.6 0.15 C19.0 0.0 18.7 -1.0 18.8 -2.9',
  'M18.4 2.5 L19.3 2.3',
  'M17.0 0.15 C16.8 -3.0 14.6 -4.6 12.6 -3.9 C10.9 -3.3 10.8 -0.6 12.6 0.0 C13.6 0.3 15.0 0.2 16.2 0.15',
  'M14.2 -10.0 C14.1 -7.2 14.0 -5.4 13.9 -4.3',
  'M11.8 0.1 C10.6 0.15 9.4 0.15 7.9 0.1',
  'M8.1 -10.2 C8.0 -6.6 7.9 -2.6 8.0 0.0 C8.1 2.8 6.5 4.2 4.5 4.2 C2.5 4.2 1.7 2.8 2.0 1.0',
];
function champion() {
  const defs: string[] = [], it: Item[] = [];
  const gy = 108;
  // light with a source: a little floor spotlight (a theatre can on a stand) at the start edge, aimed at the winner
  it.push(cone([[11, 87.6], [15.2, 94.6], [104, 76], [84, 40]], '#FFE2A6', defs, 0.32, [0, 1, 1, 0]));
  // the yafta: a cloth banner hung on two strings, sagging, fringed ends
  const bx0 = 12, bx1 = 148, by = 10, bh = 24;
  it.push(calmStroke(`M${bx0 + 4} ${by} L${bx0 - 4} ${by - 12} M${bx1 - 4} ${by} L${bx1 + 4} ${by - 12}`, W.ink, { w: 0.6, seed: 'ystr' }));
  const cloth = `M${bx0} ${by} C${bx0 + 40} ${by + 5} ${bx1 - 40} ${by + 5} ${bx1} ${by} L${bx1 - 1} ${by + bh} C${bx1 - 40} ${by + bh + 5} ${bx0 + 40} ${by + bh + 5} ${bx0 + 1} ${by + bh} Z`;
  it.push(calmThing(cloth, { fill: '#C8553D', ink: W.ink, w: 1.0, amp: 0.3, mis: W.mis, seed: 'yafta', hatch: true, hatchColor: W.ink, hatchOp: 0.18 }));
  let fringe = '';
  for (const fx of [bx0 + 0.5, bx1 - 0.5]) for (let i = 0; i < 6; i++) { const yy = by + 2 + i * 4; fringe += `M${fx} ${yy} l${fx < 80 ? -2.6 : 2.6} ${0.6} `; }
  it.push(stroke(fringe, '#E8A33A', { w: 0.7, seed: 'yfr' }));
  // lettering: one bilingual composition, centred on the cloth: CHAMPION · tile lozenge · «البطل»,
  // equal cap/alef height, one baseline, one shade
  const capS = 9.0, k = 0.98, base = by + 17.6;
  const L0 = placeLatin('CHAMPION', capS, 0, 0, { seed: 'champ', track: 0.6, rot: 2 }, 'left');
  const arBB = bboxOf(AR_CHAMP.join('')), arW = arBB.w * k, gap = 15;
  const total = L0.w + gap + arW, lx = 80 - total / 2;
  const L = placeLatin('CHAMPION', capS, lx, base, { seed: 'champ', track: 0.6, rot: 2 }, 'left');
  it.push(signPaint(L.strokes, capS / 10, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, false, 'champ'));
  it.push(...tileLozenge(lx + L0.w + gap / 2, base - 4.6, 4.4, 'yorn'));
  const arL = lx + L0.w + gap;
  const ar = AR_CHAMP.map((d) => mapPath(d, (x, y) => [arL + (x - arBB.x0) * k, base + y * k]));
  it.push(signPaint(ar, k, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, true, 'albatal'));
  // the podium: a painted wooden crate with the number 1 in a tile
  it.push(ground(80, gy + 1, 30));
  it.push(calmThing(P([[56, gy - 24], [104, gy - 24.6], [105, gy], [55, gy]]), { fill: T.wood, ink: W.ink, w: 1.1, amp: 0.3, mis: W.mis, seed: 'pod', hatch: true, hatchColor: W.ink, hatchOp: 0.22 }));
  it.push(calmThing(rr(73, gy - 19, 14, 14, 1.5), { fill: '#2F5DA8', ink: W.ink, w: 0.7, amp: 0.15, seed: 'podt' }));
  it.push(calmStroke('M78.4 ' + (gy - 15.4) + ' L80.6 ' + (gy - 16.6) + ' L80.4 ' + (gy - 7.2), W.paper, { w: 1.5, seed: 'one' }));
  // the winner: lemon star, cheer, top of a hop (squash stretched), confetti cut from its own colour
  it.push(character('star', { x: 80, y: gy - 27, s: 2.5, expr: 'cheer', world: W, squash: 1.08, groundShadow: false, seed: 'winner' }));
  // the brass cup beside the podium (dented, one handle a bit lower)
  const cx = 124, cy = gy;
  it.push(ground(cx, cy + 1, 10));
  it.push(calmThing(`M${cx - 8} ${cy - 30} C${cx - 8} ${cy - 18} ${cx - 4} ${cy - 15} ${cx - 1.6} ${cy - 14} L${cx - 1.4} ${cy - 7} L${cx - 6} ${cy - 4.5} L${cx - 6.4} ${cy} L${cx + 6.6} ${cy} L${cx + 6.2} ${cy - 4.5} L${cx + 1.6} ${cy - 7} L${cx + 1.8} ${cy - 14} C${cx + 4.4} ${cy - 15} ${cx + 8.4} ${cy - 18} ${cx + 8.2} ${cy - 30.4} Z`, { fill: T.brass, ink: '#3A1E08', w: 0.9, amp: 0.15, mis: W.mis, seed: 'cup' }));
  it.push(calmStroke(`M${cx - 8} ${cy - 27} C${cx - 14} ${cy - 27} ${cx - 13} ${cy - 18} ${cx - 5} ${cy - 18.5} M${cx + 8.2} ${cy - 26} C${cx + 14} ${cy - 26} ${cx + 13.4} ${cy - 16.4} ${cx + 5} ${cy - 17.4}`, '#3A1E08', { w: 1.3, seed: 'cuph' }));
  it.push(stroke(`M${cx - 5.2} ${cy - 27} C${cx - 5.4} ${cy - 23} ${cx - 4.4} ${cy - 20} ${cx - 3} ${cy - 18.6}`, '#FFF4D6', { w: 0.8, op: 0.85, seed: 'cuphl' }));
  it.push(stroke(`M${cx + 3} ${cy - 25} l1.6 1.2 l-.6 1.6`, '#A86F2A', { w: 0.6, seed: 'dent' }));
  // left: a second-place shilleh clapping (coral, happy), smaller
  it.push(character('circle', { x: 35, y: gy, s: 1.5, expr: 'happy', world: W, lean: 5, seed: 'second' }));
  // confetti in the winner's lemon + the room's colours
  const r = rng(hashSeed('chconf'));
  for (let i = 0; i < 24; i++) {
    const ids = ['star', 'star', 'circle', 'square', 'triangle', 'crescent'];
    const x = 10 + r() * 140, y = 38 + r() * 40, sz = 3 + r() * 3, rot = r() * 360, fl = r() < 0.3 ? 0.4 : 1;
    if (x > 56 && x < 104 && y > 40) continue; // keep the winner's face clear
    it.push(...confettiPiece(ids[i % ids.length], x, y, sz, rot, 'cc' + i, fl));
  }
  it.push(...sparkleTwinkle(60, 50, 3.5, 'cs1'), ...sparkleTwinkle(104, 46, 2.6, 'cs2', '#FFF1DC'));
  // the spotlight itself: a theatre can in a U-yoke on a short stand, barn doors open, tilted up at the winner
  it.push(stroke(`M9 99 L5 ${gy} M9 99 L13.4 ${gy} M9 99 L9.2 ${gy}`, W.ink, { w: 0.7, seed: 'spleg' }));
  it.push(thing(rr(8.2, 95.6, 1.6, 4.2, 0.5), { fill: '#3A2558', ink: W.ink, w: 0.5, amp: 0.05, seed: 'sppost' }));
  it.push(g('transform="rotate(-27 9 93)"',
    thing('M3.6 90.6 C3.4 89 4.6 88.6 6 88.6 L12.6 89 L12.8 97 L6 97.4 C4.6 97.4 3.4 97 3.6 95.4 Z', { fill: '#2A1D40', ink: W.ink, w: 0.7, amp: 0.1, seed: 'spcan', hatch: true, hatchColor: '#000', hatchOp: 0.3 }),
    thing('M12.4 88.6 L16 86.4 L16.2 87.6 L12.8 89.8 Z', { fill: '#3A2558', ink: W.ink, w: 0.45, amp: 0.04, seed: 'spbd1' }),
    thing('M12.6 97.2 L16.2 99.6 L16.0 100.6 L12.4 98.4 Z', { fill: '#3A2558', ink: W.ink, w: 0.45, amp: 0.04, seed: 'spbd2' }),
    thing(ellipseD(12.9, 93, 1.3, 3.8), { fill: '#FFF4D6', ink: W.ink, w: 0.5, amp: 0.05, seed: 'splens' }),
    stroke('M5 92 L10.6 92.2 M5 94.4 L10.6 94.6', '#4A3866', { w: 0.4, seed: 'spvent' }),
    calmStroke('M8.4 97.4 C8.2 100 9.6 100.4 9.8 98.6 M8.4 88.6 C8.2 86.4 9.6 86 9.8 87.8', '#4A3866', { w: 0.8, seed: 'spyoke' }),
  ));
  return sc('celebration-champion', it, defs, 'Champion / البطل: yafta banner, podium, the brass cup, own-colour confetti');
}

// ------------------------------------------------------ confetti pop ----
function correct() {
  const defs: string[] = [], it: Item[] = [];
  // the grape diamond, mid-yank: one nub holds a paper popper up and out, the other has just pulled its string.
  // The burst is cut from the players' own shapes (as confetti-set), plus three twisting streamers.
  const gy = 108, cx = 38, s = 2.0;
  it.push(ground(cx, gy + 1, 16));
  // pull nub (start side): stretched back, the string's ring in its fist; hold nub (end side): up, gripping the cone
  const pull = { x: cx - 30, y: gy - 17 };
  it.push(limb({ x: cx - 7, y: gy - 20 }, pull, 4.0, 3.4, -1.5, PLAYER.grape, 'pnubL'));
  const hold = { x: cx + 21, y: gy - 41 };
  it.push(limb({ x: cx + 7, y: gy - 21 }, hold, 4.0, 3.4, 2, PLAYER.grape, 'pnubR'));
  it.push(character('diamond', { x: cx, y: gy, s, expr: 'cheer', world: W, squash: 0.94, lean: -6, seed: 'popper' }));
  // the popper: a striped paper cone, narrow end in the hand, mouth up and to the end side
  const tip = { x: hold.x - 1, y: hold.y + 1 }, m1 = { x: hold.x + 8, y: hold.y - 20 }, m2 = { x: hold.x + 19, y: hold.y - 9 };
  const cone_ = `M${tip.x} ${tip.y} L${m1.x} ${m1.y} C${m1.x + 4} ${m1.y - 0.4} ${m2.x + 0.6} ${m2.y - 4} ${m2.x} ${m2.y} Z`;
  it.push(calmThing(cone_, { fill: '#E8A33A', ink: W.ink, w: 0.9, amp: 0.12, mis: W.mis, seed: 'pcone' }));
  const cid = uid('pc');
  it.push(`<clipPath id="${cid}"><path d="${cone_}"/></clipPath>`, g(`clip-path="url(#${cid})"`, stroke(`M${tip.x - 2} ${tip.y - 10} L${tip.x + 14} ${tip.y + 2} M${tip.x + 2} ${tip.y - 17} L${tip.x + 20} ${tip.y - 4} M${tip.x + 6} ${tip.y - 24} L${tip.x + 26} ${tip.y - 10}`, '#C8553D', { w: 2.0, seed: 'pstr' })));
  it.push(thumb(hold.x - 2, hold.y - 0.4, 3.4, -30, PLAYER.grape, 'pthumb'));
  // the string: from the cone's tip, taut, past the body to the ring in the pull fist
  it.push(calmStroke(`M${tip.x - 1} ${tip.y + 1.2} C${tip.x - 14} ${tip.y + 12} ${pull.x + 18} ${pull.y + 2} ${pull.x + 0.6} ${pull.y + 0.2}`, '#FFF1DC', { w: 0.55, seed: 'pstring' }));
  it.push(thing(circleD(pull.x - 3.4, pull.y + 0.6, 1.8), { ink: '#E8A33A', w: 0.7, amp: 0.05, seed: 'pring' }), thumb(pull.x - 1.2, pull.y - 1.6, 3.2, 200, PLAYER.grape, 'pthumbL'));
  // the burst out of the mouth: player-shape confetti (cut paper), denser near the mouth, falling wider further out
  const mx = (m1.x + m2.x) / 2, my = (m1.y + m2.y) / 2;
  const r = rng(hashSeed('pop'));
  for (let i = 0; i < 40; i++) {
    const a = -Math.PI * (0.08 + r() * 0.42), d = 6 + Math.pow(r(), 0.8) * 95;
    const x = mx + Math.cos(a) * d * 1.05, y = my + Math.sin(a) * d * 0.75 + (d > 60 ? (d - 60) * 0.25 : 0);
    if (x > 156 || y < 4) continue;
    it.push(...confettiPiece(SHAPE_IDS[i % SHAPE_IDS.length], x, y, 3.4 + r() * 4.2, r() * 360, 'pp' + i, r() < 0.3 ? 0.35 : 1));
  }
  it.push(ribbon(`M${mx} ${my} C${mx + 10} ${my - 26} ${mx + 30} ${my - 18} ${mx + 34} ${my - 42} C${mx + 37} ${my - 56} ${mx + 50} ${my - 52} ${mx + 54} ${my - 62}`, 2.4, 3.5, PLAYER.coral, 'str1'));
  it.push(ribbon(`M${mx + 2} ${my + 1} C${mx + 26} ${my - 12} ${mx + 44} ${my - 2} ${mx + 60} ${my - 20} C${mx + 70} ${my - 32} ${mx + 82} ${my - 24} ${mx + 92} ${my - 34}`, 2.2, 4.2, PLAYER.azure, 'str2'));
  it.push(ribbon(`M${mx - 1} ${my - 1} C${mx - 2} ${my - 20} ${mx + 8} ${my - 32} ${mx + 4} ${my - 50}`, 1.9, 2.2, PLAYER.lemon, 'str3'));
  // the cone kicks back: two recoil ticks behind the hand
  it.push(calmStroke(`M${hold.x - 6} ${hold.y - 5} l-3 -2 M${hold.x - 7} ${hold.y - 1} l-3.4 -0.4`, TEXT, { w: 0.75, seed: 'precoil' }));
  return writePiece(DIR, { name: 'celebration-confetti-pop', vbW: 160, vbH: 120, pxW: 640, pxH: 480, items: it, defs, bg: '#3A2266', label: 'Correct / round won: the grape diamond yanks a paper popper; the burst is cut from player shapes (12 fps)', fps: 12 });
}
/** A cut-paper streamer along a centreline: half-width w, `turns` twists, V-notched ends, inked thick-thin. */
function ribbon(d: string, w: number, turns: number, fill: string, seed: string) {
  const pts = samplePath(d, 0.5)[0];
  const n = pts.length, L: { x: number; y: number }[] = [], R: typeof L = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
    let tx = b.x - a.x, ty = b.y - a.y; const l = Math.hypot(tx, ty) || 1; tx /= l; ty /= l;
    const t = i / (n - 1);
    const ww = w * (0.18 + 0.82 * Math.abs(Math.cos(t * Math.PI * turns + 0.6)));
    // when the paper turns, the edge leans: offset the centre a touch toward one side
    const lean = w * 0.25 * Math.sin(t * Math.PI * turns + 0.6);
    const cx = pts[i].x - ty * lean, cy = pts[i].y + tx * lean;
    L.push({ x: cx - ty * ww, y: cy + tx * ww }); R.push({ x: cx + ty * ww, y: cy - tx * ww });
  }
  const notch = (i: number, j: number) => { const p = pts[i], q = pts[j]; return [p.x + (q.x - p.x) * 1.0, p.y + (q.y - p.y) * 1.0]; };
  const tail = notch(n - 1, n - 4), head = notch(0, 3);
  const poly = [...L.map((p) => [p.x, p.y]), tail, ...R.reverse().map((p) => [p.x, p.y]), head];
  return thing(P(poly), { fill, ink: W.ink, w: 0.7, amp: 0.15, mis: W.mis, seed, pressure: 0.55, overshoot: 0.6 });
}
const SHAPE_IDS = ['circle', 'square', 'star', 'triangle', 'diamond', 'hexagon', 'plus', 'drop', 'crescent', 'bolt', 'flower', 'arch'];

/** Review plate for the native letterer: «البطل» as painted on the yafta, big, beside a Ruq'ah font reference. */
function albatalReview() {
  const bb = bboxOf(AR_CHAMP.join('')), k = 1;
  const ar = AR_CHAMP.map((d) => mapPath(d, (x, y) => [x - bb.x0 + 2, y + 13]));
  const f3 = signPaint(ar, k, { fill: W.paper, shade: W.ink, shadeOff: [0.7, 0.9] }, true, 'albatal');
  const svg = `<svg viewBox="0 0 ${r2(bb.w + 4)} 20" width="${r2((bb.w + 4) * 22)}" height="440" style="background:#C8553D">${f3[0]}</svg>`;
  const dir = path.join(OUT, DIR);
  const ruq = path.join(OUT, '../tmp/ref/ruqaa.woff2');
  fs.writeFileSync(path.join(dir, '.ar-review.html'), `<html><head><style>@font-face{font-family:R;src:url(file://${ruq})}</style></head><body style="margin:0;background:#FFF1DC;padding:24px;width:1200px;font:600 14px system-ui;color:#160B26"><h1 style="font:800 18px system-ui;margin:0 0 10px">«البطل» on the champion yafta: native-letterer review plate (§7.3). Check: ا stands alone · ل→ب→ط→ل joins on the line · ب dot below · ط bowl closed, stem on it</h1><div style="display:flex;gap:30px;align-items:center">${svg}<div style="font:150px R;direction:rtl">البطل</div></div></body></html>`);
  shotJob({ src: path.join(dir, '.ar-review.html'), out: path.join(dir, '_ar-review@1x.png'), w: 1250, h: 0, scale: 1 } as any);
}
export function buildScenes() {
  albatalReview();
  waiting(); wrongDoor(); reconnecting(); noPacks(); thanks(); champion(); correct();
}
