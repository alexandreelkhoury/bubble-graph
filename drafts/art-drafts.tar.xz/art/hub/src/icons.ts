// icons.ts — 12 icons for settings / rules / sound / players in the house hand.
// 24 × 24 grid, ~2 px ink, single colour (currentColor). Same glyph meanings as DESIGN §5.1.
// The hand is turned down for controls: pressure ±15 %, slow bows only, closed shapes overshoot their start
// like a pen loop. They still read as buttons at 24–32 dp, but sit next to the illustrations without clashing.
import { type F3, type Item, writePiece, calmThing, calmStroke, circleD, ellipseD, P, r2 } from './kit.ts';
void (0 as unknown as F3);

const C = 'currentColor';
// line thinned ~10 % (2 → 1.8) so counters stay open at 24 px. Each icon carries one small authored quirk
// (a tick, an overshoot, a tapered end) so the set reads drawn, not filtered.
const LW = 1.8;
const line = (d: string, seed: string, w = LW) => calmStroke(d, C, { w, amp: 0.1, seed, wave: [10, 30] }, 2);
const loop = (d: string, seed: string, w = LW) => calmThing(d, { ink: C, w, amp: 0.12, seed, pressure: 0.18, overshoot: 1.8, wave: [10, 30] }, 1);
/** thick-thin: a closed shape inked with strong pressure (a brush, not a marker) */
const brushLoop = (d: string, seed: string, w = LW) => calmThing(d, { ink: C, w, amp: 0.1, seed, pressure: 0.4, overshoot: 1.2, wave: [10, 30] }, 1);
const dot = (x: number, y: number, r: number, seed: string) => calmThing(circleD(x, y, r), { fill: C, seed, amp: 0.04, w: 0.01, noInk: true }, 1);
/** a tapered flick: lands thin, swells, lifts — drawn as a filled sliver */
const flick = (x0: number, y0: number, x1: number, y1: number, wd: number, seed: string) => {
  const mx = (x0 + x1) / 2, my = (y0 + y1) / 2, l = Math.hypot(x1 - x0, y1 - y0), nx = (-(y1 - y0) / l) * wd, ny = ((x1 - x0) / l) * wd;
  return calmThing(`M${x0} ${y0} Q${r2(mx + nx)} ${r2(my + ny)} ${x1} ${y1} Q${r2(mx - nx * 0.4)} ${r2(my - ny * 0.4)} ${x0} ${y0}Z`, { fill: C, seed, amp: 0.03, w: 0.01, noInk: true }, 1);
};
// isolated «ع» for the language icon, in a 24 grid (open cup over a tail)
const AIN = 'M19.2 7.6 C18.4 6.8 16.9 6.9 16.6 8.0 C16.3 9.0 17.1 9.7 18.2 9.5 C18.7 9.4 19.1 9.2 19.4 9.0 M19.1 9.2 C17.4 9.9 16.2 11.0 16.2 12.4 C16.2 13.8 17.6 14.4 19.6 14.0';

function gear(): Item[] {
  const pts: number[][] = [];
  const n = 6, R = 9.4, r = 7.0;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2 + 0.05;
    const t = 0.2;
    for (const [da, rad] of [[-0.42, r], [-t, R], [t, R], [0.42, r]] as const) pts.push([12 + Math.cos(a + da) * rad, 12 + Math.sin(a + da) * rad]);
  }
  // quirk: the hub hole is a pen loop that overshoots and leaves a little tail
  return [loop(P(pts), 'gear'), loop(circleD(12, 12, 3.1), 'gearc', 1.6), line('M14.6 10.4 L15.6 9.6', 'gtail', 1.1)];
}
const icons: Record<string, () => Item[]> = {
  settings: gear,
  rules: () => [
    loop('M12 6.4 C9.6 5 6.6 4.7 3.4 5.4 L3.4 18.6 C6.6 17.9 9.6 18.2 12 19.6 C14.4 18.2 17.4 17.9 20.6 18.6 L20.6 5.4 C17.4 4.7 14.4 5 12 6.4 Z', 'book'),
    line('M12 6.6 L12 19.2', 'spine', 1.6),
    line('M6 9.2 L9.4 9.8 M6 12.4 L9.2 12.9', 'lines', 1.4),
    // quirk: a ribbon bookmark hanging out of the bottom, V-cut
    calmThing('M16.4 18.2 L18.2 18.0 L18.2 22.2 L17.3 21.3 L16.4 22.3 Z', { fill: C, seed: 'bkm', amp: 0.03, w: 0.01, noInk: true }, 1),
  ],
  'sound-on': () => [
    loop('M3.6 9.4 L7.2 9.4 L11.6 5.4 L11.6 18.6 L7.2 14.6 L3.6 14.6 Z', 'spk'),
    line('M15 9.2 C16.2 10.6 16.2 13.4 15 14.8', 'w1'),
    // quirk: the outer wave is two pulls, the pen lifted once
    line('M17.8 6.6 C19.3 8.2 20 10 20.1 11.3', 'w2'), line('M20.1 13.1 C19.9 14.6 19.2 16.1 17.8 17.4', 'w3'),
  ],
  'sound-off': () => [
    loop('M3.6 9.4 L7.2 9.4 L11.6 5.4 L11.6 18.6 L7.2 14.6 L3.6 14.6 Z', 'spk'),
    // quirk: the cross is two tapered flicks, the second overshoots
    flick(15.0, 9.2, 20.4, 14.6, 2.62, 'x1'), flick(20.6, 9.0, 14.8, 15.0, 2.62, 'x2'),
  ],
  music: () => [
    loop(ellipseD(6.6, 17.4, 2.6, 2.1), 'n1', 1.7), loop(ellipseD(16.8, 15.6, 2.6, 2.1), 'n2', 1.7),
    line('M9.2 17.2 L9.2 6.2 L19.4 4.2 L19.4 15.4', 'stem'),
    line('M9.2 9.6 L19.4 7.6', 'beam', 1.6),
    // quirk: a tiny 'tick' beside the note: it's playing
    flick(21.2, 2.4, 22.4, 1.2, 1.05, 'mtick'),
  ],
  players: () => [
    // two complete people, the back one partly hidden: its head and shoulders are whole outlines, cut by the front one
    loop(circleD(15.8, 7.4, 2.8), 'h2', 1.6),
    line('M11.6 13.6 C12.6 12.4 14 11.8 15.8 11.8 C18.8 11.8 20.8 13.8 21.2 17.4', 'b2', 1.6),
    loop(circleD(8.6, 9.0, 3.2), 'h1'), line('M2.6 20.2 C3 16.2 5.4 14.2 8.6 14.2 C11.8 14.2 14.2 16.2 14.6 20.2', 'b1'),
    // quirk: a small overshoot tick where the front shoulder line lands
    line('M14.6 20.2 L15.3 20.8', 'pq', 1.1),
  ],
  'player-add': () => [
    loop(circleD(9.4, 8.4, 3.3), 'h'), line('M3 19.6 C3.4 15.6 6 13.6 9.4 13.6 C12.8 13.6 15.4 15.6 15.8 19.6', 'b'),
    // quirk: the plus is written fast, its bar overshoots to the right
    line('M18.6 8.0 L18.7 14.6', 'p1'), flick(15.4, 11.6, 22.6, 11.0, 2.52, 'p2'),
  ],
  'player-kick': () => [
    loop(circleD(9.4, 8.4, 3.3), 'h'), line('M3 19.6 C3.4 15.6 6 13.6 9.4 13.6 C12.8 13.6 15.4 15.6 15.8 19.6', 'b'),
    flick(16.2, 8.6, 21.2, 13.6, 2.52, 'k1'), flick(21.4, 8.4, 16.2, 13.8, 2.52, 'k2'),
  ],
  host: () => [
    // the host crown with brush contrast: fat at the base, thin up to the points; the jewel is the amber head
    brushLoop('M3.8 17.6 L3 7.4 L8.2 11.8 L12 4.6 L15.8 11.6 L21 7.2 L20.2 17.6 Z', 'crown', 1.9),
    flick(4.0, 20.4, 20.2, 19.8, 2.42, 'band'),
    dot(12, 14.0, 1.3, 'gem'),
    // quirk: a little glint tick off the tallest point
    line('M13.6 3.0 L14.6 2.0', 'glint', 1.0),
  ],
  language: () => [
    loop('M4.6 4.4 L12.8 4.6 C14 4.6 14.8 5.4 14.8 6.6 L14.8 10.6 C14.8 11.8 14 12.6 12.8 12.6 L8.6 12.6 L5.4 15.4 L5.8 12.6 L4.6 12.6 C3.6 12.6 2.8 11.8 2.8 10.8 L2.8 6.4 C2.8 5.2 3.6 4.4 4.6 4.4 Z', 'b1', 1.7),
    loop('M21.6 7.4 C21.6 6.4 20.8 5.6 19.8 5.6 L16.8 5.6 M21.6 7.4 L21.6 15.8 C21.6 16.8 20.8 17.6 19.8 17.6 L19.0 17.6 L19.4 20.2 L16.2 17.6 L14.6 17.6 C13.6 17.6 12.8 16.8 12.8 15.8 L12.8 14.4', 'b2', 1.6),
    line('M6.0 10.8 L8.2 6.4 L10.4 10.8 M6.8 9.4 L9.6 9.4', 'A', 1.4),
    line(AIN, 'ain', 1.5),
  ],
  timer: () => [
    loop(circleD(12, 13.6, 7.4), 'face'),
    line('M12 13.6 L12 9.6', 'hand1', 1.7), flick(12, 13.6, 15.0, 15.4, 1.47, 'hand2'),
    line('M9.6 3.4 L14.4 3.4', 'top', 1.7), line('M12 3.6 L12 6.2', 'stem', 1.7), line('M18.2 6.6 L19.6 5.2', 'btn', 1.6),
    // quirk: a motion tick by the button: it's running
    line('M21.0 7.2 L22.0 7.6', 'run', 1.0),
  ],
  info: () => [loop(circleD(12, 12, 9), 'ring'), flick(11.6, 10.8, 12.3, 17.2, 2.42, 'i'), dot(12, 7.8, 1.3, 'idot')],
};

export function buildIcons() {
  for (const [name, fn] of Object.entries(icons)) {
    const items = fn();
    writePiece('icons', { name: 'icon-' + name, vbW: 24, vbH: 24, pxW: 96, pxH: 96, items: [`<g color="#FFF7EC">`, ...items, `</g>`], defs: [], bg: '#3A2266' });
  }
  // a strip at real UI sizes (24 / 32 / 48 px) on the hub surface, and a TV-distance check
  // handled by the sheet; ink variant: same files with color set by the host (currentColor).
}
