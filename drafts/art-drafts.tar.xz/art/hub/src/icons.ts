// icons.ts — 12 UI icons for the hub (settings / rules / sound / music / players / host / language / timer / info).
// ART-DIRECTION §9.5 + DESIGN §5.1: UI icons are CONTROLS, so they stay uniform: 24 × 24 grid, 2 px padding,
// one 2 px stroke everywhere, round caps and joins, currentColor. No wobble, no pressure, no boil.
// The only nod to the illustration hand is in the corners and caps: every corner is round-joined, ends are
// round-capped, and a few long straights carry a ≤ 0.3 px bow so they don't read ruler-cut at 96 px.
// The hand-inked versions (wobbly line, flicks) live in the illustration set only (scenes / ornaments).
import { type Item, writePiece, shotJob, OUT } from './kit.ts';
import fs from 'node:fs';
import path from 'node:path';

const S = (d: string) => `<path d="${d}"/>`;
const dot = (x: number, y: number, r = 1.15) => `<circle cx="${x}" cy="${y}" r="${r}" fill="currentColor" stroke="none"/>`;

// head + shoulders used by the three people icons (same construction so they read as one family)
const HEAD = (cx: number, cy: number, r = 3.4) => `<circle cx="${cx}" cy="${cy}" r="${r}"/>`;
const BODY = (cx: number, y: number, hw = 6.2) => S(`M${cx - hw} ${y} c0-3.6 2.7-6 ${hw} -6 s${hw} 2.4 ${hw} 6`);

function gearD() {
  // 6 teeth with rounded flats; built from polar points, joined round by the stroke
  const n = 6, R = 9.2, r = 6.9, out: string[] = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2;
    for (const [da, rad] of [[-0.36, r], [-0.2, R], [0.2, R], [0.36, r]] as const) {
      const x = 12 + Math.cos(a + da) * rad, y = 12 + Math.sin(a + da) * rad;
      out.push(`${x.toFixed(2)} ${y.toFixed(2)}`);
    }
  }
  return 'M' + out.join('L') + 'Z';
}

export const ICONS: Record<string, string[]> = {
  settings: [S(gearD()), `<circle cx="12" cy="12" r="3"/>`],
  rules: [
    // open book, spine at the centre, two text lines on the start page
    S('M12 6.2 C9.8 4.9 7 4.6 3 5.2 V18.4 C7 17.8 9.8 18.1 12 19.4 C14.2 18.1 17 17.8 21 18.4 V5.2 C17 4.6 14.2 4.9 12 6.2 Z'),
    S('M12 6.2 V19.4'),
    S('M6 9.4 H9 M6 12.6 H9'),
  ],
  'sound-on': [
    S('M3.5 9.5 H7 L11.5 5.5 V18.5 L7 14.5 H3.5 Z'),
    S('M15 9.4 a3.8 3.8 0 0 1 0 5.2'),
    S('M17.8 6.6 a7.6 7.6 0 0 1 0 10.8'),
  ],
  'sound-off': [
    S('M3.5 9.5 H7 L11.5 5.5 V18.5 L7 14.5 H3.5 Z'),
    S('M15.5 9.5 L20.5 14.5 M20.5 9.5 L15.5 14.5'),
  ],
  music: [
    S('M9 17.5 V6.4 L20 4.2 V15.5'),
    S('M9 9.8 L20 7.6'),
    `<circle cx="6.4" cy="17.5" r="2.6"/>`, `<circle cx="17.4" cy="15.5" r="2.6"/>`,
  ],
  players: [
    // the back person is cut by the front one (its outline stops where the front shoulder starts)
    `<circle cx="16.4" cy="7.4" r="3"/>`,
    S('M14.6 13.1 C15 13 15.5 13 16 13 C19 13 21 15 21 18'),
    HEAD(9, 8.6), BODY(9, 20.2, 6),
  ],
  'player-add': [HEAD(9.5, 8.4), BODY(9.5, 20, 6.3), S('M18.5 8.2 V14.8 M15.2 11.5 H21.8')],
  // kick = head + a diagonal × that is clearly a cross (not a sparkle): longer arms than add's plus, 45° exact
  'player-kick': [HEAD(9.5, 8.4), BODY(9.5, 20, 6.3), S('M15.6 8.6 L21.4 14.4 M21.4 8.6 L15.6 14.4')],
  host: [
    // 3-point crown, flat band underneath, one gem dot
    S('M4 17.5 L3 7.5 L8.2 11.6 L12 5 L15.8 11.6 L21 7.5 L20 17.5 Z'),
    S('M4.2 20.5 H19.8'),
    dot(12, 14.2, 1.2),
  ],
  language: [
    // globe (DESIGN §5.1 'globe'): meridian ellipse, equator, two latitudes
    `<circle cx="12" cy="12" r="9"/>`,
    `<ellipse cx="12" cy="12" rx="4" ry="9"/>`,
    S('M3.6 8.8 H20.4 M3.6 15.2 H20.4'),
  ],
  timer: [
    `<circle cx="12" cy="13.5" r="7.5"/>`,
    S('M12 13.5 V9.4 M12 13.5 L14.6 15.2'),
    S('M9.5 3 H14.5 M12 3 V6'),
    S('M18 6.8 L19.6 5.2'),
  ],
  info: [`<circle cx="12" cy="12" r="9"/>`, S('M12 11 V16.6'), dot(12, 7.7, 1.3)],
};

const wrap = (body: string[]) => `<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${body.join('')}</g>`;

export function buildIcons() {
  const dir = path.join(OUT, 'icons');
  for (const [name, body] of Object.entries(ICONS)) {
    const items: Item[] = [`<g color="#FFF7EC">`, wrap(body), `</g>`];
    writePiece('icons', { name: 'icon-' + name, vbW: 24, vbH: 24, pxW: 96, pxH: 96, items, defs: [], bg: '#3A2266' });
    // the shipping file: plain currentColor, no colour wrapper, no animation (a control does not boil)
    fs.writeFileSync(path.join(dir, `icon-${name}.ui.svg`), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">${wrap(body)}</svg>`);
  }
  // real-size check: 24 / 32 / 48 px on the hub surface, plus a "TV at 3 m" row (32 dp shown at 1/3)
  const names = Object.keys(ICONS);
  const row = (px: number) => `<div style="display:flex;gap:${Math.max(10, px * 0.6)}px;align-items:center;margin:10px 0"><span style="width:60px;font:600 12px system-ui;color:#B8A8D6">${px}px</span>${names.map((n) => `<svg viewBox="0 0 24 24" width="${px}" height="${px}" style="color:#FFF7EC">${wrap(ICONS[n])}</svg>`).join('')}</div>`;
  const html = `<html><body style="margin:0;background:#3A2266;padding:20px;width:1200px">${[16, 24, 32, 48].map(row).join('')}</body></html>`;
  fs.writeFileSync(path.join(dir, '.sizes.html'), html);
  shotJob({ src: path.join(dir, '.sizes.html'), out: path.join(dir, '_sizes@1x.png'), w: 1240, h: 0, scale: 1 } as any);
}
