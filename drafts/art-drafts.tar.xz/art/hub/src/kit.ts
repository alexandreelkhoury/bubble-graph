// kit.ts — shared helpers for the JAMAA hub art set.
// Builds on the house drawing kit (lib.ts, the same hand as the characters and
// the game key art) and adds: the hub world, light helpers, and a writer that
// emits the 3 boil frames, an animated SVG and the PNG jobs for every piece.
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { type F3, type World, cat, uid, r2, rng, hashSeed } from './lib.ts';
export * from './lib.ts';

export const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
export const OUT = path.join(ROOT, 'out');

/** Hub = palette B, the living room at 11 p.m. (ART-DIRECTION §5.2). */
export const HUB: World = {
  id: 'hub', ink: '#160B26', paper: '#FFF1DC', a: '#C8553D', b: '#E8A33A', c: '#2F5DA8',
  deep: '#1D1036', top: '#2B1650', surface: '#3A2266', elevated: '#4A2E7A', accent: '#FFC94D', glow: '#FFC94D',
  mis: [-0.4, 0.4],
};
export const TEXT = '#FFF7EC', PRIMARY = '#FF4F9A', MUTED = '#B8A8D6';
// the 12 player colours (DESIGN §5.2)
export const PLAYER = {
  coral: '#F0183A', azure: '#478CFF', lemon: '#FFF04D', jade: '#1FA88A', grape: '#7A43FF', tangerine: '#FF7A1F',
  aqua: '#7BFFF4', rose: '#FF96C5', mint: '#BDF5C8', plum: '#C02A8F', sand: '#E6C486', lilac: '#C9BFFF',
};

export type Item = string | F3;
export const P = (pts: number[][]) => 'M' + pts.map((p) => `${r2(p[0])} ${r2(p[1])}`).join('L') + 'Z';
export const PL = (pts: number[][]) => 'M' + pts.map((p) => `${r2(p[0])} ${r2(p[1])}`).join('L');
export const rect = (x: number, y: number, w: number, h: number) => P([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]);
export const rr = (x: number, y: number, w: number, h: number, r: number) => `M${x + r} ${y}H${x + w - r}Q${x + w} ${y} ${x + w} ${y + r}V${y + h - r}Q${x + w} ${y + h} ${x + w - r} ${y + h}H${x + r}Q${x} ${y + h} ${x} ${y + h - r}V${y + r}Q${x} ${y} ${x + r} ${y}Z`;
export const wire = (x1: number, y1: number, x2: number, y2: number, sag: number) => `M${x1} ${y1} Q${(x1 + x2) / 2} ${Math.max(y1, y2) + sag} ${x2} ${y2}`;
/** flat-bottomed bab arch (never pointed): x,y = top-left of the bounding box */
export const archD = (x: number, y: number, w: number, h: number, lean = 0) => {
  const r = w / 2;
  return `M${x} ${y + h}L${x + lean * 0.3} ${y + r}C${x + lean * 0.3} ${y + r * 0.42} ${x + r * 0.45} ${y - 0.2} ${x + r + lean} ${y}C${x + w - r * 0.42} ${y + 0.2} ${x + w} ${y + r * 0.47} ${x + w} ${y + r * 1.02}L${x + w + 0.2} ${y + h}Z`;
};

/** A light cone: hand-cut polygon, soft only at the far end (ART-DIRECTION §5.3). */
export function cone(pts: number[][], color: string, defs: string[], op = 0.38, dir: [number, number, number, number] = [0, 0, 0, 1]): string {
  const id = uid('cn');
  defs.push(`<linearGradient id="${id}" x1="${dir[0]}" y1="${dir[1]}" x2="${dir[2]}" y2="${dir[3]}"><stop offset="0" stop-color="${color}" stop-opacity="${op}"/><stop offset="0.7" stop-color="${color}" stop-opacity="${op * 0.5}"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient>`);
  return `<path d="${P(pts)}" fill="url(#${id})" style="mix-blend-mode:screen"/>`;
}
/** Radial wash for a light source (light is the only soft thing). */
export function glow(x: number, y: number, rx: number, ry: number, color: string, defs: string[], op = 0.5): string {
  const id = uid('gw');
  defs.push(`<radialGradient id="${id}"><stop offset="0" stop-color="${color}" stop-opacity="${op}"/><stop offset="0.45" stop-color="${color}" stop-opacity="${op * 0.45}"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></radialGradient>`);
  return `<ellipse cx="${r2(x)}" cy="${r2(y)}" rx="${r2(rx)}" ry="${r2(ry)}" fill="url(#${id})" style="mix-blend-mode:screen"/>`;
}
export function linear(id: string, stops: [number, string, number?][], x2 = 0, y2 = 1) {
  return `<linearGradient id="${id}" x1="0" y1="0" x2="${x2}" y2="${y2}">${stops.map(([o, c, a]) => `<stop offset="${o}" stop-color="${c}"${a != null ? ` stop-opacity="${a}"` : ''}/>`).join('')}</linearGradient>`;
}
/** stipple: 6–15 dots clustered, 3 sizes (ART-DIRECTION §6.2) */
export function stipple(cx: number, cy: number, n: number, sx: number, sy: number, color: string, op: number, seed: string, k = 1) {
  const r = rng(hashSeed(seed));
  let s = '';
  for (let i = 0; i < n; i++) s += `<circle cx="${r2(cx + (r() - 0.5) * sx)}" cy="${r2(cy + (r() - 0.5) * sy)}" r="${r2([0.3, 0.45, 0.65][i % 3] * k)}" fill="${color}" opacity="${op}"/>`;
  return s;
}

const grainB64 = fs.readFileSync(path.join(ROOT, '../tech/handmade/out/grain-128.png')).toString('base64');

export type Piece = {
  name: string; vbW: number; vbH: number; pxW: number; pxH: number; items: Item[]; defs: string[];
  bg?: string; grain?: number; vbX?: number; vbY?: number; label?: string; noPng?: boolean; fps?: 8 | 12;
};
const jobs: any[] = [];
export const REG: Record<string, { name: string; pxW: number; pxH: number; bg: string; label?: string }[]> = {};
/** Writes name_A/B/C.svg, name.svg (animated 8 fps boil, one shared clock, seeded offsets) and PNG jobs (1x, 2x). */
export function writePiece(dir: string, p: Piece) {
  const out = path.join(OUT, dir);
  fs.mkdirSync(out, { recursive: true });
  const vb = `${p.vbX ?? 0} ${p.vbY ?? 0} ${p.vbW} ${p.vbH}`;
  const gdef = p.grain ? `<pattern id="grain" width="16" height="16" patternUnits="userSpaceOnUse"><image href="data:image/png;base64,${grainB64}" width="16" height="16"/></pattern>` : '';
  const grainLayer = p.grain ? `<rect x="${p.vbX ?? 0}" y="${p.vbY ?? 0}" width="${p.vbW}" height="${p.vbH}" fill="url(#grain)" opacity="${p.grain}" style="mix-blend-mode:soft-light"/>` : '';
  const head = (extra = '') => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" width="${p.pxW}" height="${p.pxH}">${extra}<defs>${p.defs.join('')}${gdef}</defs>`;
  for (let f = 0; f < 3; f++) {
    let s = head();
    p.items.forEach((it, i) => { s += typeof it === 'string' ? it : it[(f + i) % 3]; });
    fs.writeFileSync(path.join(out, `${p.name}_${'ABC'[f]}.svg`), s + grainLayer + '</svg>');
  }
  const cyc = 3 / (p.fps ?? 8); // 3 drawings per cycle: 8 fps idle, 12 fps while acting (§10)
  const css = `<style>.f{opacity:0;animation:boil ${+cyc.toFixed(4)}s steps(1,end) infinite}.f1{animation-delay:-${+(cyc * 2 / 3).toFixed(4)}s}.f2{animation-delay:-${+(cyc / 3).toFixed(4)}s}@keyframes boil{0%{opacity:1}33.333%{opacity:0}100%{opacity:0}}@media (prefers-reduced-motion:reduce){.f{animation:none}.f0{opacity:1}}</style>`;
  let a = head(css);
  p.items.forEach((it, i) => {
    if (typeof it === 'string') { a += it; return; }
    if (it[0] === it[1] && it[1] === it[2]) { a += it[0]; return; }
    for (let f = 0; f < 3; f++) a += `<g class="f f${(f + i) % 3}">${it[f]}</g>`;
  });
  fs.writeFileSync(path.join(out, `${p.name}.svg`), a + grainLayer + '</svg>');
  const bg = p.bg ?? 'transparent';
  (REG[dir] ??= []).push({ name: p.name, pxW: p.pxW, pxH: p.pxH, bg, label: (p as any).label });
  for (const f of ['A', 'B', 'C']) {
    const html = path.join(out, `.${p.name}_${f}.html`);
    fs.writeFileSync(html, `<html><body style="margin:0;background:${bg}"><img src="${p.name}_${f}.svg" style="width:${p.pxW}px;height:${p.pxH}px;display:block"></body></html>`);
    if (f === 'A' && !p.noPng) {
      jobs.push({ src: html, out: path.join(out, `${p.name}@1x.png`), w: p.pxW, h: p.pxH, scale: 1 });
      jobs.push({ src: html, out: path.join(out, `${p.name}@2x.png`), w: p.pxW, h: p.pxH, scale: 2 });
    }
  }
  return path.join(out, `${p.name}.svg`);
}
/** An extra screenshot job of an arbitrary html file. */
export function shotJob(j: { src: string; out: string; w: number; h: number; scale?: number }) { jobs.push(j); }
export function runShots() {
  if (!jobs.length) return;
  execFileSync('node', [path.join(ROOT, 'src/shot.mjs'), JSON.stringify(jobs)], { stdio: 'inherit' });
  jobs.length = 0;
}
export const items = (...xs: (Item | Item[])[]) => xs.flat() as Item[];
export { cat };

// ---- calm strokes for long lines --------------------------------------------
// The ribbon's pressure wobble has fixed wavelengths (3–9 units). On long props/frames that reads as
// "beading". Drawing at 1/k scale and scaling the result up by k stretches the pressure waves k times
// (slow brush pressure), without touching the shared generator.
import { thing as _thing, stroke as _stroke, type ThingOpts } from './lib.ts';
export function scalePath(d: string, f: number): string {
  return d.replace(/([MLCQSTAHVZmlcqstahvz])([^MLCQSTAHVZmlcqstahvz]*)/g, (_, c: string, args: string) => {
    const n = args.trim() ? args.trim().split(/[\s,]+|(?=-)/).filter(Boolean).map(Number) : [];
    if (c === 'A' || c === 'a') return c + n.map((v, i) => ([2, 3, 4].includes(i % 7) ? v : v * f)).map((v) => +v.toFixed(3)).join(' ');
    return c + n.map((v) => +(v * f).toFixed(3)).join(' ');
  });
}
export function calmThing(d: string, o: ThingOpts, k = 3): F3 {
  const f = 1 / k;
  const fs = _thing(scalePath(d, f), { ...o, w: (o.w ?? 0.6) * f, amp: (o.amp ?? 0.3) * f, wave: o.wave ? [o.wave[0] * f, o.wave[1] * f] : [5.5 * f * k, 16 * f * k], mis: o.mis ? [o.mis[0] * f, o.mis[1] * f] : undefined, rimW: o.rimW ? o.rimW * f : undefined, overshoot: (o.overshoot ?? 1.6) * f });
  return fs.map((s) => `<g transform="scale(${k})">${s}</g>`);
}
export function calmStroke(d: string, color: string, o: { w?: number; amp?: number; boil?: boolean; seed?: string; op?: number; wave?: [number, number] } = {}, k = 3): F3 {
  const f = 1 / k;
  const fs = _stroke(scalePath(d, f), color, { ...o, w: (o.w ?? 0.5) * f, amp: (o.amp ?? 0.12) * f, wave: o.wave ? [o.wave[0] * f, o.wave[1] * f] : [3, 12] });
  return fs.map((s) => `<g transform="scale(${k})">${s}</g>`);
}
