// quick contact sheet of PNGs: node sheetq.mjs out.png bg file1 file2 ...
import { createRequire } from 'node:module';
const require = createRequire('/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/art/tech/bench/package.json');
const sharp = require('sharp');
const [out, bg, ...files] = process.argv.slice(2);
const metas = await Promise.all(files.map((f) => sharp(f).metadata()));
const W = Math.max(...metas.map((m) => m.width)), H = metas.reduce((a, m) => a + m.height + 10, 0);
await sharp({ create: { width: W, height: H, channels: 4, background: bg } }).composite(files.map((f, i) => ({ input: f, left: 0, top: metas.slice(0, i).reduce((a, m) => a + m.height + 10, 0) }))).png().toFile(out);
