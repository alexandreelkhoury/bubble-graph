// sheet.ts — contact sheets per folder (frame A of every piece, labelled), rendered at 1x and 2x,
// plus a boil strip (A / B / C side by side) for each folder.
import fs from 'node:fs';
import path from 'node:path';
import { OUT, shotJob, runShots } from './kit.ts';

const TITLES: Record<string, string> = {
  wordmark: 'JAMAA wordmark, hand-lettered: sign / party (cut paper) / print (riso)',
  ornaments: 'UI ornaments: confetti, sparkles, bubbles, arrows, stars, frames, dividers',
  scenes: 'Empty states and celebrations',
  icons: '12 UI icons: uniform 2 px round stroke, 24 grid (controls look like controls, §9.5)',
};
export function buildSheets(dirs = ['wordmark', 'ornaments', 'scenes', 'icons']) {
  for (const dir of dirs) {
    const d = path.join(OUT, dir);
    if (!fs.existsSync(d)) continue;
    const names = fs.readdirSync(d).filter((f) => f.endsWith('_A.svg')).map((f) => f.replace('_A.svg', '')).sort();
    const size = (n: string) => { const s = fs.readFileSync(path.join(d, n + '_A.svg'), 'utf8').slice(0, 400); const w = +s.match(/width="(\d+)"/)![1], h = +s.match(/height="(\d+)"/)![1]; return { w, h }; };
    const maxW = dir === 'icons' ? 150 : dir === 'scenes' ? 560 : 420;
    const cells = names.map((n) => {
      const { w, h } = size(n); const k = Math.min(1, maxW / w, (dir === 'icons' ? 150 : 360) / h);
      const light = n.includes('print') || n.includes('-ink');
      return `<figure style="margin:0;display:flex;flex-direction:column;align-items:center;gap:8px;padding:14px;border-radius:14px;background:${light ? '#FFF1DC' : '#24123F'}"><img src="${n}_A.svg" style="width:${Math.round(w * k)}px;height:${Math.round(h * k)}px"><figcaption style="font:600 13px/1.2 system-ui,sans-serif;color:${light ? '#160B26' : '#B8A8D6'}">${n}</figcaption></figure>`;
    }).join('');
    const html = `<html><body style="margin:0;background:#1D1036;padding:28px;width:1240px"><h1 style="font:800 22px system-ui,sans-serif;color:#FFF7EC;margin:0 0 18px">${TITLES[dir] ?? dir}</h1><div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-start">${cells}</div></body></html>`;
    fs.writeFileSync(path.join(d, '.sheet.html'), html);
    // boil strip: up to 6 pieces, A/B/C
    const pick = names.slice(0, 6);
    const strip = `<html><body style="margin:0;background:#1D1036;padding:20px;width:1240px"><h1 style="font:800 18px system-ui,sans-serif;color:#FFF7EC;margin:0 0 12px">${dir}: boil frames A · B · C (cycled at 8 fps idle, 12 fps acting)</h1>${pick.map((n) => { const { w, h } = size(n); const k = Math.min(1, 380 / w, 200 / h); return `<div style="display:flex;gap:12px;margin-bottom:10px">${['A', 'B', 'C'].map((f) => `<img src="${n}_${f}.svg" style="width:${Math.round(w * k)}px;height:${Math.round(h * k)}px;background:#24123F;border-radius:10px">`).join('')}</div>`; }).join('')}</body></html>`;
    fs.writeFileSync(path.join(d, '.boil.html'), strip);
  }
  // measure heights with a first pass is overkill: use generous fixed heights and fullPage-like clip via big viewport
  for (const dir of dirs) {
    const d = path.join(OUT, dir);
    if (!fs.existsSync(path.join(d, '.sheet.html'))) continue;
    for (const s of [1, 2]) shotJob({ src: path.join(d, '.sheet.html'), out: path.join(d, `_sheet@${s}x.png`), w: 1296, h: 0, scale: s } as any);
    shotJob({ src: path.join(d, '.boil.html'), out: path.join(d, `_boil@1x.png`), w: 1280, h: 0, scale: 1 } as any);
  }
  runShots();
}
