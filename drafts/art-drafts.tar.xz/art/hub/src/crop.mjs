// node crop.mjs in.png out.png x y w h
import { createRequire } from 'node:module';
const require = createRequire('/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/art/tech/bench/package.json');
const sharp = require('sharp');
const [i, o, x, y, w, h] = process.argv.slice(2);
await sharp(i).extract({ left: +x, top: +y, width: +w, height: +h }).toFile(o);
