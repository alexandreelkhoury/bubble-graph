// node shot.mjs '<jobs json>' — each job {src, out, w, h, scale}; h = 0 → full page
import { createRequire } from 'node:module';
const require = createRequire('/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/art/tools/package.json');
const { chromium } = require('playwright-core');
import path from 'node:path';
const jobs = JSON.parse(process.argv[2]);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome' });
for (const j of jobs) {
  const page = await browser.newPage({ viewport: { width: j.w, height: j.h || 800 }, deviceScaleFactor: j.scale || 1 });
  await page.goto('file://' + path.resolve(j.src));
  await page.waitForTimeout(j.wait || 120);
  if (j.h) await page.screenshot({ path: j.out, clip: { x: 0, y: 0, width: j.w, height: j.h }, omitBackground: true });
  else await page.screenshot({ path: j.out, fullPage: true });
  await page.close();
}
await browser.close();
console.log('shots', jobs.length);
