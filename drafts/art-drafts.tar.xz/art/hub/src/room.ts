// room.ts — pieces of the JAMAA hub room: a Beirut living room at 11 p.m.
// with the balcony door open on the rooftops. Each function draws one *thing*
// (ART-DIRECTION §4.2: no stock filler) and returns Items (strings never boil,
// F3 boil). Units: 1 unit = 8 px at 1920 × 1080 (scene 240 × 135).
import {
  type F3, type Item, HUB, thing, flat, stroke, blob, shadow, cat, g, uid, r2, rng, hashSeed, circleD, ellipseD,
  P, PL, rect, rr, wire, archD, cone, glow, linear, stipple, mapPath,
} from './kit.ts';

const W = HUB;
// background tones (15–30 % less saturated than player colours, §5.1.5)
export const T = {
  wallHi: '#33205C', wall: '#2B1650', wallLo: '#21113F', floor: '#1E1035', floorHi: '#2A1848',
  wood: '#4B2A3A', woodHi: '#5E3646', woodLo: '#341C2C',
  sofa: '#5E2C4C', sofaHi: '#713656', sofaLo: '#47203B',
  curtain: '#2E3570', curtainLo: '#232858',
  rust: '#9C4A43', saffron: '#B5813A', blue: '#34508F', leaf: '#3F6B57', leafHi: '#558565',
  sky: '#150C33', skyLo: '#2E1A58', far1: '#1E1239', far2: '#150B2B', brass: '#D99A3A', brassLo: '#A86F2A',
  cream: W.paper, lampLit: '#FFE2A6',
};

// --------------------------------------------------------------- wall ----
export function wall(Wd: number, Ht: number, floorY: number, defs: string[]): Item[] {
  const id = uid('wall');
  defs.push(linear(id, [[0, '#2E1856'], [0.55, T.wall], [1, T.wallLo]]));
  const out: Item[] = [`<rect x="-20" y="-20" width="${Wd + 40}" height="${Ht + 40}" fill="url(#${id})"/>`];
  // plaster: two faint hand-cut patches where the paint was redone (no blobs: patches with straight-ish edges)
  return out;
}

// ------------------------------------------------- the balcony doorway ----
/** The bab-arched balcony door, open: night sky, the rooftops of the neighbourhood, the rail with plant tins and the cat. */
export function balcony(x: number, y: number, w: number, h: number, defs: string[], seed: string, o: { cat?: boolean; tins?: number } = {}): Item[] {
  const out: Item[] = [];
  const arch = archD(x, y, w, h, 0.6);
  // the door frame: thick painted wood around the opening (drawn first, the opening paints over it)
  const fw = 2.4;
  out.push(thing(archD(x - fw, y - fw, w + fw * 2, h + fw, 0.6), { fill: '#3D2563', ink: W.ink, w: 0.5, amp: 0.25, boil: false, seed: seed + 'frame' }));
  const clip = uid('bc');
  defs.push(`<clipPath id="${clip}"><path d="${arch}"/></clipPath>`);
  const sky = uid('sky');
  defs.push(linear(sky, [[0, T.sky], [0.62, '#20123F'], [1, T.skyLo]]));
  const inner: Item[] = [];
  inner.push(`<rect x="${x - 2}" y="${y - 2}" width="${w + 4}" height="${h + 4}" fill="url(#${sky})"/>`);
  // the city glow on the horizon: light, so it may be soft
  inner.push(glow(x + w * 0.55, y + h * 0.66, w * 0.85, h * 0.3, '#E8A33A', defs, 0.3));
  // a few stars (hand-drawn 4-point twinkles, 3 sizes) and two low clouds lit from below by the city
  const r = rng(hashSeed(seed + 'sky'));
  let stars = '';
  for (let i = 0; i < 7; i++) {
    const sx = x + 4 + r() * (w - 8), sy = y + 4 + r() * h * 0.38, k = [0.5, 0.75, 1.0][i % 3];
    stars += `M${r2(sx)} ${r2(sy - k)} Q${r2(sx + 0.15 * k)} ${r2(sy - 0.15 * k)} ${r2(sx + k * 0.9)} ${r2(sy)} Q${r2(sx + 0.15 * k)} ${r2(sy + 0.15 * k)} ${r2(sx)} ${r2(sy + k)} Q${r2(sx - 0.15 * k)} ${r2(sy + 0.15 * k)} ${r2(sx - k * 0.85)} ${r2(sy)} Q${r2(sx - 0.15 * k)} ${r2(sy - 0.15 * k)} ${r2(sx)} ${r2(sy - k)}Z `;
  }
  inner.push(blob(stars, '#FFF1DC', { seed: seed + 'stars', op: 0.55, amp: 0.05 }));
  for (const [fx, fy, cw] of [[0.28, 0.3, 0.42], [0.74, 0.44, 0.34]]) {
    const ccx = x + w * fx, ccy = y + h * fy, c = w * cw;
    const cloud = `M${ccx - c / 2} ${ccy + 1} C${ccx - c * 0.45} ${ccy - 1.6} ${ccx - c * 0.25} ${ccy - 2.2} ${ccx - c * 0.12} ${ccy - 1.2} C${ccx - c * 0.05} ${ccy - 3.6} ${ccx + c * 0.2} ${ccy - 3.8} ${ccx + c * 0.24} ${ccy - 1.4} C${ccx + c * 0.38} ${ccy - 2.4} ${ccx + c * 0.52} ${ccy - 1} ${ccx + c * 0.5} ${ccy + 1.1} C${ccx + c * 0.1} ${ccy + 1.6} ${ccx - c * 0.2} ${ccy + 1.5} ${ccx - c / 2} ${ccy + 1} Z`;
    inner.push(flat(cloud, '#241545', { seed: seed + 'cloud' + fx, amp: 0.3 }));
    inner.push(stroke(`M${ccx - c * 0.42} ${ccy + 1.0} C${ccx - c * 0.1} ${ccy + 1.6} ${ccx + c * 0.2} ${ccy + 1.5} ${ccx + c * 0.46} ${ccy + 0.9}`, '#E8A33A', { w: 0.35, op: 0.3, seed: seed + 'cl' + fx, boil: false }));
  }
  // far rooftops: flat, no line, never boil (two tones, irregular grid)
  const hz = y + h * 0.58;
  const tops: [number, number, number][] = [];
  const roofs = (base: number, minH: number, maxH: number, step: [number, number], rec = false) => {
    const pts: number[][] = [[x - 2, y + h + 2], [x - 2, base]];
    let cx = x - 2;
    while (cx < x + w + 2) {
      const bw = step[0] + r() * (step[1] - step[0]), bh = minH + r() * (maxH - minH);
      pts.push([cx, base - bh], [cx + bw, base - bh + (r() - 0.5) * 0.6]);
      if (rec) tops.push([cx, cx + bw, base - bh]);
      cx += bw;
    }
    pts.push([x + w + 2, base], [x + w + 2, y + h + 2]);
    return P(pts);
  };
  inner.push(flat(roofs(hz + 4, 2, 9, [5, 11], true), T.far1, { amp: 0.25, seed: seed + 'r1' }));
  // rooftop clutter on the far roofs: water tanks on legs, antennas, a dish (silhouettes only)
  let clutter = '';
  const things = [
    // water tank: a short drum on 3 legs
    (cx: number, by: number) => `M${cx - 2.2} ${by - 4.2}C${cx - 2.2} ${by - 5.2} ${cx + 2.3} ${by - 5.3} ${cx + 2.3} ${by - 4.3}L${cx + 2.2} ${by - 1.6}L${cx + 1.6} ${by - 1.5}L${cx + 1.7} ${by}L${cx + 1.3} ${by}L${cx + 1.1} ${by - 1.5}L${cx - 1.0} ${by - 1.5}L${cx - 1.2} ${by}L${cx - 1.6} ${by}L${cx - 1.5} ${by - 1.6}L${cx - 2.2} ${by - 1.7}Z`,
    // antenna: a mast with two crossbars
    (cx: number, by: number) => `M${cx - 0.2} ${by}L${cx - 0.1} ${by - 7}L${cx + 0.25} ${by - 7}L${cx + 0.3} ${by}Z M${cx - 2} ${by - 6}L${cx + 2.1} ${by - 6.3}L${cx + 2.1} ${by - 5.9}L${cx - 2} ${by - 5.6}Z M${cx - 1.3} ${by - 4.4}L${cx + 1.4} ${by - 4.6}L${cx + 1.4} ${by - 4.2}L${cx - 1.3} ${by - 4.0}Z`,
    // dish: a tilted bowl on a stub
    (cx: number, by: number) => `M${cx - 1.8} ${by - 3.6}C${cx - 1.4} ${by - 1.4} ${cx + 1.4} ${by - 1.0} ${cx + 2.0} ${by - 2.8}Z M${cx - 0.1} ${by - 2}L${cx + 0.3} ${by - 2}L${cx + 0.4} ${by}L${cx - 0.2} ${by}Z`,
  ];
  const spots = [[0.12, 0], [0.3, 1], [0.47, 0], [0.63, 2], [0.8, 0], [0.9, 1]];
  for (const [fx, k] of spots) {
    const cx = x + w * fx + (r() - 0.5) * 2;
    const top = tops.find((t) => cx >= t[0] && cx < t[1]);
    clutter += things[k](cx, (top ? top[2] : hz) + 0.3);
  }
  inner.push(flat(clutter, T.far1, { amp: 0.08, seed: seed + 'cl' }));
  // nearer block of buildings (second tone), with lit windows in 3–4 drawn variants
  const near = roofs(hz + 14, 4, 13, [9, 16]);
  inner.push(flat(near, T.far2, { amp: 0.3, seed: seed + 'r2' }));
  let wins = '';
  const wr = rng(hashSeed(seed + 'win'));
  for (let i = 0; i < 14; i++) {
    const wx = x + 2 + wr() * (w - 6), wy = hz + 3 + wr() * 14;
    const ww = 1.4 + wr() * 1.1, wh = 1.7 + wr() * 0.8;
    const lit = wr();
    const col = lit > 0.86 ? '#9DB4FF' : '#FFC94D'; // one TV-blue window, the rest lamp-warm
    const op = lit < 0.35 ? 0 : 0.3 + wr() * 0.4;
    if (op === 0) continue;
    wins += `<path d="${P([[wx, wy], [wx + ww, wy + 0.15], [wx + ww - 0.1, wy + wh], [wx + 0.1, wy + wh - 0.1]])}" fill="${col}" opacity="${r2(op)}"/>`;
  }
  inner.push(wins);
  // tangled wires crossing the street (mid, thin)
  inner.push(stroke(wire(x - 2, hz + 1, x + w + 2, hz - 3, 5), W.ink, { w: 0.28, op: 0.8, seed: seed + 'w1', boil: false }));
  inner.push(stroke(wire(x - 2, hz + 3, x + w * 0.7, hz + 8, 3) + ' ' + wire(x + w * 0.3, hz + 6, x + w + 2, hz + 2, 4), W.ink, { w: 0.22, op: 0.7, seed: seed + 'w2', boil: false }));
  // the neighbour's balcony string lights (warm dots on a wire, 3 drawn bulb variants)
  const sl = wire(x + w * 0.05, hz + 9, x + w * 0.95, hz + 7, 4);
  inner.push(stroke(sl, W.ink, { w: 0.22, op: 0.8, seed: seed + 'sl', boil: false }));
  let bulbs = '';
  for (let i = 1; i < 10; i++) {
    const t = i / 10, bx = x + w * (0.05 + 0.9 * t), by = (1 - t) * (1 - t) * (hz + 9) + 2 * (1 - t) * t * (hz + 9 + 4) + t * t * (hz + 7) + 0.5;
    bulbs += `<ellipse cx="${r2(bx)}" cy="${r2(by)}" rx="${r2(0.45 + (i % 3) * 0.08)}" ry="${r2(0.6 + (i % 2) * 0.1)}" fill="${i % 4 === 2 ? '#FF9C6B' : '#FFE2A6'}" opacity="0.85"/>`;
    bulbs += glow(bx, by, 2.2, 2.2, '#FFC94D', defs, 0.25);
  }
  inner.push(bulbs);
  out.push(`<g clip-path="url(#${clip})">`, ...inner, `</g>`);

  // the balcony rail (outside, mid layer): a top bar, bars with one curl motif
  const railY = y + h * 0.8, railB = y + h - 0.6;
  let bars = '';
  const n = Math.round(w / 3.4);
  for (let i = 1; i < n; i++) { const bx = x + (w * i) / n + (i % 2 ? 0.15 : -0.1); bars += `M${r2(bx)} ${r2(railY + 0.6)} L${r2(bx + 0.1)} ${r2(railB)} `; }
  // two curls in the middle (wrought iron)
  const cx0 = x + w * 0.5;
  bars += `M${cx0 - 3} ${railY + 4} C${cx0 - 3} ${railY + 1.5} ${cx0 - 0.4} ${railY + 1.6} ${cx0 - 0.6} ${railY + 3.4} C${cx0 - 0.8} ${railY + 4.6} ${cx0 - 2.2} ${railY + 4.4} ${cx0 - 2} ${railY + 3.4}`;
  bars += ` M${cx0 + 3} ${railY + 4} C${cx0 + 3} ${railY + 1.5} ${cx0 + 0.4} ${railY + 1.6} ${cx0 + 0.6} ${railY + 3.4} C${cx0 + 0.8} ${railY + 4.6} ${cx0 + 2.2} ${railY + 4.4} ${cx0 + 2} ${railY + 3.4}`;
  out.push(`<g clip-path="url(#${clip})">`, stroke(bars, W.ink, { w: 0.42, seed: seed + 'bars', boil: false }), `</g>`);
  out.push(thing(rect(x - 0.5, railY - 0.6, w + 1, 1.3), { fill: '#3A2558', ink: W.ink, w: 0.4, amp: 0.15, boil: false, seed: seed + 'rail' }));

  // plant tins on the rail: old ghee tins (rust, saffron, blue) with basil and a geranium
  const tins = o.tins ?? 3;
  const tinCols = [T.rust, T.blue, T.saffron];
  const tinX = [0.16, 0.36, 0.72].slice(0, tins);
  tinX.forEach((fx, i) => {
    const tx = x + w * fx, tw = 3.6 + (i % 2) * 0.8, th = 3.4 + (i === 2 ? 0.7 : 0), ty = railY - 0.5 - th;
    // leaves first (behind the tin lip)
    const lr = rng(hashSeed(seed + 'lf' + i));
    let leaves = '';
    const nL = 5 + i;
    for (let k = 0; k < nL; k++) {
      const a = -Math.PI / 2 + (k - (nL - 1) / 2) * 0.42 + (lr() - 0.5) * 0.2;
      const L = 2.4 + lr() * 2.2, bx = tx + tw / 2 + (lr() - 0.5) * 1.2, by = ty + 0.4;
      const ex = bx + Math.cos(a) * L, ey = by + Math.sin(a) * L, nx = -Math.sin(a) * 0.9, ny = Math.cos(a) * 0.9;
      leaves += `M${r2(bx)} ${r2(by)} Q${r2((bx + ex) / 2 + nx)} ${r2((by + ey) / 2 + ny)} ${r2(ex)} ${r2(ey)} Q${r2((bx + ex) / 2 - nx)} ${r2((by + ey) / 2 - ny)} ${r2(bx)} ${r2(by)}Z `;
    }
    out.push(thing(leaves, { fill: i === 1 ? T.leafHi : T.leaf, ink: W.ink, w: 0.3, amp: 0.1, seed: seed + 'leaf' + i, wave: [2, 6] }));
    if (i === 2) { // geranium: three blossoms
      out.push(blob(circleD(tx + 1.2, ty - 3.4, 0.8) + circleD(tx + 2.6, ty - 4.4, 0.75) + circleD(tx + 3.6, ty - 2.8, 0.7), '#D9536B', { seed: seed + 'ger', amp: 0.12 }));
    }
    out.push(thing(P([[tx, ty], [tx + tw, ty - 0.1], [tx + tw - 0.2, ty + th], [tx + 0.15, ty + th]]), { fill: tinCols[i], ink: W.ink, w: 0.35, amp: 0.12, mis: [-0.25, 0.25], seed: seed + 'tin' + i }));
    out.push(stroke(`M${r2(tx + 0.4)} ${r2(ty + 1)} L${r2(tx + tw - 0.4)} ${r2(ty + 0.95)}`, W.ink, { w: 0.2, op: 0.5, seed: seed + 'tl' + i }));
  });

  // the cat: sitting on the rail, back to us, looking at the city; its tail hangs and swings (boils)
  if (o.cat !== false) {
    const cx = x + w * 0.86, cy = railY - 0.4;
    const body = `M${cx - 2.2} ${cy} C${cx - 2.8} ${cy - 2.4} ${cx - 2.0} ${cy - 4.6} ${cx - 1.1} ${cy - 5.4} C${cx - 1.6} ${cy - 6.6} ${cx - 1.5} ${cy - 7.6} ${cx - 1.2} ${cy - 8.4} L${cx - 0.6} ${cy - 7.6} C${cx - 0.1} ${cy - 7.8} ${cx + 0.4} ${cy - 7.8} ${cx + 0.8} ${cy - 7.6} L${cx + 1.5} ${cy - 8.5} C${cx + 1.7} ${cy - 7.6} ${cx + 1.7} ${cy - 6.6} ${cx + 1.3} ${cy - 5.6} C${cx + 2.3} ${cy - 4.8} ${cx + 3.0} ${cy - 2.4} ${cx + 2.4} ${cy} Z`;
    out.push(thing(body, { fill: '#120A20', ink: W.ink, w: 0.3, amp: 0.1, seed: seed + 'cat' }));
    // rim light from the city glow along its back and one ear
    out.push(stroke(`M${cx + 1.5} ${cy - 8.1} C${cx + 1.6} ${cy - 7.2} ${cx + 1.5} ${cy - 6.4} ${cx + 1.2} ${cy - 5.7} C${cx + 2.2} ${cy - 4.9} ${cx + 2.8} ${cy - 2.8} ${cx + 2.3} ${cy - 0.6}`, '#E8A33A', { w: 0.4, op: 0.9, seed: seed + 'rim' }));
    out.push(stroke(`M${cx + 1.6} ${cy + 0.1} C${cx + 2.8} ${cy + 1.8} ${cx + 1.6} ${cy + 3.6} ${cx + 2.6} ${cy + 5.6} C${cx + 3.0} ${cy + 6.4} ${cx + 3.8} ${cy + 6.4} ${cx + 3.9} ${cy + 5.8}`, '#120A20', { w: 0.75, amp: 0.25, seed: seed + 'tail' }));
  }

  // the inner edge of the door frame: the ink line drawn last, over sky and rail
  out.push(thing(arch, { ink: W.ink, w: 0.55, amp: 0.25, boil: false, seed: seed + 'inner' }));
  // a hatch of shadow on the frame's bottom-end side
  out.push(stroke(`M${x + w + 0.7} ${y + h * 0.35} L${x + w + 0.9} ${y + h - 1} M${x + w + 1.5} ${y + h * 0.45} L${x + w + 1.6} ${y + h - 2}`, W.ink, { w: 0.25, op: 0.5, seed: seed + 'fh', boil: false }));
  return out;
}

// ------------------------------------------------------------ curtains ----
export function curtain(x: number, y: number, w: number, h: number, side: 1 | -1, tieY: number, seed: string): Item[] {
  // side 1 = left panel gathered to its right edge's tie; drawn as one fabric mass
  const out: Item[] = [];
  const tx = side > 0 ? x + w * 0.35 : x + w * 0.65; // tie point
  const outer = side > 0 ? x : x + w, inner = side > 0 ? x + w : x;
  const d = side > 0
    ? `M${x} ${y} L${x + w} ${y + 0.2} C${x + w * 0.8} ${tieY - 12} ${tx + 1.4} ${tieY - 3} ${tx + 1.2} ${tieY} C${tx + 2.8} ${tieY + 10} ${x + w * 0.95} ${y + h - 8} ${x + w * 1.05} ${y + h} L${x - 0.5} ${y + h + 0.2} C${x + 0.6} ${tieY + 12} ${x - 0.4} ${tieY + 4} ${x + 0.4} ${tieY} C${x - 0.2} ${tieY - 10} ${x + 0.4} ${y + 12} ${x} ${y} Z`
    : `M${x + w} ${y} L${x} ${y + 0.2} C${x + w * 0.2} ${tieY - 12} ${tx - 1.4} ${tieY - 3} ${tx - 1.2} ${tieY} C${tx - 2.8} ${tieY + 10} ${x + w * 0.05} ${y + h - 8} ${x - w * 0.05} ${y + h} L${x + w + 0.5} ${y + h + 0.2} C${x + w - 0.6} ${tieY + 12} ${x + w + 0.4} ${tieY + 4} ${x + w - 0.4} ${tieY} C${x + w + 0.2} ${tieY - 10} ${x + w - 0.4} ${y + 12} ${x + w} ${y} Z`;
  out.push(thing(d, { fill: T.curtain, ink: W.ink, w: 0.45, amp: 0.3, mis: [-0.3, 0.3], seed: seed + 'c', hatch: true, hatchColor: W.ink, hatchOp: 0.25, boil: false }));
  // folds: long soft strokes converging at the tie
  let folds = '';
  for (let i = 1; i <= 3; i++) {
    const fx = outer + (inner - outer) * (i / 4.2);
    folds += `M${r2(fx)} ${r2(y + 1.5)} Q${r2((fx + tx) / 2)} ${r2(tieY - 10)} ${r2(tx + (i - 2) * 0.5)} ${r2(tieY - 1)} `;
    folds += `M${r2(tx + (i - 2) * 0.6)} ${r2(tieY + 1.5)} Q${r2(fx + side * 1.5)} ${r2(tieY + 18)} ${r2(fx + side * 2.2)} ${r2(y + h - 1)} `;
  }
  out.push(stroke(folds, W.ink, { w: 0.3, op: 0.45, seed: seed + 'f', boil: false }));
  // the tie: a saffron cord with a tassel
  out.push(thing(rr(tx - 2.2, tieY - 0.8, 4.4, 1.6, 0.7), { fill: T.saffron, ink: W.ink, w: 0.3, amp: 0.08, seed: seed + 't' }));
  out.push(thing(`M${tx + side * 1.2} ${tieY + 0.5} L${tx + side * 1.9} ${tieY + 4.2} L${tx + side * 0.6} ${tieY + 4.4} Z`, { fill: T.saffron, ink: W.ink, w: 0.28, amp: 0.06, seed: seed + 'ts' }));
  return out;
}
export function rod(x1: number, x2: number, y: number, seed: string): Item[] {
  return [
    thing(rr(x1, y - 0.6, x2 - x1, 1.2, 0.5), { fill: T.brassLo, ink: W.ink, w: 0.35, amp: 0.15, boil: false, seed: seed + 'rod' }),
    thing(circleD(x1, y, 1.1) + circleD(x2, y, 1.1), { fill: T.brass, ink: W.ink, w: 0.3, amp: 0.05, boil: false, seed: seed + 'fin' }),
  ];
}

// ---------------------------------------------------------------- lamp ----
/** The standing lamp: the brand's amber dot made into a thing. Shade top y = top. */
export function lamp(x: number, floorY: number, top: number, defs: string[], seed: string, o: { glowR?: number } = {}): Item[] {
  const out: Item[] = [];
  const sw = 15, sh = 11, shadeB = top + sh;
  const R = o.glowR ?? 70;
  // light first (screen): wall wash, the up and down cones
  out.push(glow(x, top + sh * 0.6, R, R * 0.8, '#FFC94D', defs, 0.3));
  out.push(cone([[x - sw * 0.42, top + 0.5], [x + sw * 0.42, top + 0.3], [x + sw * 1.3, top - 26], [x - sw * 1.2, top - 26]], '#FFE2A6', defs, 0.075, [0, 1, 0, 0]));
  out.push(cone([[x - sw * 0.6, shadeB], [x + sw * 0.6, shadeB], [x + sw * 2.2, floorY + 4], [x - sw * 2.0, floorY + 4]], '#FFC94D', defs, 0.085));
  // pool of light on the floor (hand-cut ellipse, screen)
  out.push(flat(`M${x - 18} ${floorY + 1.4} C${x - 16} ${floorY - 1.6} ${x + 17} ${floorY - 1.8} ${x + 19} ${floorY + 1} C${x + 18} ${floorY + 3.8} ${x - 15} ${floorY + 4} ${x - 18} ${floorY + 1.4} Z`, '#FFC94D', { op: 0.1, blend: 'screen', seed: seed + 'pool' }));
  // pole (a slight lean: the lamp has been knocked a hundred times)
  out.push(thing(P([[x - 0.45, shadeB - 0.5], [x + 0.45, shadeB - 0.5], [x + 0.9, floorY - 1.5], [x - 0.1, floorY - 1.5]]), { fill: T.brassLo, ink: W.ink, w: 0.35, amp: 0.1, seed: seed + 'pole', boil: false }));
  // base: a heavy round foot
  out.push(thing(`M${x - 5} ${floorY} C${x - 4.6} ${floorY - 2.4} ${x + 5.4} ${floorY - 2.6} ${x + 5.6} ${floorY - 0.1} C${x + 3} ${floorY + 0.8} ${x - 2.6} ${floorY + 0.8} ${x - 5} ${floorY} Z`, { fill: T.brassLo, ink: W.ink, w: 0.45, amp: 0.12, seed: seed + 'base' }));
  // shade: pleated fabric drum, lit from inside (paper colour), a darker top ellipse
  const shade = `M${x - sw * 0.36} ${top} C${x - sw * 0.1} ${top - 0.6} ${x + sw * 0.2} ${top - 0.5} ${x + sw * 0.37} ${top + 0.1} L${x + sw * 0.52} ${shadeB} C${x + sw * 0.2} ${shadeB + 1.1} ${x - sw * 0.25} ${shadeB + 1.2} ${x - sw * 0.5} ${shadeB + 0.1} Z`;
  out.push(thing(shade, { fill: T.lampLit, ink: '#5A3410', w: 0.5, amp: 0.15, mis: [-0.3, 0.3], seed: seed + 'shade' }));
  // pleats (drawn, uneven) + a warm band along the bottom
  let pl = '';
  for (let i = 1; i < 6; i++) { const t = i / 6; pl += `M${r2(x - sw * 0.36 + sw * 0.73 * t)} ${top + 0.6} L${r2(x - sw * 0.5 + sw * 1.02 * t)} ${r2(shadeB + 0.2)} `; }
  out.push(stroke(pl, '#C9852E', { w: 0.28, op: 0.6, seed: seed + 'pl' }));
  out.push(stroke(`M${x - sw * 0.5 + 0.4} ${shadeB - 0.6} C${x - sw * 0.2} ${shadeB + 0.4} ${x + sw * 0.2} ${shadeB + 0.3} ${x + sw * 0.5 - 0.4} ${shadeB - 0.7}`, '#E8A33A', { w: 0.7, op: 0.9, seed: seed + 'band' }));
  // the bright opening under the shade (where the bulb shows)
  out.push(blob(`M${x - 4.6} ${shadeB + 0.3} C${x - 2} ${shadeB + 1.8} ${x + 2.4} ${shadeB + 1.8} ${x + 4.8} ${shadeB + 0.2} C${x + 2} ${shadeB + 0.9} ${x - 2} ${shadeB + 0.9} ${x - 4.6} ${shadeB + 0.3} Z`, '#FFF4D6', { seed: seed + 'open', amp: 0.1 }));
  // pull-chain with a little bead (it swings: boils)
  out.push(stroke(`M${x + 3.2} ${shadeB + 0.6} L${x + 3.5} ${shadeB + 4.6}`, '#5A3410', { w: 0.22, seed: seed + 'ch', amp: 0.2 }));
  out.push(blob(circleD(x + 3.5, shadeB + 5.1, 0.5), T.brass, { seed: seed + 'bead' }));
  return out;
}

// ---------------------------------------------------------------- sofa ----
export function sofa(x: number, floorY: number, w: number, seed: string): Item[] {
  const out: Item[] = [];
  const backTop = floorY - 21, seatY = floorY - 10.5, armW = 6.5;
  // floor shadow (ink multiply)
  out.push(shadow(`M${x - 2} ${floorY - 0.5} L${x + w + 2} ${floorY - 0.8} L${x + w + 5} ${floorY + 2.4} L${x + 1} ${floorY + 2.6} Z`, W, 0.45));
  // back: one long soft mass, its top sagging where people always sit
  const back = `M${x + 1} ${seatY} L${x + 1.4} ${backTop + 3} C${x + 2} ${backTop - 0.4} ${x + w * 0.25} ${backTop + 0.5} ${x + w * 0.33} ${backTop + 1.2} C${x + w * 0.45} ${backTop + 1.9} ${x + w * 0.6} ${backTop - 0.3} ${x + w * 0.75} ${backTop + 0.3} C${x + w * 0.9} ${backTop + 0.8} ${x + w - 1.2} ${backTop - 0.2} ${x + w - 1} ${backTop + 3.2} L${x + w - 1.2} ${seatY} Z`;
  out.push(thing(back, { fill: T.sofaLo, ink: W.ink, w: 0.55, amp: 0.3, mis: W.mis, seed: seed + 'back', boil: false }));
  // back cushions (two, slightly different): seams as dents
  out.push(stroke(`M${x + w * 0.5} ${backTop + 2.4} C${x + w * 0.49} ${backTop + 5} ${x + w * 0.51} ${seatY - 4} ${x + w * 0.5} ${seatY - 0.5}`, W.ink, { w: 0.35, op: 0.6, seed: seed + 'seam', boil: false }));
  // seat
  const seat = `M${x + armW - 1} ${seatY + 0.2} C${x + w * 0.3} ${seatY - 1.4} ${x + w * 0.7} ${seatY - 1.0} ${x + w - armW + 1} ${seatY} L${x + w - armW + 1.2} ${floorY - 3} L${x + armW - 1.2} ${floorY - 3.1} Z`;
  out.push(thing(seat, { fill: T.sofa, ink: W.ink, w: 0.55, amp: 0.25, mis: W.mis, seed: seed + 'seat', boil: false }));
  out.push(stroke(`M${x + armW + 1} ${seatY + 3.2} C${x + w * 0.4} ${seatY + 2.4} ${x + w * 0.6} ${seatY + 2.8} ${x + w - armW - 1} ${seatY + 3}`, W.ink, { w: 0.3, op: 0.45, seed: seed + 'pip', boil: false }));
  // skirt + little wooden feet
  out.push(thing(P([[x + 1, floorY - 3.4], [x + w - 1, floorY - 3.6], [x + w - 1.2, floorY - 1.1], [x + 1.3, floorY - 1]]), { fill: T.sofaLo, ink: W.ink, w: 0.5, amp: 0.2, seed: seed + 'skirt', boil: false }));
  for (const fx of [x + 3, x + w - 4.2]) out.push(thing(P([[fx, floorY - 1.2], [fx + 1.6, floorY - 1.2], [fx + 1.3, floorY + 0.4], [fx + 0.3, floorY + 0.4]]), { fill: T.woodLo, ink: W.ink, w: 0.3, amp: 0.05, seed: seed + 'ft' + fx, boil: false }));
  // arms: rolled, the right one wears a striped throw
  for (const side of [0, 1]) {
    const ax = side ? x + w - armW : x;
    const arm = `M${ax} ${floorY - 2} L${ax - 0.2} ${seatY - 3} C${ax - 0.4} ${seatY - 6.6} ${ax + armW + 0.2} ${seatY - 6.8} ${ax + armW + 0.1} ${seatY - 3.2} L${ax + armW - 0.1} ${floorY - 2.2} Z`;
    out.push(thing(arm, { fill: T.sofa, ink: W.ink, w: 0.6, amp: 0.25, mis: W.mis, seed: seed + 'arm' + side, boil: false, hatch: side === 1, hatchColor: W.ink, hatchOp: 0.3 }));
    out.push(stroke(`M${ax + 1.2} ${seatY - 3.6} C${ax + 1.6} ${seatY - 5.2} ${ax + armW - 1.4} ${seatY - 5.4} ${ax + armW - 1} ${seatY - 3.8}`, W.ink, { w: 0.3, op: 0.5, seed: seed + 'roll' + side, boil: false }));
  }
  // the throw blanket over the right arm (saffron with rust stripes, fringe)
  const tx = x + w - armW - 2.5;
  const throwD = `M${tx} ${seatY - 5.2} C${tx + 3} ${seatY - 7.6} ${tx + 8} ${seatY - 7.4} ${tx + 9.4} ${seatY - 4.6} L${tx + 9.8} ${seatY + 4.5} L${tx + 6.2} ${seatY + 5.2} C${tx + 5.6} ${seatY + 1} ${tx + 3} ${seatY - 1.4} ${tx + 0.4} ${seatY - 1.2} Z`;
  out.push(thing(throwD, { fill: T.saffron, ink: W.ink, w: 0.45, amp: 0.2, mis: W.mis, seed: seed + 'throw' }));
  const tc = uid('tc');
  out.push(`<clipPath id="${tc}"><path d="${throwD}"/></clipPath>`);
  out.push(g(`clip-path="url(#${tc})"`, stroke(`M${tx - 1} ${seatY - 3} L${tx + 11} ${seatY - 6.5} M${tx - 1} ${seatY - 0.5} L${tx + 11} ${seatY - 4} M${tx + 2} ${seatY + 2} L${tx + 11} ${seatY - 1} M${tx + 4} ${seatY + 4.5} L${tx + 11} ${seatY + 1.8}`, T.rust, { w: 0.9, op: 0.9, seed: seed + 'str' })));
  out.push(stroke(`M${tx + 6.5} ${seatY + 5.3} l-.1 1.2 M${tx + 7.4} ${seatY + 5.1} l.05 1.3 M${tx + 8.3} ${seatY + 4.9} l-.05 1.2 M${tx + 9.2} ${seatY + 4.7} l.1 1.2`, T.saffron, { w: 0.3, seed: seed + 'fr' }));
  return out;
}
/** A floor/sofa cushion with a cement-tile motif (the room's pattern language). */
export function cushion(cx: number, cy: number, s: number, fill: string, motif: string, seed: string, tilt = 0): Item[] {
  const d = `M${cx - 4.6 * s} ${cy - 3.4 * s} C${cx - 1.6 * s} ${cy - 2.6 * s} ${cx + 1.6 * s} ${cy - 3.8 * s} ${cx + 4.8 * s} ${cy - 3.6 * s} C${cx + 4.0 * s} ${cy - 1 * s} ${cx + 4.4 * s} ${cy + 1.4 * s} ${cx + 4.6 * s} ${cy + 3.2 * s} C${cx + 1.6 * s} ${cy + 2.6 * s} ${cx - 1.4 * s} ${cy + 3.6 * s} ${cx - 4.8 * s} ${cy + 3.4 * s} C${cx - 4.0 * s} ${cy + 1 * s} ${cx - 4.4 * s} ${cy - 1.4 * s} ${cx - 4.6 * s} ${cy - 3.4 * s} Z`;
  // kilim lozenge: a diamond with a stepped inner diamond, and two woven bands
  const q = 2.3 * s;
  const motifD = P([[cx, cy - q], [cx + q * 1.25, cy + 0.1], [cx + 0.1, cy + q], [cx - q * 1.2, cy]]) + ' ' +
    P([[cx - 4.0 * s, cy - 2.6 * s], [cx + 4.2 * s, cy - 2.9 * s], [cx + 4.2 * s, cy - 2.2 * s], [cx - 4.0 * s, cy - 1.9 * s]]);
  const innerD = P([[cx, cy - q * 0.45], [cx + q * 0.55, cy], [cx, cy + q * 0.45], [cx - q * 0.55, cy]]);
  return [g(`transform="rotate(${tilt} ${cx} ${cy})"`,
    thing(d, { fill, ink: W.ink, w: 0.45, amp: 0.15, mis: W.mis, seed: seed + 'cu' }),
    blob(motifD, motif, { seed: seed + 'mo', amp: 0.08, op: 0.8 }),
    blob(innerD, fill, { seed: seed + 'mi', amp: 0.05 }),
    stroke(`M${cx - 3.4 * s} ${cy + 2.2 * s} C${cx - 1 * s} ${cy + 1.7 * s} ${cx + 1 * s} ${cy + 2.2 * s} ${cx + 3.4 * s} ${cy + 1.9 * s}`, W.ink, { w: 0.25, op: 0.4, seed: seed + 'cs' }),
  )];
}

// ----------------------------------------------- low table + rakweh ----
export function coffeeTable(x: number, floorY: number, w: number, defs: string[], seed: string): Item[] {
  const out: Item[] = [];
  const topY = floorY - 7;
  out.push(shadow(`M${x} ${floorY - 0.4} L${x + w} ${floorY - 0.6} L${x + w + 3} ${floorY + 1.8} L${x + 2} ${floorY + 2} Z`, W, 0.4));
  // legs (turned wood, one a hair shorter: there's a folded paper under it)
  for (const [lx, sh] of [[x + 2.5, 0], [x + w - 4, 0.25]] as const) out.push(thing(P([[lx, topY + 1], [lx + 1.6, topY + 1], [lx + 1.3, floorY - sh], [lx + 0.3, floorY - sh]]), { fill: T.woodLo, ink: W.ink, w: 0.35, amp: 0.06, seed: seed + 'leg' + lx, boil: false }));
  // top: a round brass tray on a wooden table
  out.push(thing(rr(x, topY - 0.6, w, 2.2, 0.8), { fill: T.wood, ink: W.ink, w: 0.5, amp: 0.15, mis: W.mis, seed: seed + 'top', boil: false }));
  out.push(stroke(`M${x + 1} ${topY + 0.9} C${x + w * 0.4} ${topY + 0.6} ${x + w * 0.6} ${topY + 1.1} ${x + w - 1} ${topY + 0.8}`, W.ink, { w: 0.22, op: 0.4, seed: seed + 'grain', boil: false }));
  const tcx = x + w * 0.52;
  out.push(thing(`M${tcx - 12} ${topY - 0.6} C${tcx - 11} ${topY - 2.4} ${tcx + 11} ${topY - 2.6} ${tcx + 12.4} ${topY - 0.7} C${tcx + 8} ${topY + 0.3} ${tcx - 8} ${topY + 0.4} ${tcx - 12} ${topY - 0.6} Z`, { fill: T.brassLo, ink: W.ink, w: 0.4, amp: 0.1, seed: seed + 'tray' }));
  // the rakweh (brass coffee pot): bowl, waist, long handle
  const rx = tcx - 4, ry = topY - 1.2;
  out.push(thing(`M${rx - 2.6} ${ry} C${rx - 3.2} ${ry - 2.4} ${rx - 2.2} ${ry - 3.8} ${rx - 1.4} ${ry - 4.6} L${rx - 1.6} ${ry - 5.8} C${rx - 1.4} ${ry - 6.4} ${rx + 1.8} ${ry - 6.6} ${rx + 2.2} ${ry - 5.9} L${rx + 2.6} ${ry - 6.5} L${rx + 2.4} ${ry - 5.3} C${rx + 2} ${ry - 4.9} ${rx + 1.7} ${ry - 4.6} ${rx + 1.6} ${ry - 4.4} C${rx + 2.6} ${ry - 3.6} ${rx + 3.2} ${ry - 2.2} ${rx + 2.6} ${ry} Z`, { fill: T.brass, ink: '#3A1E08', w: 0.42, amp: 0.1, mis: [-0.25, 0.25], seed: seed + 'rak' }));
  out.push(thing(P([[rx - 1.6, ry - 5.2], [rx - 8.2, ry - 7.4], [rx - 8.4, ry - 6.6], [rx - 1.7, ry - 4.4]]), { fill: '#6B3B1E', ink: '#3A1E08', w: 0.3, amp: 0.05, seed: seed + 'hdl' }));
  out.push(stroke(`M${rx - 1.6} ${ry - 3} C${rx - 1.8} ${ry - 2} ${rx - 1.6} ${ry - 1.2} ${rx - 1.2} ${ry - 0.6}`, T.cream, { w: 0.35, op: 0.7, seed: seed + 'rhl' }));
  // three little cups (finjan) with a blue rim, one tipped on its saucer, one half full
  const cups = [[tcx + 2.2, 0], [tcx + 6, 1], [tcx + 9.4, 2]];
  for (const [cx, i] of cups) {
    const cy = topY - 1.4;
    out.push(thing(`M${cx - 1.5} ${cy - 2.3} L${cx + 1.5} ${cy - 2.4} C${cx + 1.6} ${cy - 1.0} ${cx + 1.2} ${cy - 0.2} ${cx + 0.7} ${cy} L${cx - 0.7} ${cy} C${cx - 1.2} ${cy - 0.2} ${cx - 1.6} ${cy - 1.0} ${cx - 1.5} ${cy - 2.3} Z`, { fill: T.cream, ink: W.ink, w: 0.3, amp: 0.05, seed: seed + 'cup' + i }));
    out.push(stroke(`M${cx - 1.3} ${cy - 1.8} L${cx + 1.3} ${cy - 1.9}`, T.blue, { w: 0.35, seed: seed + 'rim' + i }));
    // steam: two curls each, light so it may glow faintly; boils (it's alive)
    if (i !== 1) out.push(stroke(`M${cx} ${cy - 2.8} C${cx - 1.2} ${cy - 4.2} ${cx + 1} ${cy - 5.2} ${cx - 0.2} ${cy - 6.8} C${cx - 1} ${cy - 7.8} ${cx + 0.4} ${cy - 8.6} ${cx + 0.2} ${cy - 9.4}`, T.cream, { w: 0.35, op: 0.35, amp: 0.35, seed: seed + 'stm' + i }));
  }
  return out;
}

// ------------------------------------------------------ cement tiles ----
/** A strip of Lebanese-style cement tiles (3 drawn patterns, non-repeating order, irregular grid, thick white edge). */
export function tileStrip(x0: number, x1: number, y: number, size: number, rows: number, seed: string, op = 0.55): Item[] {
  const out: Item[] = [];
  const r = rng(hashSeed(seed));
  const seq = [0, 1, 2, 1, 0, 2, 2, 0, 1, 0, 2, 1, 1, 2, 0];
  let s = '', motifR = '', motifB = '', motifS = '', edges = '';
  for (let row = 0; row < rows; row++) {
    let x = x0 - (row % 2) * size * 0.5;
    let i = row * 3;
    const ty = y + row * size;
    while (x < x1) {
      const tw = size + (r() - 0.5) * 0.7;
      const k = seq[i++ % seq.length];
      const cx = x + tw / 2, cy = ty + size / 2, q = size * 0.38;
      s += P([[x + 0.25, ty + 0.25], [x + tw - 0.2, ty + 0.3 + (r() - 0.5) * 0.3], [x + tw - 0.25, ty + size - 0.2], [x + 0.2, ty + size - 0.25]]) + ' ';
      if (k === 0) { // eight-point star from two squares
        const a = q, b = q * 0.72;
        motifR += P([[cx, cy - a], [cx + b, cy - b], [cx + a, cy], [cx + b, cy + b], [cx, cy + a], [cx - b, cy + b], [cx - a, cy], [cx - b, cy - b]]) + ' ';
        motifS += circleD(cx, cy, q * 0.28) + ' ';
      } else if (k === 1) { // four petals (quatrefoil of almonds)
        for (const [dx, dy] of [[0, -1], [1, 0], [0, 1], [-1, 0]]) {
          const ex = cx + dx * q, ey = cy + dy * q, nx = -dy * q * 0.32, ny = dx * q * 0.32;
          motifB += `M${r2(cx)} ${r2(cy)} Q${r2((cx + ex) / 2 + nx)} ${r2((cy + ey) / 2 + ny)} ${r2(ex)} ${r2(ey)} Q${r2((cx + ex) / 2 - nx)} ${r2((cy + ey) / 2 - ny)} ${r2(cx)} ${r2(cy)}Z `;
        }
        motifS += circleD(cx, cy, q * 0.18) + ' ';
      } else { // corner quarter-circles: four tiles make a circle
        for (const [dx, dy] of [[0, 0], [1, 0], [1, 1], [0, 1]]) {
          const ccx = x + dx * tw, ccy = ty + dy * size, rr_ = size * 0.3;
          const sx = dx ? -1 : 1, sy = dy ? -1 : 1;
          motifR += `M${r2(ccx)} ${r2(ccy)} L${r2(ccx + sx * rr_)} ${r2(ccy)} A${r2(rr_)} ${r2(rr_)} 0 0 ${sx * sy > 0 ? 1 : 0} ${r2(ccx)} ${r2(ccy + sy * rr_)} Z `;
        }
        motifB += P([[cx, cy - q * 0.55], [cx + q * 0.55, cy], [cx, cy + q * 0.55], [cx - q * 0.55, cy]]) + ' ';
      }
      edges += P([[x + 0.25, ty + 0.25], [x + tw - 0.2, ty + 0.3], [x + tw - 0.25, ty + size - 0.2], [x + 0.2, ty + size - 0.25]]) + ' ';
      x += tw;
    }
  }
  // one more value step than the wall: a lighter tile body, brighter pigments, a real white edge
  out.push(flat(s, '#33215A', { amp: 0.12, seed: seed + 'base' }));
  out.push(`<g opacity="${op}">`);
  out.push(flat(motifR, '#B85A4C', { amp: 0.1, seed: seed + 'mr' }));
  out.push(flat(motifB, '#4166B0', { amp: 0.1, seed: seed + 'mb' }));
  out.push(flat(motifS, '#D9A04A', { amp: 0.05, seed: seed + 'ms' }));
  out.push(`</g>`);
  // the thick, worn white edge of old tiles: a cream outline at low opacity
  out.push(`<path d="${edges}" fill="none" stroke="${T.cream}" stroke-opacity="0.34" stroke-width="0.85" stroke-linejoin="round"/>`);
  out.push(`<path d="${edges}" fill="none" stroke="${T.cream}" stroke-opacity="0.18" stroke-width="0.35" stroke-linejoin="round" transform="translate(0.35 0.35)"/>`);
  return out;
}

// ------------------------------------------------ cement-tile floor (v2) ----
// AD note: the old strip was a flat, saturated two-motif grid that read as wallpaper. Now: the floor lies down
// (rows narrow toward the back, columns converge on the room's vanishing point), 4 tile designs in a seeded
// non-repeating order (never the same as the left or upper neighbour), grout that wanders (shared jittered
// vertices + uneven insets), the thick worn white edge, and pigments ~22 % less saturated than v1.
const cc = (cx: number, cy: number, r: number) => { const k = 0.552 * r; return `M${cx + r} ${cy} C${cx + r} ${cy + k} ${cx + k} ${cy + r} ${cx} ${cy + r} C${cx - k} ${cy + r} ${cx - r} ${cy + k} ${cx - r} ${cy} C${cx - r} ${cy - k} ${cx - k} ${cy - r} ${cx} ${cy - r} C${cx + k} ${cy - r} ${cx + r} ${cy - k} ${cx + r} ${cy} Z `; };
const sq = (pts: number[][]) => 'M' + pts.map((p) => `${p[0]} ${p[1]}`).join(' L') + ' Z ';
/** tile designs in the unit square: [red layer, blue layer, amber layer] */
const TILE_DESIGNS: (() => [string, string, string])[] = [
  // 0 eight-point star from two squares, amber heart
  () => [sq([[0.5, 0.14], [0.75, 0.25], [0.86, 0.5], [0.75, 0.75], [0.5, 0.86], [0.25, 0.75], [0.14, 0.5], [0.25, 0.25]]), '', cc(0.5, 0.5, 0.1)],
  // 1 four almonds (quatrefoil) in blue, amber centre
  () => {
    let b = '';
    for (const [dx, dy] of [[0, -1], [1, 0], [0, 1], [-1, 0]]) {
      const ex = 0.5 + dx * 0.36, ey = 0.5 + dy * 0.36, nx = -dy * 0.13, ny = dx * 0.13;
      b += `M0.5 0.5 C${0.5 + dx * 0.12 + nx} ${0.5 + dy * 0.12 + ny} ${ex - dx * 0.08 + nx} ${ey - dy * 0.08 + ny} ${ex} ${ey} C${ex - dx * 0.08 - nx} ${ey - dy * 0.08 - ny} ${0.5 + dx * 0.12 - nx} ${0.5 + dy * 0.12 - ny} 0.5 0.5 Z `;
    }
    return ['', b, cc(0.5, 0.5, 0.07)];
  },
  // 2 corner quarter-circles in red (four tiles make a circle), blue lozenge in the middle
  () => {
    const r = 0.3, k = 0.552 * r;
    const q = `M0 0 L${r} 0 C${r} ${k} ${k} ${r} 0 ${r} Z M1 0 L1 ${r} C${1 - k} ${r} ${1 - r} ${k} ${1 - r} 0 Z M1 1 L${1 - r} 1 C${1 - r} ${1 - k} ${1 - k} ${1 - r} 1 ${1 - r} Z M0 1 L0 ${1 - r} C${k} ${1 - r} ${r} ${1 - k} ${r} 1 Z `;
    return [q, sq([[0.5, 0.3], [0.7, 0.5], [0.5, 0.7], [0.3, 0.5]]), ''];
  },
  // 3 the quiet tile: plain body, a thin blue inner border and amber corner seeds (breaks the rhythm)
  () => [
    '',
    sq([[0.16, 0.16], [0.84, 0.16], [0.84, 0.84], [0.16, 0.84]]) + sq([[0.22, 0.22], [0.22, 0.78], [0.78, 0.78], [0.78, 0.22]]),
    cc(0.08, 0.08, 0.045) + cc(0.92, 0.08, 0.045) + cc(0.92, 0.92, 0.045) + cc(0.08, 0.92, 0.045),
  ],
];
export function tileFloor(x0: number, x1: number, yTop: number, yBot: number, seed: string, o: { horizon: number; vpX: number; U: number; D?: number }): Item[] {
  const r = rng(hashSeed(seed));
  const H = o.horizon, F = (yTop - H) * 10, D = o.D ?? 0.8;
  // row boundaries in depth
  const ys: number[] = [yTop];
  for (let v = 10 - D; ys[ys.length - 1] < yBot; v -= D) ys.push(H + F / v);
  const X = (u: number, y: number) => o.vpX + u * o.U * (y - H);
  const uMin = Math.floor((x0 - o.vpX) / (o.U * (yBot - H))) - 1, uMax = Math.ceil((x1 - o.vpX) / (o.U * (yTop - H))) + 1;
  // shared jittered vertices → grout that wanders but stays continuous
  const V = new Map<string, [number, number]>();
  const vert = (u: number, i: number): [number, number] => {
    const key = u + ':' + i;
    if (!V.has(key)) { const y = ys[i], sc = (y - H) / (yTop - H); V.set(key, [X(u, y) + (r() - 0.5) * 0.5 * sc, y + (r() - 0.5) * 0.3 * sc]); }
    return V.get(key)!;
  };
  const grid: number[][] = [];
  let body = '', red = '', blue = '', amber = '', edge = '', edge2 = '';
  for (let i = 0; i < ys.length - 1; i++) {
    grid[i] = [];
    const sc = (ys[i] - H) / (yTop - H);
    for (let u = uMin; u < uMax; u++) {
      // seeded design: never equal to the left or upper neighbour
      let k = Math.floor(r() * 4);
      for (let t = 0; t < 4 && (k === grid[i][u - 1] || k === grid[i - 1]?.[u]); t++) k = (k + 1 + Math.floor(r() * 2)) % 4;
      grid[i][u] = k;
      const tl = vert(u, i), tr = vert(u + 1, i), br = vert(u + 1, i + 1), bl = vert(u, i + 1);
      if (Math.max(tr[0], br[0]) < x0 - 2 || Math.min(tl[0], bl[0]) > x1 + 2) continue;
      // uneven inset per tile edge (grout width 0.25–0.6, scaled with depth)
      const ins = () => (0.18 + r() * 0.26) * sc;
      const iL = ins(), iR = ins(), iT = ins() * 0.7, iB = ins() * 0.7;
      const f = (uu: number, vv: number): [number, number] => {
        const ax = tl[0] + (tr[0] - tl[0]) * uu, ay = tl[1] + (tr[1] - tl[1]) * uu, bx = bl[0] + (br[0] - bl[0]) * uu, by = bl[1] + (br[1] - bl[1]) * uu;
        return [ax + (bx - ax) * vv, ay + (by - ay) * vv];
      };
      const wTop = tr[0] - tl[0];
      const eu = (iL / wTop), eu2 = (iR / wTop), ev = iT / (bl[1] - tl[1]), ev2 = iB / (bl[1] - tl[1]);
      const tile = sq([f(eu, ev), f(1 - eu2, ev), f(1 - eu2, 1 - ev2), f(eu, 1 - ev2)].map((p) => [r2(p[0]), r2(p[1])]));
      body += tile;
      edge += tile;
      const g2 = (d: string) => mapPath(d, (a, b) => f(eu + a * (1 - eu - eu2), ev + b * (1 - ev - ev2)));
      // a few tiles are worn: the design is half-gone in one corner (old tiles, scrubbed for 60 years)
      const [dr, db, da] = TILE_DESIGNS[k]();
      red += dr ? g2(dr) : ''; blue += db ? g2(db) : ''; amber += da ? g2(da) : '';
      if (r() < 0.18) edge2 += tile; // a handful of tiles with a brighter, freshly-scrubbed edge
    }
  }
  const out: Item[] = [];
  out.push(flat(body, '#30224F', { amp: 0.08, seed: seed + 'base', boil: false }));
  out.push(`<g opacity="0.5">`);
  out.push(flat(red, '#9A6058', { amp: 0.06, seed: seed + 'mr', boil: false }));
  out.push(flat(blue, '#4F6494', { amp: 0.06, seed: seed + 'mb', boil: false }));
  out.push(flat(amber, '#B8955E', { amp: 0.04, seed: seed + 'ma', boil: false }));
  out.push(`</g>`);
  // the thick, worn white edge (each tile's own bevel), and a few brighter ones
  out.push(`<path d="${edge}" fill="none" stroke="${T.cream}" stroke-opacity="0.2" stroke-width="0.7" stroke-linejoin="round"/>`);
  out.push(`<path d="${edge2}" fill="none" stroke="${T.cream}" stroke-opacity="0.16" stroke-width="0.7" stroke-linejoin="round"/>`);
  // depth: the back rows sit in the room's shadow, the front ones catch the TV's spill
  const id = uid('fd');
  out.push(`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="0" y1="${yTop}" x2="0" y2="${yBot}"><stop offset="0" stop-color="${W.ink}" stop-opacity="0.45"/><stop offset="0.55" stop-color="${W.ink}" stop-opacity="0.15"/><stop offset="1" stop-color="${W.ink}" stop-opacity="0"/></linearGradient>`);
  out.push(`<rect x="${x0}" y="${yTop - 0.5}" width="${x1 - x0}" height="${yBot - yTop + 1}" fill="url(#${id})" style="mix-blend-mode:multiply"/>`);
  return out;
}

// ------------------------------------------------------- right corner ----
/** A side cabinet with the old radio, the trailing pothos and a framed photo of the gang. */
export function radioCorner(x: number, floorY: number, seed: string): Item[] {
  const out: Item[] = [];
  const cw = 26, chH = 16, topY = floorY - chH;
  out.push(shadow(`M${x - 1} ${floorY - 0.5} L${x + cw + 1} ${floorY - 0.4} L${x + cw + 3} ${floorY + 2} L${x} ${floorY + 2.2} Z`, W, 0.4));
  out.push(thing(rect(x, topY, cw, chH - 1.2), { fill: T.wood, ink: W.ink, w: 0.5, amp: 0.2, mis: W.mis, seed: seed + 'cab', boil: false, hatch: true, hatchColor: W.ink, hatchOp: 0.25 }));
  out.push(thing(rect(x - 1, topY - 1.4, cw + 2, 1.8), { fill: T.woodHi, ink: W.ink, w: 0.45, amp: 0.15, seed: seed + 'ctop', boil: false }));
  // two doors with knobs, one ajar a hair
  out.push(stroke(`M${x + cw / 2} ${topY + 1.2} L${x + cw / 2 + 0.1} ${floorY - 2.4}`, W.ink, { w: 0.35, op: 0.7, seed: seed + 'door', boil: false }));
  out.push(blob(circleD(x + cw / 2 - 1.4, topY + 6, 0.5) + circleD(x + cw / 2 + 1.5, topY + 6.2, 0.5), T.brass, { seed: seed + 'knob', boil: false }));
  for (const fx of [x + 1.5, x + cw - 3]) out.push(thing(P([[fx, floorY - 1.4], [fx + 1.5, floorY - 1.4], [fx + 1.2, floorY], [fx + 0.3, floorY]]), { fill: T.woodLo, ink: W.ink, w: 0.3, amp: 0.05, seed: seed + 'cf' + fx, boil: false }));
  // the radio: rounded wooden case, cream grille cloth, a dial with a glowing window
  const rx = x + 2.5, ry = topY - 1.4, rw = 13, rh = 9;
  out.push(thing(`M${rx} ${ry} L${rx + 0.2} ${ry - rh + 3} C${rx + 0.4} ${ry - rh - 0.4} ${rx + rw - 0.6} ${ry - rh - 0.6} ${rx + rw - 0.2} ${ry - rh + 2.6} L${rx + rw} ${ry} Z`, { fill: '#7A4630', ink: W.ink, w: 0.45, amp: 0.12, mis: W.mis, seed: seed + 'radio' }));
  out.push(thing(`M${rx + 1.5} ${ry - 1.2} L${rx + 1.6} ${ry - rh + 3.2} C${rx + 1.8} ${ry - rh + 1.2} ${rx + 7.4} ${ry - rh + 1} ${rx + 7.6} ${ry - rh + 3.2} L${rx + 7.6} ${ry - 1.2} Z`, { fill: '#D9C29A', ink: W.ink, w: 0.3, amp: 0.06, seed: seed + 'grille' }));
  out.push(stroke(`M${rx + 2.4} ${ry - 5} L${rx + 6.8} ${ry - 5.1} M${rx + 2.3} ${ry - 3.6} L${rx + 6.9} ${ry - 3.6} M${rx + 2.4} ${ry - 2.3} L${rx + 6.8} ${ry - 2.4}`, '#7A4630', { w: 0.25, op: 0.7, seed: seed + 'gl' }));
  out.push(thing(rr(rx + 8.6, ry - 6.4, 3.2, 2.2, 0.6), { fill: '#FFD98A', ink: W.ink, w: 0.25, amp: 0.04, seed: seed + 'dial' }));
  out.push(stroke(`M${rx + 9.9} ${ry - 6.1} L${rx + 10.1} ${ry - 4.5}`, '#C8553D', { w: 0.2, seed: seed + 'needle' }));
  out.push(blob(circleD(rx + 9.4, ry - 2.3, 0.8) + circleD(rx + 11.3, ry - 2.2, 0.75), '#3A1E12', { seed: seed + 'knobs' }));
  // music: two hand-drawn notes drifting out (they boil, quietly)
  out.push(stroke(`M${rx + 13.6} ${ry - 9} L${rx + 13.7} ${ry - 12.4} L${rx + 15.4} ${ry - 12.8} L${rx + 15.4} ${ry - 9.6}`, T.cream, { w: 0.3, op: 0.4, amp: 0.2, seed: seed + 'n1' }));
  out.push(blob(ellipseD(rx + 13.1, ry - 9, 0.7, 0.5) + ellipseD(rx + 14.9, ry - 9.6, 0.7, 0.5), T.cream, { seed: seed + 'n2', op: 0.4 }));
  // the pothos in a tin, trailing over the cabinet edge
  const px = x + cw - 6, py = topY - 1.4;
  const vine = `M${px + 1.6} ${py - 3} C${px + 5} ${py - 2} ${px + 7} ${py + 2} ${px + 6.4} ${py + 7} C${px + 6} ${py + 10} ${px + 7.2} ${py + 12} ${px + 6.6} ${py + 14.5}`;
  out.push(stroke(vine, T.leaf, { w: 0.35, seed: seed + 'vine' }));
  const vr = rng(hashSeed(seed + 'pv'));
  let leaves = '';
  const leaf = (lx: number, ly: number, a: number, s: number) => {
    const ex = lx + Math.cos(a) * 3.0 * s, ey = ly + Math.sin(a) * 3.0 * s, nx = -Math.sin(a) * 2.0 * s, ny = Math.cos(a) * 2.0 * s;
    return `M${r2(lx)} ${r2(ly)} C${r2(lx + nx)} ${r2(ly + ny)} ${r2(ex + nx * 0.3)} ${r2(ey + ny * 0.3)} ${r2(ex)} ${r2(ey)} C${r2(ex - nx * 0.3)} ${r2(ey - ny * 0.3)} ${r2(lx - nx)} ${r2(ly - ny)} ${r2(lx)} ${r2(ly)}Z `;
  };
  for (const [lx, ly, a] of [[px + 4.5, py - 1.8, 0.2], [px + 6.6, py + 2, 1.1], [px + 6.2, py + 6, 2.2], [px + 6.6, py + 9.6, 0.6], [px + 6.8, py + 13, 1.9], [px - 0.5, py - 5, -2.2], [px + 1.4, py - 6.6, -1.2], [px + 3.4, py - 5.4, -0.4]] as const) leaves += leaf(lx, ly, a + (vr() - 0.5) * 0.3, 0.9 + vr() * 0.3);
  out.push(thing(leaves, { fill: T.leafHi, ink: W.ink, w: 0.28, amp: 0.08, seed: seed + 'pl', wave: [2, 5] }));
  out.push(thing(P([[px - 1.6, py - 4], [px + 3.4, py - 4.1], [px + 3.1, py], [px - 1.3, py]]), { fill: T.blue, ink: W.ink, w: 0.35, amp: 0.08, mis: [-0.25, 0.25], seed: seed + 'pot' }));
  return out;
}
/** A framed photo of the gang (three blobs and the amber dot), hung slightly crooked. */
export function photo(cx: number, cy: number, s: number, seed: string, rot = -3): Item[] {
  const fw = 9 * s, fh = 7 * s;
  return [
    stroke(`M${cx - fw * 0.3} ${cy - fh / 2} L${cx} ${cy - fh / 2 - 3 * s} L${cx + fw * 0.3} ${cy - fh / 2}`, W.ink, { w: 0.25, op: 0.8, seed: seed + 'cord', boil: false }),
    g(`transform="rotate(${rot} ${cx} ${cy})"`,
      thing(rect(cx - fw / 2, cy - fh / 2, fw, fh), { fill: T.woodHi, ink: W.ink, w: 0.45, amp: 0.1, seed: seed + 'fr', boil: false }),
      thing(rect(cx - fw / 2 + 1.1 * s, cy - fh / 2 + 1.1 * s, fw - 2.2 * s, fh - 2.2 * s), { fill: '#3B2A5E', ink: W.ink, w: 0.25, amp: 0.05, seed: seed + 'pic', boil: false }),
      // three little silhouettes squeezed together for the photo: a circle, a triangle, an arch
      flat(circleD(cx - 1.9 * s, cy + 0.9 * s, 1.15 * s), '#B04A5A', { seed: seed + 'p1', amp: 0.05 }),
      flat(P([[cx - 0.2 * s, cy + 2.1 * s], [cx + 0.9 * s, cy - 0.5 * s], [cx + 2.1 * s, cy + 2.1 * s]]), '#2E8A74', { seed: seed + 'p2', amp: 0.05 }),
      flat(archD(cx + 1.9 * s, cy - 0.1 * s, 1.6 * s, 2.2 * s), '#9A90CC', { seed: seed + 'p3', amp: 0.04 }),
      flat(circleD(cx + 0.4 * s, cy - 1.6 * s, 0.45 * s), '#FFC94D', { seed: seed + 'p4', amp: 0.03 }),
    ),
  ];
}
