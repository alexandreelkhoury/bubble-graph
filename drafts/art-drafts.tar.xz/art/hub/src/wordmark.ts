// wordmark.ts — JAMAA hand-lettered: "the three heads" (DESIGN-JAMAA §1.3) drawn by a sign painter.
// Latin JAMAA: each A is a roof without a crossbar, with an amber head centred in its counter (a person under an arch).
// Arabic «جماعة»: Ruq'ah, the nuqta of ج is the same amber head. [native review before shipping]
// Three treatments: sign (primary, dark), party (cut paper), print (ink on paper, riso). Heads are amber in all of them.
import {
  type F3, type Item, HUB, TEXT, writePiece, brush, POLY_SINK, mapPath, bboxOf, blob, circleD, r2, rng, hashSeed,
} from './kit.ts';

type Pt = { x: number; y: number };
// --- centrelines, cap height 10, baseline 0 (y down) ---
const GL: Record<string, { w: number; s: string[] }> = {
  J: { w: 5.6, s: ['M2.4 -10.05 C3.6 -10.1 5.0 -10.2 6.3 -10.0', 'M5.1 -10.0 C5.1 -6.6 5.2 -3.6 4.9 -1.9 C4.6 -0.2 2.6 0.5 1.2 -0.3 C0.5 -0.7 0.2 -1.5 0.3 -2.3'] },
  A: { w: 8.3, s: ['M0.2 0.1 C1.3 -3.3 2.6 -7.0 3.65 -9.4 C3.9 -9.95 4.15 -10.05 4.35 -9.95', 'M4.0 -9.8 C4.35 -9.95 4.7 -9.8 4.95 -9.35 C5.9 -7.0 7.1 -3.4 8.2 0.05'] },
  M: { w: 8.0, s: ['M0.7 0.1 C0.8 -3.4 0.95 -6.7 1.15 -9.9', 'M1.15 -9.9 C2.0 -7.6 3.0 -5.0 3.95 -2.9', 'M3.95 -2.9 C4.9 -5.2 5.9 -7.8 6.8 -10.0', 'M6.8 -10.0 C7.0 -6.8 7.2 -3.3 7.4 0.1'] },
};
const HEAD = { x: 4.3, y: -4.0, r: 1.1 }; // in A-glyph space: centred in the counter at 40 % of cap height

type Laid = { strokes: string[]; heads: Pt[]; w: number; rots: number[]; centers: Pt[]; letterStrokes: string[][] };
function layJamaa(seed: string, o: { track: number; bounce: number; rot: number }): Laid {
  const r = rng(hashSeed(seed));
  let x = 0; const strokes: string[] = [], heads: Pt[] = [], rots: number[] = [], centers: Pt[] = [], letterStrokes: string[][] = [];
  const word = 'JAMAA';
  for (let i = 0; i < word.length; i++) {
    const ch = word[i], gl = GL[ch];
    const by = (r() - 0.5) * 2 * o.bounce, rot = (r() - 0.5) * 2 * o.rot, sc = 1 + (r() - 0.5) * 0.05, sl = -0.05;
    const cx = gl.w / 2, cy = -5;
    const ca = Math.cos((rot * Math.PI) / 180), sa = Math.sin((rot * Math.PI) / 180);
    const f = (px: number, py: number): [number, number] => {
      let X = px + sl * py, Y = py; X -= cx; Y -= cy;
      return [(X * ca - Y * sa) * sc + cx + x, (X * sa + Y * ca) * sc + cy + by];
    };
    const ls = gl.s.map((d) => mapPath(d, f));
    strokes.push(...ls); letterStrokes.push(ls);
    if (ch === 'A') { const [hx, hy] = f(HEAD.x, HEAD.y); heads.push({ x: hx, y: hy }); }
    rots.push(rot); centers.push({ x: x + cx, y: cy + by });
    x += gl.w + o.track;
  }
  return { strokes, heads, w: x - o.track, rots, centers, letterStrokes };
}

// Arabic «جماعة», alef height 10, baseline 0, right → left. Ruq'ah, traced by hand over a Ruq'ah model:
// Arabic «جماعة», alef height 10, baseline 0, right → left. Ruq'ah, traced by hand over a Ruq'ah model:
// the jeem head is a closed hook at the top right, its long diagonal runs down-left into a small medial meem knot,
// the word falls to the baseline at the alef (the Ruq'ah stair). Initial ain is an OPEN cup (mouth to the right,
// never closed, so it cannot read as ق/ف). Ta marbuta rises from the joint and loops back; its two dots stay two dots.
// [native letterer review before shipping]
const AR_JAMAA = [
  // ج initial: the head hook (pen lands at the inner notch, up, across the top, round), then the long diagonal
  'M21.6 -9.3 C21.4 -10.9 22.6 -12.0 24.4 -12.1 C25.8 -12.2 26.6 -11.6 26.2 -10.4 C25.4 -8.4 23.4 -7.2 21.2 -6.3',
  // م medial: a small loop knotted into the diagonal, then the stair down to the alef foot
  'M21.4 -6.4 C20.0 -6.0 18.6 -5.9 17.9 -4.9 C17.2 -3.8 18.1 -2.5 19.5 -2.9 C20.9 -3.3 20.8 -5.2 19.2 -5.4 C17.9 -5.0 17.3 -3.6 16.8 -2.2 C16.2 -1.0 15.2 -0.2 13.8 0.05',
  // ا final: from the top down to the foot it shares with the stair
  'M14.5 -10.6 C14.4 -7.0 14.2 -3.4 14.0 0.1',
  // ع initial: an open cup, mouth to the right (top jaw → back → lower jaw)
  'M11.6 -6.7 C10.4 -7.5 8.8 -7.3 8.2 -6.0 C7.6 -4.7 8.2 -3.5 9.4 -3.6 C10.2 -3.7 10.9 -4.0 11.7 -4.4',
  // the ain's tail sweeping down-left into the joint
  'M11.4 -4.2 C10.6 -2.2 8.4 -0.7 4.2 0.05',
  // ة final: rises from the joint, over the top, loops back
  'M4.2 0.1 C4.3 -2.4 4.5 -4.8 4.6 -6.6 C4.7 -8.1 3.5 -8.4 2.6 -7.5 C1.6 -6.4 0.9 -4.4 1.2 -3.2 C1.5 -2.0 2.9 -2.0 3.9 -2.8',
  // the two dots of ة, written as two quick flat-pen diamonds
  'M2.0 -10.2 L2.7 -10.4', 'M4.2 -10.8 L4.9 -11.0',
];
const AR_HEAD = { x: 23.4, y: -4.7, r: 1.15 }; // the jeem's nuqta, inside its bowl under the head: the amber head of the brand

// flat brush: the nib angle is the direction of the thinnest stroke. Latin: 45° (up-strokes hairline-ish, down-strokes fat).
// Arabic Ruq'ah: steep pen, the alef thin and the horizontals and down-left diagonals broad.
const BR = { lat: { nib: 45, wMax: 3.0, wMin: 0.45, amp: 0.08 }, ar: { nib: 105, wMax: 2.5, wMin: 0.5, amp: 0.08 } };
const paths = (strokes: string[], o: any, seed: string, f: number) => strokes.map((s) => brush(s, { ...o, seed }, f)).join('');
const lettersF3 = (strokes: string[], o: any, seed: string): F3 => [0, 1, 2].map((f) => paths(strokes, o, seed, f));

/** amber head: a hand-drawn dot (boils with half displacement, per the face rule) */
const head = (p: Pt, r: number, color: string, seed: string) => blob(circleD(p.x, p.y, r), color, { seed, amp: 0.06 });

type Comp = { items: Item[]; bb: { x0: number; y0: number; x1: number; y1: number } };
function bbOfStrokes(strokes: string[]) { return bboxOf(strokes.join('')); }

// ------------------------------------------------------------ treatments ----
type Treat = 'sign' | 'party' | 'print';
function latin(t: Treat, ox: number, oy: number, k: number): Comp {
  const L = layJamaa('jamaa-' + t, { track: t === 'party' ? 1.7 : 1.35, bounce: 0.2, rot: t === 'party' ? 4 : 2.0 });
  const tf = (s: string) => mapPath(s, (x, y) => [ox + x * k, oy + y * k]);
  const strokes = L.strokes.map(tf);
  const heads = L.heads.map((h) => ({ x: ox + h.x * k, y: oy + h.y * k }));
  const items = treat(t, strokes, heads.map((h) => ({ p: h, r: HEAD.r * k })), k, false, L.letterStrokes.map((ls) => ls.map(tf)));
  const bb = bbOfStrokes(strokes);
  return { items, bb: { x0: bb.x0 - 1.6 * k, y0: bb.y0 - 1.6 * k, x1: bb.x1 + 1.6 * k, y1: Math.max(bb.y1, ...heads.map((h) => h.y + HEAD.r * k)) + 1.6 * k } };
}
function arabic(t: Treat, ox: number, oy: number, k: number): Comp {
  const tf = (s: string) => mapPath(s, (x, y) => [ox + x * k, oy + y * k]);
  const strokes = AR_JAMAA.map(tf);
  const hp = { x: ox + AR_HEAD.x * k, y: oy + AR_HEAD.y * k };
  const items = treat(t, strokes, [{ p: hp, r: AR_HEAD.r * k }], k, true, [strokes]);
  const bb = bbOfStrokes(strokes);
  return { items, bb: { x0: bb.x0 - 1.6 * k, y0: bb.y0 - 1.6 * k, x1: bb.x1 + 1.6 * k, y1: Math.max(bb.y1, hp.y + AR_HEAD.r * k) + 1.6 * k } };
}


function treat(t: Treat, strokes: string[], heads: { p: Pt; r: number }[], k: number, ar: boolean, letters: string[][]): Item[] {
  const B = ar ? BR.ar : BR.lat;
  const seed = (ar ? 'ar' : 'lat') + t;
  const out: Item[] = [];
  if (t === 'sign') {
    // sign painter: one flat drop shade in ink (offset toward bottom-end), cream letter, amber heads with their own shade
    const so = [0.75 * k, 0.95 * k];
    out.push(lettersF3(strokes, { ...B, k, add: 0.9 }, seed + 'sh').map((d) => `<path d="${d}" fill="${HUB.ink}" transform="translate(${r2(so[0])} ${r2(so[1])})"/>`));
    for (const h of heads) out.push(head({ x: h.p.x + so[0], y: h.p.y + so[1] }, h.r + 0.45 * k, HUB.ink, seed + 'hs' + h.p.x));
    out.push(lettersF3(strokes, { ...B, k }, seed).map((d) => `<path d="${d}" fill="${TEXT}"/>`));
    // brush highlight: the paint is thicker where the brush landed — a few paper ticks on the top-start of stems
    heads.forEach((h, i) => out.push(head(h.p, h.r, HUB.accent, seed + 'h' + i)));
    heads.forEach((h, i) => out.push(blob(circleD(h.p.x - h.r * 0.35, h.p.y - h.r * 0.38, h.r * 0.26), '#FFF4D6', { seed: seed + 'hh' + i, op: 0.85 })));
  } else if (t === 'party') {
    // cut paper: each letter scissored from cream card (straight facets), stuck slightly crooked, paper-lift shadow
    letters.forEach((ls, li) => {
      const polys: Pt[][][] = [[], [], []];
      for (let f = 0; f < 3; f++) {
        POLY_SINK.on = true; POLY_SINK.polys = [];
        for (const s of ls) brush(s, { nib: 30, wMax: 2.6, wMin: 2.2, amp: 0.05, seed: seed + li, k }, f);
        POLY_SINK.on = false;
        polys[f] = POLY_SINK.polys.map((p) => scissor(p, 0.75 * k, rng(hashSeed(seed + li + ':' + f))));
      }
      const d3: F3 = polys.map((ps) => ps.map((p) => 'M' + p.map((q) => `${r2(q.x)} ${r2(q.y)}`).join('L') + 'Z').join(''));
      out.push(d3.map((d) => `<path d="${d}" fill="${HUB.ink}" opacity="0.55" transform="translate(${r2(0.55 * k)} ${r2(0.7 * k)})"/>`));
      out.push(d3.map((d) => `<path d="${d}" fill="${HUB.paper}"/>`));
    });
    heads.forEach((h, i) => {
      const col = HUB.accent; // amber in every variant (player-colour heads stay a proposal: see wordmark-proposal-party-colours)
      const pts = (f: number) => { const r = rng(hashSeed(seed + 'dot' + i + f)); const n = 9; const p: Pt[] = []; for (let j = 0; j < n; j++) { const a = (j / n) * Math.PI * 2 + r() * 0.3; const rr = h.r * 1.1 * (0.93 + r() * 0.12); p.push({ x: h.p.x + Math.cos(a) * rr, y: h.p.y + Math.sin(a) * rr }); } return 'M' + p.map((q) => `${r2(q.x)} ${r2(q.y)}`).join('L') + 'Z'; };
      const d3: F3 = [0, 1, 2].map(pts);
      out.push(d3.map((d) => `<path d="${d}" fill="${HUB.ink}" opacity="0.55" transform="translate(${r2(0.45 * k)} ${r2(0.55 * k)})"/>`));
      out.push(d3.map((d) => `<path d="${d}" fill="${col}"/>`));
    });
  } else {
    // print: two-pass riso on lamp-cream paper — tile-blue pass (misregistered, multiply) under the ink pass
    out.push(lettersF3(strokes, { ...B, k, add: 0.5 }, seed + 'b').map((d) => `<path d="${d}" fill="${HUB.c}" opacity="0.9" style="mix-blend-mode:multiply" transform="translate(${r2(0.55 * k)} ${r2(0.5 * k)})"/>`));
    out.push(lettersF3(strokes, { ...B, k }, seed).map((d) => `<path d="${d}" fill="${HUB.ink}"/>`));
    heads.forEach((h, i) => out.push(head({ x: h.p.x + 0.4 * k, y: h.p.y + 0.35 * k }, h.r * 1.05, HUB.b, seed + 'h' + i)));
  }
  return out;
}
/** Re-cut a smooth outline with scissors: straight facets ~step apart, the odd notch where the blade restarted. */
function scissor(poly: Pt[], step: number, r: () => number): Pt[] {
  const out: Pt[] = [];
  let acc = step;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    acc += Math.hypot(b.x - a.x, b.y - a.y);
    if (acc >= step * (0.7 + r() * 0.6)) { out.push({ x: a.x + (r() - 0.5) * step * 0.08, y: a.y + (r() - 0.5) * step * 0.08 }); acc = 0; }
  }
  return out.length > 3 ? out : poly;
}

// ---------------------------------------------------------------- build ----
function piece(name: string, comps: Comp[], pxW: number, bg: string, pad = 0) {
  const x0 = Math.min(...comps.map((c) => c.bb.x0)) - pad, y0 = Math.min(...comps.map((c) => c.bb.y0)) - pad;
  const x1 = Math.max(...comps.map((c) => c.bb.x1)) + pad, y1 = Math.max(...comps.map((c) => c.bb.y1)) + pad;
  const vbW = x1 - x0, vbH = y1 - y0;
  return writePiece('wordmark', { name, vbX: r2(x0), vbY: r2(y0), vbW: r2(vbW), vbH: r2(vbH), pxW, pxH: Math.round((pxW * vbH) / vbW), items: comps.flatMap((c) => c.items), defs: [], bg });
}
/** a shared ornament between the scripts: a short painted rule with the amber head in its middle */
function sharedOrn(t: Treat, cx: number, cy: number, len: number, vertical: boolean, k: number): Comp {
  const ink = t === 'print' ? HUB.ink : TEXT;
  const d = vertical ? `M${cx} ${cy - len / 2} C${cx + 0.3 * k} ${cy - len / 6} ${cx - 0.2 * k} ${cy + len / 6} ${cx + 0.1 * k} ${cy + len / 2}` : `M${cx - len / 2} ${cy} C${cx - len / 6} ${cy - 0.3 * k} ${cx + len / 6} ${cy + 0.2 * k} ${cx + len / 2} ${cy - 0.1 * k}`;
  const gap = 2.2 * k;
  const a = vertical ? [`M${cx} ${cy - len / 2} L${cx + 0.1 * k} ${cy - gap}`, `M${cx + 0.05 * k} ${cy + gap} L${cx + 0.1 * k} ${cy + len / 2}`] : [`M${cx - len / 2} ${cy + 0.1 * k} L${cx - gap} ${cy}`, `M${cx + gap} ${cy} L${cx + len / 2} ${cy - 0.1 * k}`];
  void d;
  const items: Item[] = [];
  const o = { nib: vertical ? 0 : 90, wMax: 0.9, wMin: 0.35, amp: 0.05, k };
  if (t === 'sign') items.push(lettersF3(a, { ...o, add: 0.6 }, 'ornsh').map((p) => `<path d="${p}" fill="${HUB.ink}" transform="translate(${r2(0.75 * k)} ${r2(0.95 * k)})"/>`));
  items.push(lettersF3(a, o, 'orn' + t).map((p) => `<path d="${p}" fill="${t === 'party' ? HUB.paper : ink}" opacity="${t === 'print' ? 0.85 : 0.9}"/>`));
  if (t === 'sign') items.push(head({ x: cx + 0.75 * k, y: cy + 0.95 * k }, 1.0 * k + 0.45 * k, HUB.ink, 'ornhs'));
  items.push(head({ x: cx, y: cy }, 1.0 * k, t === 'print' ? HUB.b : HUB.accent, 'ornh' + t));
  const L = len / 2;
  return { items, bb: vertical ? { x0: cx - 2 * k, y0: cy - L, x1: cx + 2 * k, y1: cy + L } : { x0: cx - L, y0: cy - 2 * k, x1: cx + L, y1: cy + 2 * k } };
}
export function buildWordmarks() {
  const BG: Record<Treat, string> = { sign: '#2B1650', party: '#2B1650', print: '#FFF1DC' };
  const arBB = bboxOf(AR_JAMAA.join(''));
  for (const t of ['sign', 'party', 'print'] as Treat[]) {
    const lat = latin(t, 0, 0, 10);
    piece(`wordmark-${t}-latin`, [lat], 1000, BG[t], 6);
    const ar = arabic(t, 0, 0, 10);
    piece(`wordmark-${t}-arabic`, [ar], 1000, BG[t], 6);
    // Bilingual lockups: one composition, equal visual mass. The Arabic is drawn at 1.0× (its alef = Latin cap
    // height; the jeem head rises above like a sign-painter's flourish), both on one baseline.
    // Side by side: Latin left, Arabic right — each script starts from its own outer edge, so neither is a tag.
    {
      const latC = latin(t, 0, 0, 10);
      const gap = 92;
      const ornX = latC.bb.x1 + gap * 0.42;
      const orn = sharedOrn(t, ornX, -50, 84, true, 10);
      const arK = 10.6; // a hair bigger: Arabic letterforms carry less ink per unit of width
      const arC = arabic(t, ornX + gap * 0.58 - arBB.x0 * arK, 0, arK);
      piece(`wordmark-${t}-bilingual`, [latC, orn, arC], 1100, BG[t], 8);
    }
    // Stacked, Arabic first (AR-first contexts): Arabic on top at equal mass, shared rule + head, Latin below.
    // Stacked, Latin first (EN/FR/ES contexts): the mirror.
    for (const first of ['ar', 'lat'] as const) {
      const latK = 10, arK = 12.6; // matched by painted area, not by width
      const top0 = first === 'ar' ? arabic(t, 0, 0, arK) : latin(t, 0, 0, latK);
      const cx = (top0.bb.x0 + top0.bb.x1) / 2;
      const ruleY = top0.bb.y1 + 14;
      const orn = sharedOrn(t, cx, ruleY, 240, false, 10);
      let bot: Comp;
      if (first === 'ar') {
        const lat0 = latin(t, 0, 0, latK);
        bot = latin(t, cx - (lat0.bb.x0 + lat0.bb.x1) / 2, ruleY + 14 - lat0.bb.y0, latK);
      } else {
        const ar0 = arabic(t, 0, 0, arK);
        bot = arabic(t, cx - (ar0.bb.x0 + ar0.bb.x1) / 2, ruleY + 14 - ar0.bb.y0, arK);
      }
      piece(`wordmark-${t}-bilingual-stack-${first}`, [top0, orn, bot], 820, BG[t], 8);
    }
  }
}
