// wordmark.ts — JAMAA hand-lettered: "the three heads" (DESIGN-JAMAA §1.3) drawn by a sign painter.
// Latin JAMAA: each A is a roof without a crossbar, with an amber head centred in its counter (a person under an arch).
// Arabic «جماعة»: Ruq'ah, the nuqta of ج is the same amber head. [native review before shipping]
// Three treatments: sign (primary, dark), party (cut paper), print (ink on paper, riso). Heads are amber in all of them.
import fs from 'node:fs';
import path from 'node:path';
import {
  type F3, OUT, shotJob, type Item, HUB, TEXT, writePiece, brush, POLY_SINK, mapPath, bboxOf, blob, circleD, r2, rng, hashSeed,
} from './kit.ts';

type Pt = { x: number; y: number };
// --- centrelines, cap height 10, baseline 0 (y down) ---
const GL: Record<string, { w: number; s: string[] }> = {
  J: { w: 5.6, s: ['M2.4 -10.05 C3.6 -10.1 5.0 -10.2 6.3 -10.0', 'M5.1 -10.0 C5.1 -6.6 5.2 -3.6 4.9 -1.9 C4.6 -0.2 2.6 0.5 1.2 -0.3 C0.5 -0.7 0.2 -1.5 0.3 -2.3'] },
  A: { w: 8.3, s: ['M0.2 0.1 C1.3 -3.3 2.6 -7.0 3.65 -9.4 C3.9 -9.95 4.15 -10.05 4.35 -9.95', 'M4.0 -9.8 C4.35 -9.95 4.7 -9.8 4.95 -9.35 C5.9 -7.0 7.1 -3.4 8.2 0.05'] },
  // M: legs splayed and the V stopping at 55 % of cap height so its two counters stay open at 96 px (print read 'ΛΛ')
  M: { w: 9.2, s: ['M0.6 0.1 C0.7 -3.4 0.85 -6.7 1.05 -9.9', 'M1.05 -9.9 C2.1 -8.0 3.4 -6.0 4.6 -4.5', 'M4.6 -4.5 C5.8 -6.1 7.0 -8.0 8.1 -10.0', 'M8.1 -10.0 C8.3 -6.8 8.5 -3.3 8.6 0.1'] },
};
const HEAD = { x: 4.3, y: -4.0, r: 1.1 }; // in A-glyph space: centred in the counter at 40 % of cap height

type Laid = { strokes: string[]; heads: Pt[]; w: number; rots: number[]; centers: Pt[]; letterStrokes: string[][] };
function layJamaa(seed: string, o: { track: number; bounce: number; rot: number }): Laid {
  const r = rng(hashSeed(seed));
  let x = 0; const strokes: string[] = [], heads: Pt[] = [], rots: number[] = [], centers: Pt[] = [], letterStrokes: string[][] = [];
  const word = 'JAMAA';
  for (let i = 0; i < word.length; i++) {
    const ch = word[i], gl = GL[ch];
    const by = (r() - 0.5) * 2 * o.bounce, rot = (r() - 0.5) * 2 * o.rot, sc = 1 + (r() - 0.5) * 0.05, sl = -0.05;
    const cx = gl.w / 2, cy = -5;
    const ca = Math.cos((rot * Math.PI) / 180), sa = Math.sin((rot * Math.PI) / 180);
    const f = (px: number, py: number): [number, number] => {
      let X = px + sl * py, Y = py; X -= cx; Y -= cy;
      return [(X * ca - Y * sa) * sc + cx + x, (X * sa + Y * ca) * sc + cy + by];
    };
    const ls = gl.s.map((d) => mapPath(d, f));
    strokes.push(...ls); letterStrokes.push(ls);
    if (ch === 'A') { const [hx, hy] = f(HEAD.x, HEAD.y); heads.push({ x: hx, y: hy }); }
    rots.push(rot); centers.push({ x: x + cx, y: cy + by });
    x += gl.w + o.track;
  }
  return { strokes, heads, w: x - o.track, rots, centers, letterStrokes };
}

// Arabic «جماعة», alef height 10, baseline 0, right → left. Ruq'ah, traced by hand over a Ruq'ah model:
// Arabic «جماعة», alef height 10, baseline 0, right → left. Ruq'ah, traced by hand over a Ruq'ah model:
// the jeem head is a closed hook at the top right, its long diagonal runs down-left into a small medial meem knot,
// the word falls to the baseline at the alef (the Ruq'ah stair). Initial ain is an OPEN cup (mouth to the right,
// never closed, so it cannot read as ق/ف). Ta marbuta rises from the joint and loops back; its two dots stay two dots.
// [native letterer review before shipping]
const AR_JAMAA = [
  // ج initial: the head hook (pen lands at the inner notch, up, across the top, round), then the long diagonal
  'M21.6 -9.3 C21.4 -10.9 22.6 -12.0 24.4 -12.1 C25.8 -12.2 26.6 -11.6 26.2 -10.4 C25.4 -8.4 23.4 -7.2 21.2 -6.3',
  // م medial: a small loop knotted into the diagonal, then the stair down to the alef foot
  'M21.4 -6.4 C20.0 -6.0 18.6 -5.9 17.9 -4.9 C17.2 -3.8 18.1 -2.5 19.5 -2.9 C20.9 -3.3 20.8 -5.2 19.2 -5.4 C17.9 -5.0 17.3 -3.6 16.8 -2.2 C16.2 -1.0 15.2 -0.2 13.8 0.05',
  // ا final: from the top down to the foot it shares with the stair
  'M14.5 -10.6 C14.4 -7.0 14.2 -3.4 14.0 0.1',
  // ع initial: an open cup, mouth to the right (top jaw → back → lower jaw)
  'M12.1 -8.4 C11.6 -9.7 9.6 -10.1 8.4 -8.9 C7.1 -7.5 7.2 -5.0 8.7 -4.1 C9.7 -3.5 10.9 -3.6 12.1 -3.8',
  // the ain's tail sweeping down-left into the joint
  'M11.6 -3.8 C10.8 -1.9 8.4 -0.6 4.2 0.05',
  // ة final: rises from the joint, over the top, loops back
  'M4.2 0.1 C4.3 -2.4 4.5 -4.8 4.6 -6.6 C4.7 -8.1 3.5 -8.4 2.6 -7.5 C1.6 -6.4 0.9 -4.4 1.2 -3.2 C1.5 -2.0 2.9 -2.0 3.9 -2.8',
  // the two dots of ة, written as two quick flat-pen diamonds
  'M2.0 -10.2 L2.7 -10.4', 'M4.2 -10.8 L4.9 -11.0',
  // the nuqta of ج: a letter-coloured flat-pen diamond tucked in the jeem's bowl, right under the head stroke
  // (as in the Ruq'ah model), close enough that it belongs to ج and cannot be read as a loose mark: ج, never ح
  'M23.3 -4.75 L24.0 -4.95',
];
// The brand's amber head is a SEPARATE ornament, never a nuqta (§7.3): it sits as a full stop after the word
// (left of ة, on the baseline), so «جماعة.» reads like a sign that ends with a dot of lamp light.
const AR_HEAD = { x: -1.9, y: -1.05, r: 1.05 };

// flat brush: the nib angle is the direction of the thinnest stroke. Latin: 45° (up-strokes hairline-ish, down-strokes fat).
// Arabic Ruq'ah: steep pen, the alef thin and the horizontals and down-left diagonals broad.
const BR = { lat: { nib: 45, wMax: 3.0, wMin: 0.45, amp: 0.08 }, ar: { nib: 100, wMax: 2.25, wMin: 0.32, amp: 0.08 } };
const paths = (strokes: string[], o: any, seed: string, f: number) => strokes.map((s) => brush(s, { ...o, seed }, f)).join('');
const lettersF3 = (strokes: string[], o: any, seed: string): F3 => [0, 1, 2].map((f) => paths(strokes, o, seed, f));

/** amber head: a hand-drawn dot (boils with half displacement, per the face rule) */
const head = (p: Pt, r: number, color: string, seed: string) => blob(circleD(p.x, p.y, r), color, { seed, amp: 0.06 });

type Comp = { items: Item[]; bb: { x0: number; y0: number; x1: number; y1: number } };
function bbOfStrokes(strokes: string[]) { return bboxOf(strokes.join('')); }

// ------------------------------------------------------------ treatments ----
type Treat = 'sign' | 'party' | 'print';
function latin(t: Treat, ox: number, oy: number, k: number): Comp {
  const L = layJamaa('jamaa-' + t, { track: t === 'party' ? 1.7 : 1.35, bounce: 0.2, rot: t === 'party' ? 4 : 2.0 });
  const tf = (s: string) => mapPath(s, (x, y) => [ox + x * k, oy + y * k]);
  const strokes = L.strokes.map(tf);
  const heads = L.heads.map((h) => ({ x: ox + h.x * k, y: oy + h.y * k }));
  const items = treat(t, strokes, heads.map((h) => ({ p: h, r: HEAD.r * k })), k, false, L.letterStrokes.map((ls) => ls.map(tf)));
  const bb = bbOfStrokes(strokes);
  return { items, bb: { x0: bb.x0 - 1.6 * k, y0: bb.y0 - 1.6 * k, x1: bb.x1 + 1.6 * k, y1: Math.max(bb.y1, ...heads.map((h) => h.y + HEAD.r * k)) + 1.6 * k } };
}
function arabic(t: Treat, ox: number, oy: number, k: number): Comp {
  const tf = (s: string) => mapPath(s, (x, y) => [ox + x * k, oy + y * k]);
  const strokes = AR_JAMAA.map(tf);
  const hp = { x: ox + AR_HEAD.x * k, y: oy + AR_HEAD.y * k };
  const items = treat(t, strokes, [{ p: hp, r: AR_HEAD.r * k }], k, true, [strokes]);
  const bb = bbOfStrokes(strokes);
  return { items, bb: { x0: Math.min(bb.x0, hp.x - AR_HEAD.r * k) - 1.6 * k, y0: bb.y0 - 1.6 * k, x1: bb.x1 + 1.6 * k, y1: Math.max(bb.y1, hp.y + AR_HEAD.r * k) + 1.6 * k } };
}


function treat(t: Treat, strokes: string[], heads: { p: Pt; r: number }[], k: number, ar: boolean, letters: string[][]): Item[] {
  const B = ar ? BR.ar : BR.lat;
  const seed = (ar ? 'ar' : 'lat') + t;
  const out: Item[] = [];
  if (t === 'sign') {
    // sign painter: one flat drop shade in ink (offset toward bottom-end), cream letter, amber heads with their own shade
    const so = [0.75 * k, 0.95 * k];
    out.push(lettersF3(strokes, { ...B, k, add: 0.9 }, seed + 'sh').map((d) => `<path d="${d}" fill="${HUB.ink}" transform="translate(${r2(so[0])} ${r2(so[1])})"/>`));
    for (const h of heads) out.push(head({ x: h.p.x + so[0], y: h.p.y + so[1] }, h.r + 0.45 * k, HUB.ink, seed + 'hs' + h.p.x));
    out.push(lettersF3(strokes, { ...B, k }, seed).map((d) => `<path d="${d}" fill="${TEXT}"/>`));
    // brush highlight: the paint is thicker where the brush landed — a few paper ticks on the top-start of stems
    heads.forEach((h, i) => out.push(head(h.p, h.r, HUB.accent, seed + 'h' + i)));
    heads.forEach((h, i) => out.push(blob(circleD(h.p.x - h.r * 0.35, h.p.y - h.r * 0.38, h.r * 0.26), '#FFF4D6', { seed: seed + 'hh' + i, op: 0.85 })));
  } else if (t === 'party') {
    // cut paper: each letter scissored from cream card (straight facets), stuck slightly crooked, paper-lift shadow
    letters.forEach((ls, li) => {
      const polys: Pt[][][] = [[], [], []];
      for (let f = 0; f < 3; f++) {
        POLY_SINK.on = true; POLY_SINK.polys = [];
        for (const s of ls) brush(s, ar ? { nib: 100, wMax: 2.3, wMin: 0.8, amp: 0.05, seed: seed + li, k } : { nib: 45, wMax: 2.9, wMin: 1.5, amp: 0.05, seed: seed + li, k }, f);
        POLY_SINK.on = false;
        polys[f] = POLY_SINK.polys.map((p) => scissor(p, 0.75 * k, rng(hashSeed(seed + li + ':' + f))));
      }
      const d3: F3 = polys.map((ps) => ps.map((p) => 'M' + p.map((q) => `${r2(q.x)} ${r2(q.y)}`).join('L') + 'Z').join(''));
      out.push(d3.map((d) => `<path d="${d}" fill="${HUB.ink}" opacity="0.55" transform="translate(${r2(0.55 * k)} ${r2(0.7 * k)})"/>`));
      out.push(d3.map((d) => `<path d="${d}" fill="${HUB.paper}"/>`));
    });
    heads.forEach((h, i) => {
      const col = HUB.accent; // amber in every variant (player-colour heads stay a proposal: see wordmark-proposal-party-colours)
      const pts = (f: number) => { const r = rng(hashSeed(seed + 'dot' + i + f)); const n = 9; const p: Pt[] = []; for (let j = 0; j < n; j++) { const a = (j / n) * Math.PI * 2 + r() * 0.3; const rr = h.r * 1.1 * (0.93 + r() * 0.12); p.push({ x: h.p.x + Math.cos(a) * rr, y: h.p.y + Math.sin(a) * rr }); } return 'M' + p.map((q) => `${r2(q.x)} ${r2(q.y)}`).join('L') + 'Z'; };
      const d3: F3 = [0, 1, 2].map(pts);
      out.push(d3.map((d) => `<path d="${d}" fill="${HUB.ink}" opacity="0.55" transform="translate(${r2(0.45 * k)} ${r2(0.55 * k)})"/>`));
      out.push(d3.map((d) => `<path d="${d}" fill="${col}"/>`));
    });
  } else {
    // print: two-pass riso on lamp-cream paper — tile-blue pass (misregistered, multiply) under the ink pass
    out.push(lettersF3(strokes, { ...B, k, add: 0.5 }, seed + 'b').map((d) => `<path d="${d}" fill="${HUB.c}" opacity="0.9" style="mix-blend-mode:multiply" transform="translate(${r2(0.55 * k)} ${r2(0.5 * k)})"/>`));
    out.push(lettersF3(strokes, { ...B, k }, seed).map((d) => `<path d="${d}" fill="${HUB.ink}"/>`));
    heads.forEach((h, i) => out.push(head({ x: h.p.x + 0.4 * k, y: h.p.y + 0.35 * k }, h.r * 1.05, HUB.b, seed + 'h' + i)));
  }
  return out;
}
/** Re-cut a smooth outline with scissors: straight facets ~step apart, the odd notch where the blade restarted. */
function scissor(poly: Pt[], step: number, r: () => number): Pt[] {
  const out: Pt[] = [];
  let acc = step;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    acc += Math.hypot(b.x - a.x, b.y - a.y);
    if (acc >= step * (0.7 + r() * 0.6)) { out.push({ x: a.x + (r() - 0.5) * step * 0.08, y: a.y + (r() - 0.5) * step * 0.08 }); acc = 0; }
  }
  return out.length > 3 ? out : poly;
}

// ---------------------------------------------------------------- build ----
function piece(name: string, comps: Comp[], pxW: number, bg: string, pad = 0) {
  const x0 = Math.min(...comps.map((c) => c.bb.x0)) - pad, y0 = Math.min(...comps.map((c) => c.bb.y0)) - pad;
  const x1 = Math.max(...comps.map((c) => c.bb.x1)) + pad, y1 = Math.max(...comps.map((c) => c.bb.y1)) + pad;
  const vbW = x1 - x0, vbH = y1 - y0;
  return writePiece('wordmark', { name, vbX: r2(x0), vbY: r2(y0), vbW: r2(vbW), vbH: r2(vbH), pxW, pxH: Math.round((pxW * vbH) / vbW), items: comps.flatMap((c) => c.items), defs: [], bg });
}
/** a shared ornament between the scripts: a short painted rule with the amber head in its middle */
function sharedOrn(t: Treat, cx: number, cy: number, len: number, vertical: boolean, k: number): Comp {
  const ink = t === 'print' ? HUB.ink : TEXT;
  const d = vertical ? `M${cx} ${cy - len / 2} C${cx + 0.3 * k} ${cy - len / 6} ${cx - 0.2 * k} ${cy + len / 6} ${cx + 0.1 * k} ${cy + len / 2}` : `M${cx - len / 2} ${cy} C${cx - len / 6} ${cy - 0.3 * k} ${cx + len / 6} ${cy + 0.2 * k} ${cx + len / 2} ${cy - 0.1 * k}`;
  const gap = 2.2 * k;
  const a = vertical ? [`M${cx} ${cy - len / 2} L${cx + 0.1 * k} ${cy - gap}`, `M${cx + 0.05 * k} ${cy + gap} L${cx + 0.1 * k} ${cy + len / 2}`] : [`M${cx - len / 2} ${cy + 0.1 * k} L${cx - gap} ${cy}`, `M${cx + gap} ${cy} L${cx + len / 2} ${cy - 0.1 * k}`];
  void d;
  const items: Item[] = [];
  const o = { nib: vertical ? 0 : 90, wMax: 0.9, wMin: 0.35, amp: 0.05, k };
  if (t === 'sign') items.push(lettersF3(a, { ...o, add: 0.6 }, 'ornsh').map((p) => `<path d="${p}" fill="${HUB.ink}" transform="translate(${r2(0.75 * k)} ${r2(0.95 * k)})"/>`));
  items.push(lettersF3(a, o, 'orn' + t).map((p) => `<path d="${p}" fill="${t === 'party' ? HUB.paper : ink}" opacity="${t === 'print' ? 0.85 : 0.9}"/>`));
  if (t === 'sign') items.push(head({ x: cx + 0.75 * k, y: cy + 0.95 * k }, 1.0 * k + 0.45 * k, HUB.ink, 'ornhs'));
  items.push(head({ x: cx, y: cy }, 1.0 * k, t === 'print' ? HUB.b : HUB.accent, 'ornh' + t));
  const L = len / 2;
  return { items, bb: vertical ? { x0: cx - 2 * k, y0: cy - L, x1: cx + 2 * k, y1: cy + L } : { x0: cx - L, y0: cy - 2 * k, x1: cx + L, y1: cy + 2 * k } };
}
export function buildWordmarks() {
  const BG: Record<Treat, string> = { sign: '#2B1650', party: '#2B1650', print: '#FFF1DC' };
  const arBB = bboxOf(AR_JAMAA.join(''));
  for (const t of ['sign', 'party', 'print'] as Treat[]) {
    const lat = latin(t, 0, 0, 10);
    piece(`wordmark-${t}-latin`, [lat], 1000, BG[t], 6);
    const ar = arabic(t, 0, 0, 10);
    piece(`wordmark-${t}-arabic`, [ar], 1000, BG[t], 6);
    // Bilingual lockups: one composition, equal visual mass. The Arabic is drawn at 1.0× (its alef = Latin cap
    // height; the jeem head rises above like a sign-painter's flourish), both on one baseline.
    // Side by side: Latin left, Arabic right — each script starts from its own outer edge, so neither is a tag.
    {
      const latC = latin(t, 0, 0, 10);
      const gap = 92;
      const ornX = latC.bb.x1 + gap * 0.42;
      const orn = sharedOrn(t, ornX, -50, 84, true, 10);
      const arK = 10.6; // a hair bigger: Arabic letterforms carry less ink per unit of width
      const arC = arabic(t, ornX + gap * 0.58 - arBB.x0 * arK, 0, arK);
      piece(`wordmark-${t}-bilingual`, [latC, orn, arC], 1100, BG[t], 8);
    }
    // Stacked, Arabic first (AR-first contexts): Arabic on top at equal mass, shared rule + head, Latin below.
    // Stacked, Latin first (EN/FR/ES contexts): the mirror.
    for (const first of ['ar', 'lat'] as const) {
      const latK = 10, arK = 12.6; // matched by painted area, not by width
      const top0 = first === 'ar' ? arabic(t, 0, 0, arK) : latin(t, 0, 0, latK);
      const cx = (top0.bb.x0 + top0.bb.x1) / 2;
      const ruleY = top0.bb.y1 + 14;
      const orn = sharedOrn(t, cx, ruleY, 240, false, 10);
      let bot: Comp;
      if (first === 'ar') {
        const lat0 = latin(t, 0, 0, latK);
        bot = latin(t, cx - (lat0.bb.x0 + lat0.bb.x1) / 2, ruleY + 14 - lat0.bb.y0, latK);
      } else {
        const ar0 = arabic(t, 0, 0, arK);
        bot = arabic(t, cx - (ar0.bb.x0 + ar0.bb.x1) / 2, ruleY + 14 - ar0.bb.y0, arK);
      }
      piece(`wordmark-${t}-bilingual-stack-${first}`, [top0, orn, bot], 820, BG[t], 8);
    }
  }
  lockupTest();
}

/** §7.4 acceptance: every lockup at 120 dp on the TV (= 240 px on the 1920 canvas) and 96 px on the phone,
 *  per locale (EN/FR/ES lead with Latin, AR with Arabic), on deep and surface. */
export function lockupTest() {
  const dir = path.join(OUT, 'wordmark');
  const LOC: [string, string[]][] = [
    ['EN', ['sign-latin', 'sign-bilingual-stack-lat', 'sign-bilingual']], ['FR', ['sign-latin', 'sign-bilingual-stack-lat', 'sign-bilingual']],
    ['ES', ['sign-latin', 'sign-bilingual-stack-lat', 'sign-bilingual']], ['AR', ['sign-arabic', 'sign-bilingual-stack-ar', 'sign-bilingual']],
  ];
  const cell = (n: string, w: number, bg: string) => `<div style="background:${bg};padding:10px;display:flex;align-items:center;justify-content:center;min-height:${w * 0.8}px"><img src="wordmark-${n}_A.svg" style="width:${w}px"></div>`;
  const rows = LOC.map(([loc, ns]) => `<div style="display:flex;gap:12px;align-items:center;margin-bottom:12px" dir="${loc === 'AR' ? 'rtl' : 'ltr'}"><b style="width:40px;color:#FFF7EC;font:700 16px system-ui">${loc}</b>${ns.map((n) => `<div style="display:flex;flex-direction:column;gap:4px">${cell(n, 240, '#1D1036')}${cell(n, 96, '#3A2266')}<span style="font:600 11px system-ui;color:#B8A8D6">${n}${n.endsWith('bilingual') ? ' (min 200 dp, fails at 120)' : ''}</span></div>`).join('')}</div>`).join('');
  const html = `<html><body style="margin:0;background:#160B26;padding:20px;width:1300px"><h1 style="font:800 18px system-ui;color:#FFF7EC;margin:0 0 6px">Lockup test §7.4: TV 120 dp (240 px @1080p, top of each pair) and phone 96 px (bottom), all four locales</h1><p style="font:500 13px system-ui;color:#B8A8D6;margin:0 0 14px">Rule: the inline bilingual lockup is for ≥ 200 dp only (splash, store art). Under 200 dp use the stack (≥ 120 dp) or the single-script mark of the locale.</p>${rows}</body></html>`;
  fs.writeFileSync(path.join(dir, '.lockup-test.html'), html);
  shotJob({ src: path.join(dir, '.lockup-test.html'), out: path.join(dir, '_lockup-test@1x.png'), w: 1340, h: 0, scale: 1 } as any);
  // Arabic check plate for the native letterer: our Ruq'ah strokes over a Ruq'ah font at the same size
  const ruq = path.join(dir, '../../tmp/ref/ruqaa.woff2');
  const ar = `<html><head><style>@font-face{font-family:R;src:url(file://${ruq})}</style></head><body style="margin:0;background:#FFF1DC;padding:24px;width:1100px;font:600 14px system-ui;color:#160B26">
<h1 style="font:800 18px system-ui;margin:0 0 10px">جماعة: native-letterer review plate (§7.3). Check: ج nuqta inside the bowl · join ع→ة · two dots of ة · brand dot is a full stop, not a nuqta</h1>
<div style="display:flex;gap:30px;align-items:center"><img src="wordmark-print-arabic_A.svg" style="width:520px"><div style="font:120px R;direction:rtl">جماعة.</div></div>
<div style="display:flex;gap:30px;align-items:center;margin-top:10px"><img src="wordmark-print-arabic_A.svg" style="width:96px"><img src="wordmark-sign-arabic_A.svg" style="width:96px;background:#2B1650"><span>96 px</span></div></body></html>`;
  fs.writeFileSync(path.join(dir, '.ar-review.html'), ar);
  shotJob({ src: path.join(dir, '.ar-review.html'), out: path.join(dir, '_ar-review@1x.png'), w: 1150, h: 0, scale: 1 } as any);
}
