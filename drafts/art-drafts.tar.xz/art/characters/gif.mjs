// Renders sheets/boil-strip.html once per boil frame (A, B, C) and assembles an 8 fps GIF.
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
const require = createRequire(import.meta.url);
process.env.PLAYWRIGHT_BROWSERS_PATH = '/opt/pw-browsers';
const { chromium } = require('/home/user/bubble-graph/node_modules/.pnpm/playwright@1.63.0/node_modules/playwright');
const root = new URL('./', import.meta.url).pathname, tmp = root + 'png/.gif/';
(await import('node:fs')).mkdirSync(tmp, { recursive: true });
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 1060, height: 340 }, deviceScaleFactor: 1 });
await p.goto('file://' + root + 'sheets/boil-strip.html');
for (let k = 0; k < 3; k++) {
  await p.evaluate((k) => document.querySelectorAll('svg').forEach((s) => s.setAttribute('data-frame', k)), k);
  await p.screenshot({ path: `${tmp}f${k}.png`, fullPage: true });
}
await b.close();
execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-framerate', '8', '-stream_loop', '7', '-i', `${tmp}f%d.png`, '-vf', 'split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse', '-loop', '0', root + 'png/boil-idle-8fps.gif']);
console.log('gif ok');
