// The 12 shilleh bodies, redrawn by hand inside the hand budget (ART-DIRECTION §3.3):
// canonical DESIGN §5.2 glyphs, but no corner shares a radius, edges carry a slight
// belly, halves differ by 1-3 %, and the mass sits low. Each vertex list below was
// placed by eye; `poly()` only turns [x, y, cornerRadius, edgeBelly] into path data.

type V = [number, number, number, number?]; // x, y, corner radius, belly of the edge that LEAVES this vertex (+ = outward)

function poly(vs: V[]): string {
  const n = vs.length; const P = (i: number) => vs[(i + n) % n];
  const f = (v: number) => +v.toFixed(3);
  const pts: { a: [number, number]; b: [number, number]; c: [number, number] }[] = [];
  for (let i = 0; i < n; i++) {
    const [x, y, r] = P(i), [px, py] = P(i - 1), [nx, ny] = P(i + 1);
    const la = Math.hypot(px - x, py - y), lb = Math.hypot(nx - x, ny - y);
    const rr = Math.min(r, la * 0.45, lb * 0.45);
    pts.push({ a: [x + ((px - x) / la) * rr, y + ((py - y) / la) * rr], c: [x, y], b: [x + ((nx - x) / lb) * rr, y + ((ny - y) / lb) * rr] });
  }
  // orientation for "outward"
  let area = 0; for (let i = 0; i < n; i++) { const p = P(i), q = P(i + 1); area += p[0] * q[1] - q[0] * p[1]; }
  const sgn = area > 0 ? 1 : -1;
  let d = `M${f(pts[0].b[0])} ${f(pts[0].b[1])}`;
  for (let i = 0; i < n; i++) {
    const cur = pts[i], nxt = pts[(i + 1) % n];
    const belly = P(i)[3] ?? 0;
    const mx = (cur.b[0] + nxt.a[0]) / 2, my = (cur.b[1] + nxt.a[1]) / 2;
    const ex = nxt.a[0] - cur.b[0], ey = nxt.a[1] - cur.b[1], el = Math.hypot(ex, ey) || 1;
    // outward normal for a positive-area (clockwise on screen) loop is (ey, -ex)
    const ox = (sgn * ey) / el, oy = (sgn * -ex) / el;
    if (belly) d += `Q${f(mx + ox * belly * 2)} ${f(my + oy * belly * 2)} ${f(nxt.a[0])} ${f(nxt.a[1])}`;
    else d += `L${f(nxt.a[0])} ${f(nxt.a[1])}`;
    const rr = Math.hypot(nxt.c[0] - nxt.a[0], nxt.c[1] - nxt.a[1]);
    if (rr > 0.01) d += `Q${f(nxt.c[0])} ${f(nxt.c[1])} ${f(nxt.b[0])} ${f(nxt.b[1])}`;
  }
  return d + 'Z';
}

export type Body = {
  id: string; color: string; shape: string; glyph: 'ink' | 'cream';
  d: string; face: { x: number; y: number; w: number; h: number };
  hl: string[];           // highlight brush ticks (top-start shoulder), empty on near-white bodies
  ring?: boolean;          // low-contrast colours keep the 24 % cream ring (DESIGN §2.3)
  hand: [number, number]; // hand anchor (end side, ~60 % height), on the contour
  head: [number, number]; // head anchor (top centre)
  faceScale?: number;      // features ×, for the tiny bolt / star faces (size floor)
  fixedFace?: boolean;     // face box already final (no global TV boost)
  sclera?: boolean;        // cream eye whites + ink pupils (plum: the bolt is too thin for solid eyes)
  shade: number;           // how far the hand-cut shadow reaches in from the bottom-end edge (units)
};

export const BODIES: Body[] = [
  { id: 'coral', shade: 4.6, faceScale: 1.18, shape: 'circle', color: '#F0183A', glyph: 'ink',
    // an egg that has sat down: flatter, wider bottom, crown slightly off to the start side
    d: 'M11.7 3.05C16.9 2.85 21.05 6.6 21.15 12.15C21.25 17.4 17.5 21.15 12.2 21.1C6.75 21.05 2.85 17.55 2.9 12.3C2.95 6.9 6.6 3.25 11.7 3.05Z',
    face: { x: 6, y: 7.5, w: 12, h: 9 }, hl: ['M5.85 9.75Q6.0 8.75 6.6 7.95', 'M7.75 7.0Q8.45 6.35 9.45 6.05'], hand: [20.6, 14.2], head: [11.8, 3.0] },
  { id: 'azure', shade: 4.4, faceScale: 1.16, shape: 'square', color: '#478CFF', glyph: 'ink',
    d: poly([[3.6, 3.7, 3.0, 0.05], [20.45, 3.4, 4.1, 0.08], [20.7, 20.6, 3.4, 0.06], [3.35, 20.75, 4.4, -0.05]]),
    face: { x: 6, y: 7.5, w: 12, h: 9 }, hl: ['M5.95 9.6Q5.85 8.6 6.05 7.75', 'M7.2 6.25Q8.0 5.85 9.05 5.95'], hand: [20.7, 13.8], head: [12, 3.5] },
  { id: 'lemon', shade: 2.4, shape: 'star', color: '#FFF04D', glyph: 'ink', ring: true, faceScale: 1.38,
    d: poly([[12.15, 2.3, 0.0, 0.0], [15.0, 8.55, 0.9, -0.12], [21.65, 9.25, 0.0, 0.0], [16.75, 14.05, 0.8, -0.1], [18.15, 20.75, 0.0, 0.0], [12.05, 17.45, 1.1, -0.1], [5.95, 20.55, 0.0, 0.0], [7.3, 14.0, 0.7, -0.12], [2.35, 9.5, 0.0, 0.0], [9.05, 8.6, 1.0, -0.1]]),
    face: { x: 8, y: 9, w: 8, h: 6 }, hl: [], hand: [18.6, 12.6], head: [12.1, 2.4] },
  { id: 'jade', shade: 3.4, faceScale: 1.2, shape: 'triangle', color: '#1FA88A', glyph: 'ink',
    d: poly([[12.1, 2.2, 1.4, 0.06], [21.6, 19.1, 2.3, 0.1], [2.45, 19.2, 1.8, -0.06]]),
    face: { x: 7.0, y: 10.9, w: 10, h: 7.5 }, hl: ['M8.95 11.35Q9.35 10.45 9.95 9.55', 'M10.55 8.45Q10.85 7.75 11.3 7.1'], hand: [18.0, 13.3], head: [12.1, 2.4] },
  { id: 'grape', shade: 3.6, faceScale: 1.14, shape: 'diamond', color: '#7A43FF', glyph: 'cream',
    d: poly([[12.05, 2.05, 1.3, 0.08], [21.95, 12.1, 0.9, 0.12], [11.9, 21.9, 1.6, 0.06], [2.1, 11.85, 1.1, -0.08]]),
    face: { x: 7, y: 8, w: 10, h: 7.5 }, hl: ['M6.7 9.8Q7.1 9.15 7.8 8.75', 'M8.6 7.95Q8.95 7.4 9.45 7.15'], hand: [19.1, 14.8], head: [12.05, 2.2] },
  { id: 'tangerine', shade: 4.2, faceScale: 1.14, shape: 'hexagon', color: '#FF7A1F', glyph: 'ink',
    d: poly([[12.05, 2.45, 1.2, 0.06], [20.35, 7.2, 1.0, 0.1], [20.25, 16.8, 1.5, 0.05], [11.95, 21.5, 1.1, 0.08], [3.7, 16.65, 1.4, -0.05], [3.85, 7.35, 0.8, 0.07]]),
    face: { x: 6.5, y: 7.5, w: 11, h: 8.25 }, hl: ['M5.95 11.55Q5.85 10.6 6.05 9.85', 'M6.95 8.15Q7.65 7.45 8.55 7.05'], hand: [20.3, 13.6], head: [12, 2.6] },
  { id: 'aqua', shade: 2.5, faceScale: 1.3, shape: 'plus', color: '#7BFFF4', glyph: 'ink', ring: true,
    d: poly([[8.9, 3.05, 1.3, 0.05], [15.1, 2.85, 1.6, 0.04], [15.05, 8.9, 0.6, 0.04], [21.15, 9.05, 1.5, 0.06], [21.0, 15.1, 1.2, -0.04], [15.0, 15.0, 0.7, 0.04], [15.15, 21.2, 1.7, 0.06], [8.85, 21.05, 1.2, -0.04], [9.05, 15.05, 0.5, 0.05], [2.9, 14.95, 1.4, 0.05], [3.05, 8.95, 1.1, -0.04], [8.95, 9.05, 0.7, 0.04]]),
    face: { x: 8.5, y: 8.5, w: 7, h: 7 }, hl: [], hand: [21.0, 13.2], head: [12, 3] },
  { id: 'rose', shade: 3.8, faceScale: 1.15, shape: 'drop', color: '#FF96C5', glyph: 'ink',
    d: 'M12.35 1.15C13.4 3.3 19.25 9.0 19.1 13.85C19.0 18.05 15.95 20.95 12.0 20.95C7.9 20.9 4.85 18.1 4.95 13.95C5.05 9.35 10.9 3.5 12.35 1.15Z',
    face: { x: 7, y: 11, w: 10, h: 7.5 }, hl: ['M7.05 13.2Q7.1 12.15 7.65 11.25', 'M8.55 9.85Q8.95 9.15 9.55 8.55'], hand: [19.0, 15.0], head: [12.3, 1.4] },
  { id: 'mint', shade: 2.6, faceScale: 1.12, shape: 'crescent', color: '#BDF5C8', glyph: 'ink', ring: true,
    d: 'M15.1 2.6A9.6 9.35 -4 1 0 21.35 16.45A7.45 7.8 0 0 1 15.1 2.6Z',
    face: { x: 4, y: 9, w: 8, h: 6 }, hl: [], hand: [14.6, 11.0], head: [10.5, 2.9] },
  { id: 'plum', shade: 1.9, shape: 'bolt', color: '#C02A8F', glyph: 'cream', sclera: true, fixedFace: true, faceScale: 1.24,
    // upper segment opened up a hair (inside the 0.35 budget) so the whole face sits on ONE segment
    d: poly([[13.8, 1.85, 0.4, 0.05], [4.6, 13.7, 0.6, 0.06], [11.35, 13.5, 0.5, 0.0], [10.05, 22.2, 0.3, 0.06], [19.25, 9.95, 0.7, 0.05], [13.15, 10.05, 0.45, 0.0]]),
    face: { x: 6.78, y: 8.86, w: 6, h: 4.5 }, hl: ['M10.45 6.55Q10.8 5.75 11.35 5.15', 'M9.35 8.35L9.7 7.75'], hand: [17.4, 12.4], head: [13.5, 2.2] },
  { id: 'sand', shade: 3.4, faceScale: 1.2, shape: 'flower', color: '#E6C486', glyph: 'ink', ring: true,
    d: 'M7.35 7.5A4.7 4.5 0 0 1 16.7 7.3A4.5 4.75 0 0 1 16.55 16.75A4.65 4.6 0 0 1 7.45 16.65A4.6 4.85 0 0 1 7.35 7.5Z',
    face: { x: 7.5, y: 7.5, w: 9, h: 9 }, hl: ['M9.15 6.85Q9.35 5.95 10.25 5.35', 'M5.05 10.85Q5.2 10.05 5.75 9.55'], hand: [21.2, 13.2], head: [12, 2.8] },
  { id: 'lilac', shade: 2.9, faceScale: 1.15, shape: 'arch', color: '#C9BFFF', glyph: 'ink', ring: true,
    d: 'M4.95 20.8L5.05 10.4C5.1 6.35 8.2 3.25 12.1 3.25C15.95 3.3 19.05 6.4 19.05 10.2L19.1 20.7L14.4 20.75L14.35 16.75C14.3 15.65 13.25 14.95 12.05 14.55C10.85 14.95 9.8 15.7 9.75 16.8L9.7 20.8Z',
    face: { x: 7.0, y: 5.2, w: 10, h: 7.5 }, hl: ['M6.95 11.4Q6.9 10.4 7.15 9.7', 'M7.95 8.05Q8.6 7.15 9.6 6.65'], hand: [19.05, 13.8], head: [12, 3.3] },
];
