// Faces (12 × 9 face space, DESIGN-JAMAA §4.2/§4.3) + acting extras in body space.
// Drawn by hand: every expression is authored as path data here; the boil comes later.
// "end" side = +x (LTR); RTL does not mirror characters (TECHNIQUE §3.1).
import type { Body } from './bodies.ts';

export type Col = 'glyph' | 'ink' | 'paper' | 'cream' | 'rose' | 'body' | 'aqua' | 'accent' | 'success' | 'danger' | 'muted' | 'bg' | 'coral' | 'bodyLite' | 'bodyDeep' | 'blushDeep';
export type Prim =
  | { t: 'blob'; d: string; c: Col; o?: number; amp?: number; burst?: boolean }
  | { t: 'stroke'; d: string; w: number; c: Col; o?: number; amp?: number; burst?: boolean }
  | { t: 'sticker'; d: string; c: Col; w?: number; o?: number; shade?: boolean; tip?: string; burst?: boolean }; // filled + ink ring + paper rim (props, bursts, nubs)

export type Trait = {
  persona: string;
  eyeScale: number; gap: number; tilt: number; // tilt: start eye dy (− = higher)
  lid: number;            // idle top lid (0 = open)
  lidSlant?: number;      // + = lid lower toward the inside (cheeky V), − = toward the outside (sleepy/sad)
  bottomLid?: number;     // idle smiling lower lid
  look: [number, number]; // idle gaze
  lean: number;           // idle lean (deg, + = toward end)
  mouth: string;          // idle mouth (face space)
  mouthOpen?: boolean;    // idle mouth drawn as an open grin
  cheeks?: boolean;
  glint?: boolean;
  hl2?: boolean;          // second catch-light (the softie)
};

export const TRAITS: Record<string, Trait> = {
  coral:     { persona: 'the ringleader — loud, sure of herself, first to the party', eyeScale: 1.06, gap: 0, tilt: -0.14, lid: 0, look: [0.15, 0], lean: -2.5, mouth: 'M3.9 6.25Q6.1 8.35 8.4 6.0' },
  azure:     { persona: 'the straight man — deadpan, reliable, unimpressed', eyeScale: 0.9, gap: 0.25, tilt: 0.08, lid: 0.22, lidSlant: 0, look: [0, 0.1], lean: 0, mouth: 'M4.85 6.95Q6.1 7.3 7.35 6.8' },
  lemon:     { persona: 'the show-off — chin up, always on camera', eyeScale: 1.0, gap: -0.1, tilt: -0.12, lid: 0, look: [0.2, -0.45], lean: -3, mouth: 'M4.1 6.3Q6.0 8.0 8.0 6.25', glint: true },
  jade:      { persona: 'the calm one — sleepy-content, unbothered, wise', eyeScale: 1.0, gap: 0.1, tilt: -0.1, lid: 0.42, lidSlant: -0.12, look: [0, 0.15], lean: 0, mouth: 'M4.7 6.75Q6.0 7.45 7.35 6.7' },
  grape:     { persona: 'the schemer — one eye always narrowed, a plan forming', eyeScale: 1.0, gap: 0, tilt: -0.18, lid: 0.12, lidSlant: 0.18, look: [-0.35, 0], lean: 2, mouth: 'M4.6 6.95Q6.6 7.45 7.85 6.35' },
  tangerine: { persona: 'the hype — can’t sit still, eyes wide, grin open', eyeScale: 1.16, gap: -0.15, tilt: -0.1, lid: 0, look: [0, -0.1], lean: 3.5, mouth: 'M4.3 5.95Q6.0 6.1 7.75 5.9', mouthOpen: true },
  aqua:      { persona: 'the sweetheart — helpful, wide-eyed, blushes easily', eyeScale: 0.96, gap: 0.45, tilt: -0.08, lid: 0, look: [0, 0.15], lean: 0, mouth: 'M5.1 6.85Q6.0 7.55 6.95 6.85', cheeks: true },
  rose:      { persona: 'the softie — big glassy eyes, feels everything', eyeScale: 1.14, gap: 0.05, tilt: -0.12, lid: 0, look: [0, 0.05], lean: -1, mouth: 'M5.15 6.9Q6.05 7.5 6.95 6.85', cheeks: true, hl2: true },
  mint:      { persona: 'the dreamer — head in the clouds, gazing at the opening', eyeScale: 0.98, gap: 0, tilt: -0.15, lid: 0.1, lidSlant: -0.1, look: [0.55, -0.6], lean: -2, mouth: 'M5.3 6.85Q6.1 7.25 6.85 6.8' },
  plum:      { persona: 'the troublemaker — zippy, cheeky, already up to something', eyeScale: 1.83, gap: -0.45, tilt: 1.1, lid: 0.14, lidSlant: 0.3, look: [0.3, 0], lean: 4, mouth: 'M4.3 6.4Q6.1 7.9 7.9 5.9' },
  sand:      { persona: 'the host — “tfaddalo!”, warm smiling eyes, feeds everyone', eyeScale: 1.0, gap: 0.1, tilt: -0.1, lid: 0, bottomLid: 0.3, look: [0, 0], lean: -1, mouth: 'M3.95 6.4Q6.0 8.0 8.05 6.45', cheeks: true },
  lilac:     { persona: 'the doorkeeper — calm, knowing, a little mysterious', eyeScale: 0.96, gap: 0.3, tilt: -0.1, lid: 0.2, lidSlant: -0.05, look: [-0.1, 0], lean: 0, mouth: 'M4.9 6.6Q6.2 7.45 7.4 6.5' },
};

// ------------------------------------------------------------ helpers ----
const f = (v: number) => +v.toFixed(3);
/** An eye as a polygon (sampled ellipse, cut by an upper lid line and an optional lower lid). */
export function eye(cx: number, cy: number, rx: number, ry: number, o: { top?: number; slant?: number; inner?: 1 | -1; bot?: number } = {}): string {
  const N = 28; const pts: [number, number][] = [];
  const top = o.top ?? 0, slant = o.slant ?? 0, inner = o.inner ?? 1, bot = o.bot ?? 0;
  // lid line: y = y0 + m*(x-cx); inner side (toward the face centre) lower when slant > 0
  const y0 = cy - ry + 2 * ry * top, m = (slant * 2 * ry) / (2 * rx) * inner;
  const yb = cy + ry - 2 * ry * bot;
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    let x = cx + rx * Math.cos(a), y = cy + ry * Math.sin(a);
    const lid = y0 + m * (x - cx);
    if (top > 0 && y < lid) y = lid;
    if (bot > 0 && y > yb) y = yb - (y - yb) * 0.35; // smiling lower lid bows upward
    pts.push([x, y]);
  }
  return 'M' + pts.map(([x, y]) => `${f(x)} ${f(y)}`).join('L') + 'Z';
}
const ell = (cx: number, cy: number, rx: number, ry: number) => eye(cx, cy, rx, ry);
function star4(cx: number, cy: number, r: number, rot = 0): string {
  const pts: string[] = [];
  for (let i = 0; i < 8; i++) {
    const a = rot + (i * Math.PI) / 4 - Math.PI / 2, rr = i % 2 ? r * 0.36 : r * (i === 0 ? 1.05 : i === 4 ? 0.95 : 1);
    pts.push(`${f(cx + rr * Math.cos(a))} ${f(cy + rr * Math.sin(a))}`);
  }
  return 'M' + pts.join('L') + 'Z';
}
/** Half-ellipse open mouth with a flat (slightly tilted) top. */
function openMouth(cx: number, top: number, w: number, h: number, tilt = 0): string {
  const N = 14, pts: string[] = [];
  for (let i = 0; i <= N; i++) { const a = (i / N) * Math.PI; pts.push(`${f(cx + (w / 2) * Math.cos(a))} ${f(top + h * Math.sin(a) + tilt * Math.cos(a))}`); }
  return 'M' + pts.join('L') + 'Z';
}
function tongue(cx: number, top: number, w: number, h: number): string {
  // the bottom of the open mouth: a soft lump, drawn inside the mouth
  const N = 10, pts: string[] = [];
  for (let i = 0; i <= N; i++) { const a = (i / N) * Math.PI; pts.push(`${f(cx + (w / 2) * Math.cos(a))} ${f(top + h - (h * 0.42) + h * 0.42 * Math.sin(a))}`); }
  pts.push(`${f(cx - w / 2 + 0.2)} ${f(top + h * 0.55)}`);
  pts.push(`${f(cx + w / 2 - 0.2)} ${f(top + h * 0.6)}`);
  return 'M' + pts.join('L') + 'Z';
}

export type Ctx = { B: Body; T: Trait; bw: number; bh: number; bb: { x0: number; y0: number; x1: number; y1: number; cx: number; cy: number }; k: number; eyeMin: number;
  edge?: (y: number, dir: 1 | -1) => [number, number]; eyeY?: number };

export type Acting = {
  face: Prim[];            // face space
  body: Prim[];            // body space, in front, moves with the rig
  behind: Prim[];          // body space, behind the body (nubs)
  free: Prim[];            // body space, not rigged (dashed lines, puffs, confetti that floats)
  rig: { lean: number; squash: number; y: number };
  rigF?: { lean?: number; squash?: number; y?: number }[]; // per boil frame: shakes, sags, trembles (12 fps acting)
  dim?: boolean;           // away: 60 % + desaturated
  shadowScale?: number;
};

/** Eye scale after the TV floor (eye ≥ EYE_MIN_RY body units tall); plum's sclera eyes are sized by hand. */
const eyeS = (c: Ctx, scale = 1) => (c.B.fixedFace ? c.T.eyeScale : Math.max(c.T.eyeScale, c.eyeMin)) * scale;
/** A pupil ellipse cut by the same lid line as its sclera. */
function pupil(px: number, py: number, pr: number, sc: { cx: number; cy: number; rx: number; ry: number; top: number; slant: number; inner: 1 | -1 }): string {
  const y0 = sc.cy - sc.ry + 2 * sc.ry * sc.top, m = ((sc.slant * 2 * sc.ry) / (2 * sc.rx)) * sc.inner;
  const pts: string[] = [];
  for (let i = 0; i < 22; i++) {
    const a = (i / 22) * Math.PI * 2; let x = px + pr * Math.cos(a), y = py + pr * 1.12 * Math.sin(a);
    const lid = y0 + m * (x - sc.cx) + 0.05; if (sc.top > 0 && y < lid) y = lid;
    pts.push(`${f(x)} ${f(y)}`);
  }
  return 'M' + pts.join('L') + 'Z';
}
function eyes(c: Ctx, o: { look?: [number, number]; top?: number; slant?: number; bot?: number; scale?: number; hl?: boolean } = {}): Prim[] {
  const { T, B } = c;
  const s = eyeS(c, o.scale), [lx, ly] = o.look ?? [0, 0];
  const L = { x: 3.8 - T.gap / 2 + (B.sclera ? 0 : lx), y: 3.6 + T.tilt + (B.sclera ? 0 : ly) }, R = { x: 8.2 + T.gap / 2 + (B.sclera ? 0 : lx), y: 3.6 + (B.sclera ? 0 : ly) };
  if (B.sclera) {
    // cream eye-whites with an ink rim, ink pupils that do the looking: readable on the thin bolt
    const out: Prim[] = [];
    for (const [e, k, inner] of [[L, 1, 1], [R, 1.05, -1]] as const) {
      const rx = 1.1 * s * k, ry = 1.45 * s * k, top = o.top ?? 0, slant = o.slant ?? 0;
      out.push({ t: 'blob', d: eye(e.x, e.y, rx + 0.42, ry + 0.42, { top: top * 0.9, slant, inner, bot: o.bot }), c: 'ink' });
      out.push({ t: 'blob', d: eye(e.x, e.y, rx, ry, { top, slant, inner, bot: o.bot }), c: 'cream' });
      const pr = rx * 0.6, px = e.x + Math.max(-1, Math.min(1, lx * 1.1)) * (rx - pr) * 0.95, py = e.y + 0.15 + Math.max(-1, Math.min(1, ly * 1.1)) * (ry - pr * 1.12) * 0.9;
      out.push({ t: 'blob', d: pupil(px, py, pr, { cx: e.x, cy: e.y, rx, ry, top, slant, inner }), c: 'ink', amp: 0.05 });
      if (top < 0.45) out.push({ t: 'blob', d: ell(px + pr * 0.38, py - pr * 0.42, pr * 0.3, pr * 0.32), c: 'cream', amp: 0.02 });
    }
    return out;
  }
  const out: Prim[] = [
    { t: 'blob', d: eye(L.x, L.y, 1.1 * s, 1.45 * s, { top: o.top, slant: o.slant, inner: 1, bot: o.bot }), c: 'glyph' },
    { t: 'blob', d: eye(R.x, R.y, 1.1 * s * 1.04, 1.45 * s * 1.04, { top: o.top, slant: o.slant, inner: -1, bot: o.bot }), c: 'glyph' },
  ];
  if (B.glyph === 'ink' && o.hl !== false) {
    const hy = (o.top ?? 0) > 0.3 ? 0.15 : -0.45;
    out.push({ t: 'blob', d: ell(L.x + 0.36 * s, L.y + hy * s, 0.36 * s, 0.4 * s), c: 'cream', amp: 0.02 });
    out.push({ t: 'blob', d: ell(R.x + 0.38 * s, R.y + hy * s, 0.37 * s, 0.41 * s), c: 'cream', amp: 0.02 });
    if (T.hl2) {
      out.push({ t: 'blob', d: ell(L.x - 0.35 * s, L.y + 0.55 * s, 0.17 * s, 0.17 * s), c: 'cream', amp: 0.01 });
      out.push({ t: 'blob', d: ell(R.x - 0.35 * s, R.y + 0.55 * s, 0.17 * s, 0.17 * s), c: 'cream', amp: 0.01 });
    }
  }
  return out;
}
/** Blush hatch colour per body: the one that still shows on that body at 3 m. */
const BLUSH: Record<string, Col> = { coral: 'rose', azure: 'rose', lemon: 'coral', jade: 'rose', grape: 'rose', tangerine: 'blushDeep', aqua: 'coral', rose: 'blushDeep', mint: 'coral', plum: 'rose', sand: 'blushDeep', lilac: 'coral' };
const cheeks = (c: Ctx, big = false): Prim[] => {
  // 2–4 short hatch strokes per cheek (§8.3 shy), heavier and longer when it acts
  const col = BLUSH[c.B.id] ?? 'rose';
  const o = big ? 0.95 : 0.8, n = big ? 4 : 3, w = big ? 0.62 : 0.42, len = big ? 1.35 : 1.05;
  const out: Prim[] = [];
  for (const [cx, cy] of [[1.85, 5.9], [10.15, 5.8]] as const) {
    for (let i = 0; i < n; i++) { const x = cx - (n - 1) * 0.33 + i * 0.66; out.push({ t: 'stroke', d: `M${f(x - 0.32)} ${f(cy + len / 2 + (i % 2) * 0.08)}L${f(x + 0.3)} ${f(cy - len / 2)}`, w, c: col, o, amp: 0.03 }); }
  }
  return out;
};

// body-space extras -------------------------------------------------------
const top = (c: Ctx) => c.bb.y0;
const endX = (c: Ctx) => c.bb.x1;
function heart(x: number, y: number, s: number): string {
  const p = [[0, 1.0], [-0.9, -0.2], [-2.35, 0.05], [-2.55, 1.55], [-2.2, 3.0], [-0.9, 4.1], [0.05, 4.95], [0.95, 4.05], [2.35, 2.85], [2.55, 1.35], [2.15, 0.05], [0.95, -0.25]];
  const q = p.map(([a, b]) => [x + a * s, y + b * s]);
  return `M${f(q[0][0])} ${f(q[0][1])}C${f(q[1][0])} ${f(q[1][1])} ${f(q[2][0])} ${f(q[2][1])} ${f(q[3][0])} ${f(q[3][1])}C${f(q[4][0])} ${f(q[4][1])} ${f(q[5][0])} ${f(q[5][1])} ${f(q[6][0])} ${f(q[6][1])}C${f(q[7][0])} ${f(q[7][1])} ${f(q[8][0])} ${f(q[8][1])} ${f(q[9][0])} ${f(q[9][1])}C${f(q[10][0])} ${f(q[10][1])} ${f(q[11][0])} ${f(q[11][1])} ${f(q[0][0])} ${f(q[0][1])}Z`;
}
function drop(x: number, y: number, s: number, rot = 0): string {
  const p = [[0, -2.2], [0.5, -1.2], [1.35, -0.2], [1.3, 0.75], [1.2, 1.7], [-1.2, 1.75], [-1.3, 0.7], [-1.35, -0.25], [-0.55, -1.1]];
  const c = Math.cos(rot), sn = Math.sin(rot);
  const q = p.map(([a, b]) => [x + (a * c - b * sn) * s, y + (a * sn + b * c) * s]);
  return `M${f(q[0][0])} ${f(q[0][1])}C${f(q[1][0])} ${f(q[1][1])} ${f(q[2][0])} ${f(q[2][1])} ${f(q[3][0])} ${f(q[3][1])}C${f(q[4][0])} ${f(q[4][1])} ${f(q[5][0])} ${f(q[5][1])} ${f(q[6][0])} ${f(q[6][1])}C${f(q[7][0])} ${f(q[7][1])} ${f(q[8][0])} ${f(q[8][1])} ${f(q[0][0])} ${f(q[0][1])}Z`;
}
function cloud(x: number, y: number): string {
  return `M${x - 3.6} ${y + 1.4}C${x - 4.9} ${y + 1.3} ${x - 4.8} ${y - 0.9} ${x - 3.3} ${y - 0.75}C${x - 3.2} ${y - 2.5} ${x - 0.9} ${y - 2.9} ${x - 0.2} ${y - 1.5}C${x + 0.6} ${y - 3.1} ${x + 3.2} ${y - 2.6} ${x + 3.0} ${y - 0.7}C${x + 4.7} ${y - 0.6} ${x + 4.6} ${y + 1.6} ${x + 3.1} ${y + 1.55}Z`;
}
function bang(x: number, y: number, rot = 0.12): string {
  // a hand-lettered "!": a fat brush wedge
  const p = [[-0.95, -3.4], [1.05, -3.2], [0.45, 0.6], [-0.35, 0.55]];
  const c = Math.cos(rot), sn = Math.sin(rot);
  const q = p.map(([a, b]) => [x + a * c - b * sn, y + a * sn + b * c]);
  return `M${f(q[0][0])} ${f(q[0][1])}Q${f((q[0][0] + q[1][0]) / 2)} ${f(q[0][1] - 0.6)} ${f(q[1][0])} ${f(q[1][1])}L${f(q[2][0])} ${f(q[2][1])}Q${f((q[2][0] + q[3][0]) / 2)} ${f(q[2][1] + 0.35)} ${f(q[3][0])} ${f(q[3][1])}Z`;
}
function spark(x: number, y: number, r: number): string { return star4(x, y, r, 0.1); }
/** Confetti: cut from the character's own colour; little versions of its own shape + paper strips. */
function confetti(c: Ctx, seedPts: [number, number, number, number][]): Prim[] {
  const out: Prim[] = [];
  for (const [x, y, s, rot] of seedPts) {
    if (s > 0) {
      const ca = Math.cos(rot), sa = Math.sin(rot);
      const p = [[-1, -0.55], [1.05, -0.45], [0.95, 0.5], [-1.0, 0.58]].map(([a, b]) => [x + (a * ca - b * sa) * s, y + (a * sa + b * ca) * s]);
      out.push({ t: 'sticker', d: `M${p.map(([a, b]) => `${f(a)} ${f(b)}`).join('L')}Z`, c: 'body', w: 0.38 });
    } else {
      out.push({ t: 'sticker', d: `SHAPE:${x}:${y}:${-s}:${rot}`, c: 'body', w: 0.4 });
    }
  }
  return out;
}
/**
 * A hand: a separate, tapered cut-paper shape floating clear of the body (a visible gap,
 * like a puppet's mitten), never an extrusion of the outline. (ex, ey) is the point on the
 * silhouette it comes from; ang is where it points (deg, 0 = end side, −90 = up).
 */
function hand(c: Ctx, ex: number, ey: number, angDeg: number, len = 1, o: { thumb?: boolean } = {}): Prim {
  const a = (angDeg * Math.PI) / 180, ca = Math.cos(a), sa = Math.sin(a);
  const sc = Math.max(0.85, Math.min(1.15, c.bw / 18)) * len * 1.3;
  // keep the tip under the top of the head
  const off = 1.45 + 1.45 * sc;
  const bx = ex + ca * off, by = ey + sa * off;
  const R = (u: number, v: number) => `${f(bx + (u * ca - v * sa) * sc)} ${f(by + (u * sa + v * ca) * sc)}`;
  // drawn by eye: fat round heel, belly on the underside, slightly hollow top edge, a round tip that tilts up
  let d = `M${R(-1.45, 0.05)}C${R(-1.45, 0.95)} ${R(-0.75, 1.5)} ${R(0.1, 1.42)}C${R(1.3, 1.3)} ${R(2.55, 0.85)} ${R(3.2, 0.45)}C${R(3.85, 0.1)} ${R(3.8, -0.6)} ${R(3.15, -0.62)}C${R(2.4, -0.72)} ${R(1.3, -1.1)} ${R(0.05, -1.46)}C${R(-0.8, -1.52)} ${R(-1.45, -0.88)} ${R(-1.45, 0.05)}Z`;
  if (o.thumb) d = `M${R(-1.45, 0.05)}C${R(-1.45, 0.95)} ${R(-0.75, 1.5)} ${R(0.1, 1.42)}C${R(1.3, 1.32)} ${R(2.45, 0.98)} ${R(3.1, 0.6)}C${R(3.8, 0.22)} ${R(3.85, -0.62)} ${R(3.1, -0.74)}C${R(2.35, -0.84)} ${R(1.6, -0.95)} ${R(1.0, -1.15)}C${R(1.15, -1.9)} ${R(0.55, -2.35)} ${R(0.0, -2.0)}C${R(-0.25, -1.8)} ${R(-0.3, -1.6)} ${R(-0.35, -1.45)}C${R(-1.0, -1.35)} ${R(-1.45, -0.8)} ${R(-1.45, 0.05)}Z`;
  return { t: 'sticker', d, c: 'body', w: 0.85, shade: false };
}
/** Silhouette point on one side at height y (the true edge, not pulled in). */
function edgeAt(c: Ctx, dir: 1 | -1, y: number): [number, number] {
  if (!c.edge) return dir > 0 ? [c.bb.x1, y] : [c.bb.x0, y];
  return c.edge(y, dir);
}
/** Where a hand meets the body: on the silhouette's side at a given height (below the eye line). */
function sideAnchor(c: Ctx, dir: 1 | -1, y?: number): [number, number] {
  const yy = y ?? c.B.hand[1];
  if (!c.edge) return dir > 0 ? [c.B.hand[0], yy] : [2 * c.bb.cx - c.B.hand[0], yy];
  const [x, ey] = c.edge(yy, dir);
  return [x - dir * 0.9, ey];
}
/** A short hand-lettered "z": brush stroke, the diagonal heavier than the bars. */
function zLetter(x: number, y: number, s: number, rot = -0.12): string {
  const ca = Math.cos(rot), sa = Math.sin(rot);
  const p = [[0, 0.1], [0.85, -0.12], [1.75, 0.02], [0.15, 1.9], [1.0, 1.72], [1.95, 1.85]].map(([a, b]) => [x + (a * ca - b * sa) * s, y + (a * sa + b * ca) * s]);
  const P = (i: number) => `${f(p[i][0])} ${f(p[i][1])}`;
  return `M${P(0)}Q${P(1)} ${P(2)}L${P(3)}Q${P(4)} ${P(5)}`;
}
function zz(x: number, y: number, s: number): string {
  return `M${f(x)} ${f(y)}L${f(x + 1.7 * s)} ${f(y - 0.15 * s)}L${f(x + 0.1 * s)} ${f(y + 1.85 * s)}L${f(x + 1.95 * s)} ${f(y + 1.75 * s)}`;
}

// ------------------------------------------------------------ the 13 ----
export const EXPRESSIONS = ['idle', 'think', 'done', 'happy', 'laugh', 'smug', 'shock', 'sad', 'facepalm', 'shy', 'point', 'cheer', 'away'] as const;
export const POSES = ['wave', 'point', 'cheer', 'sneak'] as const;
export type Expr = typeof EXPRESSIONS[number];

const blank = (): Acting => ({ face: [], body: [], behind: [], free: [], rig: { lean: 0, squash: 1, y: 0 } });

/** Everything that is not the face, the body or a hand is a burst: the TV test hides them. */
function markBursts(A: Acting): Acting {
  for (const p of A.face) if (p.t === 'sticker') p.burst = true;
  for (const p of [...A.body, ...A.free]) if (!(p.t === 'sticker' && p.d === 'PALM')) p.burst = true;
  return A;
}

export function acting(expr: Expr, c: Ctx): Acting {
  const { T, B } = c; const A = blank();
  const tx = endX(c), ty = top(c);
  const s = eyeS(c);
  const g = T.gap / 2;
  switch (expr) {
    case 'idle': {
      A.face.push(...eyes(c, { look: T.look, top: T.lid, slant: T.lidSlant, bot: T.bottomLid }));
      if (T.mouthOpen) { A.face.push({ t: 'blob', d: openMouth(6, 5.9, 3.4, 1.5, -0.12), c: 'glyph' }); A.face.push({ t: 'blob', d: tongue(6.15, 5.9, 1.9, 1.35), c: 'rose' }); }
      else A.face.push({ t: 'stroke', d: T.mouth, w: 0.9, c: 'glyph' });
      if (T.cheeks) A.face.push(...cheeks(c));
      if (T.glint) A.body.push({ t: 'blob', d: spark(tx + 1.2, ty + 2.4, 1.5), c: 'paper', o: 0.95 }, { t: 'blob', d: spark(tx + 3.0, ty + 5.0, 0.8), c: 'paper', o: 0.8 });
      A.rig.lean = T.lean;
      break;
    }
    case 'think': {
      // eyes rolled up to the end side, one brow hiked, mouth shoved aside; body leans and stretches up a little
      A.face.push(...eyes(c, { look: [0.95, -0.85], top: Math.min(T.lid, 0.12) }));
      A.face.push({ t: 'stroke', d: `M${7.9 + g} 0.6Q${8.9 + g} -0.35 ${10.1 + g} 0.2`, w: 0.78, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${2.5 - g} 1.7Q${3.6 - g} 1.45 ${4.75 - g} 1.65`, w: 0.7, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M5.6 7.1Q6.7 6.65 8.05 6.75', w: 0.9, c: 'glyph' });
      A.body.push({ t: 'stroke', d: `M${tx - 2.2} ${ty - 0.9}q0.4 -1.0 1.2 -1.3`, w: 0.55, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${tx - 0.6} ${ty - 2.4}q0.5 -1.3 1.6 -1.6`, w: 0.6, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${tx + 1.3} ${ty - 3.6}q0.9 -1.5 2.3 -1.6q1.0 0.1 0.6 1.0q-0.5 0.9 -1.5 0.4`, w: 0.6, c: 'paper' });
      A.rig = { lean: 5, squash: 1.04, y: 0 };
      A.rigF = [{}, { lean: 0.6 }, { lean: 1.1 }];
      break;
    }
    case 'done': {
      A.face.push({ t: 'stroke', d: `M${2.6 - g} ${3.9 + T.tilt}Q${3.8 - g} ${2.65 + T.tilt} ${5.0 - g} ${3.9 + T.tilt}`, w: 0.85, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.0 + g} 3.85Q${8.2 + g} 2.65 ${9.4 + g} 3.85`, w: 0.85, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.7 6.55Q6.0 7.6 7.35 6.5', w: 0.9, c: 'glyph' });
      if (T.cheeks) A.face.push(...cheeks(c));
      A.body.push({ t: 'sticker', d: 'BADGE:check', c: 'success' });
      // the satisfied nod: forward, settled
      A.rig = { lean: 7, squash: 0.95, y: 0 };
      break;
    }
    case 'happy': {
      A.face.push({ t: 'stroke', d: `M${2.55 - g} ${4.3 + T.tilt}Q${3.8 - g} ${2.35 + T.tilt} ${5.05 - g} ${4.25 + T.tilt}`, w: 0.95, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${6.95 + g} 4.25Q${8.2 + g} 2.35 ${9.45 + g} 4.3`, w: 0.95, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6, 5.95, 3.9, 2.1, -0.1), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.2, 5.95, 2.1, 1.95), c: 'rose' });
      if (T.cheeks) A.face.push(...cheeks(c));
      A.body.push({ t: 'sticker', d: heart(tx + 1.2, ty - 1.6, 0.55), c: 'rose', w: 0.5 });
      // the hop: up in the air, stretched, shadow shrinks under it
      A.rig = { lean: -3, squash: 1.07, y: -2.4 };
      A.shadowScale = 0.78;
      break;
    }
    case 'laugh': {
      A.face.push({ t: 'stroke', d: 'M2.2 2.45L4.6 3.65L2.3 4.85', w: 0.95, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M9.8 2.4L7.4 3.6L9.7 4.85', w: 0.95, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.05, 5.5, 4.9, 2.75, 0.18), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.3, 5.5, 2.5, 2.55), c: 'rose' });
      A.face.push({ t: 'sticker', d: drop(0.4, 3.0, 0.5, 0.9), c: 'aqua', w: 0.3 });
      A.face.push({ t: 'sticker', d: drop(11.7, 3.1, 0.5, -0.9), c: 'aqua', w: 0.3 });
      // thrown back and squashed, shaking on the 12 fps steps
      A.rig = { lean: -10, squash: 0.9, y: 0 };
      A.rigF = [{}, { lean: 2.2, y: -0.35, squash: 1.015 }, { lean: -1.4, y: 0.1 }];
      break;
    }
    case 'smug': {
      A.face.push(...eyes(c, { look: [0.3, 0.1], top: 0.5, slant: 0.02 }));
      A.face.push({ t: 'stroke', d: `M${2.45 - g} 2.0L${4.9 - g} 1.85`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.05 + g} 0.95Q${8.3 + g} 0.0 ${9.6 + g} 0.6`, w: 0.78, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.4 6.95Q6.95 7.7 8.05 5.85', w: 0.95, c: 'glyph' });
      A.body.push({ t: 'blob', d: spark(tx + 0.4, ty + 3.6, 1.1), c: 'paper' });
      // leaning back, chest out
      A.rig = { lean: -9, squash: 1.04, y: 0 };
      break;
    }
    case 'shock': {
      const L = { x: 3.65 - g, y: 3.35 + T.tilt }, R = { x: 8.35 + g, y: 3.35 };
      for (const [e, k] of [[L, 1], [R, 1.06]] as const) {
        A.face.push({ t: 'blob', d: ell(e.x, e.y, 1.68 * s * k, 1.68 * s * k), c: B.sclera ? 'ink' : 'glyph' });
        A.face.push({ t: 'blob', d: ell(e.x, e.y, 1.24 * s * k, 1.24 * s * k), c: 'cream' });
        A.face.push({ t: 'blob', d: ell(e.x + 0.12, e.y + 0.05, 0.42 * s, 0.44 * s), c: 'ink' });
      }
      A.face.push({ t: 'stroke', d: `M${2.25 - g} 0.7Q${3.6 - g} -0.6 ${5.0 - g} 0.2`, w: 0.78, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.0 + g} 0.2Q${8.4 + g} -0.65 ${9.8 + g} 0.65`, w: 0.78, c: 'glyph' });
      A.face.push({ t: 'blob', d: ell(6.05, 7.05, 0.85, 1.12), c: 'glyph' });
      A.body.push({ t: 'sticker', d: bang(tx + 1.9, ty + 2.0), c: 'accent', w: 0.55 });
      A.body.push({ t: 'sticker', d: ell(tx + 1.55, ty + 3.75, 0.62, 0.6), c: 'accent', w: 0.5 });
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 - 0.8} ${ty + 2.6}l-1.5 -1.3`, w: 0.6, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 + 0.6} ${ty + 0.2}l-0.9 -1.7`, w: 0.6, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 - 1.2} ${ty + 5.4}l-1.9 -0.4`, w: 0.6, c: 'paper' });
      // jumped back: stretched tall, leaning away, a hair off the ground, trembling
      A.rig = { lean: -10, squash: 1.1, y: -0.9 };
      A.rigF = [{}, { lean: -0.8, y: -0.15 }, { lean: 0.5 }];
      A.shadowScale = 0.9;
      break;
    }
    case 'sad': {
      A.face.push(...eyes(c, { look: [0, 0.55], top: 0.34, slant: -0.42 }));
      A.face.push({ t: 'stroke', d: `M${2.35 - g} 2.0Q${3.6 - g} 1.8 ${4.8 - g} 0.8`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.2 + g} 0.8Q${8.4 + g} 1.8 ${9.65 + g} 2.0`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.35 7.7Q6.0 6.35 7.7 7.6', w: 0.95, c: 'glyph' });
      A.face.push({ t: 'sticker', d: drop(9.7 + g, 6.1, 0.5, 0), c: 'aqua', w: 0.3 });
      A.body.push({ t: 'sticker', d: cloud(c.bb.cx + 3.5, ty - 3.4), c: 'muted', w: 0.55 });
      for (const [x, y] of [[0.8, -1.0], [3.0, -0.6], [5.0, -1.1]]) A.body.push({ t: 'stroke', d: `M${c.bb.cx + x + 0.5} ${ty + y}l-0.45 1.3`, w: 0.45, c: 'aqua' });
      // sagging: squashed down, sunk, drooping forward; the sag lands a frame after the face
      A.rig = { lean: 4, squash: 0.9, y: 0.7 };
      A.rigF = [{}, { squash: 0.99, y: 0.15 }, { squash: 1.005 }];
      A.shadowScale = 1.08;
      break;
    }
    case 'facepalm': {
      A.face.push({ t: 'stroke', d: `M${7.1 + g} 3.85Q${8.2 + g} 4.3 ${9.4 + g} 3.8`, w: 0.85, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.8 7.15Q6.1 6.9 7.4 7.2', w: 0.9, c: 'glyph' });
      A.body.push({ t: 'sticker', d: 'PALM', c: 'body' });
      A.body.push({ t: 'sticker', d: drop(tx + 0.6, ty + 2.6, 0.62, 0.35), c: 'aqua', w: 0.4 });
      A.rig = { lean: 10, squash: 0.94, y: 0.2 };
      break;
    }
    case 'shy': {
      // eyes cast down and away under heavy lids, a pinched smile, big blush; the body shrinks and turns away
      A.face.push(...eyes(c, { look: [-0.55, 1.05], top: 0.3, slant: -0.12, scale: 0.94 }));
      A.face.push({ t: 'stroke', d: 'M5.15 7.2Q5.65 7.75 6.1 7.3Q6.55 7.75 7.0 7.15', w: 0.75, c: 'glyph' });
      A.face.push(...cheeks(c, true));
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 + 0.2} ${ty + 1.2}q-0.9 -0.6 -1.0 -1.7`, w: 0.5, c: 'paper', o: 0.85 }, { t: 'stroke', d: `M${c.bb.x0 + 1.9} ${ty - 0.4}q-0.5 -0.9 -0.2 -1.9`, w: 0.5, c: 'paper', o: 0.85 });
      A.rig = { lean: -7, squash: 0.92, y: 0.3 };
      A.rigF = [{}, { lean: -0.7 }, { lean: 0.4 }];
      break;
    }
    case 'point': {
      A.face.push(...eyes(c, { look: [1.1, -0.05], top: 0.08, slant: 0.2 }));
      A.face.push({ t: 'stroke', d: `M${2.6 - g} 1.5L${4.8 - g} 1.95`, w: 0.72, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.4, 6.4, 3.0, 1.15, -0.08), c: 'glyph' });
      // a separate tapered hand floating off the end side, a dashed accusation line beyond its tip
      const hy = Math.max(B.hand[1] + 0.4, (c.eyeY ?? 0) + 3.6);
      const [ex, ey] = edgeAt(c, 1, hy), pa = -10, pr = (pa * Math.PI) / 180;
      A.behind.push(hand(c, ex, ey, pa, 1.05));
      const reach = 1.45 + 1.45 * Math.max(0.85, Math.min(1.15, c.bw / 18)) * 1.05 * 1.3 + 5.2;
      for (let i = 0; i < 3; i++) { const dd = reach + 1.0 + i * 1.8; A.body.push({ t: 'stroke', d: `M${f(ex + Math.cos(pr) * dd)} ${f(ey + Math.sin(pr) * dd)}l${f(Math.cos(pr) * 0.95)} ${f(Math.sin(pr) * 0.95)}`, w: 0.6, c: 'paper', o: 1 - i * 0.22 }); }
      A.rig = { lean: 11, squash: 0.98, y: 0 };
      break;
    }
    case 'cheer': {
      A.face.push({ t: 'blob', d: star4(3.75 - g, 3.5 + T.tilt, 1.8 * s, -0.12), c: 'glyph' });
      A.face.push({ t: 'blob', d: star4(8.25 + g, 3.45, 1.85 * s, 0.1), c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.05, 5.6, 4.7, 2.6, 0.05), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.25, 5.6, 2.4, 2.4), c: 'rose' });
      A.free.push(...confetti(c, [[c.bb.x0 - 2.5, ty + 0.5, 0.9, 0.5], [tx + 2.2, ty - 0.8, -0.2, 0.4], [c.bb.cx - 3, ty - 4.2, -0.17, -0.3], [tx + 3.3, ty + 5.5, 0.75, -0.7], [c.bb.cx + 3.5, ty - 4.5, 0.7, 1.1], [c.bb.x0 - 1.5, ty + 6.5, -0.15, 0.9]]));
      A.rig = { lean: 2, squash: 1.08, y: -3.0 };
      A.rigF = [{}, { y: -0.4 }, { y: -0.15, squash: 0.985 }];
      A.shadowScale = 0.72;
      break;
    }
    case 'away': {
      A.face.push({ t: 'stroke', d: `M${2.5 - g} ${3.85 + T.tilt}Q${3.8 - g} ${4.45 + T.tilt} ${5.1 - g} ${3.8 + T.tilt}`, w: 0.9, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${6.9 + g} 3.8Q${8.2 + g} 4.45 ${9.5 + g} 3.85`, w: 0.9, c: 'glyph' });
      A.face.push({ t: 'blob', d: ell(6.1, 7.0, 0.55, 0.62), c: 'glyph' });
      A.free.push({ t: 'stroke', d: zLetter(tx - 0.8, ty - 1.0, 1.25, -0.1), w: 0.72, c: 'paper' });
      A.free.push({ t: 'stroke', d: zLetter(tx + 1.9, ty - 4.1, 0.9, 0.08), w: 0.58, c: 'paper', o: 0.8 });
      A.free.push({ t: 'stroke', d: zLetter(tx + 4.0, ty - 6.6, 0.62, -0.15), w: 0.46, c: 'paper', o: 0.6 });
      // asleep on its feet: slumped, tipped back, breathing between frames
      A.dim = true; A.rig = { lean: -5, squash: 0.93, y: 0.2 };
      A.rigF = [{}, { squash: 1.01 }, { squash: 1.02 }];
      break;
    }
  }
  return markBursts(A);
}

export function pose(p: typeof POSES[number], c: Ctx, contour: (ang: number) => [number, number]): Acting {
  const { T, B } = c; const A = blank();
  const tx = endX(c), ty = top(c);
  const s = eyeS(c), g = T.gap / 2;
  switch (p) {
    case 'wave': {
      A.face.push(...eyes(c, { look: [0.2, -0.1], top: Math.min(T.lid, 0.2), slant: T.lidSlant, bot: 0.22 }));
      A.face.push({ t: 'blob', d: openMouth(6, 6.0, 3.2, 1.55, -0.12), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.2, 6.0, 1.8, 1.45), c: 'rose' });
      if (T.cheeks) A.face.push(...cheeks(c));
      // one hand up beside the head, thumb out, two motion ticks
      const hy = Math.max(B.hand[1] - 1.2, (c.eyeY ?? 0) + 1.5);
      const [ex, ey] = edgeAt(c, 1, hy);
      A.behind.push(hand(c, ex, ey, -58, 0.95, { thumb: true }));
      const a = (-58 * Math.PI) / 180, kx = ex + Math.cos(a) * 6.2, ky = ey + Math.sin(a) * 6.2;
      A.free.push({ t: 'stroke', d: `M${f(kx + 1.5)} ${f(ky - 1.7)}Q${f(kx + 2.3)} ${f(ky - 1.0)} ${f(kx + 2.45)} ${f(ky)}`, w: 0.55, c: 'paper' });
      A.free.push({ t: 'stroke', d: `M${f(kx + 2.5)} ${f(ky + 1.1)}Q${f(kx + 3.1)} ${f(ky + 1.8)} ${f(kx + 3.05)} ${f(ky + 2.7)}`, w: 0.5, c: 'paper', o: 0.8 });
      A.rig = { lean: -5, squash: 1.03, y: 0 };
      A.rigF = [{}, { lean: -1 }, { lean: 0.6 }];
      break;
    }
    case 'point': {
      A.face.push(...eyes(c, { look: [1.15, 0], top: 0.2, slant: 0.28 }));
      A.face.push({ t: 'stroke', d: `M${2.55 - g} 1.4L${4.85 - g} 1.95`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.15 + g} 1.95L${9.45 + g} 1.35`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.4, 6.3, 3.0, 1.35, -0.1), c: 'glyph' });
      const hy = Math.max(B.hand[1] - 0.2, (c.eyeY ?? 0) + 3.0);
      const [ex, ey] = edgeAt(c, 1, hy);
      A.behind.push(hand(c, ex, ey, -6, 1.15));
      const sx = ex + 1.45 + 1.45 * 1.15 * 1.3 * Math.max(0.85, Math.min(1.15, c.bw / 18)) + 5.8;
      for (let i = 0; i < 3; i++) A.free.push({ t: 'stroke', d: `M${f(sx + 0.4 + i * 2.0)} ${f(ey - 0.5 - i * 0.22)}l1.1 -0.12`, w: 0.6, c: 'paper', o: 1 - i * 0.2 });
      A.rig = { lean: 12, squash: 0.97, y: 0 };
      break;
    }
    case 'cheer': {
      A.face.push({ t: 'blob', d: star4(3.75 - g, 3.5 + T.tilt, 1.8 * s, -0.12), c: 'glyph' });
      A.face.push({ t: 'blob', d: star4(8.25 + g, 3.45, 1.85 * s, 0.1), c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.05, 5.55, 4.8, 2.7, 0.05), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.25, 5.55, 2.5, 2.5), c: 'rose' });
      // both hands flung out and up beside the head (never above it)
      const hy = Math.max(B.hand[1] - 1.6, (c.eyeY ?? 0) + 1.2);
      const [lx, ly] = edgeAt(c, -1, hy + 0.3), [rx, ry] = edgeAt(c, 1, hy);
      A.behind.push(hand(c, lx, ly, -140, 0.95), hand(c, rx, ry, -40, 0.95));
      A.free.push(...confetti(c, [[c.bb.x0 - 3, ty - 2.5, 0.85, 0.6], [tx + 2.6, ty - 3.4, -0.22, 0.3], [c.bb.cx, ty - 7.0, -0.18, -0.4], [tx + 3.8, ty + 3.5, 0.8, -0.8], [c.bb.cx - 5.5, ty - 6.0, 0.7, 1.2], [c.bb.x0 - 2.6, ty + 4.5, -0.16, 0.8], [c.bb.cx + 5.2, ty - 6.6, 0.6, 2.2]]));
      A.rig = { lean: 0, squash: 1.09, y: -3.6 };
      A.rigF = [{}, { y: -0.45 }, { y: -0.2 }];
      A.shadowScale = 0.66;
      break;
    }
    case 'sneak': {
      A.face.push(...eyes(c, { look: [-1.0, 0.2], top: 0.42, slant: 0.1, scale: 0.98 }));
      A.face.push({ t: 'stroke', d: `M${2.5 - g} 1.65L${4.7 - g} 2.0`, w: 0.68, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M5.0 6.95Q5.5 6.6 6.0 6.95Q6.5 7.3 7.0 6.95', w: 0.8, c: 'glyph' });
      // two paws held low and forward, tiptoeing
      const lowY = Math.max(B.hand[1] + 0.8, (c.eyeY ?? 0) + 3.5);
      const [ax, ay] = edgeAt(c, 1, lowY), [bx, by] = edgeAt(c, 1, Math.min(lowY + 3.0, c.bb.y1 - 2.2));
      A.behind.push(hand(c, bx, by, 24, 0.72), hand(c, ax, ay, 4, 0.78));
      for (const [x, k] of [[c.bb.x0 - 1.2, 1.0], [c.bb.x0 - 3.6, 0.75], [c.bb.x0 - 5.6, 0.55]] as const)
        A.free.push({ t: 'blob', d: ell(x, c.bb.y1 - 0.2, 0.75 * k, 0.5 * k), c: 'paper', o: 0.55 });
      A.free.push({ t: 'stroke', d: `M${c.bb.x0 - 0.2} ${ty + 5.0}l-2.2 0.2`, w: 0.5, c: 'paper', o: 0.7 });
      A.free.push({ t: 'stroke', d: `M${c.bb.x0 - 0.6} ${ty + 8.0}l-3.0 0.1`, w: 0.5, c: 'paper', o: 0.7 });
      A.rig = { lean: 9, squash: 0.88, y: 0 };
      A.rigF = [{}, { y: -0.2 }, { lean: 0.6 }];
      break;
    }
  }
  return markBursts(A);
}
