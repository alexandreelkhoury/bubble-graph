// Builds the JAMAA cast: 12 characters × 13 expressions + 4 poses, 3 boil frames each.
// Output: ../svg/<id>/<name>.svg (standalone, boiling at 8 fps), ../characters.json,
// and ../sheets/*.html (rendered to PNG by ../render.mjs).
import { writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { parsePath, cubicsToD, bbox, densify, polyToD, handmade, type Pt, type Sub } from './handmade.ts';
import { bodyFrames, strokeFrames, blobFrames } from './ink.ts';
import { BODIES, type Body } from './bodies.ts';
import { TRAITS, EXPRESSIONS, POSES, acting, pose, type Prim, type Ctx, type Acting, type Col } from './faces.ts';

const ROOT = new URL('../', import.meta.url).pathname;
const C = { ink: '#160B26', glyphInk: '#120A1F', cream: '#FFF7EC', paper: '#FFF1DC', rose: '#FF96C5', aqua: '#7BFFF4', accent: '#FFC94D', success: '#3DDC97', danger: '#FF6B60', muted: '#B8A8D6', bg: '#1D1036', coral: '#F0183A', blushDeep: '#B5103E' };
const MISREG = { x: 0.24, y: 0.32 };  // fill pass offset: 0.4 unit toward bottom-end, fixed for the screen (ART-DIRECTION §5.4); off below 64 dp
const FACE_BOOST = 1.18;              // TV pass: face boxes +18 % (10-ft test)
const EYE_MIN_RY = 1.55;              // eye half-height floor in body units (≥ 12 dp tall at 96 dp)
const LIGHT = { x: -0.6, y: -0.8 };   // light from top-start
const VB = { x: -8, y: -10, w: 40, h: 37 };
const NF = 3;

type M = (p: Pt) => Pt;
function mapD(d: string, m: M): string {
  const subs = parsePath(d);
  const out: Sub[] = subs.map((s) => ({ closed: s.closed, segs: s.segs.map((c) => { const a = m({ x: c[0], y: c[1] }), b = m({ x: c[2], y: c[3] }), e = m({ x: c[4], y: c[5] }), g = m({ x: c[6], y: c[7] }); return [a.x, a.y, b.x, b.y, e.x, e.y, g.x, g.y] as any; }) }));
  return cubicsToD(out, 3);
}
function mix(hex: string, to: string, k: number) {
  const a = parseInt(hex.slice(1), 16), b = parseInt(to.slice(1), 16);
  const ch = (n: number, sh: number) => (n >> sh) & 255;
  return '#' + [16, 8, 0].map((sh) => Math.round(ch(a, sh) + (ch(b, sh) - ch(a, sh)) * k).toString(16).padStart(2, '0')).join('');
}
/** Away: keep the player's hue, soften it (saturation ×0.58, lightness ×0.9) so it reads as resting, not broken. */
function rest(hex: string) {
  const n = parseInt(hex.slice(1), 16); let r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, sat = 0; let l = (mx + mn) / 2;
  if (mx !== mn) { const d = mx - mn; sat = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
  sat *= 0.58; l *= 0.9;
  const q = l < 0.5 ? l * (1 + sat) : l + sat - l * sat, p = 2 * l - q;
  const hue = (t: number) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  return '#' + [hue(h + 1 / 3), hue(h), hue(h - 1 / 3)].map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
}
function desat(hex: string, k = 0.8) {
  const n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  const l = 0.299 * r + 0.587 * g + 0.114 * b, mix = (v: number) => Math.round(v + (l - v) * k);
  return '#' + [mix(r), mix(g), mix(b)].map((v) => v.toString(16).padStart(2, '0')).join('');
}

type Frames = { fill: string; ink: string; paper: string; fillPts: Pt[] }[];
type CharData = { B: Body; ctx: Ctx; frames: Frames; contour: (a: number) => [number, number]; toBody: M; k: number; hatch: string[] };

function prep(B: Body): CharData {
  const subs = parsePath(B.d), bb = bbox(subs);
  const frames = bodyFrames(B.d, { seed: `jamaa-cast:${B.id}`, boilAmp: 0.25 });
  // the games/scenes hand: a few tapered hatch scribbles on the shadow side, one set per boil pass
  const hatch = handmade(B.d, { seed: `jamaa-cast:${B.id}:hatch`, hatch: true, dp: 2, hand: { amp: 0.24 } as any, pen: { width: 0.95 } as any }).map((v) => v.hatch);
  const pts = densify(subs[0].segs, 0.3);
  const contour = (ang: number): [number, number] => {
    const a = (ang * Math.PI) / 180, dx = Math.cos(a), dy = Math.sin(a);
    let best = pts[0], bs = -1e9;
    for (const p of pts) { const vx = p.x - bb.cx, vy = p.y - bb.cy, along = vx * dx + vy * dy, off = Math.abs(vx * dy - vy * dx); const sc = along - off * 2.5; if (sc > bs) { bs = sc; best = p; } }
    return [best.x, best.y];
  };
  const edge = (y: number, dir: 1 | -1): [number, number] => {
    let best = pts[0], bs = -1e9;
    for (const p of pts) { if (Math.abs(p.y - y) > 0.6) continue; const sc = (p.x - bb.cx) * dir; if (sc > bs) { bs = sc; best = p; } }
    return [best.x, best.y];
  };
  const fs = (B.faceScale ?? 1) * (B.fixedFace ? 1 : FACE_BOOST), k = (B.face.w / 12) * fs;
  // boosted faces grow around the eye line's centre, not the box corner
  const fcx = B.face.x + B.face.w / 2, fcy = B.face.y + (B.face.w / 12) * 4.5 + (B.fixedFace ? 0 : (B.face.w / 12) * (B.faceScale ?? 1) * (FACE_BOOST - 1) * 0.6);
  const toBody: M = (p) => ({ x: fcx + (p.x - 6) * k, y: fcy + (p.y - 4.5) * k });
  const ctx: Ctx = { B, T: TRAITS[B.id], bw: bb.x1 - bb.x0, bh: bb.y1 - bb.y0, bb, k, eyeMin: EYE_MIN_RY / (1.45 * k) };
  ctx.edge = edge; ctx.eyeY = toBody({ x: 6, y: 3.6 }).y;
  return { B, ctx, frames, contour, toBody, k, hatch };
}

function colour(c: Col, B: Body, dim: boolean): string {
  switch (c) {
    case 'glyph': return B.glyph === 'ink' ? C.glyphInk : C.cream;
    case 'body': return dim ? rest(B.color) : B.color;
    case 'bodyLite': return mix(dim ? rest(B.color) : B.color, C.cream, 0.55);
    case 'bodyDeep': return mix(dim ? rest(B.color) : B.color, C.ink, 0.28);
    default: return (C as any)[c];
  }
}

// Stickers: little cut-paper props (fill + ink ring + paper rim), 3 frames
function sticker(d: string, seed: string, w = 0.6, amp = 0.1): Frames {
  return bodyFrames(d, { seed, width: w, gain: 0.3, hand: { amp, waveMin: 2, waveMax: 7, rot: 1.5, shift: 0.06 } as any, spacing: 1.0, overshoot: 0.9, lift: 0.05 });
}

/** Render one prim into NF frame strings. */
function prim(P: Prim, cd: CharData, space: 'face' | 'body', seed: string, dim: boolean): string[] {
  const { B, ctx } = cd;
  const tf = space === 'face' ? cd.toBody : (p: Pt) => p;
  const sc = space === 'face' ? cd.k : 1;
  const op = P.o != null ? ` opacity="${P.o}"` : '';
  if (P.t === 'blob') {
    const d = mapD(P.d, tf);
    return blobFrames(d, seed, (P.amp ?? 0.1) * Math.min(1, sc * 1.2)).map((v) => `<path d="${v}" fill="${colour(P.c, B, dim)}"${op}/>`);
  }
  if (P.t === 'stroke') {
    const d = mapD(P.d, tf);
    const belly = space === 'face' && (P.c === 'glyph' || P.c === 'ink') ? 1 : 0;
    return strokeFrames(d, P.w * sc * (belly ? 1.12 : 1) * (belly && B.sclera ? 1.35 : 1), seed, (P.amp ?? 0.11) * Math.min(1, sc * 1.2), 3, belly).map((v) => `<path d="${v}" fill="${colour(P.c, B, dim)}"${op}/>`);
  }
  // sticker
  let d = P.d, w = P.w ?? 0.6, extra: string[] = ['', '', ''];
  if (d === 'DISC') {
    const r = 0.2 * ctx.bw, cc = cd.toBody({ x: 4.3, y: 3.0 });
    d = `M${cc.x - r} ${cc.y}C${cc.x - r} ${cc.y - r * 0.58} ${cc.x - r * 0.52} ${cc.y - r * 1.02} ${cc.x + 0.1} ${cc.y - r}C${cc.x + r * 0.6} ${cc.y - r * 0.98} ${cc.x + r * 1.03} ${cc.y - r * 0.5} ${cc.x + r} ${cc.y + 0.1}C${cc.x + r * 0.97} ${cc.y + r * 0.62} ${cc.x + r * 0.5} ${cc.y + r} ${cc.x - 0.15} ${cc.y + r * 0.97}C${cc.x - r * 0.6} ${cc.y + r * 0.95} ${cc.x - r} ${cc.y + r * 0.55} ${cc.x - r} ${cc.y}Z`;
    w = 0.75;
    if (B.hl.length) extra = strokeFrames(`M${cc.x - r * 0.62} ${cc.y + r * 0.05}Q${cc.x - r * 0.55} ${cc.y - r * 0.5} ${cc.x - r * 0.05} ${cc.y - r * 0.62}`, 0.5, seed + 'hl').map((v) => `<path d="${v}" fill="${C.paper}" opacity=".7"/>`);
  } else if (d === 'PALM') {
    // a mitten pressed over the start eye, thumb up, tilted: a hand without an arm
    const e = cd.toBody({ x: 3.75 - ctx.T.gap / 2, y: 3.55 + ctx.T.tilt }), sc = 0.66 * cd.k * ctx.T.eyeScale, rot = -0.38, ca = Math.cos(rot), sa = Math.sin(rot);
    const R: M = (p) => ({ x: e.x + (p.x * ca - p.y * sa) * sc, y: e.y + (p.x * sa + p.y * ca) * sc });
    d = mapD('M-2.9 0.2C-2.9 -1.3 -1.6 -2.1 -0.2 -2.0C0.35 -2.95 1.65 -3.05 1.95 -2.1C2.85 -1.7 3.15 -0.6 2.95 0.4C2.7 1.65 1.4 2.2 -0.1 2.1C-1.7 2.0 -2.9 1.4 -2.9 0.2Z', R);
    extra = [0, 1, 2].map((k) => strokeFrames(mapD('M-0.6 0.9Q0.5 1.1 1.6 0.6', R), 0.42, seed + 'cr', 0.04)[k] + strokeFrames(mapD('M-0.9 -0.15Q0.2 0.1 1.3 -0.4', R), 0.4, seed + 'cr2', 0.04)[k]).map((v) => `<path d="${v}" fill="${C.ink}" opacity=".8"/>`.replace('d="', 'd="'));
    w = 0.75;
  } else if (d.startsWith('BADGE:')) {
    const kind = d.slice(6), bx = ctx.bb.x1 - 0.6, by = ctx.bb.y0 + 1.4, r = 2.5;
    const rot = kind === 'check' ? 0.1 : -0.06, ca = Math.cos(rot), sa = Math.sin(rot);
    const R: M = (p) => ({ x: bx + p.x * ca - p.y * sa, y: by + p.x * sa + p.y * ca });
    d = mapD(`M${-r} 0C${-r} ${-r * 0.6} ${-r * 0.55} ${-r} 0.05 ${-r}C${r * 0.6} ${-r * 0.98} ${r} ${-r * 0.55} ${r} 0.05C${r * 0.98} ${r * 0.6} ${r * 0.55} ${r} -0.05 ${r}C${-r * 0.6} ${r} ${-r} ${r * 0.55} ${-r} 0Z`, R);
    const icon = kind === 'check' ? ['M-1.25 0.1L-0.35 1.05L1.35 -0.95'] : ['M-1.45 -0.15Q0 -1.45 1.45 -0.15', 'M-0.75 0.6Q0 -0.05 0.75 0.6', 'M-1.3 -1.3L1.3 1.4'];
    const ring = blobFrames(mapD(`M${-r - 0.55} 0A${r + 0.55} ${r + 0.55} 0 1 0 ${r + 0.55} 0A${r + 0.55} ${r + 0.55} 0 1 0 ${-r - 0.55} 0Z`, R), seed + 'ring', 0.05);
    const ic = icon.map((s, i) => strokeFrames(mapD(s, R), i === 2 ? 0.45 : 0.6, seed + 'ic' + i, 0.04));
    const dot = kind === 'wifi' ? blobFrames(mapD('M-0.32 1.15A0.32 0.32 0 1 0 0.32 1.15A0.32 0.32 0 1 0 -0.32 1.15Z', R), seed + 'dot', 0.01) : null;
    const fr = sticker(d, seed, 0.42, 0.06);
    return fr.map((v, i) => `<path d="${ring[i]}" fill="${C.bg}"/><path d="${v.fill}" fill="${colour(P.c, B, false)}"/><path d="${v.ink}" fill="${C.ink}"/>` + ic.map((x) => `<path d="${x[i]}" fill="${C.ink}"/>`).join('') + (dot ? `<path d="${dot[i]}" fill="${C.ink}"/>` : ''));
  } else if (d.startsWith('SHAPE:')) {
    const [, x, y, s, rot] = d.split(':').map(Number) as any;
    const bb = ctx.bb, ca = Math.cos(rot), sa = Math.sin(rot);
    d = mapD(B.d, (p) => { const u = (p.x - bb.cx) * s, v = (p.y - bb.cy) * s; return { x: x + u * ca - v * sa, y: y + u * sa + v * ca }; });
  } else if (space === 'face') d = mapD(d, tf);
  const fr = sticker(d, seed, w * (space === 'face' ? Math.max(0.8, sc) : 1), P.t === 'sticker' && d.length < 400 ? 0.06 : 0.1);
  const fillCol = colour(P.c, B, dim);
  const rim = P.c === 'body' && !B.ring ? () => '' : (v: { paper: string }) => `<path d="${v.paper}" fill="none" stroke="${C.paper}" stroke-width="${(w * 1.3).toFixed(2)}" stroke-linejoin="round"/>`;
  const tipD = (P as any).tip as string | undefined;
  const tip = tipD ? blobFrames(tipD, seed + 'tip', 0.05) : null;
  return fr.map((v, i) => `<g${op}>${rim(v)}<g transform="translate(${MISREG.x * 0.6} ${MISREG.y * 0.6})"><path d="${v.fill}" fill="${fillCol}"/>${(P as any).shade ? `<path d="${v.fill}" fill="${C.ink}" opacity=".2"/>` : ''}${tip ? `<path d="${tip[i]}" fill="${colour('bodyLite', B, dim)}"/>` : ''}</g><path d="${v.ink}" fill="${C.ink}"/>${extra[i]}</g>`);
}

/** Hand-cut ground shadow (one side flatter). */
function groundShadow(cd: CharData, scale: number, seed: string): string[] {
  const { bb, bw } = cd.ctx;
  const cx = bb.cx + 0.3, cy = bb.y1 + 0.55, rx = 0.37 * bw * scale, ry = 1.05 * scale;
  const d = `M${cx - rx} ${cy + 0.1}C${cx - rx} ${cy - ry * 0.75} ${cx - rx * 0.45} ${cy - ry} ${cx + 0.2} ${cy - ry * 0.92}C${cx + rx * 0.6} ${cy - ry * 0.9} ${cx + rx * 1.02} ${cy - ry * 0.55} ${cx + rx} ${cy + 0.05}C${cx + rx * 0.98} ${cy + ry * 0.7} ${cx + rx * 0.5} ${cy + ry * 1.05} ${cx - 0.3} ${cy + ry}C${cx - rx * 0.6} ${cy + ry * 0.95} ${cx - rx} ${cy + ry * 0.6} ${cx - rx} ${cy + 0.1}Z`;
  return blobFrames(d, seed, 0.18, NF, 1.2).map((v) => `<path d="${v}" fill="${C.ink}" opacity="${(0.34 * scale).toFixed(2)}"/>`);
}

function shadowShape(cd: CharData, k: number): string {
  // hand-cut shadow on the bottom-end side: the body minus itself slid toward the light by
  // `B.shade` units (so every arm of the star / plus gets its own cut), clipped to the body
  const src = cd.frames[(k + 1) % NF].fillPts, { bb } = cd.ctx;
  const sh = cd.B.shade;
  const moved = src.map((p) => ({ x: bb.cx + (p.x - bb.cx) * 1.03 + LIGHT.x * sh, y: bb.cy + (p.y - bb.cy) * 1.03 + LIGHT.y * sh - 0.15 * sh }));
  return `M-40 -40H70V70H-40Z` + polyToD(moved, 2);
}

type Rig = { lean: number; squash: number; y: number };
function rigT(bb: CharData['ctx']['bb'], r: Rig) {
  const sy = r.squash, sx = 1 / Math.sqrt(sy);
  return `translate(0 ${r.y}) translate(${bb.cx} ${bb.y1}) rotate(${r.lean}) scale(${sx.toFixed(4)} ${sy}) translate(${-bb.cx} ${-bb.y1})`;
}

function drawing(cd: CharData, A: Acting, id: string, name: string, opt: { noBurst?: boolean } = {}): string[] {
  const { B, ctx } = cd; const dim = !!A.dim;
  const seed = (i: number, tag: string) => `${B.id}:${name}:${tag}:${i}`;
  const keep = (p: { burst?: boolean }) => !(opt.noBurst && p.burst);
  const faces = A.face.filter(keep).map((p, i) => prim(p, cd, 'face', seed(i, 'f'), dim));
  const bodies = A.body.filter(keep).map((p, i) => prim(p, cd, 'body', seed(i, 'b'), dim));
  const behind = A.behind.filter(keep).map((p, i) => prim(p, cd, 'body', seed(i, 'n'), dim));
  const free = A.free.filter(keep).map((p, i) => prim(p, cd, 'body', seed(i, 'x'), dim));
  const hl = B.hl.map((d, i) => strokeFrames(d, i === 0 ? 0.62 : 0.55, seed(i, 'hl'), 0.05));
  const gs = groundShadow(cd, A.shadowScale ?? 1, `${B.id}:ground:${A.shadowScale ?? 1}`);
  const { bb } = ctx;
  const fillCol = dim ? rest(B.color) : B.color;
  const out: string[] = [];
  for (let k = 0; k < NF; k++) {
    const F = cd.frames[k];
    const cid = `${id}-c${k}`;
    const d = A.rigF?.[k] ?? {};
    const rig = rigT(bb, { lean: A.rig.lean + (d.lean ?? 0), squash: A.rig.squash * (d.squash ?? 1), y: A.rig.y + (d.y ?? 0) });
    out.push(`<g class="f f${k}">`
      + gs[k]
      + `<g transform="${rig}">`
      + behind.map((x) => x[k]).join('')
      + (B.ring ? `<path d="${F.paper}" fill="none" stroke="${C.paper}" stroke-width="1.5" stroke-linejoin="round"/>` : '')
      + `<clipPath id="${cid}"><path d="${F.fill}"/></clipPath>`
      + `<g transform="translate(${MISREG.x} ${MISREG.y})"><path d="${F.fill}" fill="${fillCol}"/>`
      + `<g clip-path="url(#${cid})">`
      + `<path d="${shadowShape(cd, k)}" fill="${C.ink}" fill-rule="evenodd" opacity=".22" style="mix-blend-mode:multiply"/>`
      + `<path d="${cd.hatch[k]}" fill="${C.ink}" opacity="${B.ring ? 0.13 : 0.17}"/>`
      + hl.map((h) => `<path d="${h[k]}" fill="${C.paper}" opacity=".68"/>`).join('')
      + `</g></g>`
      + `<path d="${F.ink}" fill="${C.ink}"/>`
      + faces.map((x) => x[k]).join('')
      + bodies.map((x) => x[k]).join('')
      + `</g>`
      + free.map((x) => x[k]).join('')
      + `</g>`);
  }
  return out;
}

const BOIL_CSS = `.f{opacity:0;animation:boil 375ms step-end infinite}.f1{animation-delay:-250ms}.f2{animation-delay:-125ms}@keyframes boil{0%{opacity:1}33.333%{opacity:0}100%{opacity:0}}@media (prefers-reduced-motion:reduce){.f{animation:none}.f0{opacity:1}}`;
function svgDoc(frames: string[], title: string) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${VB.x} ${VB.y} ${VB.w} ${VB.h}" width="400" height="370"><title>${title}</title><style>${BOIL_CSS}</style>${frames.join('')}</svg>\n`;
}
function inline(frames: string[], w: number, frame = 0) {
  return `<svg viewBox="${VB.x} ${VB.y} ${VB.w} ${VB.h}" width="${w}" height="${(w * VB.h) / VB.w}" data-frame="${frame}">${frames.join('')}</svg>`;
}

// ------------------------------------------------------------- build -----
const all: Record<string, Record<string, string[]>> = {};
const bare: Record<string, Record<string, string[]>> = {}; // same drawings, burst props hidden (10-ft test)
const json: any = { meta: { viewBox: VB, frames: NF, fps: { idle: 8, acting: 12 }, misregistration: MISREG, colours: C, note: 'Each drawing: 3 boil frames (A,B,C) as SVG <g> groups; cycle A→B→C on one shared clock.' }, characters: {} };
for (const B of BODIES) {
  const cd = prep(B);
  mkdirSync(`${ROOT}svg/${B.id}`, { recursive: true });
  all[B.id] = {}; bare[B.id] = {};
  json.characters[B.id] = { colour: B.color, shape: B.shape, persona: TRAITS[B.id].persona, body: B.d, drawings: {} };
  const jobs: [string, Acting][] = [
    ...EXPRESSIONS.map((e) => [e, acting(e, cd.ctx)] as [string, Acting]),
    ...POSES.map((p) => [`pose-${p}`, pose(p, cd.ctx, cd.contour)] as [string, Acting]),
  ];
  for (const [name, A] of jobs) {
    const fr = drawing(cd, A, `${B.id}-${name}`, name);
    all[B.id][name] = fr;
    bare[B.id][name] = drawing(cd, A, `${B.id}-${name}-np`, name, { noBurst: true });
    writeFileSync(`${ROOT}svg/${B.id}/${name}.svg`, svgDoc(fr.map((x) => x), `${B.id} (${B.shape}) — ${name}`));
    json.characters[B.id].drawings[name] = { rig: A.rig, frames: fr };
  }
}
writeFileSync(`${ROOT}characters.json`, JSON.stringify(json));

// ------------------------------------------------------------ sheets -----
const grain = readFileSync(`${ROOT}src/grain-128.png`).toString('base64');
const STAGE = `background:#1D1036;background-image:radial-gradient(90% 55% at 50% -5%,rgba(140,80,230,.42),transparent 70%),radial-gradient(70% 45% at 105% 100%,rgba(255,201,77,.12),transparent 70%),linear-gradient(180deg,#2B1650 0%,#24124A 55%,#1D1036 100%);`;
const PAGE = (body: string, extra = '') => `<!doctype html><html><head><meta charset="utf-8"><style>
*{box-sizing:border-box}html,body{margin:0}body{position:relative}body::after{content:'';position:absolute;inset:0;background:url(data:image/png;base64,${grain});opacity:.08;mix-blend-mode:overlay;pointer-events:none}body{${STAGE}color:#FFF7EC;font:600 13px/1.3 "DejaVu Sans",system-ui,sans-serif;padding:28px 32px 32px;display:inline-block;min-width:100%}
h1{font-size:22px;margin:0 0 4px;letter-spacing:.01em}h1 small{font-weight:400;color:#B8A8D6;font-size:14px;margin-inline-start:8px}
.grid{display:grid;gap:4px 6px}.cell{display:flex;flex-direction:column;align-items:center}.cell span{color:#B8A8D6;font-size:11px;margin-top:-6px;letter-spacing:.04em}
.f{opacity:0}svg[data-frame="0"] .f0,svg[data-frame="1"] .f1,svg[data-frame="2"] .f2{opacity:1}
${extra}</style></head><body>${body}</body></html>`;
mkdirSync(`${ROOT}sheets`, { recursive: true });
const names = [...EXPRESSIONS, ...POSES.map((p) => `pose-${p}`)];

// per-character sheets
for (const B of BODIES) {
  const cells = names.map((n) => `<div class="cell">${inline(all[B.id][n], 200)}<span>${n.replace('pose-', 'pose · ')}</span></div>`).join('');
  writeFileSync(`${ROOT}sheets/sheet-${B.id}.html`, PAGE(`<h1>${B.id} · ${B.shape}<small>${TRAITS[B.id].persona}</small></h1><div class="grid" style="grid-template-columns:repeat(6,200px)">${cells}</div>`));
}
// lineup
writeFileSync(`${ROOT}sheets/lineup.html`, PAGE(`<h1>The JAMAA cast<small>12 shilleh · idle · hub palette B</small></h1><div class="grid" style="grid-template-columns:repeat(6,230px)">${BODIES.map((B) => `<div class="cell">${inline(all[B.id].idle, 230)}<span>${B.id} · ${B.shape}</span></div>`).join('')}</div>`));
// expressions grid (small, family check)
writeFileSync(`${ROOT}sheets/expressions-grid.html`, PAGE(`<h1>13 expressions × 12<small>${EXPRESSIONS.join(' · ')}</small></h1><div class="grid" style="grid-template-columns:repeat(13,104px);gap:0 2px">${BODIES.map((B) => EXPRESSIONS.map((e) => `<div class="cell">${inline(all[B.id][e], 104)}</div>`).join('')).join('')}</div>`));
// poses grid
writeFileSync(`${ROOT}sheets/poses-grid.html`, PAGE(`<h1>Poses<small>wave · point · cheer · sneak</small></h1><div class="grid" style="grid-template-columns:repeat(8,150px);gap:0 4px">${BODIES.map((B) => POSES.map((p) => `<div class="cell">${inline(all[B.id]['pose-' + p], 150)}</div>`).join('')).join('')}</div>`));
// boil frames: every idle in A, B, C
writeFileSync(`${ROOT}sheets/boil-frames.html`, PAGE(`<h1>Boil frames A · B · C<small>same drawing traced three times; cycled at 8 fps idle / 12 fps acting</small></h1><div class="grid" style="grid-template-columns:repeat(9,140px);gap:0 4px">${BODIES.map((B) => [0, 1, 2].map((k) => `<div class="cell">${inline(all[B.id].idle, 140, k)}<span>${B.id} ${'ABC'[k]}</span></div>`).join('')).join('')}</div>`));
// TV distance: 960×540 canvas, characters at 72 dp, mixed expressions
const tvEx = ['idle', 'happy', 'shock', 'smug', 'sad', 'cheer', 'think', 'laugh', 'shy', 'point', 'done', 'facepalm'];
writeFileSync(`${ROOT}sheets/tv-distance.html`, PAGE(`<div style="width:960px;height:540px;position:relative"><div style="position:absolute;left:0;right:0;top:90px;display:flex;flex-wrap:wrap;justify-content:center;gap:24px 22px;padding:0 40px">${BODIES.map((B, i) => `<div class="cell">${inline(all[B.id][tvEx[i]], 120)}<span style="font-size:15px;color:#FFF7EC;margin-top:-8px">${['Rami', 'Léa', 'Nour', 'Carlos', 'Maya', 'Hadi', 'Inès', 'Ziad', 'Sofía', 'Karim', 'Yara', 'Paul'][i]}</span></div>`).join('')}</div></div>`, 'body{padding:0;min-width:0;width:960px;height:540px;overflow:hidden}'));
// TV, no burst props: every expression at 72 dp (body = 72 px), face + body acting only
writeFileSync(`${ROOT}sheets/tv-expressions.html`, PAGE(`<h1>10-ft test · 72 dp · no burst props<small>${EXPRESSIONS.join(' · ')}</small></h1><div class="grid" style="grid-template-columns:repeat(13,120px);gap:0 0">${BODIES.map((B) => EXPRESSIONS.map((e) => `<div class="cell">${inline(bare[B.id][e], 120)}</div>`).join('')).join('')}</div>`, '.cell{height:104px;overflow:visible}'));
writeFileSync(`${ROOT}sheets/tv-distance-noprops.html`, PAGE(`<div style="width:960px;height:540px;position:relative"><div style="position:absolute;left:0;right:0;top:90px;display:flex;flex-wrap:wrap;justify-content:center;gap:24px 22px;padding:0 40px">${BODIES.map((B, i) => `<div class="cell">${inline(bare[B.id][tvEx[i]], 120)}<span style="font-size:15px;color:#FFF7EC;margin-top:-8px">${tvEx[i]}</span></div>`).join('')}</div></div>`, 'body{padding:0;min-width:0;width:960px;height:540px;overflow:hidden}'));
// boil strip for the GIF: one row of idles, rendered once per frame by ../gif.mjs
writeFileSync(`${ROOT}sheets/boil-strip.html`, PAGE(`<div class="grid" style="grid-template-columns:repeat(6,160px);gap:0 4px">${BODIES.map((B) => `<div class="cell">${inline(all[B.id].idle, 160, 0)}</div>`).join('')}</div>`));
// live boil page
writeFileSync(`${ROOT}boil.html`, `<!doctype html><html><head><meta charset="utf-8"><title>JAMAA cast — live boil</title><style>body{${STAGE}margin:0;padding:24px;color:#FFF7EC;font:600 13px system-ui}.f{opacity:0}.grid{display:grid;grid-template-columns:repeat(6,200px);gap:8px}</style></head><body><h2>Live boil (8 fps). Hover a character to cycle expressions.</h2><div class="grid">${BODIES.map((B) => `<div data-id="${B.id}">${inline(all[B.id].idle, 200)}</div>`).join('')}</div><script>
const D=${JSON.stringify(Object.fromEntries(BODIES.map((B) => [B.id, Object.fromEntries(names.map((n) => [n, all[B.id][n].join('')]))])))};
const N=${JSON.stringify(names)};let t=0;setInterval(()=>{t=(t+1)%3;document.querySelectorAll('svg').forEach(s=>s.setAttribute('data-frame',t));document.querySelectorAll('.f').forEach(g=>g.style.opacity=g.classList.contains('f'+t)?1:0)},125);
document.querySelectorAll('[data-id]').forEach(el=>{let i=0;el.onclick=el.onmouseenter=()=>{i=(i+1)%N.length;el.querySelector('svg').innerHTML=D[el.dataset.id][N[i]];el.title=N[i]}});
</script></body></html>`);
console.log('ok', Object.keys(all).length, 'characters ×', names.length, 'drawings');
