import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const sharp = require('../tech/bench/node_modules/sharp');
const [inp, out, x, y, w, h] = process.argv.slice(2);
await sharp(inp).extract({ left: +x, top: +y, width: +w, height: +h }).toFile(out);
