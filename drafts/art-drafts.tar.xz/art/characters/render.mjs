import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
process.env.PLAYWRIGHT_BROWSERS_PATH = '/opt/pw-browsers';
const { chromium } = require('/home/user/bubble-graph/node_modules/.pnpm/playwright@1.63.0/node_modules/playwright');
const root = new URL('./', import.meta.url).pathname;
const only = process.argv.slice(2);
const fs = await import('node:fs');
const pages = fs.readdirSync(root + 'sheets').filter((f) => f.endsWith('.html')).map((f) => f.replace('.html', '')).filter((n) => !only.length || only.some((o) => n.includes(o)));
const b = await chromium.launch();
for (const scale of [1, 2]) {
  const ctx = await b.newContext({ viewport: { width: 800, height: 600 }, deviceScaleFactor: scale });
  const p = await ctx.newPage();
  for (const n of pages) {
    await p.goto('file://' + root + 'sheets/' + n + '.html');
    const box = await p.evaluate(() => { const b = document.body; return { w: Math.ceil(b.scrollWidth), h: Math.ceil(b.scrollHeight) }; });
    await p.setViewportSize({ width: box.w, height: box.h });
    await p.screenshot({ path: `${root}png/${n}@${scale}x.png`, fullPage: true });
  }
  await ctx.close();
}
await b.close();
console.log('rendered', pages.length * 2);
