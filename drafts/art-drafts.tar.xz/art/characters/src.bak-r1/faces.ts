// Faces (12 × 9 face space, DESIGN-JAMAA §4.2/§4.3) + acting extras in body space.
// Drawn by hand: every expression is authored as path data here; the boil comes later.
// "end" side = +x (LTR); RTL does not mirror characters (TECHNIQUE §3.1).
import type { Body } from './bodies.ts';

export type Col = 'glyph' | 'ink' | 'paper' | 'cream' | 'rose' | 'body' | 'aqua' | 'accent' | 'success' | 'danger' | 'muted' | 'bg' | 'coral';
export type Prim =
  | { t: 'blob'; d: string; c: Col; o?: number; amp?: number }
  | { t: 'stroke'; d: string; w: number; c: Col; o?: number; amp?: number }
  | { t: 'sticker'; d: string; c: Col; w?: number; o?: number; shade?: boolean }; // filled + ink ring + paper rim (props, bursts, nubs)

export type Trait = {
  persona: string;
  eyeScale: number; gap: number; tilt: number; // tilt: start eye dy (− = higher)
  lid: number;            // idle top lid (0 = open)
  lidSlant?: number;      // + = lid lower toward the inside (cheeky V), − = toward the outside (sleepy/sad)
  bottomLid?: number;     // idle smiling lower lid
  look: [number, number]; // idle gaze
  lean: number;           // idle lean (deg, + = toward end)
  mouth: string;          // idle mouth (face space)
  mouthOpen?: boolean;    // idle mouth drawn as an open grin
  cheeks?: boolean;
  glint?: boolean;
  hl2?: boolean;          // second catch-light (the softie)
};

export const TRAITS: Record<string, Trait> = {
  coral:     { persona: 'the ringleader — loud, sure of herself, first to the party', eyeScale: 1.06, gap: 0, tilt: -0.14, lid: 0, look: [0.15, 0], lean: -2.5, mouth: 'M3.9 6.25Q6.1 8.35 8.4 6.0' },
  azure:     { persona: 'the straight man — deadpan, reliable, unimpressed', eyeScale: 0.9, gap: 0.25, tilt: 0.08, lid: 0.22, lidSlant: 0, look: [0, 0.1], lean: 0, mouth: 'M4.85 6.95Q6.1 7.3 7.35 6.8' },
  lemon:     { persona: 'the show-off — chin up, always on camera', eyeScale: 1.0, gap: -0.1, tilt: -0.12, lid: 0, look: [0.2, -0.45], lean: -3, mouth: 'M4.1 6.3Q6.0 8.0 8.0 6.25', glint: true },
  jade:      { persona: 'the calm one — sleepy-content, unbothered, wise', eyeScale: 1.0, gap: 0.1, tilt: -0.1, lid: 0.42, lidSlant: -0.12, look: [0, 0.15], lean: 0, mouth: 'M4.7 6.75Q6.0 7.45 7.35 6.7' },
  grape:     { persona: 'the schemer — one eye always narrowed, a plan forming', eyeScale: 1.0, gap: 0, tilt: -0.18, lid: 0.12, lidSlant: 0.18, look: [-0.35, 0], lean: 2, mouth: 'M4.6 6.95Q6.6 7.45 7.85 6.35' },
  tangerine: { persona: 'the hype — can’t sit still, eyes wide, grin open', eyeScale: 1.16, gap: -0.15, tilt: -0.1, lid: 0, look: [0, -0.1], lean: 3.5, mouth: 'M4.3 5.95Q6.0 6.1 7.75 5.9', mouthOpen: true },
  aqua:      { persona: 'the sweetheart — helpful, wide-eyed, blushes easily', eyeScale: 0.96, gap: 0.45, tilt: -0.08, lid: 0, look: [0, 0.15], lean: 0, mouth: 'M5.1 6.85Q6.0 7.55 6.95 6.85', cheeks: true },
  rose:      { persona: 'the softie — big glassy eyes, feels everything', eyeScale: 1.14, gap: 0.05, tilt: -0.12, lid: 0, look: [0, 0.05], lean: -1, mouth: 'M5.15 6.9Q6.05 7.5 6.95 6.85', cheeks: true, hl2: true },
  mint:      { persona: 'the dreamer — head in the clouds, gazing at the opening', eyeScale: 0.98, gap: 0, tilt: -0.15, lid: 0.1, lidSlant: -0.1, look: [0.55, -0.6], lean: -2, mouth: 'M5.3 6.85Q6.1 7.25 6.85 6.8' },
  plum:      { persona: 'the troublemaker — zippy, cheeky, already up to something', eyeScale: 1.0, gap: -0.1, tilt: -0.15, lid: 0.18, lidSlant: 0.32, look: [0.3, 0], lean: 4, mouth: 'M4.0 6.35Q6.4 8.1 8.05 5.95' },
  sand:      { persona: 'the host — “tfaddalo!”, warm smiling eyes, feeds everyone', eyeScale: 1.0, gap: 0.1, tilt: -0.1, lid: 0, bottomLid: 0.3, look: [0, 0], lean: -1, mouth: 'M3.95 6.4Q6.0 8.0 8.05 6.45', cheeks: true },
  lilac:     { persona: 'the doorkeeper — calm, knowing, a little mysterious', eyeScale: 0.96, gap: 0.3, tilt: -0.1, lid: 0.2, lidSlant: -0.05, look: [-0.1, 0], lean: 0, mouth: 'M4.9 6.6Q6.2 7.45 7.4 6.5' },
};

// ------------------------------------------------------------ helpers ----
const f = (v: number) => +v.toFixed(3);
/** An eye as a polygon (sampled ellipse, cut by an upper lid line and an optional lower lid). */
export function eye(cx: number, cy: number, rx: number, ry: number, o: { top?: number; slant?: number; inner?: 1 | -1; bot?: number } = {}): string {
  const N = 28; const pts: [number, number][] = [];
  const top = o.top ?? 0, slant = o.slant ?? 0, inner = o.inner ?? 1, bot = o.bot ?? 0;
  // lid line: y = y0 + m*(x-cx); inner side (toward the face centre) lower when slant > 0
  const y0 = cy - ry + 2 * ry * top, m = (slant * 2 * ry) / (2 * rx) * inner;
  const yb = cy + ry - 2 * ry * bot;
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    let x = cx + rx * Math.cos(a), y = cy + ry * Math.sin(a);
    const lid = y0 + m * (x - cx);
    if (top > 0 && y < lid) y = lid;
    if (bot > 0 && y > yb) y = yb - (y - yb) * 0.35; // smiling lower lid bows upward
    pts.push([x, y]);
  }
  return 'M' + pts.map(([x, y]) => `${f(x)} ${f(y)}`).join('L') + 'Z';
}
const ell = (cx: number, cy: number, rx: number, ry: number) => eye(cx, cy, rx, ry);
function star4(cx: number, cy: number, r: number, rot = 0): string {
  const pts: string[] = [];
  for (let i = 0; i < 8; i++) {
    const a = rot + (i * Math.PI) / 4 - Math.PI / 2, rr = i % 2 ? r * 0.36 : r * (i === 0 ? 1.05 : i === 4 ? 0.95 : 1);
    pts.push(`${f(cx + rr * Math.cos(a))} ${f(cy + rr * Math.sin(a))}`);
  }
  return 'M' + pts.join('L') + 'Z';
}
/** Half-ellipse open mouth with a flat (slightly tilted) top. */
function openMouth(cx: number, top: number, w: number, h: number, tilt = 0): string {
  const N = 14, pts: string[] = [];
  for (let i = 0; i <= N; i++) { const a = (i / N) * Math.PI; pts.push(`${f(cx + (w / 2) * Math.cos(a))} ${f(top + h * Math.sin(a) + tilt * Math.cos(a))}`); }
  return 'M' + pts.join('L') + 'Z';
}
function tongue(cx: number, top: number, w: number, h: number): string {
  // the bottom of the open mouth: a soft lump, drawn inside the mouth
  const N = 10, pts: string[] = [];
  for (let i = 0; i <= N; i++) { const a = (i / N) * Math.PI; pts.push(`${f(cx + (w / 2) * Math.cos(a))} ${f(top + h - (h * 0.42) + h * 0.42 * Math.sin(a))}`); }
  pts.push(`${f(cx - w / 2 + 0.2)} ${f(top + h * 0.55)}`);
  pts.push(`${f(cx + w / 2 - 0.2)} ${f(top + h * 0.6)}`);
  return 'M' + pts.join('L') + 'Z';
}

export type Ctx = { B: Body; T: Trait; bw: number; bh: number; bb: { x0: number; y0: number; x1: number; y1: number; cx: number; cy: number } };

export type Acting = {
  face: Prim[];            // face space
  body: Prim[];            // body space, in front, moves with the rig
  behind: Prim[];          // body space, behind the body (nubs)
  free: Prim[];            // body space, not rigged (dashed lines, puffs, confetti that floats)
  rig: { lean: number; squash: number; y: number };
  dim?: boolean;           // away: 60 % + desaturated
  shadowScale?: number;
};

function eyes(c: Ctx, o: { look?: [number, number]; top?: number; slant?: number; bot?: number; scale?: number; hl?: boolean } = {}): Prim[] {
  const { T, B } = c;
  const s = T.eyeScale * (o.scale ?? 1), [lx, ly] = o.look ?? [0, 0];
  const L = { x: 3.8 - T.gap / 2 + lx, y: 3.6 + T.tilt + ly }, R = { x: 8.2 + T.gap / 2 + lx, y: 3.6 + ly };
  const out: Prim[] = [
    { t: 'blob', d: eye(L.x, L.y, 1.1 * s, 1.45 * s, { top: o.top, slant: o.slant, inner: 1, bot: o.bot }), c: 'glyph' },
    { t: 'blob', d: eye(R.x, R.y, 1.1 * s * 1.04, 1.45 * s * 1.04, { top: o.top, slant: o.slant, inner: -1, bot: o.bot }), c: 'glyph' },
  ];
  if (B.glyph === 'ink' && o.hl !== false) {
    const hy = (o.top ?? 0) > 0.3 ? 0.15 : -0.45;
    out.push({ t: 'blob', d: ell(L.x + 0.36 * s, L.y + hy * s, 0.36 * s, 0.4 * s), c: 'cream', amp: 0.02 });
    out.push({ t: 'blob', d: ell(R.x + 0.38 * s, R.y + hy * s, 0.37 * s, 0.41 * s), c: 'cream', amp: 0.02 });
    if (T.hl2) {
      out.push({ t: 'blob', d: ell(L.x - 0.35 * s, L.y + 0.55 * s, 0.17 * s, 0.17 * s), c: 'cream', amp: 0.01 });
      out.push({ t: 'blob', d: ell(R.x - 0.35 * s, R.y + 0.55 * s, 0.17 * s, 0.17 * s), c: 'cream', amp: 0.01 });
    }
  }
  return out;
}
const cheeks = (c: Ctx, big = false): Prim[] => {
  const col: Col = c.B.id === 'rose' || c.B.id === 'coral' ? 'ink' : 'rose';
  const o = col === 'ink' ? (big ? 0.42 : 0.3) : (big ? 0.95 : 0.75); const n = big ? 4 : 3, w = big ? 0.46 : 0.36;
  const out: Prim[] = [];
  for (const [cx, cy] of [[2.0, 5.85], [10.0, 5.75]] as const) {
    for (let i = 0; i < n; i++) out.push({ t: 'stroke', d: `M${f(cx - 0.95 + i * 0.6)} ${f(cy + 0.55)}L${f(cx - 0.5 + i * 0.6)} ${f(cy - 0.5)}`, w, c: col, o, amp: 0.03 });
  }
  return out;
};

// body-space extras -------------------------------------------------------
const top = (c: Ctx) => c.bb.y0;
const endX = (c: Ctx) => c.bb.x1;
function heart(x: number, y: number, s: number): string {
  const p = [[0, 1.0], [-0.9, -0.2], [-2.35, 0.05], [-2.55, 1.55], [-2.2, 3.0], [-0.9, 4.1], [0.05, 4.95], [0.95, 4.05], [2.35, 2.85], [2.55, 1.35], [2.15, 0.05], [0.95, -0.25]];
  const q = p.map(([a, b]) => [x + a * s, y + b * s]);
  return `M${f(q[0][0])} ${f(q[0][1])}C${f(q[1][0])} ${f(q[1][1])} ${f(q[2][0])} ${f(q[2][1])} ${f(q[3][0])} ${f(q[3][1])}C${f(q[4][0])} ${f(q[4][1])} ${f(q[5][0])} ${f(q[5][1])} ${f(q[6][0])} ${f(q[6][1])}C${f(q[7][0])} ${f(q[7][1])} ${f(q[8][0])} ${f(q[8][1])} ${f(q[9][0])} ${f(q[9][1])}C${f(q[10][0])} ${f(q[10][1])} ${f(q[11][0])} ${f(q[11][1])} ${f(q[0][0])} ${f(q[0][1])}Z`;
}
function drop(x: number, y: number, s: number, rot = 0): string {
  const p = [[0, -2.2], [0.5, -1.2], [1.35, -0.2], [1.3, 0.75], [1.2, 1.7], [-1.2, 1.75], [-1.3, 0.7], [-1.35, -0.25], [-0.55, -1.1]];
  const c = Math.cos(rot), sn = Math.sin(rot);
  const q = p.map(([a, b]) => [x + (a * c - b * sn) * s, y + (a * sn + b * c) * s]);
  return `M${f(q[0][0])} ${f(q[0][1])}C${f(q[1][0])} ${f(q[1][1])} ${f(q[2][0])} ${f(q[2][1])} ${f(q[3][0])} ${f(q[3][1])}C${f(q[4][0])} ${f(q[4][1])} ${f(q[5][0])} ${f(q[5][1])} ${f(q[6][0])} ${f(q[6][1])}C${f(q[7][0])} ${f(q[7][1])} ${f(q[8][0])} ${f(q[8][1])} ${f(q[0][0])} ${f(q[0][1])}Z`;
}
function cloud(x: number, y: number): string {
  return `M${x - 3.6} ${y + 1.4}C${x - 4.9} ${y + 1.3} ${x - 4.8} ${y - 0.9} ${x - 3.3} ${y - 0.75}C${x - 3.2} ${y - 2.5} ${x - 0.9} ${y - 2.9} ${x - 0.2} ${y - 1.5}C${x + 0.6} ${y - 3.1} ${x + 3.2} ${y - 2.6} ${x + 3.0} ${y - 0.7}C${x + 4.7} ${y - 0.6} ${x + 4.6} ${y + 1.6} ${x + 3.1} ${y + 1.55}Z`;
}
function bang(x: number, y: number, rot = 0.12): string {
  // a hand-lettered "!": a fat brush wedge
  const p = [[-0.95, -3.4], [1.05, -3.2], [0.45, 0.6], [-0.35, 0.55]];
  const c = Math.cos(rot), sn = Math.sin(rot);
  const q = p.map(([a, b]) => [x + a * c - b * sn, y + a * sn + b * c]);
  return `M${f(q[0][0])} ${f(q[0][1])}Q${f((q[0][0] + q[1][0]) / 2)} ${f(q[0][1] - 0.6)} ${f(q[1][0])} ${f(q[1][1])}L${f(q[2][0])} ${f(q[2][1])}Q${f((q[2][0] + q[3][0]) / 2)} ${f(q[2][1] + 0.35)} ${f(q[3][0])} ${f(q[3][1])}Z`;
}
function spark(x: number, y: number, r: number): string { return star4(x, y, r, 0.1); }
/** Confetti: cut from the character's own colour; little versions of its own shape + paper strips. */
function confetti(c: Ctx, seedPts: [number, number, number, number][]): Prim[] {
  const out: Prim[] = [];
  for (const [x, y, s, rot] of seedPts) {
    if (s > 0) {
      const ca = Math.cos(rot), sa = Math.sin(rot);
      const p = [[-1, -0.55], [1.05, -0.45], [0.95, 0.5], [-1.0, 0.58]].map(([a, b]) => [x + (a * ca - b * sa) * s, y + (a * sa + b * ca) * s]);
      out.push({ t: 'sticker', d: `M${p.map(([a, b]) => `${f(a)} ${f(b)}`).join('L')}Z`, c: 'body', w: 0.38 });
    } else {
      out.push({ t: 'sticker', d: `SHAPE:${x}:${y}:${-s}:${rot}`, c: 'body', w: 0.4 });
    }
  }
  return out;
}
function nub(c: Ctx, ax: number, ay: number, angDeg: number, len = 0.2): Prim {
  // a short mitten nub, body colour; base sinks 1.7 into the body
  const L = Math.max(3.2, c.bw * len) + 1.9, a = (angDeg * Math.PI) / 180, ca = Math.cos(a), sa = Math.sin(a);
  const loc = [[-1.9, -1.55], [L - 2.0, -1.7], [L - 0.1, -1.5], [L + 0.75, 0.1], [L - 0.05, 1.6], [L - 2.0, 1.75], [-1.9, 1.6]];
  const p = loc.map(([u, v]) => [ax + u * ca - v * sa, ay + u * sa + v * ca]);
  const P = (i: number) => `${f(p[i][0])} ${f(p[i][1])}`;
  return { t: 'sticker', d: `M${P(0)}L${P(1)}C${P(2)} ${P(2)} ${P(3)}C${P(3)} ${P(4)} ${P(5)}L${P(6)}Z`, c: 'body', w: 0.75, shade: true };
}
function zz(x: number, y: number, s: number): string {
  return `M${f(x)} ${f(y)}L${f(x + 1.7 * s)} ${f(y - 0.15 * s)}L${f(x + 0.1 * s)} ${f(y + 1.85 * s)}L${f(x + 1.95 * s)} ${f(y + 1.75 * s)}`;
}

// ------------------------------------------------------------ the 13 ----
export const EXPRESSIONS = ['idle', 'think', 'done', 'happy', 'laugh', 'smug', 'shock', 'sad', 'facepalm', 'shy', 'point', 'cheer', 'away'] as const;
export const POSES = ['wave', 'point', 'cheer', 'sneak'] as const;
export type Expr = typeof EXPRESSIONS[number];

const blank = (): Acting => ({ face: [], body: [], behind: [], free: [], rig: { lean: 0, squash: 1, y: 0 } });

export function acting(expr: Expr, c: Ctx): Acting {
  const { T, B } = c; const A = blank();
  const tx = endX(c), ty = top(c);
  switch (expr) {
    case 'idle': {
      A.face.push(...eyes(c, { look: T.look, top: T.lid, slant: T.lidSlant, bot: T.bottomLid }));
      if (T.mouthOpen) { A.face.push({ t: 'blob', d: openMouth(6, 5.9, 3.4, 1.5, -0.12), c: 'glyph' }); A.face.push({ t: 'blob', d: tongue(6.15, 5.9, 1.9, 1.35), c: 'rose' }); }
      else A.face.push({ t: 'stroke', d: T.mouth, w: 0.8, c: 'glyph' });
      if (T.cheeks) A.face.push(...cheeks(c));
      if (T.glint) A.body.push({ t: 'blob', d: spark(tx + 1.2, ty + 2.4, 1.5), c: 'paper', o: 0.95 }, { t: 'blob', d: spark(tx + 3.0, ty + 5.0, 0.8), c: 'paper', o: 0.8 });
      A.rig.lean = T.lean;
      break;
    }
    case 'think': {
      A.face.push(...eyes(c, { look: [0.9, -0.8], top: Math.min(T.lid, 0.15) }));
      A.face.push({ t: 'stroke', d: 'M8.05 0.65Q8.9 -0.15 10.0 0.25', w: 0.7, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M2.55 1.55Q3.6 1.35 4.7 1.5', w: 0.62, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M5.35 6.95Q6.5 6.65 7.75 6.9', w: 0.78, c: 'glyph' });
      // the three-line thinking scribble, above the end side of the head
      A.body.push({ t: 'stroke', d: `M${tx - 2.2} ${ty - 0.9}q0.4 -1.0 1.2 -1.3`, w: 0.55, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${tx - 0.6} ${ty - 2.4}q0.5 -1.3 1.6 -1.6`, w: 0.6, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${tx + 1.3} ${ty - 3.6}q0.9 -1.5 2.3 -1.6q1.0 0.1 0.6 1.0q-0.5 0.9 -1.5 0.4`, w: 0.6, c: 'paper' });
      A.rig.lean = 3;
      break;
    }
    case 'done': {
      A.face.push({ t: 'stroke', d: `M${2.7 - T.gap / 2} ${3.85 + T.tilt}Q${3.8 - T.gap / 2} ${2.75 + T.tilt} ${4.9 - T.gap / 2} ${3.85 + T.tilt}`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.1 + T.gap / 2} 3.8Q${8.2 + T.gap / 2} 2.75 ${9.3 + T.gap / 2} 3.8`, w: 0.75, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.8 6.55Q6.0 7.45 7.25 6.5', w: 0.8, c: 'glyph' });
      if (T.cheeks) A.face.push(...cheeks(c));
      A.body.push({ t: 'sticker', d: 'BADGE:check', c: 'success' });
      A.rig.lean = 5;
      break;
    }
    case 'happy': {
      A.face.push({ t: 'stroke', d: `M${2.65 - T.gap / 2} ${4.25 + T.tilt}Q${3.8 - T.gap / 2} ${2.5 + T.tilt} ${4.95 - T.gap / 2} ${4.2 + T.tilt}`, w: 0.82, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.05 + T.gap / 2} 4.2Q${8.2 + T.gap / 2} 2.5 ${9.35 + T.gap / 2} 4.25`, w: 0.82, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6, 5.95, 3.7, 1.9, -0.1), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.2, 5.95, 2.0, 1.75), c: 'rose' });
      if (T.cheeks) A.face.push(...cheeks(c));
      A.body.push({ t: 'sticker', d: heart(tx + 1.2, ty - 1.6, 0.62), c: 'rose', w: 0.5 });
      A.rig.y = -1.2; A.rig.squash = 1.04;
      break;
    }
    case 'laugh': {
      A.face.push({ t: 'stroke', d: 'M2.35 2.55L4.5 3.65L2.45 4.75', w: 0.82, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M9.65 2.5L7.5 3.6L9.55 4.75', w: 0.82, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.05, 5.55, 4.6, 2.55, 0.15), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.3, 5.55, 2.4, 2.35), c: 'rose' });
      A.face.push({ t: 'sticker', d: drop(0.6, 3.0, 0.55, 0.9), c: 'aqua', w: 0.32 });
      A.face.push({ t: 'sticker', d: drop(11.5, 3.1, 0.55, -0.9), c: 'aqua', w: 0.32 });
      A.rig.squash = 0.93; A.rig.lean = -4;
      break;
    }
    case 'smug': {
      A.face.push(...eyes(c, { look: [0.25, 0.1], top: 0.47, slant: 0.02 }));
      A.face.push({ t: 'stroke', d: `M${2.55 - T.gap / 2} 1.95L${4.85 - T.gap / 2} 1.85`, w: 0.66, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.15 + T.gap / 2} 1.0Q${8.3 + T.gap / 2} 0.2 ${9.5 + T.gap / 2} 0.75`, w: 0.68, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.55 6.85Q6.9 7.55 7.95 5.95', w: 0.82, c: 'glyph' });
      A.body.push({ t: 'blob', d: spark(tx + 0.4, ty + 3.6, 1.3), c: 'paper' });
      A.rig.lean = -6;
      break;
    }
    case 'shock': {
      const s = T.eyeScale;
      const L = { x: 3.7 - T.gap / 2, y: 3.4 + T.tilt }, R = { x: 8.3 + T.gap / 2, y: 3.4 };
      for (const [e, k] of [[L, 1], [R, 1.06]] as const) {
        A.face.push({ t: 'blob', d: ell(e.x, e.y, 1.62 * s * k, 1.62 * s * k), c: 'glyph' });
        A.face.push({ t: 'blob', d: ell(e.x, e.y, 1.2 * s * k, 1.2 * s * k), c: 'cream' });
        A.face.push({ t: 'blob', d: ell(e.x + 0.12, e.y + 0.05, 0.5, 0.52), c: 'ink' });
      }
      A.face.push({ t: 'stroke', d: `M${2.35 - T.gap / 2} 0.85Q${3.6 - T.gap / 2} -0.4 ${4.95 - T.gap / 2} 0.35`, w: 0.68, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.05 + T.gap / 2} 0.35Q${8.4 + T.gap / 2} -0.45 ${9.7 + T.gap / 2} 0.8`, w: 0.68, c: 'glyph' });
      A.face.push({ t: 'blob', d: ell(6.05, 7.0, 0.78, 1.0), c: 'glyph' });
      A.body.push({ t: 'sticker', d: bang(tx + 1.9, ty + 2.0), c: 'accent', w: 0.55 });
      A.body.push({ t: 'sticker', d: ell(tx + 1.55, ty + 3.75, 0.62, 0.6), c: 'accent', w: 0.5 });
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 - 0.8} ${ty + 2.6}l-1.5 -1.3`, w: 0.6, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 + 0.6} ${ty + 0.2}l-0.9 -1.7`, w: 0.6, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 - 1.2} ${ty + 5.4}l-1.9 -0.4`, w: 0.6, c: 'paper' });
      A.rig.squash = 1.08; A.rig.lean = -5;
      break;
    }
    case 'sad': {
      A.face.push(...eyes(c, { look: [0, 0.45], top: 0.3, slant: -0.4 }));
      A.face.push({ t: 'stroke', d: `M${2.45 - T.gap / 2} 1.95Q${3.6 - T.gap / 2} 1.75 ${4.75 - T.gap / 2} 0.85`, w: 0.64, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.25 + T.gap / 2} 0.85Q${8.4 + T.gap / 2} 1.75 ${9.55 + T.gap / 2} 1.95`, w: 0.64, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.5 7.55Q6.0 6.45 7.6 7.45', w: 0.8, c: 'glyph' });
      A.face.push({ t: 'sticker', d: drop(9.6 + T.gap / 2, 6.0, 0.5, 0), c: 'aqua', w: 0.3 });
      A.body.push({ t: 'sticker', d: cloud(c.bb.cx + 3.5, ty - 3.4), c: 'muted', w: 0.55 });
      for (const [x, y] of [[0.8, -1.0], [3.0, -0.6], [5.0, -1.1]]) A.body.push({ t: 'stroke', d: `M${c.bb.cx + x + 0.5} ${ty + y}l-0.45 1.3`, w: 0.45, c: 'aqua' });
      A.rig.squash = 0.95; A.rig.y = 0.5; A.rig.lean = 2;
      break;
    }
    case 'facepalm': {
      A.face.push({ t: 'stroke', d: `M${7.2 + T.gap / 2} 3.9Q${8.2 + T.gap / 2} 4.25 ${9.3 + T.gap / 2} 3.85`, w: 0.72, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M4.9 7.05Q6.1 6.9 7.3 7.1', w: 0.78, c: 'glyph' });
      A.body.push({ t: 'sticker', d: 'PALM', c: 'body' });
      A.body.push({ t: 'sticker', d: drop(tx + 0.6, ty + 2.6, 0.62, 0.35), c: 'aqua', w: 0.4 });
      A.rig.lean = 5;
      break;
    }
    case 'shy': {
      A.face.push(...eyes(c, { look: [-0.45, 1.0], top: 0.2, scale: 0.9 }));
      A.face.push({ t: 'stroke', d: 'M5.3 7.15Q6.0 7.55 6.75 7.1', w: 0.7, c: 'glyph' });
      A.face.push(...cheeks(c, true));
      A.body.push({ t: 'stroke', d: `M${c.bb.x0 + 0.2} ${ty + 1.2}q-0.9 -0.6 -1.0 -1.7`, w: 0.5, c: 'paper', o: 0.85 }, { t: 'stroke', d: `M${c.bb.x0 + 1.9} ${ty - 0.4}q-0.5 -0.9 -0.2 -1.9`, w: 0.5, c: 'paper', o: 0.85 });
      A.rig.lean = -7; A.rig.squash = 0.95;
      break;
    }
    case 'point': {
      A.face.push(...eyes(c, { look: [1.05, -0.05] }));
      A.face.push({ t: 'blob', d: openMouth(6.35, 6.45, 2.8, 1.05, -0.08), c: 'glyph' });
      A.behind.push(nub(c, B.hand[0], B.hand[1] - 0.6, -16, 0.24));
      A.rig.lean = 10;
      break;
    }
    case 'cheer': {
      const s = T.eyeScale;
      A.face.push({ t: 'blob', d: star4(3.75 - T.gap / 2, 3.5 + T.tilt, 1.75 * s, -0.12), c: 'glyph' });
      A.face.push({ t: 'blob', d: star4(8.25 + T.gap / 2, 3.45, 1.8 * s, 0.1), c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.05, 5.6, 4.6, 2.5, 0.05), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.25, 5.6, 2.4, 2.3), c: 'rose' });
      A.free.push(...confetti(c, [[c.bb.x0 - 2.5, ty + 0.5, 0.9, 0.5], [tx + 2.2, ty - 0.8, -0.2, 0.4], [c.bb.cx - 3, ty - 4.2, -0.17, -0.3], [tx + 3.3, ty + 5.5, 0.75, -0.7], [c.bb.cx + 3.5, ty - 4.5, 0.7, 1.1], [c.bb.x0 - 1.5, ty + 6.5, -0.15, 0.9]]));
      A.rig.y = -2.0; A.rig.squash = 1.06;
      A.shadowScale = 0.8;
      break;
    }
    case 'away': {
      A.face.push({ t: 'stroke', d: `M${2.75 - T.gap / 2} ${3.95 + T.tilt}Q${3.8 - T.gap / 2} ${4.2 + T.tilt} ${4.85 - T.gap / 2} ${3.9 + T.tilt}`, w: 0.7, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.15 + T.gap / 2} 3.9Q${8.2 + T.gap / 2} 4.2 ${9.25 + T.gap / 2} 3.95`, w: 0.7, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M5.3 7.0L6.75 6.95', w: 0.72, c: 'glyph' });
      A.body.push({ t: 'stroke', d: zz(tx - 0.5, ty - 1.2, 1.0), w: 0.62, c: 'paper' });
      A.body.push({ t: 'stroke', d: zz(tx + 1.9, ty - 4.3, 0.7), w: 0.5, c: 'paper', o: 0.8 });
      A.body.push({ t: 'sticker', d: 'BADGE:wifi', c: 'danger' });
      A.dim = true; A.rig.squash = 0.97; A.rig.lean = -2;
      break;
    }
  }
  return A;
}

export function pose(p: typeof POSES[number], c: Ctx, contour: (ang: number) => [number, number]): Acting {
  const { T, B } = c; const A = blank();
  const tx = endX(c), ty = top(c);
  switch (p) {
    case 'wave': {
      A.face.push(...eyes(c, { look: [0.2, -0.1], top: Math.min(T.lid, 0.2), slant: T.lidSlant, bot: 0.22 }));
      A.face.push({ t: 'blob', d: openMouth(6, 6.0, 3.2, 1.55, -0.12), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.2, 6.0, 1.8, 1.45), c: 'rose' });
      if (T.cheeks) A.face.push(...cheeks(c));
      const [ax, ay] = contour(-38);
      A.behind.push(nub(c, ax, ay, -62, 0.22));
      const a = (-62 * Math.PI) / 180, L = Math.max(3.0, c.bw * 0.22) + 0.6;
      const kx = ax + Math.cos(a) * L, ky = ay + Math.sin(a) * L;
      A.body.push({ t: 'stroke', d: `M${f(kx - 2.6)} ${f(ky - 1.4)}Q${f(kx - 1.6)} ${f(ky - 3.4)} ${f(kx + 0.4)} ${f(ky - 3.6)}`, w: 0.55, c: 'paper' });
      A.body.push({ t: 'stroke', d: `M${f(kx + 2.0)} ${f(ky - 2.2)}Q${f(kx + 3.2)} ${f(ky - 0.9)} ${f(kx + 3.0)} ${f(ky + 1.0)}`, w: 0.55, c: 'paper' });
      A.rig.lean = -5; A.rig.squash = 1.02;
      break;
    }
    case 'point': {
      A.face.push(...eyes(c, { look: [1.15, 0], top: 0.18, slant: 0.25 }));
      A.face.push({ t: 'stroke', d: `M${2.6 - T.gap / 2} 1.45L${4.8 - T.gap / 2} 1.95`, w: 0.66, c: 'glyph' });
      A.face.push({ t: 'stroke', d: `M${7.2 + T.gap / 2} 1.95L${9.4 + T.gap / 2} 1.4`, w: 0.66, c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.4, 6.3, 3.0, 1.35, -0.1), c: 'glyph' });
      A.behind.push(nub(c, B.hand[0], B.hand[1], -6, 0.24));
      // the dashed "accusation" line toward the target
      const sx = B.hand[0] + Math.max(3.0, c.bw * 0.24) + 1.6;
      for (let i = 0; i < 3; i++) A.free.push({ t: 'stroke', d: `M${f(sx + 0.6 + i * 2.1)} ${f(B.hand[1] - 2.4 - i * 0.28)}l1.1 -0.14`, w: 0.6, c: 'paper', o: 1 - i * 0.2 });
      A.rig.lean = 12;
      break;
    }
    case 'cheer': {
      const s = T.eyeScale;
      A.face.push({ t: 'blob', d: star4(3.75 - T.gap / 2, 3.5 + T.tilt, 1.75 * s, -0.12), c: 'glyph' });
      A.face.push({ t: 'blob', d: star4(8.25 + T.gap / 2, 3.45, 1.8 * s, 0.1), c: 'glyph' });
      A.face.push({ t: 'blob', d: openMouth(6.05, 5.55, 4.8, 2.7, 0.05), c: 'glyph' });
      A.face.push({ t: 'blob', d: tongue(6.25, 5.55, 2.5, 2.5), c: 'rose' });
      const [lx, ly] = contour(-148), [rx, ry] = contour(-32);
      A.behind.push(nub(c, lx, ly, -122, 0.2), nub(c, rx, ry, -58, 0.2));
      A.free.push(...confetti(c, [[c.bb.x0 - 3, ty - 2.5, 0.85, 0.6], [tx + 2.6, ty - 3.4, -0.22, 0.3], [c.bb.cx, ty - 7.0, -0.18, -0.4], [tx + 3.8, ty + 3.5, 0.8, -0.8], [c.bb.cx - 5.5, ty - 6.0, 0.7, 1.2], [c.bb.x0 - 2.6, ty + 4.5, -0.16, 0.8], [c.bb.cx + 5.2, ty - 6.6, 0.6, 2.2]]));
      A.rig.y = -3.6; A.rig.squash = 1.08;
      A.shadowScale = 0.66;
      break;
    }
    case 'sneak': {
      A.face.push(...eyes(c, { look: [-1.0, 0.2], top: 0.42, slant: 0.1, scale: 0.98 }));
      A.face.push({ t: 'stroke', d: `M${2.5 - T.gap / 2} 1.65L${4.7 - T.gap / 2} 2.0`, w: 0.6, c: 'glyph' });
      A.face.push({ t: 'stroke', d: 'M5.0 6.95Q5.5 6.6 6.0 6.95Q6.5 7.3 7.0 6.95', w: 0.7, c: 'glyph' });
      const [ax, ay] = contour(-22), [bx, by] = contour(-158);
      A.behind.push(nub(c, ax, ay, -48, 0.16), nub(c, bx, by, -140, 0.14));
      // tiptoe puffs behind, and a dotted trail
      for (const [x, s] of [[c.bb.x0 - 1.2, 1.0], [c.bb.x0 - 3.6, 0.75], [c.bb.x0 - 5.6, 0.55]] as const)
        A.free.push({ t: 'blob', d: ell(x, c.bb.y1 - 0.2, 0.75 * s, 0.5 * s), c: 'paper', o: 0.55 });
      A.free.push({ t: 'stroke', d: `M${c.bb.x0 - 0.2} ${ty + 5.0}l-2.2 0.2`, w: 0.5, c: 'paper', o: 0.7 });
      A.free.push({ t: 'stroke', d: `M${c.bb.x0 - 0.6} ${ty + 8.0}l-3.0 0.1`, w: 0.5, c: 'paper', o: 0.7 });
      A.rig.squash = 0.88; A.rig.lean = 9;
      break;
    }
  }
  return A;
}
