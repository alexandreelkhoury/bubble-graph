/**
 * handmade.ts — a deterministic "drawn by hand" generator.
 *
 * Clean geometry (SVG path data in the 24-unit character box) goes in;
 * N "boil" variants come out. Each variant is one pass of the same hand:
 * the same wobble spectrum, a different seed. Cycle the variants at 8–12 fps
 * and the line lives; freeze on variant 0 and it is still visibly hand-made.
 *
 * Zero dependencies, no Math.random, no Date: the same input + seed gives the
 * same bytes on every machine, so web (runtime or build) and the Kotlin
 * generator produce identical drawings (fixture-testable).
 *
 * Layers produced per variant:
 *   fill  — the colour shape, boiled with a low amplitude and its own seed.
 *           The renderer offsets it (misregistration) so it never sits exactly
 *           inside the line, like a riso / screen print.
 *   ink   — the outline as a variable-width filled ribbon (pressure + taper),
 *           drawn as ONE open stroke that starts at a seeded point and
 *           overshoots its own start, the way a pen closes a loop.
 *   line  — the cheap alternative to `ink`: the boiled centreline as a path
 *           for a constant-width stroke (small sizes, low-end TV).
 *   hatch — a few tapered scribble strokes on the shadow side; clip with `fill`.
 *   paper — a calm blob drawn under everything with a wide round stroke in the
 *           paper colour: the cut-out / shadow-puppet backing that makes a
 *           dark ink line read on the dark stages.
 */

export type Pt = { x: number; y: number };
export type Cubic = [number, number, number, number, number, number, number, number];
export type Sub = { closed: boolean; segs: Cubic[] };

// ---------------------------------------------------------------- PRNG ----
export function hashSeed(s: string): number {
  let h = 2166136261 >>> 0; // FNV-1a
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h;
}
export function rng(seed: number) { // mulberry32
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// --------------------------------------------------------- path parser ----
const CMD = /([MmLlHhVvCcSsQqTtAaZz])|(-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)/g;

export function parsePath(d: string): Sub[] {
  const toks: (string | number)[] = [];
  for (const m of d.matchAll(CMD)) toks.push(m[1] ?? parseFloat(m[2]));
  const subs: Sub[] = [];
  let cur: Sub | null = null;
  let x = 0, y = 0, sx = 0, sy = 0, lcx = 0, lcy = 0, lqx = 0, lqy = 0, prev = '';
  let i = 0, cmd = '';
  const num = () => toks[i++] as number;
  const line = (x1: number, y1: number) => {
    cur!.segs.push([x, y, x + (x1 - x) / 3, y + (y1 - y) / 3, x + (2 * (x1 - x)) / 3, y + (2 * (y1 - y)) / 3, x1, y1]);
    x = x1; y = y1;
  };
  while (i < toks.length) {
    if (typeof toks[i] === 'string') cmd = toks[i++] as string;
    else if (cmd === 'M') cmd = 'L'; else if (cmd === 'm') cmd = 'l';
    const rel = cmd === cmd.toLowerCase() && cmd !== 'z' && cmd !== 'Z';
    const ox = rel ? x : 0, oy = rel ? y : 0;
    const C = cmd.toUpperCase();
    if (C === 'M') {
      x = ox + num(); y = oy + num(); sx = x; sy = y;
      cur = { closed: false, segs: [] }; subs.push(cur);
    } else if (C === 'L') line(ox + num(), oy + num());
    else if (C === 'H') line(ox + num(), y);
    else if (C === 'V') line(x, oy + num());
    else if (C === 'C' || C === 'S') {
      let x1: number, y1: number;
      if (C === 'C') { x1 = ox + num(); y1 = oy + num(); }
      else if (prev === 'C' || prev === 'S') { x1 = 2 * x - lcx; y1 = 2 * y - lcy; } else { x1 = x; y1 = y; }
      const x2 = ox + num(), y2 = oy + num(), x3 = ox + num(), y3 = oy + num();
      cur!.segs.push([x, y, x1, y1, x2, y2, x3, y3]);
      lcx = x2; lcy = y2; x = x3; y = y3;
    } else if (C === 'Q' || C === 'T') {
      let qx: number, qy: number;
      if (C === 'Q') { qx = ox + num(); qy = oy + num(); }
      else if (prev === 'Q' || prev === 'T') { qx = 2 * x - lqx; qy = 2 * y - lqy; } else { qx = x; qy = y; }
      const x3 = ox + num(), y3 = oy + num();
      cur!.segs.push([x, y, x + (2 / 3) * (qx - x), y + (2 / 3) * (qy - y), x3 + (2 / 3) * (qx - x3), y3 + (2 / 3) * (qy - y3), x3, y3]);
      lqx = qx; lqy = qy; x = x3; y = y3;
    } else if (C === 'A') {
      const rx = num(), ry = num(), rot = num(), fa = num(), fs = num(), x3 = ox + num(), y3 = oy + num();
      for (const c of arcToCubics(x, y, rx, ry, rot, fa, fs, x3, y3)) cur!.segs.push(c);
      x = x3; y = y3;
    } else if (C === 'Z') {
      if (Math.hypot(x - sx, y - sy) > 1e-6) line(sx, sy);
      cur!.closed = true; x = sx; y = sy;
    }
    prev = C;
  }
  return subs.filter((s) => s.segs.length);
}

function arcToCubics(x1: number, y1: number, rx: number, ry: number, phiDeg: number, fa: number, fs: number, x2: number, y2: number): Cubic[] {
  if (rx === 0 || ry === 0) return [[x1, y1, x1, y1, x2, y2, x2, y2]];
  const phi = (phiDeg * Math.PI) / 180, cos = Math.cos(phi), sin = Math.sin(phi);
  const dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
  const x1p = cos * dx + sin * dy, y1p = -sin * dx + cos * dy;
  rx = Math.abs(rx); ry = Math.abs(ry);
  const lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
  if (lam > 1) { rx *= Math.sqrt(lam); ry *= Math.sqrt(lam); }
  const num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
  const den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
  const co = (fa === fs ? -1 : 1) * Math.sqrt(Math.max(0, num / den));
  const cxp = (co * rx * y1p) / ry, cyp = (-co * ry * x1p) / rx;
  const cx = cos * cxp - sin * cyp + (x1 + x2) / 2, cy = sin * cxp + cos * cyp + (y1 + y2) / 2;
  const ang = (ux: number, uy: number, vx: number, vy: number) => {
    const a = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy);
    return a;
  };
  const t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
  let dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
  if (!fs && dt > 0) dt -= 2 * Math.PI; else if (fs && dt < 0) dt += 2 * Math.PI;
  const n = Math.ceil(Math.abs(dt) / (Math.PI / 2) - 1e-9);
  const out: Cubic[] = [];
  const d = dt / n, k = (4 / 3) * Math.tan(d / 4);
  let a = t1;
  const P = (t: number): Pt => ({ x: cx + rx * Math.cos(t) * cos - ry * Math.sin(t) * sin, y: cy + rx * Math.cos(t) * sin + ry * Math.sin(t) * cos });
  const D = (t: number): Pt => ({ x: -rx * Math.sin(t) * cos - ry * Math.cos(t) * sin, y: -rx * Math.sin(t) * sin + ry * Math.cos(t) * cos });
  for (let s = 0; s < n; s++) {
    const p0 = P(a), p3 = P(a + d), d0 = D(a), d3 = D(a + d);
    out.push([p0.x, p0.y, p0.x + k * d0.x, p0.y + k * d0.y, p3.x - k * d3.x, p3.y - k * d3.y, p3.x, p3.y]);
    a += d;
  }
  return out;
}

/** Circle / rounded-rect primitives as path data (so everything is one representation). */
export const circleD = (cx: number, cy: number, r: number) =>
  `M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0z`;
export const ellipseD = (cx: number, cy: number, rx: number, ry: number) =>
  `M${cx - rx} ${cy}a${rx} ${ry} 0 1 0 ${2 * rx} 0a${rx} ${ry} 0 1 0 ${-2 * rx} 0z`;
export const rrectD = (x: number, y: number, w: number, h: number, r: number) =>
  `M${x + r} ${y}H${x + w - r}a${r} ${r} 0 0 1 ${r} ${r}V${y + h - r}a${r} ${r} 0 0 1 ${-r} ${r}H${x + r}a${r} ${r} 0 0 1 ${-r} ${-r}V${y + r}a${r} ${r} 0 0 1 ${r} ${-r}z`;

// ------------------------------------------------------------ sampling ----
const bez = (c: Cubic, t: number): Pt => {
  const u = 1 - t, a = u * u * u, b = 3 * u * u * t, cc = 3 * u * t * t, d = t * t * t;
  return { x: a * c[0] + b * c[2] + cc * c[4] + d * c[6], y: a * c[1] + b * c[3] + cc * c[5] + d * c[7] };
};
const segLen = (c: Cubic) => {
  let L = 0, p = bez(c, 0);
  for (let i = 1; i <= 16; i++) { const q = bez(c, i / 16); L += Math.hypot(q.x - p.x, q.y - p.y); p = q; }
  return L;
};
const tanAt = (c: Cubic, end: boolean): Pt => {
  // robust end tangents (control points may coincide with the anchors)
  const pts = end ? [[c[6], c[7]], [c[4], c[5]], [c[2], c[3]], [c[0], c[1]]] : [[c[0], c[1]], [c[2], c[3]], [c[4], c[5]], [c[6], c[7]]];
  for (let i = 1; i < 4; i++) {
    const dx = pts[i][0] - pts[0][0], dy = pts[i][1] - pts[0][1], l = Math.hypot(dx, dy);
    if (l > 1e-6) return end ? { x: -dx / l, y: -dy / l } : { x: dx / l, y: dy / l };
  }
  return { x: 1, y: 0 };
};

export type Knot = Pt & { corner: boolean; s: number };

/** Knots along a subpath: anchors kept at corners, otherwise ~`spacing` apart. */
export function knots(sub: Sub, spacing: number, cornerDeg = 28): Knot[] {
  const out: Knot[] = [];
  const n = sub.segs.length;
  let s = 0;
  for (let i = 0; i < n; i++) {
    const c = sub.segs[i];
    const prevSeg = i > 0 ? sub.segs[i - 1] : sub.closed ? sub.segs[n - 1] : null;
    let corner = !prevSeg; // open ends are "corners" (fixed)
    if (prevSeg) {
      const a = tanAt(prevSeg, true), b = tanAt(c, false);
      corner = Math.acos(Math.max(-1, Math.min(1, a.x * b.x + a.y * b.y))) > (cornerDeg * Math.PI) / 180;
    }
    const L = segLen(c);
    const k = Math.max(1, Math.round(L / spacing));
    for (let j = 0; j < k; j++) {
      const p = bez(c, j / k);
      out.push({ ...p, corner: j === 0 && corner, s: s + (L * j) / k });
    }
    s += L;
  }
  if (!sub.closed) { const c = sub.segs[n - 1]; out.push({ x: c[6], y: c[7], corner: true, s }); }
  return out;
}

// -------------------------------------------------------- the "hand" ------
export type Hand = {
  /** max wobble across the line, in 24-box units (0.25 ≈ 1 dp at 96 dp) */
  amp: number;
  /** wobble wavelengths, units (an artist's wrist: slow bows, no buzz) */
  waveMin: number; waveMax: number;
  /** per-variant whole-drawing drift: rotation (deg) and translation (units) */
  rot: number; shift: number;
};
export const DEFAULT_HAND: Hand = { amp: 0.24, waveMin: 5.5, waveMax: 16, rot: 0.9, shift: 0.12 };

/** A band-limited 1-D noise along arc length; periodic over L when closed. */
export function wobble(L: number, closed: boolean, hand: Hand, r: () => number) {
  const terms: { f: number; a: number; p: number }[] = [];
  const kMin = Math.max(1, Math.floor(L / hand.waveMax)), kMax = Math.max(kMin + 1, Math.ceil(L / hand.waveMin));
  const count = Math.min(4, kMax - kMin + 1);
  for (let i = 0; i < count; i++) {
    const k = closed ? kMin + Math.floor(r() * (kMax - kMin + 1)) : (kMin + r() * (kMax - kMin));
    terms.push({ f: (2 * Math.PI * k) / L, a: (0.55 + 0.45 * r()) / Math.sqrt(count), p: r() * 2 * Math.PI });
  }
  return (s: number) => { let v = 0; for (const t of terms) v += t.a * Math.sin(t.f * s + t.p); return v; };
}

export function normals(k: Knot[], closed: boolean): Pt[] {
  const n = k.length;
  return k.map((p, i) => {
    const a = k[closed ? (i - 1 + n) % n : Math.max(0, i - 1)], b = k[closed ? (i + 1) % n : Math.min(n - 1, i + 1)];
    let tx = b.x - a.x, ty = b.y - a.y;
    if (p.corner && (closed || (i > 0 && i < n - 1))) {
      // bisector of the two edges keeps corners coherent
      const ax = p.x - a.x, ay = p.y - a.y, bx = b.x - p.x, by = b.y - p.y;
      const la = Math.hypot(ax, ay) || 1, lb = Math.hypot(bx, by) || 1;
      tx = ax / la + bx / lb; ty = ay / la + by / lb;
    }
    const l = Math.hypot(tx, ty) || 1;
    return { x: ty / l, y: -tx / l };
  });
}

export function boilKnots(sub: Sub, spacing: number, hand: Hand, r: () => number, center: Pt): Knot[] {
  const k = knots(sub, spacing);
  const L = sub.closed ? sub.segs.reduce((a, c) => a + segLen(c), 0) : k[k.length - 1].s;
  const w = wobble(L, sub.closed, hand, r);
  const nm = normals(k, sub.closed);
  const rot = ((r() * 2 - 1) * hand.rot * Math.PI) / 180, cs = Math.cos(rot), sn = Math.sin(rot);
  const tx = (r() * 2 - 1) * hand.shift, ty = (r() * 2 - 1) * hand.shift;
  return k.map((p, i) => {
    const d = w(p.s) * hand.amp;
    const x = p.x + nm[i].x * d - center.x, y = p.y + nm[i].y * d - center.y;
    return { x: center.x + x * cs - y * sn + tx, y: center.y + x * sn + y * cs + ty, corner: p.corner, s: p.s };
  });
}

/** Catmull-Rom through knots → cubics; one-sided tangents at corners. */
export function smooth(k: Knot[], closed: boolean, tension = 1): Cubic[] {
  const n = k.length, out: Cubic[] = [];
  const at = (i: number) => k[closed ? (i + n) % n : Math.max(0, Math.min(n - 1, i))];
  const segs = closed ? n : n - 1;
  for (let i = 0; i < segs; i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const t1 = p1.corner ? { x: (p2.x - p1.x) / 2, y: (p2.y - p1.y) / 2 } : { x: (p2.x - p0.x) / 2, y: (p2.y - p0.y) / 2 };
    const t2 = p2.corner ? { x: (p2.x - p1.x) / 2, y: (p2.y - p1.y) / 2 } : { x: (p3.x - p1.x) / 2, y: (p3.y - p1.y) / 2 };
    const f = tension / 3;
    out.push([p1.x, p1.y, p1.x + t1.x * f, p1.y + t1.y * f, p2.x - t2.x * f, p2.y - t2.y * f, p2.x, p2.y]);
  }
  return out;
}

export function densify(cs: Cubic[], step: number): Pt[] {
  const out: Pt[] = [];
  for (const c of cs) {
    const k = Math.max(1, Math.round(segLen(c) / step));
    for (let j = 0; j < k; j++) out.push(bez(c, j / k));
  }
  const l = cs[cs.length - 1];
  out.push({ x: l[6], y: l[7] });
  return out;
}

// ------------------------------------------------------------- output ----
/** Compact path data: absolute rounding first, then relative deltas (no drift). */
function fmt(v: number, dp: number) {
  let s = (Math.round(v * 10 ** dp) / 10 ** dp).toString();
  if (s === '-0') s = '0';
  return s.replace(/^(-?)0\./, '$1.');
}
function joinNums(nums: number[], dp: number) {
  let out = '', prev = '';
  for (const v of nums) {
    const s = fmt(v, dp);
    // a separator is only needed when the next token could merge with the previous one
    if (prev && !s.startsWith('-') && !(s.startsWith('.') && prev.includes('.'))) out += ' ';
    out += s; prev = s;
  }
  return out;
}
export function cubicsToD(subs: { closed: boolean; segs: Cubic[] }[], dp = 2): string {
  const q = (v: number) => Math.round(v * 10 ** dp) / 10 ** dp;
  let d = '';
  for (const sub of subs) {
    let x = q(sub.segs[0][0]), y = q(sub.segs[0][1]);
    d += 'M' + joinNums([x, y], dp);
    let nums: number[] = [];
    for (const c of sub.segs) {
      const a = [q(c[2]), q(c[3]), q(c[4]), q(c[5]), q(c[6]), q(c[7])];
      nums.push(a[0] - x, a[1] - y, a[2] - x, a[3] - y, a[4] - x, a[5] - y);
      x = a[4]; y = a[5];
    }
    d += 'c' + joinNums(nums.map((v) => Math.round(v * 10 ** dp) / 10 ** dp), dp);
    if (sub.closed) d += 'z';
  }
  return d;
}
/** Polygon → smooth closed path with quadratic midpoints (≈ half the bytes of cubics). */
export function polyToD(pts: Pt[], dp = 2): string {
  const q = (v: number) => Math.round(v * 10 ** dp) / 10 ** dp;
  const n = pts.length;
  const mid = (a: Pt, b: Pt) => ({ x: q((a.x + b.x) / 2), y: q((a.y + b.y) / 2) });
  const m0 = mid(pts[n - 1], pts[0]);
  let x = m0.x, y = m0.y;
  const nums: number[] = [];
  for (let i = 0; i < n; i++) {
    const c = { x: q(pts[i].x), y: q(pts[i].y) }, m = mid(pts[i], pts[(i + 1) % n]);
    nums.push(c.x - x, c.y - y, m.x - x, m.y - y);
    x = m.x; y = m.y;
  }
  return 'M' + joinNums([m0.x, m0.y], dp) + 'q' + joinNums(nums.map((v) => Math.round(v * 10 ** dp) / 10 ** dp), dp) + 'z';
}

// -------------------------------------------------------------- ribbon ----
export type Pen = {
  width: number;      // nominal ink width, units (0.9 ≈ 3.6 dp at 96 dp)
  pressure: number;   // ± fraction of width
  overshoot: number;  // closed loops: how far the pen runs past its start, units
  lift: number;       // closed loops: how far the overlapping tail drifts outward
  taperIn: number; taperOut: number; // units
  step: number;       // ribbon sample spacing, units
};
export const DEFAULT_PEN: Pen = { width: 0.95, pressure: 0.35, overshoot: 2.2, lift: 0.35, taperIn: 1.2, taperOut: 2.4, step: 1.2 };

export function ribbon(line: Pt[], closed: boolean, pen: Pen, r: () => number): Pt[] {
  let pts = line.slice();
  if (closed) {
    // start somewhere seeded, run once around, then overshoot drifting outward
    pts.pop();
    const n = pts.length, start = Math.floor(r() * n);
    pts = [...pts.slice(start), ...pts.slice(0, start)];
    let run = 0; const extra: Pt[] = [];
    for (let i = 0; i <= n && run < pen.overshoot; i++) {
      const a = pts[i % n], b = pts[(i + 1) % n];
      run += Math.hypot(b.x - a.x, b.y - a.y);
      extra.push(a);
    }
    pts = [...pts, ...extra];
    // drift: the overlapping tail sits `lift` outside the start (normal of the loop)
    const m = pts.length, from = n - 1;
    const nm = normals(pts.map((p) => ({ ...p, corner: false, s: 0 })), false);
    for (let i = from; i < m; i++) {
      const t = (i - from) / Math.max(1, m - 1 - from);
      pts[i] = { x: pts[i].x - nm[i].x * pen.lift * t, y: pts[i].y - nm[i].y * pen.lift * t };
    }
  }
  // resample to pen.step
  const res: Pt[] = [pts[0]]; let acc = 0;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i], l = Math.hypot(b.x - a.x, b.y - a.y);
    let t = pen.step - acc;
    while (t <= l) { res.push({ x: a.x + ((b.x - a.x) * t) / l, y: a.y + ((b.y - a.y) * t) / l }); t += pen.step; }
    acc = l - (t - pen.step);
  }
  res.push(pts[pts.length - 1]);
  const L = (res.length - 1) * pen.step;
  const press = wobble(L, false, { ...DEFAULT_HAND, waveMin: 3, waveMax: 9 }, r);
  const nm = normals(res.map((p) => ({ ...p, corner: false, s: 0 })), false);
  const left: Pt[] = [], right: Pt[] = [];
  res.forEach((p, i) => {
    const s = i * pen.step;
    const taper = Math.min(1, 0.3 + (0.7 * s) / pen.taperIn) * Math.min(1, 0.12 + (0.88 * (L - s)) / pen.taperOut);
    const w = (pen.width / 2) * (1 + pen.pressure * press(s)) * taper;
    left.push({ x: p.x + nm[i].x * w, y: p.y + nm[i].y * w });
    right.push({ x: p.x - nm[i].x * w, y: p.y - nm[i].y * w });
  });
  return [...left, ...right.reverse()];
}

// ------------------------------------------------------------ variants ----
export type Variant = { paper: string; fill: string; ink: string; line: string; hatch: string };
export type GenOpts = {
  variants: number; seed: string; hand: Hand; pen: Pen; dp: number;
  fillAmp: number;              // fill wobble relative to the hand (fills are looser, flatter)
  hatch: boolean;
  /** shadow-side direction for hatching (unit vector, from the light) */
  shade: Pt;
};
export const DEFAULT_OPTS: GenOpts = {
  variants: 3, seed: 'jamaa', hand: DEFAULT_HAND, pen: DEFAULT_PEN, dp: 1, fillAmp: 0.6, hatch: true,
  shade: { x: 0.55, y: 0.83 },
};

export function bbox(subs: Sub[]) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const s of subs) for (const c of s.segs) for (let i = 0; i < 8; i += 2) {
    x0 = Math.min(x0, c[i]); x1 = Math.max(x1, c[i]); y0 = Math.min(y0, c[i + 1]); y1 = Math.max(y1, c[i + 1]);
  }
  return { x0, y0, x1, y1, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
}

export function handmade(d: string, opts: Partial<GenOpts> = {}): Variant[] {
  const o = { ...DEFAULT_OPTS, ...opts, hand: { ...DEFAULT_HAND, ...opts.hand }, pen: { ...DEFAULT_PEN, ...opts.pen } };
  const subs = parsePath(d);
  const bb = bbox(subs), center = { x: bb.cx, y: bb.cy };
  const out: Variant[] = [];
  for (let v = 0; v < o.variants; v++) {
    const r = rng(hashSeed(`${o.seed}:${d}:${v}`));
    const fillHand = { ...o.hand, amp: o.hand.amp * o.fillAmp };
    const fill = subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, 2.6, fillHand, r, center), s.closed) }));
    const lineSubs = subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, 2.2, o.hand, r, center), s.closed) }));
    const ink = lineSubs.map((s) => polyToD(ribbon(densify(s.segs, 0.4), s.closed, o.pen, r), o.dp)).join('');
    let hatch = '';
    if (o.hatch) hatch = hatchStrokes(bb, o, r);
    // paper: the cut-out sticker/puppet backing — loosest, calmest layer
    const paperHand = { ...o.hand, amp: o.hand.amp * 0.45, rot: o.hand.rot * 0.5 };
    const paper = subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, 3, paperHand, r, center), s.closed) }));
    out.push({ paper: cubicsToD(paper, 1), fill: cubicsToD(fill, Math.max(1, o.dp - 1)), ink, line: cubicsToD(lineSubs, o.dp), hatch });
  }
  return out;
}

/** 3–5 tapered parallel scribbles across the shadow side (clip them with the fill). */
function hatchStrokes(bb: ReturnType<typeof bbox>, o: GenOpts, r: () => number): string {
  const ang = -0.95 + (r() - 0.5) * 0.12; // ≈ −55°, slightly different each pass
  const dir = { x: Math.cos(ang), y: Math.sin(ang) }, nrm = { x: -dir.y, y: dir.x };
  const R = Math.max(bb.x1 - bb.x0, bb.y1 - bb.y0) * 0.75;
  const out: string[] = [];
  const pen: Pen = { ...o.pen, width: o.pen.width * 0.55, pressure: 0.5, taperIn: 1.5, taperOut: 3, step: 1.8 };
  const count = 4;
  for (let i = 0; i < count; i++) {
    // place lines on the shade side: offset along the normal toward `shade`
    const side = Math.sign(nrm.x * o.shade.x + nrm.y * o.shade.y) || 1;
    const off = side * (R * 0.32 + i * 1.55 + (r() - 0.5) * 0.4);
    const cx = bb.cx + nrm.x * off, cy = bb.cy + nrm.y * off;
    const len = R * (0.62 - i * 0.07);
    const a = { x: cx - dir.x * len, y: cy - dir.y * len }, b = { x: cx + dir.x * len, y: cy + dir.y * len };
    const sub: Sub = { closed: false, segs: [[a.x, a.y, a.x + (b.x - a.x) / 3, a.y + (b.y - a.y) / 3, a.x + (2 * (b.x - a.x)) / 3, a.y + (2 * (b.y - a.y)) / 3, b.x, b.y]] };
    const k = boilKnots(sub, 2.5, { ...o.hand, amp: o.hand.amp * 0.8, rot: 0, shift: 0 }, r, { x: bb.cx, y: bb.cy });
    out.push(polyToD(ribbon(densify(smooth(k, false), 0.5), false, pen, r), 1));
  }
  return out.join('');
}

/** Open strokes (mouths, brows): just the ribbon, lighter wobble. */
export function handStroke(d: string, opts: Partial<GenOpts> & { width?: number } = {}): string[] {
  const o = { ...DEFAULT_OPTS, ...opts, hand: { ...DEFAULT_HAND, amp: 0.08, rot: 0, shift: 0, ...opts.hand } };
  const subs = parsePath(d), bb = bbox(subs);
  const pen: Pen = { ...DEFAULT_PEN, width: opts.width ?? 0.8, taperIn: 0.6, taperOut: 0.8, step: 0.35, pressure: 0.25 };
  const out: string[] = [];
  for (let v = 0; v < o.variants; v++) {
    const r = rng(hashSeed(`${o.seed}:${d}:${v}`));
    out.push(subs.map((s) => polyToD(ribbon(densify(smooth(boilKnots(s, 0.8, o.hand, r, { x: bb.cx, y: bb.cy }), false), 0.2), false, pen, r), o.dp)).join(''));
  }
  return out;
}

/** Small filled blobs (eyes): barely boiled so the face stays readable. */
export function handBlob(d: string, opts: Partial<GenOpts> = {}): string[] {
  const o = { ...DEFAULT_OPTS, ...opts, hand: { ...DEFAULT_HAND, amp: 0.07, waveMin: 1, waveMax: 3, rot: 2, shift: 0.04, ...opts.hand } };
  const subs = parsePath(d), bb = bbox(subs);
  const out: string[] = [];
  for (let v = 0; v < o.variants; v++) {
    const r = rng(hashSeed(`${o.seed}:${d}:${v}`));
    out.push(cubicsToD(subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, 0.9, o.hand, r, { x: bb.cx, y: bb.cy }), s.closed) })), o.dp));
  }
  return out;
}
