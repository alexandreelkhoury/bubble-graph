// Directional ink ring (ART-DIRECTION §3.2): the outline is thickest on the
// bottom-end side (in shadow) and thinnest on the top-start side (in light),
// plus a slow pressure wobble and a self-closing pen stroke that lands with a
// small overlap. Output is a filled path (no strokes), so SVG and Compose match.
import { parsePath, bbox, boilKnots, smooth, densify, normals, polyToD, wobble, rng, hashSeed, DEFAULT_HAND, type Hand, type Pt } from './handmade.ts';

export type InkOpts = {
  seed: string; variants: number; hand: Hand; width: number; gain: number; pressure: number;
  overshoot: number; lift: number; shade: Pt; spacing: number; dp: number;
};
export const INK: InkOpts = {
  seed: 'jamaa-cast', variants: 3, hand: { ...DEFAULT_HAND, amp: 0.19 }, width: 0.95, gain: 0.32, pressure: 0.16,
  overshoot: 1.6, lift: 0.12, shade: { x: 0.6, y: 0.8 }, spacing: 2.0, dp: 2,
};

function orient(pts: Pt[]) { let a = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; a += p.x * q.y - q.x * p.y; } return a; }

export function ribbonDir(line: Pt[], closed: boolean, o: InkOpts, r: () => number, taper = true): Pt[] {
  let pts = line.slice();
  // outward normals must point out of the body for the light rule
  let flip = 1;
  if (closed) {
    pts.pop();
    // normals() gives (ty, -tx); for a positive-area loop (clockwise on screen) that points outward
    flip = orient(pts) > 0 ? 1 : -1;
    const n = pts.length, start = Math.floor(r() * n);
    pts = [...pts.slice(start), ...pts.slice(0, start)];
    let run = 0; const extra: Pt[] = [];
    for (let i = 0; i <= n && run < o.overshoot; i++) { const a = pts[i % n], b = pts[(i + 1) % n]; run += Math.hypot(b.x - a.x, b.y - a.y); extra.push(a); }
    pts = [...pts, ...extra];
    const m = pts.length, from = n - 1;
    const nm = normals(pts.map((p) => ({ ...p, corner: false, s: 0 })), false);
    for (let i = from; i < m; i++) { const t = (i - from) / Math.max(1, m - 1 - from); pts[i] = { x: pts[i].x + flip * nm[i].x * o.lift * t, y: pts[i].y + flip * nm[i].y * o.lift * t }; }
  }
  const step = 0.5;
  const res: Pt[] = [pts[0]]; let acc = 0;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i], l = Math.hypot(b.x - a.x, b.y - a.y);
    let t = step - acc;
    while (t <= l) { res.push({ x: a.x + ((b.x - a.x) * t) / l, y: a.y + ((b.y - a.y) * t) / l }); t += step; }
    acc = l - (t - step);
  }
  res.push(pts[pts.length - 1]);
  const L = (res.length - 1) * step;
  const press = wobble(L, false, { ...DEFAULT_HAND, waveMin: 3, waveMax: 10 }, r);
  const nm = normals(res.map((p) => ({ ...p, corner: false, s: 0 })), false);
  const left: Pt[] = [], right: Pt[] = [];
  res.forEach((p, i) => {
    const s = i * step;
    const tp = !taper ? 1 : closed
      ? Math.min(1, 0.55 + (0.45 * s) / 1.0) * Math.min(1, 0.25 + (0.75 * (L - s)) / 1.4)
      : Math.min(1, 0.35 + (0.65 * s) / 0.8) * Math.min(1, 0.3 + (0.7 * (L - s)) / 0.9);
    const out = { x: flip * nm[i].x, y: flip * nm[i].y };
    const dir = out.x * o.shade.x + out.y * o.shade.y;
    const w = (o.width / 2) * (1 + o.gain * dir) * (1 + o.pressure * press(s)) * tp;
    left.push({ x: p.x + nm[i].x * w, y: p.y + nm[i].y * w });
    right.push({ x: p.x - nm[i].x * w, y: p.y - nm[i].y * w });
  });
  return [...left, ...right.reverse()];
}

/** Body variants: fill (calm wobble), ink ring (directional), paper (calmest), all seeded. */
export function bodyFrames(d: string, opts: Partial<InkOpts> = {}) {
  const o = { ...INK, ...opts, hand: { ...INK.hand, ...opts.hand } };
  const subs = parsePath(d);
  const bb = bbox(subs), center = { x: bb.cx, y: bb.cy };
  const out: { fill: string; ink: string; paper: string; fillPts: Pt[] }[] = [];
  for (let v = 0; v < o.variants; v++) {
    const r = rng(hashSeed(`${o.seed}:${d}:${v}`));
    const fillHand = { ...o.hand, amp: o.hand.amp * 0.6 };
    const fillSegs = subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, 2.4, fillHand, r, center), s.closed) }));
    const lineSegs = subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, o.spacing, o.hand, r, center), s.closed) }));
    const ink = lineSegs.map((s) => polyToD(ribbonDir(densify(s.segs, 0.35), s.closed, o, r), o.dp)).join('');
    const paperHand = { ...o.hand, amp: o.hand.amp * 0.5, rot: o.hand.rot * 0.5 };
    const paperSegs = subs.map((s) => ({ closed: s.closed, segs: smooth(boilKnots(s, 2.8, paperHand, r, center), s.closed) }));
    const fp = densify(fillSegs[0].segs, 0.5);
    out.push({ fill: polyToD(fp, 2), ink, paper: polyToD(densify(paperSegs[0].segs, 0.6), 2), fillPts: fp });
  }
  return out;
}

/** Open strokes (mouths, brows, closed eyes, motion marks): tapered ribbon, light boil. */
export function strokeFrames(d: string, width: number, seed: string, amp = 0.07, variants = 3): string[] {
  const subs = parsePath(d); const bb = bbox(subs);
  const o = { ...INK, width, gain: 0, pressure: 0.22 };
  const out: string[] = [];
  for (let v = 0; v < variants; v++) {
    const r = rng(hashSeed(`${seed}:${d}:${v}`));
    const hand = { ...DEFAULT_HAND, amp, waveMin: 1.5, waveMax: 5, rot: 1.2, shift: 0.05 };
    out.push(subs.map((s) => polyToD(ribbonDir(densify(smooth(boilKnots(s, 0.6, hand, r, { x: bb.cx, y: bb.cy }), s.closed), 0.15), s.closed, o, r), 3)).join(''));
  }
  return out;
}

/** Closed filled blobs (eyes, mouths, nubs, bursts): calm boil. */
export function blobFrames(d: string, seed: string, amp = 0.06, variants = 3, spacing = 0.7): string[] {
  const subs = parsePath(d); const bb = bbox(subs);
  const out: string[] = [];
  for (let v = 0; v < variants; v++) {
    const r = rng(hashSeed(`${seed}:${d}:${v}`));
    const hand = { ...DEFAULT_HAND, amp, waveMin: 1.2, waveMax: 4, rot: 1.5, shift: 0.04 };
    out.push(subs.map((s) => polyToD(densify(smooth(boilKnots(s, spacing, hand, r, { x: bb.cx, y: bb.cy }), s.closed), 0.25), 3)).join(''));
  }
  return out;
}
