// lettering.js — sign-painter treatment of display words for the board (ART-DIRECTION §7).
// Latin: glyph outlines from a chunky display face, then re-drawn with a hand: bouncing baseline (±2 %),
// letters leaning into each other, wobbly contours, one flat ink drop shadow. This is a STAND-IN for the
// hand-lettered outlines a letterer will deliver (P4). Arabic: Ruq'ah (Aref Ruqaa) as live text, same
// treatment rules; it must be redrawn by a native Arabic letterer.
import opentype from "./opentype.module.js";
import { rng, hashStr, subpaths, sampleClosed, wobble, smoothPath, el } from "./hand.js";

const fonts = {};
export async function loadFonts() {
  const get = async (u) => opentype.parse(await (await fetch(u)).arrayBuffer());
  fonts.lilita = await get("../fonts/lilita.woff");
  try { fonts.lilitaExt = await get("../fonts/lilita-ext.woff"); } catch {}
}

/** Returns { d: [per-glyph path strings], width, cap } for text at size, origin (0,0) baseline, with hand jitter. */
export function latinGlyphs(text, size, seed, { track = 0.005, bounce = 0.025, rot = 3.2, wob = 0.01, font = "lilita" } = {}) {
  const F = fonts[font]; const r = rng(seed); let x = 0; const out = [];
  const cap = (F.tables.os2.sCapHeight || F.unitsPerEm * 0.7) / F.unitsPerEm * size;
  const chars = [...text];
  chars.forEach((ch, i) => {
    let fnt = F; let g = F.charToGlyph(ch);
    if ((!g || g.index === 0) && fonts.lilitaExt) { fnt = fonts.lilitaExt; g = fnt.charToGlyph(ch); }
    const adv = (g.advanceWidth / fnt.unitsPerEm) * size;
    if (ch === " ") { x += adv * 1.25; return; }
    const by = (r() - 0.5) * 2 * bounce * cap; const rr = (r() - 0.5) * 2 * rot; const sc = 0.97 + r() * 0.07;
    const pd = g.getPath(0, 0, size).toPathData(2);
    const subs = subpaths(pd).map((sp, k) => { const pts = sampleClosed(sp, size * 0.012, 24); return smoothPath(wobble(pts, size * wob, seed + i * 17 + k, { freqs: [2, 3, 4] })); }).join("");
    const cx = adv / 2;
    out.push({ d: subs, tf: `translate(${(x + cx).toFixed(2)} ${by.toFixed(2)}) rotate(${rr.toFixed(2)}) scale(${sc.toFixed(3)}) translate(${(-cx).toFixed(2)} 0)` });
    let kern = 0; if (i < chars.length - 1) { const g2 = F.charToGlyph(chars[i + 1]); kern = (F.getKerningValue(g, g2) / F.unitsPerEm) * size; }
    x += adv + kern + track * size;
  });
  return { glyphs: out, width: x - track * size, cap };
}

/**
 * A Latin display word. style: { fill, ink, shadow:[dx,dy], back (paper backing colour), backW, extrude, line, bulbs }
 * anchor: 'middle' | 'start'. Returns an svg <g> positioned with baseline at (x,y). maxW scales down to fit.
 */
export function latinWord(text, x, y, size, seed, s = {}) {
  const { glyphs, width, cap } = latinGlyphs(text, size, seed, s);
  let k = 1; if (s.maxW && width > s.maxW) k = s.maxW / width;
  const ox = s.anchor === "start" ? 0 : -width / 2;
  const tf = `translate(${x} ${y}) scale(${k}) translate(${ox} 0) ${s.skew ? `skewX(${s.skew})` : ""}`;
  const all = (attrs, dx = 0, dy = 0) => glyphs.map((g) => el("path", { d: g.d, transform: `translate(${dx} ${dy}) ${g.tf}`, ...attrs }, "")).join("");
  let out = "";
  if (s.back) out += all({ fill: s.back, stroke: s.back, "stroke-width": s.backW || size * 0.16, "stroke-linejoin": "round" });
  if (s.extrude) for (let i = s.extrude; i > 0; i -= 0.6) out += all({ fill: s.extrudeFill || s.ink }, i * 0.7, i);
  if (s.shadow) out += all({ fill: s.ink, opacity: s.shadowOp ?? 1 }, s.shadow[0], s.shadow[1]);
  out += all({ fill: s.fill, stroke: s.line ? s.ink : undefined, "stroke-width": s.line || undefined, "stroke-linejoin": "round", "paint-order": "stroke" });
  if (s.inline) out += all({ fill: "none", stroke: s.inline, "stroke-width": size * 0.022, "stroke-dasharray": `${size * 0.09} ${size * 0.05}`, transform: undefined, opacity: 0.9 });
  return el("g", { transform: tf }, out);
}

/** An Arabic display word in Ruq'ah (live text stand-in). */
export function arabicWord(text, x, y, size, s = {}) {
  const base = { x, y, "font-family": "Ruqaa", "font-weight": 700, "font-size": size, "text-anchor": s.anchor || "middle", direction: "rtl" };
  let out = "";
  const tf = s.rot ? `rotate(${s.rot} ${x} ${y})` : undefined;
  if (s.back) out += el("text", { ...base, fill: s.back, stroke: s.back, "stroke-width": s.backW || size * 0.16, "stroke-linejoin": "round", textLength: s.len, lengthAdjust: s.len ? "spacingAndGlyphs" : undefined }, text);
  if (s.extrude) for (let i = s.extrude; i > 0; i -= 0.6) out += el("text", { ...base, x: x + i * 0.7, y: y + i, fill: s.extrudeFill || s.ink }, text);
  if (s.shadow) out += el("text", { ...base, x: x + s.shadow[0], y: y + s.shadow[1], fill: s.ink }, text);
  out += el("text", { ...base, fill: s.fill, stroke: s.line ? s.ink : undefined, "stroke-width": s.line, "paint-order": "stroke", "stroke-linejoin": "round" }, text);
  return el("g", { transform: tf }, out);
}
