export const theme = new URLSearchParams(location.search).get("theme") || "dark";
document.documentElement.dataset.theme = theme;
export async function ready() { await document.fonts.ready; await Promise.all([...document.fonts].map((f) => f.load().catch(() => {}))); await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))); window.__ready = true; }
export const $ = (s) => document.querySelector(s);
