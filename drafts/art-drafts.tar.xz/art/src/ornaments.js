// ornaments.js — wordmark (hand-inked variant), arch frames, dividers, flourish, reaction bursts.
import { rng, subpaths, sampleClosed, wobble, smoothPath, inkRing, brush, handPoly, handEllipse, smooth, poly, el, uid } from "./hand.js";
import { WM_LATIN, WM_AR } from "./brand.js";
import { tile } from "./scenes.js";

/** Wordmark: 'clean' = the shipped generated outlines; 'hand' = re-inked (wobble ≤ 0.6 % of cap, dots off-register). */
export function wordmark(which, { letters = "#FFF7EC", dots = ["#FFC94D", "#FFC94D", "#FFC94D"], hand = true, seed = 5, shadow = null, glow = true } = {}) {
  const W = which === "ar" ? WM_AR : WM_LATIN;
  const handD = (d, s) => hand ? subpaths(d).map((sp, i) => smoothPath(wobble(sampleClosed(sp, 1.6, 20), 1.3, s + i * 7, { freqs: [2, 3, 5] }))).join("") : d;
  let out = "";
  const L = W.letters.map((d, i) => handD(d, seed + i)).join("");
  if (shadow) out += el("path", { d: L, fill: shadow, transform: "translate(6 7)" }, "");
  out += el("path", { d: L, fill: letters }, "");
  W.dots.forEach((d, i) => {
    const col = dots[i % dots.length];
    if (glow) out += el("path", { d, fill: col, opacity: 0.25, transform: "", style: "filter:blur(8px)" }, "");
    out += el("path", { d: handD(d, seed + 40 + i), fill: col, transform: hand ? "translate(3 2.5)" : "" }, "");
  });
  return out;
}
export const WM_VIEW = { latin: "0 0 1000 260", ar: "0 0 1000 300" };

/** Bab arch frame (flat-bottomed, slightly asymmetric), proportion = h / w. */
export function archFrame(x, y, w, h, seed, { fill = "#2B1650", ink = "#160B26", trim = "#E8A33A", paper = "#FFF1DC" } = {}) {
  const r = w / 2; const d = `M${x} ${y + h}V${y + r}a${r} ${r} 0 0 1 ${w} 0V${y + h}Z`;
  const pts = wobble(sampleClosed(d, 1.5), w * 0.006, seed, { squish: [1.01, 1] });
  const inner = wobble(sampleClosed(`M${x + 8} ${y + h - 8}V${y + r}a${r - 8} ${r - 8} 0 0 1 ${w - 16} 0V${y + h - 8}Z`, 1.5), w * 0.005, seed + 1);
  return el("path", { d: smoothPath(pts), fill: trim, transform: "translate(1.5 1.2)" }, "") + el("path", { d: inkRing(pts, 3, { contrast: 0.35 }), fill: ink }, "") + el("path", { d: smoothPath(inner), fill }, "") + el("path", { d: inkRing(inner, 1.6), fill: ink }, "") +
    el("path", { d: brush(`M${x + 14} ${y + r * 0.9}Q${x + 18} ${y + r * 0.35} ${x + r * 0.7} ${y + 14}`, 2.4, { seed }), fill: paper, opacity: 0.55 }, "");
}

/** Dividers: brush stroke, tile row, bulb string are drawn by callers; here the brush one. */
export function brushDivider(x, y, w, color, seed) {
  const r = rng(seed); const pts = []; for (let i = 0; i <= 24; i++) { const t = i / 24; pts.push([x + w * t, y + Math.sin(t * 3.2 + r()) * 2.2]); }
  return el("path", { d: brush(poly(pts, false), 9, { seed, endRatio: 0.15, pressure: 0.25, step: 1 }), fill: color }, "") + el("path", { d: brush(`M${x + w + 10} ${y - 2}l6 4`, 4, { seed: seed + 1 }), fill: color }, "");
}

/** Corner flourish: a cut-paper petal cluster with a lifted-paper shadow. */
export function flourish(x, y, s, cols, ink, seed) {
  let out = ""; const r = rng(seed);
  const petal = (a, len, wid, col, k) => { const pts = []; for (let i = 0; i < 18; i++) { const t = (i / 18) * Math.PI * 2; pts.push([Math.cos(t) * len / 2 + len / 2, Math.sin(t) * wid / 2]); } const ca = Math.cos(a), sa = Math.sin(a); const P = handPoly(pts.map(([px, py]) => [x + px * ca - py * sa, y + px * sa + py * ca]), seed + k, { belly: 0.02, perEdge: 2, round: 1 }); return el("path", { d: smoothPath(P), fill: ink, opacity: 0.4, transform: "translate(1.6 1.8)" }, "") + el("path", { d: smoothPath(P), fill: col }, ""); };
  [[-0.1, 1, 0.42], [0.45, 0.82, 0.36], [0.95, 1, 0.42], [1.45, 0.7, 0.32]].forEach(([a, l, w], k) => (out += petal(a, s * l, s * w, cols[k % cols.length], k)));
  out += el("path", { d: smoothPath(handEllipse(x, y, s * 0.12, s * 0.12, seed + 9, 0.05)), fill: cols[cols.length - 1] }, "");
  return out;
}

/** Reaction bursts in marker style, 3 boil variants (ART-DIRECTION §9.5). Box 0..48. */
export function burst(kind, variant, ink = "#160B26") {
  const s = 100 + variant * 17; const wob = (pts, a = 0.5) => wobble(pts, a, s);
  const filled = (d, col, step = 0.6, a = 0.5, w = 1.8) => { const p = wob(sampleClosed(d, step), a); return el("path", { d: smoothPath(p), fill: col, transform: "translate(.8 .7)" }, "") + el("path", { d: inkRing(p, w), fill: ink }, ""); };
  const mark = (d, col, w) => el("path", { d: brush(d, w, { seed: s, jitter: 0.25 + variant * 0.1 }), fill: col }, "");
  switch (kind) {
    case "heart": return filled("M24 40C10 31 6 23 8 16c2-6 10-8 16-1 6-7 14-5 16 1 2 7-2 15-16 24z", "#FF96C5") + mark("M13 17q1-4 5-4", "#FFF1DC", 2.2);
    case "exclaim": return filled("M20 6h9l-2 24h-5z", "#FFF04D", 0.5, 0.35) + filled("M24.5 34a3.6 3.6 0 1 0 0.1 0z", "#FFF04D", 0.4, 0.25);
    case "sweat": return filled("M28 6C22 16 16 22 16 30a9 9 0 0 0 18 0c0-8-4-14-6-24z", "#7BFFF4") + mark("M21 28q0 4 3 6", "#FFF1DC", 2.2);
    case "tears": return filled("M14 10C10 17 8 21 8 26a6 6 0 0 0 12 0c0-5-3-9-6-16z", "#7BFFF4", 0.5, 0.35) + filled("M34 14C30 21 28 25 28 30a6 6 0 0 0 12 0c0-5-3-9-6-16z", "#7BFFF4", 0.5, 0.35);
    case "raincloud": return filled("M12 26a7 7 0 0 1 2-13 9 9 0 0 1 17-2 7 7 0 0 1 5 15z", "#C9BFFF") + mark("M15 31l-2 6M24 31l-2 7M33 31l-2 6", "#478CFF", 2.4);
    case "confetti": { let o = ""; const r = rng(s); const cols = ["#F0183A", "#FFF04D", "#478CFF", "#1FA88A", "#FF96C5", "#FF7A1F"]; for (let i = 0; i < 9; i++) { const cx = 6 + r() * 36, cy = 6 + r() * 36, a = r() * 180; const k = i % 3; const d = k === 0 ? `M${cx - 3} ${cy - 2}h6v4h-6z` : k === 1 ? `M${cx} ${cy - 3}l3 5h-6z` : `M${cx - 2.6} ${cy}a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0-5.2 0`; const p = handPoly(sampleClosed(d, 0.5), s + i, { belly: 0, perEdge: 1, round: 0 }); o += el("g", { transform: `rotate(${a.toFixed(0)} ${cx} ${cy})` }, el("path", { d: poly(p), fill: ink, opacity: 0.4, transform: "translate(.8 .9)" }, "") + el("path", { d: poly(p), fill: cols[i % cols.length] }, "")); } return o; }
  }
  return "";
}

/** A tile border: n tiles of one pattern with drawn variants. */
export function tileBorder(x, y, s, n, pattern, inks, paper, ink, seed) {
  let o = ""; for (let i = 0; i < n; i++) o += tile(x + i * s, y, s, pattern, seed + i * 13, inks, paper, ink, { base: "#E9D6B4", line: 0.8 }); return o;
}
