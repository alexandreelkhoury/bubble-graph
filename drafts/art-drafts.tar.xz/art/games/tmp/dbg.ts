import { brush, mapPath } from '../src/lib.ts';
import { ARABIC } from '../src/arabic.ts';
for (const s of ARABIC.likely) { const m = mapPath(s, (x, y) => [80 + x * 0.9, 82 + y * 0.9]); const b = brush(m, { nib: 70, wMax: 2.3, wMin: 0.7, amp: 0.12, seed: 'likely', k: 0.9 }, 0); console.log(s.slice(0,22).padEnd(24), m.slice(0,30).padEnd(32), (b.match(/Z/g)||[]).length, b.slice(0,40)); }
