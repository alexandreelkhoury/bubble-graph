// Hand-authored Ruq'ah-style centrelines for the four Arabic titles.
// Units: alef height ≈ 10, baseline y = 0, y down. Words run right → left;
// coordinates are absolute (x grows to the right as in SVG).
// Ruq'ah conventions used: three dots as a caret (^), two dots as a short dash,
// seen/sheen teeth flattened, bowls sit low, no kashida.  [native review]
export const ARABIC: Record<string, string[]> = {
  // مش أنا!
  mishana: [
    // meem (initial): a small closed loop on the baseline, exits left
    'M21.4 -0.3 C23.0 0.0 23.4 -2.6 21.9 -2.7 C20.7 -2.8 20.3 -1.2 21.1 -0.2',
    // joint into sheen: flat ruq'ah teeth, then the deep final bowl
    'M21.4 0 C19.6 0.1 18.6 0 17.8 -1.3 C17.4 -0.2 16.4 0.1 15.6 -1.2 C15.2 -0.2 14.6 0.2 13.8 -0.2 C13.6 2.8 12.0 4.4 9.8 4.4 C7.6 4.4 6.4 3.0 6.3 0.4',
    // the three dots as a caret
    'M14.9 -4.4 L16.3 -6.4', 'M16.3 -6.4 L17.7 -4.4',
    // alef + hamza
    'M3.3 -9.4 C3.1 -6 2.9 -3 2.7 0.1',
    'M4.2 -12.6 C3.7 -13.1 3.0 -12.7 3.25 -12.2 C3.5 -11.85 4.0 -11.9 4.5 -12.2', 'M3.25 -12.15 C3.0 -11.7 2.8 -11.5 2.4 -11.3',
    // nun (initial) tooth + join + final alef
    'M0.2 -2.8 C0.4 -1.0 0.0 0.1 -1.2 0.1 C-2.4 0.1 -3.6 0.1 -4.6 0.1',
    'M-4.6 0.2 C-4.8 -3 -5.0 -6.4 -5.0 -9.6',
    'M-0.5 -4.7 L0.5 -5.4',
    // !
    'M-8.2 -9.4 C-8.3 -7.0 -8.4 -5.0 -8.4 -3.2', 'M-8.5 -0.8 L-8.35 -0.1',
  ],
  // بلوف!
  bluff: [
    // ba (initial) tooth, baseline running under the lam into the waw
    'M17.2 -2.6 C17.4 -0.8 17.0 0.1 15.8 0.1 C14.0 0.1 12.4 0.1 10.8 0.1',
    'M16.0 2.6 L16.9 2.0',
    // lam ascender
    'M12.0 0.1 C12.0 -3.4 12.2 -7.0 12.6 -10.6',
    // waw (final): head loop, tail sweeping below
    'M11.0 0.1 C9.8 0.0 9.6 -2.9 8.4 -2.9 C7.3 -2.9 6.9 -1.6 7.5 -0.9 C8.2 -0.2 9.2 -0.4 9.4 0.6 C9.6 2.0 8.0 3.8 5.2 4.4',
    // fa (isolated): head loop, long low boat
    'M2.6 -0.6 C4.0 -0.4 4.4 -3.0 2.9 -3.1 C1.6 -3.2 1.2 -1.6 2.4 -0.5 C3.4 0.3 3.0 1.1 1.2 1.1 C-1.2 1.1 -3.4 1.1 -5.0 1.0 C-6.2 0.9 -6.8 0.0 -6.6 -1.6',
    'M2.4 -5.0 L3.4 -5.6',
    // !
    'M-9.6 -9.4 C-9.7 -7.0 -9.8 -5.0 -9.8 -3.2', 'M-9.9 -0.8 L-9.75 -0.1',
  ],
  // مين فينا؟
  likely: [
    // meem loop
    'M25.4 -0.2 C27.4 0.2 28.0 -3.2 26.0 -3.3 C24.4 -3.4 23.8 -1.2 25.0 -0.1',
    // baseline: meem → ya tooth → nun bowl
    'M25.2 0 C24.0 0.1 23.2 0.1 22.4 0.1', 'M22.6 0.1 C22.4 -0.8 22.4 -1.6 22.6 -2.6', 'M22.6 0.1 C21.0 0.1 20.0 0.0 19.4 -1.0',
    'M19.4 -1.2 C19.4 2.6 18.0 4.2 15.8 4.2 C13.6 4.2 12.6 2.8 12.6 0.4',
    // ya: two dots below; nun: one dot above the bowl
    'M20.9 2.9 L21.6 3.2', 'M23.7 2.9 L24.4 3.2', 'M15.7 -3.6 L16.4 -3.3',
    // fa (initial) loop
    'M9.8 -0.1 C11.4 0.0 11.6 -2.9 10.0 -3.0 C8.7 -3.1 8.3 -1.2 9.3 -0.1',
    'M9.6 0.1 C7.4 0.1 6.0 0.1 4.6 0.1 C3.0 0.1 1.8 0.1 0.4 0.1',
    // ya tooth, nun tooth, final alef
    'M6.4 0.1 C6.3 -0.8 6.3 -1.6 6.5 -2.5', 'M3.6 0.1 C3.5 -0.8 3.5 -1.7 3.7 -2.6',
    'M0.4 0.2 C0.2 -3 0.0 -6.4 0.0 -9.6',
    // fa: one dot above; ya: two dots below; nun: one dot above
    'M9.9 -5.2 L10.6 -4.9', 'M4.8 2.9 L5.5 3.2', 'M7.5 2.9 L8.2 3.2', 'M3.3 -5.0 L4.0 -4.7',
    // ؟ (mirrored question mark)
    'M-2.6 -8.4 C-2.8 -10.2 -5.4 -10.4 -5.8 -8.6 C-6.1 -7.0 -4.4 -6.4 -4.3 -4.6 L-4.3 -3.2', 'M-4.45 -0.8 L-4.3 -0.1',
  ],
  // مسابقة  (DESIGN-JAMAA §1.6: the Trivia title)
  trivia: [
    // meem (initial): small closed loop on the baseline, exits left
    'M28.6 -0.3 C30.7 0.0 31.1 -3.3 29.1 -3.4 C27.5 -3.5 27.1 -1.4 28.2 -0.2',
    // seen (medial): three flat ruq'ah teeth, then the join into the final alef
    'M28.5 0.1 L27.0 0.1 C26.6 0.0 26.5 -1.0 26.5 -1.9 C26.5 -0.4 25.9 0.1 25.1 -0.1 C24.6 -0.3 24.5 -1.1 24.5 -1.8 C24.5 -0.4 23.9 0.1 23.1 -0.1 C22.6 -0.3 22.5 -1.0 22.5 -1.7 C22.5 -0.2 21.9 0.1 20.9 0.1 L19.7 0.1',
    // alef (final, joined): rises from the end of the join
    'M19.7 0.3 C19.5 -3.0 19.4 -6.4 19.6 -9.9',
    // ba (initial) tooth → baseline → qaf (medial) loop → join
    'M17.6 -2.7 C17.8 -0.8 17.4 0.1 16.2 0.1 L15.3 0.1 C14.1 0.1 14.5 -4.3 12.6 -4.3 C10.8 -4.3 10.5 -1.4 11.7 -0.5 C12.2 -0.1 11.9 0.1 10.9 0.1 L9.0 0.1',
    // ta marbuta (final): the teardrop loop rising back over the join
    'M9.0 0.1 C8.0 0.1 7.6 -1.0 6.9 -2.7 C6.2 -4.5 4.2 -4.3 4.2 -2.6 C4.2 -1.0 5.8 -0.1 7.9 0.0',
    // nuqat: ba one below; qaf two above; ta marbuta two above (ruq'ah: two dots as a short dash)
    'M16.1 2.6 L16.8 2.95',
    'M11.4 -7.0 L13.8 -6.4',
    'M4.6 -6.7 L6.9 -6.1',
  ],
  // هس!  («shh!», the secret poster)
  shh: [
    // ha (initial): a loop on the baseline, exits left
    'M12.4 -5.0 C14.4 -3.8 14.2 -0.2 12.2 0.0 C10.2 0.2 9.6 -2.4 10.9 -3.6 C11.8 -4.4 13.2 -3.2 12.5 -1.4 C12.1 -0.3 11.0 0.1 9.5 0.1',
    // seen (final): three teeth, then the deep bowl
    'M9.5 0.1 C9.1 0.1 8.9 -0.8 8.9 -1.8 C8.9 -0.3 8.3 0.1 7.5 -0.1 C7.0 -0.3 6.9 -1.1 6.9 -1.8 C6.9 -0.3 6.3 0.2 5.5 0.0 C5.3 2.6 3.9 4.2 1.9 4.2 C-0.1 4.2 -1.1 2.8 -1.1 0.6',
    // !
    'M-4.2 -9.4 C-4.3 -7.0 -4.4 -5.0 -4.4 -3.2', 'M-4.5 -0.8 L-4.35 -0.1',
  ],
};
