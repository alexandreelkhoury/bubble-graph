import fs from 'node:fs';
import { brush, mapPath } from '../src/lib.ts';
import { ARABIC } from '../src/arabic.ts';
let s = '';
for (const st of ARABIC.likely) { const m = mapPath(st, (x, y) => [40 + x * 3, 50 + y * 3]); s += `<path d="${brush(m, { nib: 70, wMax: 2.3, wMin: 0.7, amp: 0.12, seed: 'likely', k: 3 }, 0)}" fill="#FFE9C7" stroke="red" stroke-width="0.2"/>`; }
fs.writeFileSync('tmp/dbg.svg', `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 80" width="1600" height="800"><rect width="160" height="80" fill="#1D1036"/>${s}</svg>`);
