// scenes.ts — the four game key-art illustrations, each in two formats.
// wide = 16:9 TV hub card (240 × 135 units), square = 1:1 phone card (150 × 150 units).
// 1 unit = 4 px at 960 × 540. Hand-authored geometry; the seeded hand does the rest.
import {
  type F3, type World, same, cat, g, thing, flat, stroke, blob, shadow, character, circleD, ellipseD,
  placeArabic, placeLatin, signPaint, neon, rng, hashSeed, r2, uid,
} from './lib.ts';

export type Layout = 'wide' | 'square';
export type Item = string | F3;
export type Scene = { w: number; h: number; defs: string; items: Item[] };

export const WORLDS: Record<string, World> = {
  mishana: { id: 'night-market', ink: '#140818', paper: '#FFE9C7', a: '#E2477F', b: '#F29B38', c: '#2A7F86', deep: '#1D1036', top: '#2B1650', surface: '#3A2266', elevated: '#4A2E7A', accent: '#FF4F9A', glow: '#FFC94D', mis: [-0.4, 0.4] },
  bluff: { id: 'hakawati-cafe', ink: '#1A0F07', paper: '#FFEBC2', a: '#E9A23B', b: '#B5452B', c: '#3D6B4F', deep: '#1C1209', top: '#2E1D0E', surface: '#33230F', elevated: '#4A3418', accent: '#E9A23B', glow: '#FFE3A3', signal: '#FF5A5F', mis: [-0.4, 0.4] },
  likely: { id: 'rooftop', ink: '#06141C', paper: '#E9FFF9', a: '#29D3C2', b: '#3A6EA5', c: '#D2694A', deep: '#071A24', top: '#0E2C3B', surface: '#0F2E3D', elevated: '#17404F', accent: '#29D3C2', glow: '#B8FFF6', signal: '#FFC94D', mis: [-0.4, 0.4] },
  trivia: { id: 'quiz-studio', ink: '#070B22', paper: '#FFF6D6', a: '#5B7CFF', b: '#FFD84D', c: '#E5484D', deep: '#0A0F2E', top: '#141C52', surface: '#161D4A', elevated: '#222B63', accent: '#5B7CFF', glow: '#FFD84D', signal: '#3DDC97', mis: [-0.4, 0.4] },
};

const P = (pts: number[][]) => 'M' + pts.map((p) => `${r2(p[0])} ${r2(p[1])}`).join('L') + 'Z';
const L2 = (pts: number[][]) => 'M' + pts.map((p) => `${r2(p[0])} ${r2(p[1])}`).join('L');
const rect = (x: number, y: number, w: number, h: number) => P([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]);
const rr = (x: number, y: number, w: number, h: number, r: number) => `M${x + r} ${y}H${x + w - r}Q${x + w} ${y} ${x + w} ${y + r}V${y + h - r}Q${x + w} ${y + h} ${x + w - r} ${y + h}H${x + r}Q${x} ${y + h} ${x} ${y + h - r}V${y + r}Q${x} ${y} ${x + r} ${y}Z`;

function stage(w: World, W: number, H: number, defs: string[]) {
  // world stage: stageTop → deep, the top glow is light so it may be a gradient
  const id = uid('st'), gl = uid('gl');
  defs.push(`<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${w.top}"/><stop offset="0.6" stop-color="${w.deep}"/></linearGradient>`);
  defs.push(`<radialGradient id="${gl}" cx="0.5" cy="-0.05" r="0.7"><stop offset="0" stop-color="${w.glow}" stop-opacity="0.16"/><stop offset="1" stop-color="${w.glow}" stop-opacity="0"/></radialGradient>`);
  return `<rect width="${W}" height="${H}" fill="url(#${id})"/><rect width="${W}" height="${H}" fill="url(#${gl})"/>`;
}
/** A light cone: hand-cut polygon, soft only at the far end (ART-DIRECTION §5.3). */
function cone(pts: number[][], color: string, defs: string[], op = 0.38, dir: [number, number, number, number] = [0, 0, 0, 1]): string {
  const id = uid('cn');
  defs.push(`<linearGradient id="${id}" x1="${dir[0]}" y1="${dir[1]}" x2="${dir[2]}" y2="${dir[3]}"><stop offset="0" stop-color="${color}" stop-opacity="${op}"/><stop offset="0.75" stop-color="${color}" stop-opacity="${op * 0.55}"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient>`);
  return `<path d="${P(pts)}" fill="url(#${id})" style="mix-blend-mode:screen"/>`;
}
function glowDot(x: number, y: number, r: number, color: string, defs: string[], op = 0.5): string {
  const id = uid('gd');
  defs.push(`<radialGradient id="${id}"><stop offset="0" stop-color="${color}" stop-opacity="${op}"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></radialGradient>`);
  return `<circle cx="${r2(x)}" cy="${r2(y)}" r="${r2(r)}" fill="url(#${id})" style="mix-blend-mode:screen"/>`;
}
/** A sagging wire (catenary-ish) between two points. */
const wire = (x1: number, y1: number, x2: number, y2: number, sag: number) => `M${x1} ${y1} Q${(x1 + x2) / 2} ${Math.max(y1, y2) + sag} ${x2} ${y2}`;
/** Dashed "accusation" line toward a target (DESIGN §8.3 point). Drawn dashes, each a little stroke. */
function accuse(x1: number, y1: number, x2: number, y2: number, color: string, seed: string, n = 5): F3 {
  const out: F3[] = [];
  for (let i = 0; i < n; i++) {
    const t0 = (i + 0.15) / (n + 0.4), t1 = (i + 0.62) / (n + 0.4);
    const bow = Math.sin(Math.PI * ((t0 + t1) / 2)) * -2.2;
    const a = [x1 + (x2 - x1) * t0, y1 + (y2 - y1) * t0 + bow], b = [x1 + (x2 - x1) * t1, y1 + (y2 - y1) * t1 + bow];
    out.push(stroke(`M${r2(a[0])} ${r2(a[1])} L${r2(b[0])} ${r2(b[1])}`, color, { w: 1.0, seed: seed + i }));
  }
  return cat(...out);
}

// =====================================================================
// MISH ANA! — night market. Two point at a third under a sodium lamp,
// peeling posters, a rolling shutter, two gossips whispering.
// =====================================================================
export function mishana(L: Layout): Scene {
  const w = WORLDS.mishana, wide = L === 'wide';
  const Wd = wide ? 240 : 150, Ht = wide ? 135 : 150;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(stage(w, Wd, Ht, defs));
  const ground = wide ? 112 : 128;

  // far: a row of building tops against the sky, flat, no line (never boils)
  const far = wide
    ? P([[0, 34], [18, 34], [18, 26], [40, 26], [40, 31], [64, 31], [64, 20], [70, 20], [70, 30], [100, 30], [100, 24], [140, 24], [140, 33], [176, 33], [176, 22], [204, 22], [204, 28], [240, 28], [240, 60], [0, 60]])
    : P([[0, 38], [20, 38], [20, 30], [46, 30], [46, 36], [70, 36], [70, 26], [104, 26], [104, 33], [150, 33], [150, 70], [0, 70]]);
  it.push(flat(far, w.surface, { amp: 0.4 }));
  // a few far windows still lit (3 drawn variants, never on a grid)
  const winR = rng(hashSeed('nm-win' + L));
  let wins = '';
  const winSpots = wide ? [[24, 29], [48, 33], [78, 33], [108, 27], [116, 27], [150, 36], [184, 25], [212, 31], [226, 31]] : [[26, 33], [54, 39], [80, 29], [90, 29], [120, 36]];
  for (const [x, y] of winSpots) { const ww = 2 + winR() * 1.4, hh = 2.2 + winR() * 1; wins += `<path d="${P([[x, y], [x + ww, y + 0.2], [x + ww - 0.1, y + hh], [x + 0.1, y + hh - 0.1]])}" fill="${w.glow}" opacity="${0.35 + winR() * 0.35}"/>`; }
  it.push(wins);

  // the wall (mid layer, thin line) — plaster in the elevated violet
  const wallTop = wide ? 40 : 46;
  it.push(thing(P([[-4, wallTop], [Wd + 4, wallTop - 1.5], [Wd + 4, ground + 2], [-4, ground + 2]]), { fill: w.elevated, ink: w.ink, w: 0.45, amp: 0.5, boil: false }));
  // old stains on the wall (stipple clusters, 3 sizes)
  const st = rng(hashSeed('stain' + L)); let stip = '';
  for (const [cx, cy] of (wide ? [[205, 96], [12, 60], [150, 52]] : [[130, 108], [10, 64]])) for (let i = 0; i < 11; i++) { const rr_ = [0.35, 0.55, 0.8][i % 3]; stip += `<circle cx="${r2(cx + (st() - 0.5) * 9)}" cy="${r2(cy + (st() - 0.5) * 6)}" r="${rr_}" fill="${w.ink}" opacity="0.28"/>`; }
  it.push(stip);

  // peeling plaster: a patch of bricks showing through
  for (const [bx, by, bw, bh] of (wide ? [[150, 47, 22, 12], [218, 92, 18, 11]] : [[118, 96, 18, 11]])) {
    const patch = P([[bx, by + 2], [bx + bw * 0.3, by - 0.6], [bx + bw * 0.7, by + 0.8], [bx + bw, by + 3], [bx + bw - 1, by + bh * 0.7], [bx + bw * 0.6, by + bh], [bx + bw * 0.2, by + bh - 1.2], [bx - 0.8, by + bh * 0.55]]);
    it.push(thing(patch, { fill: '#5B3A86', ink: w.ink, w: 0.45, amp: 0.2, boil: false, seed: 'pl' + bx }));
    let br = '';
    for (let r = 0; r < 3; r++) { const yy = by + 2.6 + r * 3.1; br += `M${bx + 1.5} ${r2(yy)} L${bx + bw - 1.5} ${r2(yy + 0.2)} `; for (let c = 0; c < 3; c++) { const xx = bx + 3 + c * 6 + (r % 2) * 3; br += `M${r2(xx)} ${r2(yy - 3)} L${r2(xx + 0.1)} ${r2(yy)} `; } }
    it.push(`<clipPath id="pc${bx}"><path d="${patch}"/></clipPath>`);
    it.push(g(`clip-path="url(#pc${bx})"`, stroke(br, w.ink, { w: 0.35, op: 0.55, seed: 'brk' + bx, boil: false })));
  }

  // rolling shutter (teal), slats as hand strokes, a padlock
  const sx = wide ? 6 : 4, sw = wide ? 92 : 62, sy = wide ? 66 : wallTop + 30, sh = ground - sy;
  it.push(thing(rect(sx, sy, sw, sh), { fill: w.c, ink: w.ink, w: 0.7, amp: 0.35, mis: w.mis, seed: 'shutter' + L }));
  it.push(thing(rect(sx - 2, sy - 4, sw + 4, 5), { fill: '#1F5F66', ink: w.ink, w: 0.7, amp: 0.3, mis: w.mis, seed: 'box' + L }));
  for (let y = sy + 3.2, i = 0; y < ground - 1; y += 3.1, i++) it.push(stroke(`M${sx + 1.2} ${r2(y)} Q${sx + sw / 2} ${r2(y + (i % 2 ? 0.35 : -0.3))} ${sx + sw - 1.2} ${r2(y + 0.15)}`, w.ink, { w: 0.38, op: 0.55, seed: 'slat' + i + L }));
  // shadow of the box on the shutter
  it.push(shadow(P([[sx, sy], [sx + sw, sy], [sx + sw, sy + 3.5], [sx + sw * 0.6, sy + 4.2], [sx, sy + 3]]), w, 0.3));
  // hand-painted shop sign on the box: an invented name, bilingual (only marks, it's far): small sign plate
  // padlock
  const plx = sx + sw * 0.62, ply = ground - 3.2;
  it.push(thing(rect(sx + 0.5, ground - 5, sw - 1, 3.2), { fill: '#1F5F66', ink: w.ink, w: 0.5, amp: 0.2, seed: 'bar' + L }));
  it.push(stroke(`M${plx - 2.2} ${ply - 2.6} C${plx - 2.4} ${ply - 7.4} ${plx + 2.4} ${ply - 7.4} ${plx + 2.2} ${ply - 2.6}`, w.ink, { w: 1.1, seed: 'shk' + L }));
  it.push(stroke(`M${plx - 2.2} ${ply - 2.6} C${plx - 2.4} ${ply - 7.4} ${plx + 2.4} ${ply - 7.4} ${plx + 2.2} ${ply - 2.6}`, '#B9B2C9', { w: 0.45, seed: 'shk2' + L }));
  it.push(thing(rr(plx - 3.4, ply - 3, 6.8, 5.6, 1.2), { fill: w.b, ink: w.ink, w: 0.6, amp: 0.12, mis: [-0.3, 0.3], seed: 'lock' + L }));
  it.push(blob(circleD(plx, ply - 0.6, 0.7) + `M${plx - 0.35} ${ply - 0.4}L${plx + 0.35} ${ply - 0.4}L${plx + 0.25} ${ply + 1.4}L${plx - 0.25} ${ply + 1.4}Z`, w.ink));

  // peeling posters (cut paper, torn corners) — a "?" poster and a blank one: who is the Blank?
  const posters = wide
    ? [{ x: 182, y: 50, w: 26, h: 34, r: -4, c: w.a, kind: 'q' }, { x: 208, y: 56, w: 24, h: 30, r: 5, c: w.paper, kind: 'blank' }, { x: 108, y: 52, w: 20, h: 22, r: 3, c: w.b, kind: 'ear' }]
    : [{ x: 102, y: 56, w: 22, h: 28, r: -4, c: w.a, kind: 'q' }, { x: 124, y: 62, w: 20, h: 24, r: 6, c: w.paper, kind: 'blank' }, { x: 30, y: 51, w: 18, h: 18, r: -3, c: w.b, kind: 'ear' }];
  for (const p of posters) {
    const torn = P([[p.x, p.y], [p.x + p.w * 0.45, p.y + 0.6], [p.x + p.w * 0.55, p.y - 0.4], [p.x + p.w, p.y + 0.3], [p.x + p.w + 0.4, p.y + p.h * 0.7], [p.x + p.w - 3.5, p.y + p.h - 0.5], [p.x + p.w - 6, p.y + p.h + 0.8], [p.x + 0.4, p.y + p.h], [p.x - 0.5, p.y + p.h * 0.5]]);
    const cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    const parts: F3[] = [];
    parts.push(shadow(torn.replace(/(-?\d+\.?\d*) (-?\d+\.?\d*)/g, (_, a, b) => `${r2(+a + 1.2)} ${r2(+b + 1.4)}`), w, 0.4));
    parts.push(thing(torn, { fill: p.c, ink: w.ink, w: 0.45, amp: 0.25, mis: w.mis, seed: 'pst' + p.kind + L }));
    // the peeled corner flap
    const fx = p.x + p.w - 3.5, fy = p.y + p.h - 0.5;
    parts.push(thing(P([[fx, fy], [p.x + p.w + 0.4, p.y + p.h * 0.7], [fx - 1.5, fy - 6.5]]), { fill: '#F3D7AE', ink: w.ink, w: 0.4, amp: 0.1 }));
    if (p.kind === 'q') {
      // a big brush "?" on the poster
      parts.push(stroke(`M${cx - 4.5} ${cy - 6} C${cx - 4.5} ${cy - 11.5} ${cx + 5.5} ${cy - 11.5} ${cx + 4.6} ${cy - 5.6} C${cx + 4} ${cy - 2.4} ${cx} ${cy - 2.6} ${cx} ${cy + 2.4}`, w.paper, { w: 2.8, seed: 'pq' + L }));
      parts.push(blob(circleD(cx + 0.1, cy + 6.8, 1.6), w.paper, { amp: 0.15 }));
      parts.push(stroke(`M${p.x + 3} ${p.y + p.h - 4} L${p.x + p.w - 8} ${p.y + p.h - 4.4}`, w.ink, { w: 0.6, op: 0.6 }));
    } else if (p.kind === 'blank') {
      // the Blank: an empty role card drawn on the poster, a dotted silhouette
      parts.push(thing(rr(cx - 6, cy - 9, 12, 16, 1.6), { ink: w.ink, w: 0.5, amp: 0.15, seed: 'blank' + L }));
      for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i / 7) * Math.PI * 2; parts.push(blob(circleD(cx + Math.cos(a) * 3.2, cy - 2 + Math.sin(a) * 3.2, 0.45), w.a, { seed: 'bd' + i + L })); }
      parts.push(stroke(`M${p.x + 3} ${p.y + p.h - 3.4} L${p.x + p.w - 7} ${p.y + p.h - 3.0}`, w.ink, { w: 0.55, op: 0.5 }));
    } else {
      // "psst": an ear and three sound arcs — the whisper poster
      parts.push(stroke(`M${cx + 1} ${cy - 5} C${cx - 4} ${cy - 6} ${cx - 5} ${cy + 1} ${cx - 1} ${cy + 3} C${cx + 1} ${cy + 4} ${cx} ${cy + 6} ${cx - 2} ${cy + 6}`, w.ink, { w: 1.1, seed: 'ear' + L }));
      for (let i = 0; i < 3; i++) parts.push(stroke(`M${cx + 3 + i * 2.2} ${cy - 3 - i} Q${cx + 5 + i * 2.6} ${cy} ${cx + 3 + i * 2.2} ${cy + 3 + i}`, w.ink, { w: 0.7, seed: 'arc' + i + L }));
    }
    it.push(g(`transform="rotate(${p.r} ${cx} ${cy})"`, ...parts));
  }

  // pavement + curb
  it.push(thing(P([[-4, ground], [Wd + 4, ground - 0.8], [Wd + 4, Ht + 4], [-4, Ht + 4]]), { fill: '#251344', ink: w.ink, w: 0.8, amp: 0.4, seed: 'pave' + L }));
  it.push(stroke(`M-2 ${ground + 6.5} Q${Wd / 2} ${ground + 7.2} ${Wd + 2} ${ground + 6}`, w.ink, { w: 0.5, op: 0.5 }));
  for (const x of (wide ? [30, 84, 150, 214] : [36, 96])) it.push(stroke(`M${x} ${ground + 1} L${x - 4} ${ground + 6.5}`, w.ink, { w: 0.45, op: 0.45, seed: 'crk' + x }));

  // a puddle holding the lamp's reflection, and a torn flyer on the ground
  { const px = wide ? 214 : 132, py = ground + 13;
    it.push(thing(`M${px - 12} ${py} C${px - 12} ${py - 3} ${px - 2} ${py - 3.4} ${px + 4} ${py - 2.6} C${px + 11} ${py - 2} ${px + 13} ${py + 1.4} ${px + 7} ${py + 2.6} C${px} ${py + 3.6} ${px - 12} ${py + 3} ${px - 12} ${py} Z`, { fill: '#33205A', ink: w.ink, w: 0.45, amp: 0.15, seed: 'pud' + L }));
    it.push(stroke(`M${px - 6} ${py - 0.6} L${px - 1} ${py - 0.9}`, w.b, { w: 0.7, op: 0.8 }));
    it.push(stroke(`M${px + 2} ${py + 0.8} L${px + 5} ${py + 0.6}`, w.b, { w: 0.5, op: 0.6 }));
    if (wide) { const fx = 52, fy = ground + 14;
      it.push(g(`transform="rotate(-14 ${fx} ${fy})"`, thing(P([[fx - 5, fy - 3], [fx + 4, fy - 3.4], [fx + 5.2, fy + 2.6], [fx + 1, fy + 3.2], [fx - 0.5, fy + 1.8], [fx - 5.4, fy + 2.4]]), { fill: w.a, ink: w.ink, w: 0.4, amp: 0.15, mis: w.mis, seed: 'fly' }), stroke(`M${fx - 3} ${fy - 1} L${fx + 2.6} ${fy - 1.2} M${fx - 3} ${fy + 0.8} L${fx + 1} ${fy + 0.7}`, w.paper, { w: 0.45, op: 0.8 }))); }
  }

  // tangled overhead wires (Beirut), mid line weight
  const wires = wide
    ? [wire(-4, 8, 244, 12, 10), wire(-4, 14, 160, 6, 9), wire(60, -2, 244, 20, 14)]
    : [wire(-4, 10, 154, 14, 10), wire(-4, 18, 154, 6, 8)];
  wires.forEach((d, i) => it.push(stroke(d, w.ink, { w: 0.55, seed: 'wire' + i + L })));

  // sodium streetlight: a bent pole from the end edge, a lamp head, a hand-cut cone
  const lx = wide ? 132 : 80, ly = wide ? 20 : 63;
  const coneBot = ground + 3;
  it.push(cone([[lx - 4, ly + 2], [lx + 4, ly + 2], [lx + (wide ? 30 : 30), coneBot], [lx - (wide ? 26 : 27), coneBot]], w.b, defs, 0.42));
  it.push(glowDot(lx, ly + 1, wide ? 18 : 16, w.glow, defs, 0.5));
  const poleX = wide ? 236 : 146;
  it.push(thing(`M${poleX + 1} ${Ht + 2} L${poleX - 1} ${ly + 8} Q${poleX - 2} ${ly - 4} ${poleX - 14} ${ly - 4} L${lx + 3} ${ly - 3} L${lx + 3} ${ly - 1.4} L${poleX - 14} ${ly - 1.6} Q${poleX - 4.2} ${ly - 1.6} ${poleX - 3.6} ${ly + 8} L${poleX - 2} ${Ht + 2} Z`, { fill: '#2E2140', ink: w.ink, w: 0.6, amp: 0.25, seed: 'pole' + L }));
  it.push(thing(`M${lx - 5} ${ly + 1.8} C${lx - 4.4} ${ly - 3.6} ${lx + 4.4} ${ly - 3.6} ${lx + 5} ${ly + 1.8} Z`, { fill: '#3D2E52', ink: w.ink, w: 0.7, amp: 0.12, mis: w.mis, seed: 'lamp' + L }));
  it.push(blob(ellipseD(lx, ly + 2.2, 3.4, 1.0), w.paper, { amp: 0.1 }));

  // light pool on the pavement
  { const pid = uid('pool'); defs.push(`<radialGradient id="${pid}"><stop offset="0" stop-color="${w.b}" stop-opacity="0.45"/><stop offset="0.7" stop-color="${w.b}" stop-opacity="0.18"/><stop offset="1" stop-color="${w.b}" stop-opacity="0"/></radialGradient>`);
    it.push(`<ellipse cx="${lx + 2}" cy="${coneBot + 1}" rx="${wide ? 40 : 32}" ry="6" fill="url(#${pid})" style="mix-blend-mode:screen"/>`); }

  // --- the cast ---
  const cy = ground + 2;
  if (wide) {
    // two gossips whispering, small, by the shutter
    it.push(character('triangle', { x: 24, y: cy - 1, s: 0.86, expr: 'whisper', world: w, lean: 8, look: [0.8, 0], seed: 'gos1' }));
    it.push(character('drop', { x: 41, y: cy - 1, s: 0.8, expr: 'shy', world: w, lean: -6, dir: -1, seed: 'gos2' }));
    it.push(whisper(31, cy - 27, w, 'w1'));
    it.push(character('circle', { x: 82, y: cy, s: 1.6, expr: 'point', world: w, lean: 9, nub: 1, look: [1.0, 0.2], brows: true, seed: 'p1' }));
    it.push(character('square', { x: 192, y: cy, s: 1.52, expr: 'point', world: w, lean: -9, nub: -1, dir: -1, look: [-1.0, 0.1], brows: true, seed: 'p2' }));
    it.push(accuse(108, cy - 24, 116, cy - 27, w.paper, 'acc1', 2));
    it.push(accuse(168, cy - 23, 158, cy - 27, w.paper, 'acc2', 2));
    it.push(character('star', { x: 137, y: cy, s: 1.9, expr: 'shock', world: w, squash: 1.05, seed: 'mole' }));
    it.push(shockMarks(137, cy - 46, w, 'sm'));
  } else {
    it.push(character('circle', { x: 24, y: cy, s: 1.5, expr: 'point', world: w, lean: 9, nub: 1, look: [1.0, 0.2], brows: true, seed: 'p1s' }));
    it.push(character('square', { x: 128, y: cy, s: 1.42, expr: 'point', world: w, lean: -9, nub: -1, dir: -1, look: [-1.0, 0.1], brows: true, seed: 'p2s' }));
    it.push(character('star', { x: 79, y: cy + 1, s: 1.85, expr: 'shock', world: w, squash: 1.05, seed: 'moles' }));
    it.push(shockMarks(79, cy - 45, w, 'sms'));
  }

  // --- title lockup: Latin sign-painted on the wall, Arabic sharing its bang ---
  if (wide) {
    const lat = placeLatin('MISH ANA!', 15, 11, 31, { seed: 'mish', track: 0.7 });
    const ar = placeArabic('mishana', 1.55, 11 + lat.w, 55, 'right');
    it.push(signPaint(lat.strokes, 1.4, { fill: w.paper, shade: w.a, key: w.ink, keyAdd: 1.5 }, false, 'mishL'));
    it.push(signPaint(ar.strokes, 1.55, { fill: w.b, shade: w.ink, key: w.ink, keyAdd: 1.4, shadeOff: [0.9, 1.1] }, true, 'mishA'));
  } else {
    const lat = placeLatin('MISH ANA!', 13, 75, 22, { seed: 'mish', track: 0.7 }, 'center');
    const ar = placeArabic('mishana', 1.3, 75, 45, 'center');
    it.push(signPaint(lat.strokes, 1.3, { fill: w.paper, shade: w.a, key: w.ink, keyAdd: 1.5 }, false, 'mishLs'));
    it.push(signPaint(ar.strokes, 1.3, { fill: w.b, shade: w.ink, key: w.ink, keyAdd: 1.4 }, true, 'mishAs'));
  }
  return { w: Wd, h: Ht, defs: defs.join(''), items: it };
}

/** A cupped whisper balloon with three dots. */
function whisper(x: number, y: number, w: World, seed: string): F3 {
  const d = `M${x - 6} ${y} C${x - 6} ${y - 4.5} ${x + 6} ${y - 4.5} ${x + 6} ${y} C${x + 6} ${y + 3} ${x + 2} ${y + 3.6} ${x - 0.6} ${y + 3.2} L${x - 3.6} ${y + 6} L${x - 2.6} ${y + 2.8} C${x - 4.8} ${y + 2.2} ${x - 6} ${y + 1.4} ${x - 6} ${y} Z`;
  return cat(
    thing(d, { fill: w.paper, ink: w.ink, w: 0.5, amp: 0.15, seed, mis: [-0.3, 0.3] }),
    blob(circleD(x - 2.8, y - 0.1, 0.65) + circleD(x, y - 0.3, 0.65) + circleD(x + 2.8, y - 0.1, 0.65), w.ink, { seed: seed + 'd' }),
  );
}
/** Shock marks: three short brush ticks fanning out over the head. */
function shockMarks(x: number, y: number, w: World, seed: string): F3 {
  return cat(
    stroke(`M${x - 9} ${y + 2} L${x - 12.5} ${y - 1.5}`, w.paper, { w: 1.2, seed: seed + 1 }),
    stroke(`M${x} ${y - 2} L${x + 0.3} ${y - 6.5}`, w.paper, { w: 1.3, seed: seed + 2 }),
    stroke(`M${x + 9} ${y + 2} L${x + 12.5} ${y - 1.5}`, w.paper, { w: 1.2, seed: seed + 3 }),
  );
}


// =====================================================================
// BLUFF! — hakawati café. A smug liar holds up the moustache on a stick
// under a painted mirror arch; two friends think over their cups.
// Brass lantern, neon sign, a proverb scroll, a mask on a nail.
// =====================================================================
export function bluff(L: Layout): Scene {
  const w = WORLDS.bluff, wide = L === 'wide';
  const Wd = wide ? 240 : 150, Ht = wide ? 135 : 150;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(stage(w, Wd, Ht, defs));
  const table = wide ? 104 : 120;
  const wood = '#6B3F1F', woodDark = '#4A2A14', woodLight = '#8A5A30';

  // upper wall: limewash in the café brown, a faded stencil border (cement-tile petals)
  it.push(flat(rect(-4, -4, Wd + 8, table), w.surface, { amp: 0.3 }));
  const borderY = wide ? 66 : 84;
  let petals = '';
  for (let x = 4, i = 0; x < Wd; x += 9, i++) {
    const y = borderY + (i % 2 ? 0.3 : -0.2);
    petals += `M${x} ${y} Q${x + 2.2} ${y - 2.6} ${x + 4.5} ${y} Q${x + 2.2} ${y + 2.6} ${x} ${y} Z`;
  }
  it.push(flat(petals, w.elevated, { amp: 0.06 }));
  it.push(stroke(`M-2 ${borderY - 4} Q${Wd / 2} ${borderY - 4.6} ${Wd + 2} ${borderY - 3.8}`, w.elevated, { w: 0.6, boil: false }));
  it.push(stroke(`M-2 ${borderY + 4} Q${Wd / 2} ${borderY + 3.5} ${Wd + 2} ${borderY + 4.3}`, w.elevated, { w: 0.6, boil: false }));
  // wainscot planks under the border
  it.push(thing(rect(-4, borderY + 6, Wd + 8, table - borderY - 6), { fill: woodDark, ink: w.ink, w: 0.5, amp: 0.3, boil: false, seed: 'wain' + L }));
  for (let x = 10, i = 0; x < Wd; x += 13 + (i % 3) * 2, i++) it.push(stroke(`M${x} ${borderY + 7} L${x + (i % 2 ? 0.4 : -0.3)} ${table}`, w.ink, { w: 0.4, op: 0.6, boil: false, seed: 'plk' + i }));
  for (let x = 14, i = 0; x < Wd; x += 21 + (i % 2) * 4, i++) it.push(stroke(`M${x} ${borderY + 12 + (i % 3) * 3} Q${x + 2} ${borderY + 15 + (i % 3) * 3} ${x + 1} ${borderY + 19 + (i % 3) * 3}`, woodLight, { w: 0.35, op: 0.5, boil: false, seed: 'grn' + i }));

  // the painted mirror arch (bab), behind the liar: brass rim, copper frame, glass
  const ax = wide ? 124 : 75, aw = wide ? 52 : 46, aTop = wide ? 14 : 44, aBot = table + 2;
  const arch = (x: number, wdt: number, top: number, bot: number) => `M${x - wdt / 2} ${bot} L${x - wdt / 2} ${top + wdt * 0.5} C${x - wdt / 2} ${top + wdt * 0.12} ${x - wdt * 0.2} ${top} ${x + 0.6} ${top - 0.3} C${x + wdt * 0.22} ${top} ${x + wdt / 2} ${top + wdt * 0.14} ${x + wdt / 2} ${top + wdt * 0.5} L${x + wdt / 2} ${bot} Z`;
  it.push(thing(arch(ax, aw, aTop, aBot), { fill: w.b, ink: w.ink, w: 0.8, amp: 0.3, mis: w.mis, seed: 'arch' + L }));
  it.push(thing(arch(ax, aw - 9, aTop + 5, aBot), { fill: '#2B2A22', ink: w.ink, w: 0.6, amp: 0.25, seed: 'glass' + L }));
  // tiny painted flowers on the frame (copper on copper, hand dots)
  for (let i = 0; i < 9; i++) { const t = i / 8; const a = Math.PI * (1 - t); const px = ax + Math.cos(a) * (aw / 2 - 2.3), py = aTop + aw * 0.5 - Math.sin(a) * (aw * 0.5 - 2.4) * 0.95; it.push(blob(circleD(px, py, 0.8), w.a, { seed: 'fl' + i + L })); }
  // reflections on the glass: two brush ticks
  it.push(stroke(`M${ax - aw * 0.28} ${aTop + aw * 0.55} L${ax - aw * 0.12} ${aTop + aw * 0.3}`, w.paper, { w: 1.2, op: 0.25 }));
  it.push(stroke(`M${ax - aw * 0.27} ${aTop + aw * 0.78} L${ax - aw * 0.02} ${aTop + aw * 0.42}`, w.paper, { w: 0.7, op: 0.2 }));

  // neon sign on a dark board with screws
  const nb = wide ? { x: 6, y: 7, w: 92, h: 52 } : { x: 18, y: 5, w: 114, h: 36 };
  it.push(thing(rr(nb.x, nb.y, nb.w, nb.h, 3), { fill: '#24150A', ink: w.ink, w: 0.7, amp: 0.3, seed: 'nb' + L, mis: w.mis }));
  for (const [sx, sy] of [[nb.x + 3, nb.y + 3], [nb.x + nb.w - 3, nb.y + 3], [nb.x + 3, nb.y + nb.h - 3], [nb.x + nb.w - 3, nb.y + nb.h - 3]]) it.push(blob(circleD(sx, sy, 0.8), w.a, { seed: 'scr' + sx + sy }));
  // neon cable dropping out of the board
  it.push(stroke(`M${nb.x + nb.w - 8} ${nb.y + nb.h} C${nb.x + nb.w - 8} ${nb.y + nb.h + 10} ${nb.x + nb.w + 2} ${nb.y + nb.h + 6} ${nb.x + nb.w + 4} ${nb.y + nb.h + 16}`, w.ink, { w: 0.6 }));
  { const gid = uid('ng'); defs.push(`<radialGradient id="${gid}"><stop offset="0" stop-color="${w.a}" stop-opacity="0.35"/><stop offset="1" stop-color="${w.a}" stop-opacity="0"/></radialGradient>`);
    it.push(`<ellipse cx="${nb.x + nb.w / 2}" cy="${nb.y + nb.h / 2}" rx="${nb.w * 0.75}" ry="${nb.h * 0.95}" fill="url(#${gid})" style="mix-blend-mode:screen"/>`); }
  if (wide) {
    const lat = placeLatin('BLUFF!', 17, nb.x + 9, nb.y + 25, { seed: 'bluff', track: 1.0, rot: 2 });
    const ar = placeArabic('bluff', 1.45, nb.x + nb.w - 9, nb.y + 42, 'right');
    it.push(neon(lat.strokes, 1.7, '#FFF4DC', w.a, '#000', false, 'blL'));
    it.push(neon(ar.strokes, 1.45, '#FFD9A0', w.signal!, '#000', true, 'blA'));
  } else {
    const lat = placeLatin('BLUFF!', 15, nb.x + 8, nb.y + 23, { seed: 'bluff', track: 1.0, rot: 2 });
    const ar = placeArabic('bluff', 1.3, nb.x + nb.w - 7, nb.y + 24, 'right');
    it.push(neon(lat.strokes, 1.5, '#FFF4DC', w.a, '#000', false, 'blLs'));
    it.push(neon(ar.strokes, 1.3, '#FFD9A0', w.signal!, '#000', true, 'blAs'));
  }

  // brass lantern on a chain
  const lx = wide ? 176 : 138, ly = wide ? 30 : 60;
  // the lantern's warm reflection in the mirror glass
  { const rid = uid('rf'); defs.push(`<radialGradient id="${rid}"><stop offset="0" stop-color="${w.glow}" stop-opacity="0.22"/><stop offset="1" stop-color="${w.glow}" stop-opacity="0"/></radialGradient>`);
    it.push(`<ellipse cx="${ax + aw * 0.22}" cy="${aTop + aw * 0.45}" rx="${aw * 0.2}" ry="${aw * 0.26}" fill="url(#${rid})" style="mix-blend-mode:screen"/>`); }
  for (let y = -2, i = 0; y < ly - 9; y += 2.6, i++) it.push(stroke(i % 2 ? `M${lx - 0.9} ${y} L${lx + 0.9} ${y + 2.2}` : `M${lx} ${y} L${lx} ${y + 2.4}`, w.ink, { w: 0.7, seed: 'ch' + i + L }));
  it.push(glowDot(lx, ly + 4, wide ? 34 : 28, w.glow, defs, 0.42));
  it.push(thing(`M${lx - 5.5} ${ly - 4} C${lx - 5} ${ly - 9} ${lx + 5} ${ly - 9} ${lx + 5.5} ${ly - 4} Z`, { fill: w.a, ink: w.ink, w: 0.6, amp: 0.1, mis: w.mis, seed: 'ldome' + L }));
  it.push(thing(P([[lx - 6, ly - 4], [lx + 6, ly - 4], [lx + 4.8, ly + 9], [lx - 4.8, ly + 9]]), { fill: '#FFE3A3', ink: w.ink, w: 0.7, amp: 0.12, mis: w.mis, seed: 'lglass' + L }));
  it.push(stroke(`M${lx - 2} ${ly - 3.6} L${lx - 1.6} ${ly + 8.6} M${lx + 2} ${ly - 3.6} L${lx + 1.6} ${ly + 8.6}`, w.ink, { w: 0.55 }));
  it.push(thing(P([[lx - 5.4, ly + 9], [lx + 5.4, ly + 9], [lx + 3, ly + 12.5], [lx - 3, ly + 12.5]]), { fill: w.a, ink: w.ink, w: 0.6, amp: 0.1, mis: w.mis, seed: 'lbase' + L }));
  it.push(blob(circleD(lx, ly - 9.6, 1.1), w.a));
  it.push(blob(`M${lx - 1.1} ${ly + 3.6} C${lx - 1.2} ${ly + 1.4} ${lx} ${ly + 0.4} ${lx} ${ly - 0.6} C${lx + 0.4} ${ly + 0.6} ${lx + 1.3} ${ly + 1.6} ${lx + 1.1} ${ly + 3.6} Z`, '#FF9A3D', { seed: 'flame' + L, amp: 0.15 }));

  if (wide) {
    // moustache sample card pinned on the wall: spares for every liar
    const cx0 = 200, cy0 = 22;
    it.push(g(`transform="rotate(4 ${cx0 + 16} ${cy0 + 9})"`,
      shadow(rect(cx0 + 1.2, cy0 + 1.4, 32, 18), w, 0.45),
      thing(rect(cx0, cy0, 32, 18), { fill: w.paper, ink: w.ink, w: 0.5, amp: 0.2, mis: w.mis, seed: 'card' }),
      ...[0, 1, 2].map((i) => blob(moustacheD(cx0 + 6 + i * 10, cy0 + 9 + (i === 1 ? -0.6 : 0.4), 0.62 + i * 0.06, i), '#2A1A12', { seed: 'ms' + i, amp: 0.06 })),
      blob(circleD(cx0 + 16, cy0 + 1.6, 1.0), w.signal!),
    ));
    // the mask on a nail
    it.push(stroke(`M222 46 L216 56 M222 46 L230 55`, w.ink, { w: 0.4 }));
    it.push(blob(circleD(222, 46, 0.7), w.a));
    it.push(mask(222, 60, 1.0, w, 'mk'));
  } else {
    it.push(blob(circleD(11, 54, 0.7), w.a));
    it.push(stroke(`M11 54 L6 62 M11 54 L16 62`, w.ink, { w: 0.4 }));
    it.push(mask(11, 66, 0.8, w, 'mks'));
  }

  // --- the cast, behind the table (the table hides their feet: they're sitting) ---
  const cy = table + 3;
  if (wide) {
    it.push(character('flower', { x: 64, y: cy, s: 1.75, expr: 'think', world: w, lean: -3, seed: 'th1', groundShadow: false }));
    it.push(qMark(90, cy - 40, 1, w, 'q1'));
    it.push(character('hexagon', { x: 188, y: cy, s: 1.7, expr: 'think', world: w, lean: 4, dir: -1, seed: 'th2', groundShadow: false }));
    it.push(qMark(201, cy - 49, 0.9, w, 'q2'));
    it.push(character('diamond', { x: 124, y: cy - 4, s: 2.05, expr: 'smug', world: w, lean: -6, prop: 'moustache', seed: 'liar', groundShadow: false }));
  } else {
    it.push(character('flower', { x: 27, y: cy, s: 1.5, expr: 'think', world: w, lean: -3, seed: 'th1s', groundShadow: false }));
    it.push(character('hexagon', { x: 123, y: cy, s: 1.45, expr: 'think', world: w, lean: 4, dir: -1, seed: 'th2s', groundShadow: false }));
    it.push(qMark(133, cy - 42, 0.85, w, 'q2s'));
    it.push(character('diamond', { x: 75, y: cy - 4, s: 1.9, expr: 'smug', world: w, lean: -6, prop: 'moustache', seed: 'liars', groundShadow: false }));
  }

  // the table: top edge + front, wood with line hatching
  it.push(thing(`M-4 ${table} C${Wd * 0.3} ${table - 1.6} ${Wd * 0.7} ${table - 1.2} ${Wd + 4} ${table + 0.4} L${Wd + 4} ${table + 6} L-4 ${table + 6} Z`, { fill: woodLight, ink: w.ink, w: 0.8, amp: 0.3, mis: w.mis, seed: 'top' + L }));
  it.push(thing(rect(-4, table + 6, Wd + 8, Ht - table), { fill: wood, ink: w.ink, w: 0.8, amp: 0.3, seed: 'front' + L }));
  for (let x = 8, i = 0; x < Wd; x += 16 + (i % 3) * 3, i++) it.push(stroke(`M${x} ${table + 10 + (i % 2) * 3} Q${x + 5} ${table + 9 + (i % 2) * 3} ${x + 10} ${table + 11 + (i % 2) * 3}`, woodDark, { w: 0.45, op: 0.8, seed: 'tg' + i + L }));
  it.push(stroke(`M2 ${table + 1.6} Q${Wd * 0.4} ${table + 0.4} ${Wd * 0.62} ${table + 1.2}`, w.paper, { w: 0.5, op: 0.4 }));
  it.push(shadow(`M-4 ${table + 6} L${Wd + 4} ${table + 6} L${Wd + 4} ${table + 9.5} C${Wd * 0.6} ${table + 8.6} ${Wd * 0.3} ${table + 10.2} -4 ${table + 9} Z`, w, 0.35));

  // cups (finjan) on saucers, the rakweh, a tawleh corner, the proverb scroll
  const cup = (x: number, s: number, seed: string): F3 => cat(
    thing(ellipseD(x, table + 1.6, 6 * s, 1.5 * s), { fill: w.paper, ink: w.ink, w: 0.5, amp: 0.08, seed: seed + 's' }),
    thing(`M${x - 3.4 * s} ${table - 4.5 * s} L${x + 3.4 * s} ${table - 4.5 * s} C${x + 3.2 * s} ${table - 0.8 * s} ${x + 2 * s} ${table + 1 * s} ${x} ${table + 1 * s} C${x - 2 * s} ${table + 1 * s} ${x - 3.2 * s} ${table - 0.8 * s} ${x - 3.4 * s} ${table - 4.5 * s} Z`, { fill: w.paper, ink: w.ink, w: 0.5, amp: 0.08, seed: seed + 'c', mis: w.mis }),
    stroke(`M${x - 3.1 * s} ${table - 3 * s} Q${x} ${table - 2.4 * s} ${x + 3.1 * s} ${table - 3 * s}`, w.c, { w: 0.9 * s, seed: seed + 'b' }),
    blob(ellipseD(x, table - 4.4 * s, 3.2 * s, 0.6 * s), '#2A140A', { seed: seed + 'k' }),
    stroke(`M${x - 1} ${table - 6.5 * s} C${x - 2.4} ${table - 9 * s} ${x + 1.4} ${table - 10 * s} ${x} ${table - 13 * s}`, w.paper, { w: 0.5, op: 0.5, seed: seed + 'st' }),
  );
  if (wide) {
    it.push(cup(48, 1, 'cup1'));
    it.push(cup(205, 1, 'cup2'));
    it.push(rakweh(92, table, 1, w, 'rk'));
    it.push(tawleh(222, table, w, 'tw'));
    it.push(scroll(112, table + 3, 1, w, 'sc'));
  } else {
    it.push(cup(12, 0.9, 'cup1s'));
    it.push(cup(140, 0.9, 'cup2s'));
    it.push(scroll(68, table + 3, 0.85, w, 'scs'));
  }
  return { w: Wd, h: Ht, defs: defs.join(''), items: it };
}

function moustacheD(cx: number, cy: number, s: number, v = 0) {
  const c = v === 1 ? 0.6 : v === 2 ? -0.4 : 0; // three drawn variants: handlebar, walrus-ish, pencil-ish
  return `M${cx} ${cy - 0.6 * s} C${cx + 1.6 * s} ${cy - 1.6 * s} ${cx + 3.6 * s} ${cy - (1.1 + c) * s} ${cx + 4.4 * s} ${cy - 0.2 * s} C${cx + 5.2 * s} ${cy + 0.5 * s} ${cx + 5.6 * s} ${cy - 0.6 * s} ${cx + 5.1 * s} ${cy - (1.3 - c) * s} C${cx + 6.2 * s} ${cy - 0.8 * s} ${cx + 6.0 * s} ${cy + 1.4 * s} ${cx + 4.4 * s} ${cy + 1.2 * s} C${cx + 3 * s} ${cy + 1.1 * s} ${cx + 1.4 * s} ${cy + 0.5 * s} ${cx} ${cy + 0.3 * s} C${cx - 1.4 * s} ${cy + 0.5 * s} ${cx - 3 * s} ${cy + 1.1 * s} ${cx - 4.4 * s} ${cy + 1.2 * s} C${cx - 6.0 * s} ${cy + 1.4 * s} ${cx - 6.2 * s} ${cy - 0.8 * s} ${cx - 5.1 * s} ${cy - (1.3 - c) * s} C${cx - 5.6 * s} ${cy - 0.6 * s} ${cx - 5.2 * s} ${cy + 0.5 * s} ${cx - 4.4 * s} ${cy - 0.2 * s} C${cx - 3.6 * s} ${cy - (1.1 + c) * s} ${cx - 1.6 * s} ${cy - 1.6 * s} ${cx} ${cy - 0.6 * s} Z`;
}
/** A theatre half-mask: one eye winks (the liar's mask). */
function mask(x: number, y: number, s: number, w: World, seed: string): F3 {
  const d = `M${x - 9 * s} ${y - 3 * s} C${x - 6 * s} ${y - 6.5 * s} ${x - 2 * s} ${y - 5 * s} ${x} ${y - 3.6 * s} C${x + 2 * s} ${y - 5 * s} ${x + 6 * s} ${y - 6.5 * s} ${x + 9 * s} ${y - 3 * s} C${x + 9.4 * s} ${y + 1 * s} ${x + 6 * s} ${y + 4.4 * s} ${x + 2.4 * s} ${y + 3 * s} C${x + 1.2 * s} ${y + 2.6 * s} ${x + 0.6 * s} ${y + 1.4 * s} ${x} ${y + 1.4 * s} C${x - 0.6 * s} ${y + 1.4 * s} ${x - 1.2 * s} ${y + 2.6 * s} ${x - 2.4 * s} ${y + 3 * s} C${x - 6 * s} ${y + 4.4 * s} ${x - 9.4 * s} ${y + 1 * s} ${x - 9 * s} ${y - 3 * s} Z`;
  return cat(
    shadow(d.replace(/(-?\d+\.?\d*) (-?\d+\.?\d*)/g, (_, a, b) => `${r2(+a + 1)} ${r2(+b + 1.3)}`), w, 0.45),
    thing(d, { fill: w.b, ink: w.ink, w: 0.6, amp: 0.12, mis: w.mis, seed }),
    blob(`M${x - 6.4 * s} ${y - 1.2 * s} C${x - 5.6 * s} ${y - 3.2 * s} ${x - 2.8 * s} ${y - 3.2 * s} ${x - 2.2 * s} ${y - 1.1 * s} C${x - 3 * s} ${y - 0.2 * s} ${x - 5.6 * s} ${y - 0.2 * s} ${x - 6.4 * s} ${y - 1.2 * s} Z`, w.ink, { seed: seed + 'e1' }),
    stroke(`M${x + 2.4 * s} ${y - 1.2 * s} Q${x + 4.4 * s} ${y - 2.6 * s} ${x + 6.4 * s} ${y - 1.4 * s}`, w.ink, { w: 0.9 * s, seed: seed + 'e2' }),
    stroke(`M${x - 7.6 * s} ${y - 3.4 * s} Q${x - 5 * s} ${y - 5.4 * s} ${x - 1.6 * s} ${y - 3.6 * s}`, w.a, { w: 0.6 * s, seed: seed + 't' }),
  );
}
/** The brass rakweh (coffee pot) with its long handle. */
function rakweh(x: number, base: number, s: number, w: World, seed: string): F3 {
  const body = `M${x - 4 * s} ${base} C${x - 6.4 * s} ${base - 3 * s} ${x - 4.6 * s} ${base - 7 * s} ${x - 2.6 * s} ${base - 9 * s} L${x - 3.4 * s} ${base - 11.6 * s} C${x - 1 * s} ${base - 11 * s} ${x + 1 * s} ${base - 11 * s} ${x + 3.2 * s} ${base - 11.6 * s} L${x + 2.6 * s} ${base - 9 * s} C${x + 4.6 * s} ${base - 7 * s} ${x + 6.4 * s} ${base - 3 * s} ${x + 4 * s} ${base} Z`;
  const handle = `M${x + 4 * s} ${base - 8.4 * s} L${x + 15 * s} ${base - 12.4 * s} L${x + 15.4 * s} ${base - 11 * s} L${x + 4.6 * s} ${base - 6.6 * s} Z`;
  const spout = `M${x - 3 * s} ${base - 10.8 * s} L${x - 6.2 * s} ${base - 13 * s} L${x - 5.6 * s} ${base - 11 * s} L${x - 2.8 * s} ${base - 9.6 * s} Z`;
  return cat(
    thing(handle, { fill: '#3A2210', ink: w.ink, w: 0.5, amp: 0.08, seed: seed + 'h' }),
    thing(spout, { fill: w.a, ink: w.ink, w: 0.5, amp: 0.06, seed: seed + 'sp' }),
    thing(body, { fill: w.a, ink: w.ink, w: 0.6, amp: 0.1, mis: w.mis, seed: seed + 'b', hatch: true, hatchColor: w.ink, hatchOp: 0.25 }),
    stroke(`M${x - 3 * s} ${base - 6 * s} Q${x - 3.6 * s} ${base - 3.6 * s} ${x - 2.6 * s} ${base - 1.6 * s}`, w.paper, { w: 0.6, op: 0.7, seed: seed + 'hl' }),
    stroke(`M${x - 2.6 * s} ${base - 9.2 * s} Q${x} ${base - 8.6 * s} ${x + 2.6 * s} ${base - 9.2 * s}`, w.ink, { w: 0.4, op: 0.7, seed: seed + 'n' }),
  );
}
/** Corner of a backgammon (tawleh) board with its points and a die. */
function tawleh(x: number, base: number, w: World, seed: string): F3 {
  const parts: F3[] = [];
  parts.push(thing(P([[x - 12, base - 1.4], [x + 22, base - 2.4], [x + 24, base + 5.4], [x - 13, base + 6]]), { fill: '#C8A270', ink: w.ink, w: 0.6, amp: 0.15, mis: w.mis, seed: seed + 'b' }));
  for (let i = 0; i < 5; i++) { const px = x - 10 + i * 6; parts.push(flat(P([[px, base - 1.2], [px + 4.6, base - 1.3], [px + 2.3, base + 3.2]]), i % 2 ? w.c : w.b, { amp: 0.05 })); }
  parts.push(thing(rr(x - 5, base - 6.5, 5, 5, 1), { fill: w.paper, ink: w.ink, w: 0.45, amp: 0.06, seed: seed + 'd' }));
  parts.push(blob(circleD(x - 3.7, base - 5.2, 0.5) + circleD(x - 1.3, base - 2.8, 0.5) + circleD(x - 2.5, base - 4, 0.5), w.ink, { seed: seed + 'pips' }));
  return cat(...parts);
}
/** The proverb scroll unrolled over the table edge: rolled ends, scribbled lines, a red seal. */
function scroll(x: number, y: number, s: number, w: World, seed: string): F3 {
  const W2 = 26 * s, H = 13 * s;
  const sheet = `M${x - W2} ${y} C${x - W2 / 2} ${y - 1.2 * s} ${x + W2 / 2} ${y + 0.8 * s} ${x + W2} ${y - 0.4 * s} L${x + W2 - 0.6 * s} ${y + H} C${x + W2 / 2} ${y + H + 1.2 * s} ${x - W2 / 2} ${y + H - 0.6 * s} ${x - W2 + 0.4 * s} ${y + H + 0.6 * s} Z`;
  const parts: F3[] = [];
  parts.push(shadow(sheet.replace(/(-?\d+\.?\d*) (-?\d+\.?\d*)/g, (_, a, b) => `${r2(+a + 1.2)} ${r2(+b + 1.6)}`), w, 0.4));
  parts.push(thing(sheet, { fill: w.paper, ink: w.ink, w: 0.6, amp: 0.2, mis: w.mis, seed: seed + 'sh' }));
  // three lines of "writing": quick connected strokes, read as a proverb from across the room
  for (let i = 0; i < 3; i++) {
    const ly = y + 3.2 * s + i * 3.2 * s, x0 = x + W2 - 4 * s, x1 = x - W2 + 4 * s + (i === 2 ? 14 * s : 0);
    let d = `M${r2(x0)} ${r2(ly)}`; const r = rng(hashSeed(seed + i));
    for (let xx = x0; xx > x1; xx -= 2.2 * s) { const up = r() > 0.6 ? -1.6 * s : -0.4 * s; d += ` Q${r2(xx - 0.6 * s)} ${r2(ly + up)} ${r2(xx - 1.1 * s)} ${r2(ly)} L${r2(xx - 2.2 * s)} ${r2(ly + (r() - 0.5) * 0.3)}`; if (r() > 0.82) xx -= 1.6 * s; }
    parts.push(stroke(d, '#5A3A20', { w: 0.55 * s, seed: seed + 'ln' + i }));
  }
  // rolled ends
  parts.push(thing(rr(x - W2 - 2.2 * s, y - 1.6 * s, 3.4 * s, H + 3 * s, 1.6 * s), { fill: '#F2D49A', ink: w.ink, w: 0.55, amp: 0.1, seed: seed + 'r1' }));
  parts.push(thing(rr(x + W2 - 1.2 * s, y - 2.2 * s, 3.4 * s, H + 3 * s, 1.6 * s), { fill: '#F2D49A', ink: w.ink, w: 0.55, amp: 0.1, seed: seed + 'r2' }));
  // seal
  parts.push(thing(`M${x - W2 + 7 * s} ${y + H - 2 * s} m-2.4 0 a2.4 2.2 0 1 0 4.8 0 a2.4 2.2 0 1 0 -4.8 0`, { fill: w.signal!, ink: w.ink, w: 0.45, amp: 0.15, seed: seed + 'se' }));
  parts.push(stroke(`M${x - W2 + 6 * s} ${y + H - 1.4 * s} L${x - W2 + 5.4 * s} ${y + H + 2.6 * s} M${x - W2 + 8 * s} ${y + H - 1.4 * s} L${x - W2 + 8.8 * s} ${y + H + 2.4 * s}`, w.signal!, { w: 0.8, seed: seed + 'rb' }));
  return cat(...parts);
}
/** A small brush "?" — which one is the lie? */
function qMark(x: number, y: number, s: number, w: World, seed: string): F3 {
  return cat(
    stroke(`M${x - 2.4 * s} ${y - 3 * s} C${x - 2.4 * s} ${y - 6.4 * s} ${x + 3 * s} ${y - 6.4 * s} ${x + 2.6 * s} ${y - 3 * s} C${x + 2.3 * s} ${y - 1.2 * s} ${x} ${y - 1.4 * s} ${x - 0.1 * s} ${y + 1.4 * s}`, w.paper, { w: 1.3 * s, seed }),
    blob(circleD(x - 0.1 * s, y + 4 * s, 0.85 * s), w.paper, { seed: seed + 'd' }),
  );
}
/** "hmm…" — a tiny 3-line thinking scribble above a head (ART-DIRECTION §8.3). */
function thinkScribble(x: number, y: number, w: World, seed: string): F3 {
  return cat(
    stroke(`M${x - 3} ${y + 2} C${x - 4} ${y - 1} ${x - 1} ${y - 2.6} ${x} ${y - 0.4} C${x + 1} ${y + 1.6} ${x + 3} ${y - 0.6} ${x + 2.4} ${y - 2.4}`, w.paper, { w: 0.8, seed: seed + 1 }),
    stroke(`M${x + 4.6} ${y - 3.4} L${x + 5.6} ${y - 5.4}`, w.paper, { w: 0.8, seed: seed + 2 }),
    blob(circleD(x + 6.6, y - 7, 0.7), w.paper, { seed: seed + 3 }),
  );
}

// =====================================================================
// MOST LIKELY — a Beirut rooftop at night. Two point at a shy one who
// wears the rosette in the spotlight; two gossip behind the water tanks.
// String lights, plant tins, a plastic chair, the city glowing behind.
// =====================================================================
export function likely(L: Layout): Scene {
  const w = WORLDS.likely, wide = L === 'wide';
  const Wd = wide ? 240 : 150, Ht = wide ? 135 : 150;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(stage(w, Wd, Ht, defs));
  const par = wide ? 86 : 100, floor = wide ? 104 : 118, ground = wide ? 122 : 138;

  // city glow on the horizon (light: a gradient is allowed)
  { const id = uid('cg'); defs.push(`<radialGradient id="${id}" cx="0.5" cy="1" r="0.8"><stop offset="0" stop-color="#FFB46B" stop-opacity="0.32"/><stop offset="1" stop-color="#FFB46B" stop-opacity="0"/></radialGradient>`);
    it.push(`<rect x="0" y="${par - 60}" width="${Wd}" height="62" fill="url(#${id})" style="mix-blend-mode:screen"/>`); }
  // a few stars: tiny 4-point sparkles (things in the sky, sparingly)
  const sr = rng(hashSeed('stars' + L)); let stars = '';
  for (let i = 0; i < (wide ? 9 : 6); i++) { const x = 6 + sr() * (Wd - 12), y = 4 + sr() * (wide ? 34 : 30), r = 0.5 + sr() * 0.6; stars += `M${r2(x)} ${r2(y - r * 2)}Q${r2(x + r * 0.3)} ${r2(y - r * 0.3)} ${r2(x + r * 2)} ${r2(y)}Q${r2(x + r * 0.3)} ${r2(y + r * 0.3)} ${r2(x)} ${r2(y + r * 2)}Q${r2(x - r * 0.3)} ${r2(y + r * 0.3)} ${r2(x - r * 2)} ${r2(y)}Q${r2(x - r * 0.3)} ${r2(y - r * 0.3)} ${r2(x)} ${r2(y - r * 2)}Z`; }
  it.push(`<path d="${stars}" fill="${w.glow}" opacity="0.7"/>`);

  // far city: blocks with balconies and roof tanks, flat, no line, irregular
  const br = rng(hashSeed('city' + L));
  let x = -4; const blocks: number[][] = [];
  while (x < Wd + 4) { const bw = 14 + br() * 18, bh = 22 + br() * 30; blocks.push([x, par - bh, bw]); x += bw - 1; }
  for (const [bx, by, bw] of blocks) it.push(flat(P([[bx, by], [bx + bw, by + 0.6], [bx + bw, par + 2], [bx, par + 2]]), br() > 0.5 ? w.surface : w.elevated, { amp: 0.3 }));
  let lit = '', tanks = '';
  for (const [bx, by, bw] of blocks) {
    for (let yy = by + 4; yy < par - 3; yy += 5.5) for (let xx = bx + 2.5; xx < bx + bw - 3; xx += 4.6) {
      const v = br(); if (v > 0.82) { const jx = xx + (br() - 0.5) * 1.4, jy = yy + (br() - 0.5) * 0.8, ww = 1.6 + br() * 1.3, hh = 2 + br() * 1.2; lit += `<path d="${P([[jx, jy], [jx + ww, jy + 0.15], [jx + ww - 0.1, jy + hh], [jx + 0.1, jy + hh - 0.1]])}" fill="${v > 0.93 ? '#FFC94D' : w.glow}" opacity="${r2(0.3 + br() * 0.45)}"/>`; }
    }
    if (br() > 0.45) { const tx = bx + 3 + br() * (bw - 10); tanks += `M${r2(tx)} ${r2(by)}L${r2(tx)} ${r2(by - 3.2)}Q${r2(tx + 2.5)} ${r2(by - 4.4)} ${r2(tx + 5)} ${r2(by - 3.2)}L${r2(tx + 5)} ${r2(by)}Z`; }
    if (br() > 0.6) { const ax_ = bx + bw * 0.7; tanks += `M${r2(ax_)} ${r2(by)}L${r2(ax_ + 0.4)} ${r2(by - 7)}L${r2(ax_ + 0.8)} ${r2(by)}Z M${r2(ax_ - 2)} ${r2(by - 5)}L${r2(ax_ + 2.8)} ${r2(by - 5.3)}L${r2(ax_ + 2.8)} ${r2(by - 4.8)}L${r2(ax_ - 2)} ${r2(by - 4.5)}Z`; }
  }
  it.push(`<path d="${tanks}" fill="${w.elevated}"/>`);
  it.push(lit);

  // parapet wall (mid), rooftop floor (near)
  it.push(thing(P([[-4, par], [Wd + 4, par - 1.2], [Wd + 4, floor], [-4, floor]]), { fill: '#24505E', ink: w.ink, w: 0.6, amp: 0.4, seed: 'par' + L, boil: false }));
  it.push(thing(P([[-4, par - 3], [Wd + 4, par - 4.2], [Wd + 4, par + 0.6], [-4, par + 1.4]]), { fill: '#3B6E7B', ink: w.ink, w: 0.6, amp: 0.3, seed: 'cap' + L }));
  for (let xx = 18, i = 0; xx < Wd; xx += 24 + (i % 3) * 5, i++) it.push(stroke(`M${xx} ${par + 2} L${xx + 0.5} ${floor - 1}`, w.ink, { w: 0.35, op: 0.4, boil: false, seed: 'pj' + i }));
  it.push(thing(P([[-4, floor], [Wd + 4, floor - 0.6], [Wd + 4, Ht + 4], [-4, Ht + 4]]), { fill: '#16343F', ink: w.ink, w: 0.7, amp: 0.3, seed: 'floor' + L }));
  for (let i = 0; i < (wide ? 7 : 4); i++) { const fx = 10 + i * (wide ? 34 : 36) + (i % 2) * 6; it.push(stroke(`M${fx} ${floor + 6 + (i % 3) * 5} L${fx + 9} ${floor + 5.6 + (i % 3) * 5}`, w.ink, { w: 0.4, op: 0.45, seed: 'fl' + i + L })); }

  // plant tins on the parapet (old ghee tins with basil and a geranium)
  const tin = (tx: number, s: number, c: string, seed: string): F3 => cat(
    ...[[-2, -9], [0, -11], [2, -8.5], [-0.6, -7.4], [1.4, -10]].map(([dx, dy], i) => thing(`M${tx + dx * s} ${par - 4.5 * s} Q${tx + (dx - 1.6) * s} ${par + (dy + 2) * s} ${tx + (dx + 0.2) * s} ${par + (dy - 1) * s} Q${tx + (dx + 1.6) * s} ${par + (dy + 1.5) * s} ${tx + dx * s} ${par - 4.5 * s} Z`, { fill: i % 2 ? '#3E9A5B' : '#2F7A48', ink: w.ink, w: 0.35, amp: 0.05, seed: seed + 'lf' + i })),
    thing(P([[tx - 3.6 * s, par - 9.5 * s + 4], [tx + 3.6 * s, par - 9.7 * s + 4], [tx + 3.4 * s, par - 3.4], [tx - 3.4 * s, par - 3.2]]), { fill: c, ink: w.ink, w: 0.5, amp: 0.1, mis: w.mis, seed: seed + 't' }),
    stroke(`M${tx - 2.4 * s} ${par - 6.2 * s + 2.4} L${tx + 2.2 * s} ${par - 6.3 * s + 2.4}`, w.paper, { w: 0.5, op: 0.6, seed: seed + 'lb' }),
  );
  if (wide) { it.push(tin(12, 1.1, '#C9B26A', 'tin1')); it.push(tin(24, 0.95, w.c, 'tin2')); it.push(blob(circleD(24.5, par - 13.6, 1.3), '#FF6F7A', { seed: 'ger' })); }
  else { it.push(tin(140, 1.0, '#C9B26A', 'tin1s')); }

  // water tanks on a steel stand — the gossips hide behind them
  if (wide) {
    const tx = 228;
    it.push(thing(P([[tx - 14, par - 9], [tx + 30, par - 10], [tx + 30, par - 7], [tx - 14, par - 6]]), { fill: '#5C6B70', ink: w.ink, w: 0.5, amp: 0.15, seed: 'stand' }));
    for (const lx of [tx - 12, tx + 1, tx + 15]) it.push(thing(rect(lx, par - 7, 1.6, floor - par + 7), { fill: '#5C6B70', ink: w.ink, w: 0.45, amp: 0.08, seed: 'leg' + lx }));
    const tank = (cx: number, s: number, seed: string) => cat(
      thing(`M${cx - 9 * s} ${par - 9} L${cx - 9 * s} ${par - 26 * s - 9} C${cx - 9 * s} ${par - 29 * s - 9} ${cx + 9 * s} ${par - 29 * s - 9} ${cx + 9 * s} ${par - 26 * s - 9} L${cx + 9 * s} ${par - 9} C${cx + 4 * s} ${par - 7.8} ${cx - 4 * s} ${par - 7.8} ${cx - 9 * s} ${par - 9} Z`, { fill: w.b, ink: w.ink, w: 0.7, amp: 0.15, mis: w.mis, seed: seed + 'b', hatch: true, hatchColor: w.ink, hatchOp: 0.25 }),
      stroke(`M${cx - 8.6 * s} ${par - 18 * s - 9} Q${cx} ${par - 16.6 * s - 9} ${cx + 8.6 * s} ${par - 18 * s - 9}`, w.ink, { w: 0.4, op: 0.7, seed: seed + 'r1' }),
      stroke(`M${cx - 8.6 * s} ${par - 9 * s - 9} Q${cx} ${par - 7.6 * s - 9} ${cx + 8.6 * s} ${par - 9 * s - 9}`, w.ink, { w: 0.4, op: 0.7, seed: seed + 'r2' }),
      thing(ellipseD(cx, par - 28.2 * s - 9, 3 * s, 1 * s), { fill: '#2A4F7E', ink: w.ink, w: 0.4, amp: 0.05, seed: seed + 'lid' }),
      stroke(`M${cx - 6 * s} ${par - 24 * s - 9} L${cx - 6.3 * s} ${par - 13 * s - 9}`, w.paper, { w: 0.6, op: 0.5, seed: seed + 'hl' }),
    );
    it.push(tank(tx, 1, 'tk1'));
    // the two gossips, sitting on the parapet edge with the city behind them
    it.push(character('bolt', { x: 192, y: par - 2.5, s: 1.0, expr: 'whisper', world: w, lean: 12, look: [0.9, 0], seed: 'g1', groundShadow: false }));
    it.push(character('triangle', { x: 208, y: par - 2.5, s: 0.92, expr: 'shy', world: w, lean: -8, dir: -1, seed: 'g2', groundShadow: false }));
    it.push(whisper2(200, par - 32, w, 'wh'));
    // satellite dish on the parapet
    it.push(thing(`M150 ${par - 3} L152 ${par - 9} L154 ${par - 3} Z`, { fill: '#8FA3A8', ink: w.ink, w: 0.4, amp: 0.05 }));
    it.push(g(`transform="rotate(-24 152 ${par - 12})"`, thing(`M144 ${par - 12} C144 ${par - 18} 160 ${par - 18} 160 ${par - 12} C156 ${par - 10} 148 ${par - 10} 144 ${par - 12} Z`, { fill: '#C9D6D8', ink: w.ink, w: 0.5, amp: 0.08, mis: w.mis, seed: 'dish' }), stroke(`M152 ${par - 13} L152 ${par - 19}`, w.ink, { w: 0.4 })));
  }

  // string lights: wires with bulbs in 4 drawn variants, each a light source
  const lights = wide ? [[-4, 6, 116, 20, 9], [116, 20, 244, 4, 10]] : [[-4, 8, 76, 18, 8], [76, 18, 154, 6, 8]];
  let bulbsI = 0;
  for (const [x1, y1, x2, y2, sag] of lights) {
    const cxq = (x1 + x2) / 2, cyq = Math.max(y1, y2) + sag;
    it.push(stroke(`M${x1} ${y1} Q${cxq} ${cyq} ${x2} ${y2}`, w.ink, { w: 0.5, seed: 'sl' + x1 + L }));
    const n = wide ? 9 : 6;
    for (let i = 1; i < n; i++) {
      const t = i / n, bx = (1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * cxq + t * t * x2, by = (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * cyq + t * t * y2;
      const v = bulbsI++ % 4, col = [w.glow, '#FFE7A0', w.glow, '#FFC9B0'][v];
      it.push(glowDot(bx, by + 2.4, 5.5, col, defs, 0.45));
      it.push(blob(`M${r2(bx - 0.6)} ${r2(by)}L${r2(bx + 0.6)} ${r2(by)}L${r2(bx + 0.6)} ${r2(by + 1)}L${r2(bx - 0.6)} ${r2(by + 1)}Z`, w.ink, { seed: 'bc' + bulbsI }));
      it.push(blob(ellipseD(bx + [0, 0.1, -0.1, 0][v], by + 2.4, [1.1, 1.0, 1.15, 1.05][v], [1.5, 1.6, 1.4, 1.55][v]), col, { seed: 'bb' + bulbsI }));
    }
  }

  // the spotlight on the shy one
  const sx = wide ? 124 : 75;
  it.push(cone([[sx - 5, -4], [sx + 5, -4], [sx + (wide ? 25 : 23), ground + 2], [sx - (wide ? 23 : 22), ground + 2]], w.glow, defs, 0.3));
  { const pid = uid('pool'); defs.push(`<radialGradient id="${pid}"><stop offset="0" stop-color="${w.glow}" stop-opacity="0.35"/><stop offset="1" stop-color="${w.glow}" stop-opacity="0"/></radialGradient>`);
    it.push(`<ellipse cx="${sx}" cy="${ground + 1}" rx="26" ry="5" fill="url(#${pid})" style="mix-blend-mode:screen"/>`); }

  // plastic chair
  if (wide) it.push(chair(26, ground + 4, 1, w, 'chair'));

  // the cast
  if (wide) {
    it.push(character('hexagon', { x: 74, y: ground, s: 1.65, expr: 'point', world: w, lean: 8, nub: 1, look: [1.1, 0.1], brows: true, seed: 'c1' }));
    it.push(character('crescent', { x: 176, y: ground, s: 1.75, expr: 'point', world: w, lean: -9, nub: -1, dir: -1, look: [-1.0, 0], brows: true, seed: 'c2' }));
    it.push(accuse(97, ground - 27, 106, ground - 30, w.paper, 'la1', 2));
    it.push(accuse(156, ground - 26, 143, ground - 30, w.paper, 'la2', 2));
    it.push(character('drop', { x: 124, y: ground, s: 1.85, expr: 'shy', world: w, lean: 3, prop: 'rosette', seed: 'shy' }));
  } else {
    it.push(character('hexagon', { x: 25, y: ground, s: 1.45, expr: 'point', world: w, lean: 8, nub: 1, look: [1.1, 0.1], brows: true, seed: 'c1s' }));
    it.push(character('crescent', { x: 126, y: ground, s: 1.55, expr: 'point', world: w, lean: -9, nub: -1, dir: -1, look: [-1.0, 0], brows: true, seed: 'c2s' }));
    it.push(character('drop', { x: 75, y: ground, s: 1.75, expr: 'shy', world: w, lean: 3, prop: 'rosette', seed: 'shys' }));
  }

  // title: award gold, stamped edge, an ink keyline
  const T = { fill: '#FFC94D', shade: '#9A5E0E', key: w.ink, keyAdd: 1.5, shadeOff: [0.5, 1.4] as [number, number] };
  if (wide) {
    const lat = placeLatin('MOST LIKELY', 12.5, 10, 42, { seed: 'likely', track: 0.6 });
    const ar = placeArabic('likely', 1.4, 10 + lat.w, 66, 'right');
    it.push(signPaint(lat.strokes, 1.25, T, false, 'lkL'));
    it.push(goldTicks(lat.strokes.length, 10, 42, lat.w, 12.5, w));
    it.push(signPaint(ar.strokes, 1.4, T, true, 'lkA'));
    it.push(sparkle(10 + lat.w + 5, 27, 2.2, w)); it.push(sparkle(14, 60, 1.5, w));
  } else {
    const lat = placeLatin('MOST LIKELY', 11, 75, 38, { seed: 'likely', track: 0.6 }, 'center');
    const ar = placeArabic('likely', 1.2, 75, 58, 'center');
    it.push(signPaint(lat.strokes, 1.1, T, false, 'lkLs'));
    it.push(signPaint(ar.strokes, 1.2, T, true, 'lkAs'));
    it.push(sparkle(75 + lat.w / 2 + 4, 26, 2, w));
  }
  return { w: Wd, h: Ht, defs: defs.join(''), items: it };
}
/** paper highlight ticks on the gold letters' top-start (printed highlight, not a gloss) */
function goldTicks(_n: number, x: number, y: number, wdt: number, size: number, w: World): F3 {
  const out: F3[] = [];
  for (let i = 0; i < 5; i++) { const xx = x + 3 + i * (wdt / 5) + (i % 2) * 2; out.push(stroke(`M${r2(xx)} ${r2(y - size * 0.72)} L${r2(xx + 0.4)} ${r2(y - size * 0.86)}`, '#FFF4C9', { w: 0.6, op: 0.85, seed: 'gt' + i })); }
  return cat(...out);
}
function sparkle(x: number, y: number, r: number, w: World): F3 {
  return blob(`M${x} ${y - r * 2}Q${x + r * 0.3} ${y - r * 0.3} ${x + r * 2} ${y}Q${x + r * 0.3} ${y + r * 0.3} ${x} ${y + r * 2}Q${x - r * 0.3} ${y + r * 0.3} ${x - r * 2} ${y}Q${x - r * 0.3} ${y - r * 0.3} ${x} ${y - r * 2}Z`, '#FFC94D', { seed: 'sp' + x, amp: 0.1 });
}
function whisper2(x: number, y: number, w: World, seed: string): F3 {
  const d = `M${x - 6} ${y} C${x - 6} ${y - 4.5} ${x + 6} ${y - 4.5} ${x + 6} ${y} C${x + 6} ${y + 3} ${x + 2} ${y + 3.6} ${x + 0.6} ${y + 3.2} L${x + 2.6} ${y + 6} L${x - 1.6} ${y + 3.0} C${x - 4.8} ${y + 2.6} ${x - 6} ${y + 1.4} ${x - 6} ${y} Z`;
  return cat(
    thing(d, { fill: w.paper, ink: w.ink, w: 0.5, amp: 0.15, seed, mis: [-0.3, 0.3] }),
    blob(circleD(x - 2.8, y - 0.1, 0.65) + circleD(x, y - 0.3, 0.65) + circleD(x + 2.8, y - 0.1, 0.65), w.ink, { seed: seed + 'd' }),
  );
}
/** A white plastic garden chair (the rooftop's real furniture). */
function chair(x: number, base: number, s: number, w: World, seed: string): F3 {
  const c = '#E6EEEC';
  return cat(
    thing(`M${x - 8 * s} ${base} L${x - 7 * s} ${base - 11 * s} L${x - 5.6 * s} ${base - 11 * s} L${x - 6.2 * s} ${base} Z`, { fill: '#C4D0CE', ink: w.ink, w: 0.5, amp: 0.08, seed: seed + 'l1' }),
    thing(`M${x + 8 * s} ${base} L${x + 7 * s} ${base - 11 * s} L${x + 5.6 * s} ${base - 11 * s} L${x + 6.2 * s} ${base} Z`, { fill: '#C4D0CE', ink: w.ink, w: 0.5, amp: 0.08, seed: seed + 'l2' }),
    thing(`M${x - 8 * s} ${base - 24 * s} C${x - 7 * s} ${base - 28 * s} ${x + 7 * s} ${base - 28 * s} ${x + 8 * s} ${base - 24 * s} L${x + 7 * s} ${base - 13 * s} L${x - 7 * s} ${base - 13 * s} Z`, { fill: c, ink: w.ink, w: 0.6, amp: 0.12, mis: w.mis, seed: seed + 'b' }),
    ...[0, 1, 2].map((i) => thing(rr(x - 5 * s + i * 3.6 * s, base - 24 * s, 2.2 * s, 8 * s, 1 * s), { fill: '#16343F', ink: w.ink, w: 0.35, amp: 0.05, seed: seed + 'sl' + i })),
    thing(P([[x - 9 * s, base - 13.5 * s], [x + 9 * s, base - 13.5 * s], [x + 8.4 * s, base - 10.6 * s], [x - 8.4 * s, base - 10.6 * s]]), { fill: c, ink: w.ink, w: 0.6, amp: 0.1, mis: w.mis, seed: seed + 's' }),
  );
}

// =====================================================================
// QUIZ NIGHT — a 1970s TV quiz set. Three behind rounded podiums, one
// cheering; two spotlight cones crossing; a marquee title; a porthole
// screen with tonight's question (Raouché, Beirut); category tiles.
// =====================================================================
export function trivia(L: Layout): Scene {
  const w = WORLDS.trivia, wide = L === 'wide';
  const Wd = wide ? 240 : 150, Ht = wide ? 135 : 150;
  const defs: string[] = [];
  const it: Item[] = [];
  it.push(stage(w, Wd, Ht, defs));
  const floor = wide ? 117 : 134;
  const veneer = '#9A6236', veneerD = '#7A4A26', veneerL = '#B97A45';

  // the set: a big rounded back flat with a halftone band (1970s TV graphics)
  it.push(thing(rr(wide ? 4 : 3, wide ? 6 : 50, wide ? 232 : 144, floor - (wide ? 6 : 50) + 6, 8), { fill: w.surface, ink: w.ink, w: 0.6, amp: 0.4, boil: false, seed: 'set' + L }));
  const hb = wide ? { x: 8, y: 70, w: 224, h: 18 } : { x: 6, y: 96, w: 138, h: 14 };
  let dots = '';
  const hr = rng(hashSeed('ht' + L));
  for (let yy = hb.y, row = 0; yy < hb.y + hb.h; yy += 2.6, row++) for (let xx = hb.x + (row % 2) * 1.3; xx < hb.x + hb.w; xx += 2.6) {
    const t = (yy - hb.y) / hb.h, r = 0.35 + t * 0.85 + (hr() - 0.5) * 0.12;
    dots += `M${r2(xx - r)} ${r2(yy)}a${r2(r)} ${r2(r)} 0 1 0 ${r2(2 * r)} 0a${r2(r)} ${r2(r)} 0 1 0 ${r2(-2 * r)} 0z`;
  }
  it.push(`<path d="${dots}" fill="${w.a}" opacity="0.55"/>`);
  // wood veneer lower set
  it.push(thing(rect(wide ? 4 : 3, hb.y + hb.h + 1, wide ? 232 : 144, floor - hb.y - hb.h - 1), { fill: veneerD, ink: w.ink, w: 0.5, amp: 0.3, boil: false, seed: 'ven' + L }));
  for (let xx = 12, i = 0; xx < Wd - 6; xx += 7 + (i % 3), i++) it.push(stroke(`M${xx} ${hb.y + hb.h + 2} L${xx + (i % 2 ? 0.3 : -0.2)} ${floor - 1}`, veneer, { w: 0.9, op: 0.8, boil: false, seed: 'vs' + i + L }));

  // the porthole screen: tonight's question — Raouché, the Pigeon Rocks
  const sc = wide ? { x: 150, y: 36, r: 22 } : { x: 75, y: 67, r: 14 };
  it.push(screen(sc.x, sc.y, sc.r, w, 'scr' + L, defs));

  // category tiles: cedar (nature), darbuka (music), football — the quiz's own categories
  if (wide) {
    tile(it, 196, 16, 18, 'cedar', w); tile(it, 201, 38, 18, 'drum', w); tile(it, 195, 60 - 1, 0, 'none', w);
    tile(it, 214, 27, 18, 'ball', w);
  } else {
    tile(it, 20, 60, 15, 'cedar', w); tile(it, 115, 62, 15, 'ball', w);
  }

  // marquee title panel with chasing bulbs
  const mq = wide ? { x: 8, y: 8, w: 104, h: 54 } : { x: 8, y: 5, w: 134, h: 42 };
  it.push(shadow(rr(mq.x + 1.4, mq.y + 1.8, mq.w, mq.h, 7), w, 0.5));
  it.push(thing(rr(mq.x, mq.y, mq.w, mq.h, 7), { fill: w.elevated, ink: w.ink, w: 0.8, amp: 0.3, mis: w.mis, seed: 'mq' + L }));
  it.push(thing(rr(mq.x + 4.5, mq.y + 4.5, mq.w - 9, mq.h - 9, 4), { fill: '#1B2358', ink: w.ink, w: 0.5, amp: 0.2, seed: 'mqi' + L }));
  {
    const per = 2 * (mq.w + mq.h) - 4 * 7, n = wide ? 30 : 32;
    for (let i = 0; i < n; i++) {
      let d = (i / n) * per; let bx = 0, by = 0;
      const ix = mq.x + 2.2, iy = mq.y + 2.2, iw = mq.w - 4.4, ih = mq.h - 4.4;
      if (d < iw) { bx = ix + d; by = iy; } else if ((d -= iw) < ih) { bx = ix + iw; by = iy + d; } else if ((d -= ih) < iw) { bx = ix + iw - d; by = iy + ih; } else { d -= iw; bx = ix; by = iy + ih - Math.min(d, ih); }
      const on = i % 3 !== 1;
      if (on) it.push(glowDot(bx, by, 4, w.glow, defs, 0.4));
      it.push(blob(circleD(bx, by, 1.15 + (i % 4 === 0 ? 0.1 : 0)), on ? '#FFF1B8' : '#8C7A3A', { seed: 'mb' + i + L }));
    }
  }
  if (wide) {
    const lat = placeLatin('QUIZ NIGHT', 11.5, mq.x + mq.w / 2, mq.y + 27, { seed: 'quiz', track: 0.7 }, 'center');
    const ar = placeArabic('trivia', 1.12, mq.x + mq.w / 2, mq.y + 46, 'center');
    it.push(felt(lat.strokes, 1.15, w, false, 'tqL'));
    it.push(signPaint(ar.strokes, 1.12, { fill: w.b, shade: '#000', key: w.ink, keyAdd: 1.2, shadeOff: [0.6, 0.9] }, true, 'tqA'));
  } else {
    const lat = placeLatin('QUIZ NIGHT', 10, mq.x + 6.5, mq.y + 23, { seed: 'quiz', track: 0.7 }, 'left');
    const ar = placeArabic('trivia', 0.95, mq.x + mq.w - 7, mq.y + 31, 'right');
    it.push(felt(lat.strokes, 1.0, w, false, 'tqLs'));
    it.push(signPaint(ar.strokes, 0.95, { fill: w.b, shade: '#000', key: w.ink, keyAdd: 1.2, shadeOff: [0.6, 0.9] }, true, 'tqAs'));
  }

  // floor
  it.push(thing(P([[-4, floor], [Wd + 4, floor - 0.6], [Wd + 4, Ht + 4], [-4, Ht + 4]]), { fill: '#10153A', ink: w.ink, w: 0.7, amp: 0.3, seed: 'fl' + L }));
  for (let i = 0; i < 5; i++) { const fx = -10 + i * (Wd / 4); it.push(stroke(`M${fx + Wd / 8} ${floor + 1} L${fx} ${Ht + 2}`, '#1E2660', { w: 0.6, op: 0.8, seed: 'fs' + i + L })); }

  // two spotlight cones, crossing on the winner
  const cx = wide ? 120 : 75;
  it.push(cone([[wide ? 6 : 2, -4], [wide ? 18 : 12, -4], [cx + 22, floor + 8], [cx + 2, floor + 10]], w.glow, defs, 0.26));
  it.push(cone([[Wd - (wide ? 18 : 12), -4], [Wd - (wide ? 6 : 2), -4], [cx - 2, floor + 10], [cx - 22, floor + 8]], '#FFFFFF', defs, 0.2));

  // the contestants behind podiums: think · cheer · happy
  const pods = wide
    ? [{ x: 64, s: 1.75, sh: 'arch', e: 'think' as const, tok: 'sun', h: 0 }, { x: 120, s: 1.9, sh: 'plus', e: 'cheer' as const, tok: 'wave', h: -4 }, { x: 176, s: 1.75, sh: 'circle', e: 'happy' as const, tok: 'leaf', h: 0 }]
    : [{ x: 26, s: 1.4, sh: 'arch', e: 'think' as const, tok: 'sun', h: 0 }, { x: 75, s: 1.55, sh: 'plus', e: 'cheer' as const, tok: 'wave', h: -4 }, { x: 124, s: 1.4, sh: 'circle', e: 'happy' as const, tok: 'leaf', h: 0 }];
  const ptop = floor - (wide ? 24 : 22);
  for (const p of pods) {
    const rid = uid('pr'); defs.push(`<radialGradient id="${rid}"><stop offset="0" stop-color="${p.e === 'cheer' ? '#FFFFFF' : '#C9CFE8'}" stop-opacity="0.22"/><stop offset="1" stop-color="#C9CFE8" stop-opacity="0"/></radialGradient>`);
    it.push(`<ellipse cx="${p.x}" cy="${floor + 7}" rx="${wide ? 22 : 18}" ry="${wide ? 6 : 5}" fill="url(#${rid})" style="mix-blend-mode:screen"/>`);
  }
  for (const p of pods) {
    const top = ptop + p.h;
    if (p.e === 'cheer' && wide) it.push(confetti(p.x, top - p.s * 24 - 4, p.s, w, 'cf' + L));
    it.push(character(p.sh, { x: p.x, y: top + 4, s: p.s, expr: p.e, world: w, groundShadow: false, seed: 'qz' + p.sh + L, lean: p.e === 'think' ? -3 : p.e === 'happy' ? 3 : 0, squash: p.e === 'cheer' ? 1.04 : 1, dir: p.sh === 'circle' ? -1 : 1 }));
    it.push(podium(p.x, top, floor + 2, wide ? 34 : 30, p.tok, p.e === 'cheer', w, 'pd' + p.sh + L));
  }
  return { w: Wd, h: Ht, defs: defs.join(''), items: it };
}
/** Felt letters with a short extruded depth (≤ 4 % cap height), the only 3D lettering allowed. */
function felt(strokes: string[], k: number, w: World, arabic: boolean, seed: string): F3 {
  const layers: F3[] = [];
  const B = { nib: 30, wMax: 2.35, wMin: 1.0, amp: 0.1 };
  const base = letter2(strokes, { ...B, seed: seed + 'k', k, add: 1.3 });
  for (let i = 4; i >= 1; i--) layers.push(base.map((sv) => `<g fill="${w.ink}" transform="translate(${r2(i * 0.22 * k)} ${r2(i * 0.3 * k)})">${sv}</g>`));
  layers.push(base.map((sv) => `<g fill="${w.ink}">${sv}</g>`));
  layers.push(letter2(strokes, { ...B, seed, k }).map((sv) => `<g fill="${w.paper}">${sv}</g>`));
  return cat(...layers);
}
import { letter as letter2 } from './lib.ts';
/** The porthole screen: a wood bezel, the sea, Raouché's arch rock, a "?" sticker. */
function screen(x: number, y: number, r: number, w: World, seed: string, defs: string[]): F3 {
  const id = uid('sc');
  const s = r / 22;
  const sea = '#2C6FB8', sky = '#F2B36B', sky2 = '#E5484D';
  const rock = `M${x - 8 * s} ${y + 8 * s} L${x - 7 * s} ${y - 2 * s} C${x - 6 * s} ${y - 8 * s} ${x - 2 * s} ${y - 11 * s} ${x + 1 * s} ${y - 10 * s} C${x + 5 * s} ${y - 9 * s} ${x + 7 * s} ${y - 5 * s} ${x + 7.5 * s} ${y + 1 * s} L${x + 8 * s} ${y + 8 * s} L${x + 3.6 * s} ${y + 8 * s} C${x + 3.6 * s} ${y + 3 * s} ${x + 1.6 * s} ${y + 0.6 * s} ${x - 0.4 * s} ${y + 0.6 * s} C${x - 2.6 * s} ${y + 0.6 * s} ${x - 3.6 * s} ${y + 3 * s} ${x - 3.6 * s} ${y + 8 * s} Z`;
  const small = `M${x + 10 * s} ${y + 8 * s} L${x + 10.6 * s} ${y + 1 * s} C${x + 11.4 * s} ${y - 2 * s} ${x + 14 * s} ${y - 2.4 * s} ${x + 15 * s} ${y + 0.6 * s} L${x + 15.6 * s} ${y + 8 * s} Z`;
  const inner = r * 0.8;
  return cat(
    thing(circleD(x, y, r), { fill: '#B97A45', ink: w.ink, w: 0.9, amp: 0.25, mis: w.mis, seed: seed + 'bz' }),
    stroke(`M${x - r * 0.62} ${y - r * 0.62} Q${x - r * 0.9} ${y - r * 0.1} ${x - r * 0.8} ${y + r * 0.35}`, '#F2C48C', { w: 0.9, op: 0.8, seed: seed + 'bh' }),
    `<clipPath id="${id}"><circle cx="${x}" cy="${y}" r="${inner}"/></clipPath>`,
    g(`clip-path="url(#${id})"`,
      flat(rect(x - r, y - r, 2 * r, 2 * r), sky, { amp: 0.1 }),
      flat(rect(x - r, y - r, 2 * r, r * 0.55), sky2, { amp: 0.4, op: 0.75 }),
      blob(circleD(x - 9 * s, y - 2 * s, 3.4 * s), '#FFE7A0', { amp: 0.1 }),
      flat(rect(x - r, y + 4 * s, 2 * r, r), sea, { amp: 0.3 }),
      thing(rock, { fill: '#8E5A3C', ink: w.ink, w: 0.7, amp: 0.15, seed: seed + 'rk', hatch: true, hatchColor: w.ink, hatchOp: 0.3 }),
      thing(small, { fill: '#7A4C33', ink: w.ink, w: 0.6, amp: 0.1, seed: seed + 'rk2' }),
      stroke(`M${x - 16 * s} ${y + 10 * s} Q${x - 13 * s} ${y + 9 * s} ${x - 10 * s} ${y + 10 * s} M${x + 2 * s} ${y + 12.5 * s} Q${x + 5 * s} ${y + 11.5 * s} ${x + 8 * s} ${y + 12.5 * s} M${x - 6 * s} ${y + 15 * s} Q${x - 3 * s} ${y + 14 * s} ${x} ${y + 15 * s}`, w.paper, { w: 0.6, op: 0.8, seed: seed + 'wv' }),
      // two gulls
      stroke(`M${x + 2 * s} ${y - 14 * s} Q${x + 3.4 * s} ${y - 15.6 * s} ${x + 4.6 * s} ${y - 14 * s} Q${x + 5.8 * s} ${y - 15.6 * s} ${x + 7 * s} ${y - 14 * s}`, w.ink, { w: 0.5, seed: seed + 'gl1' }),
      stroke(`M${x + 9 * s} ${y - 11 * s} Q${x + 10 * s} ${y - 12.2 * s} ${x + 11 * s} ${y - 11 * s} Q${x + 12 * s} ${y - 12.2 * s} ${x + 13 * s} ${y - 11 * s}`, w.ink, { w: 0.45, seed: seed + 'gl2' }),
    ),
    stroke(`M${x - inner} ${y} a${inner} ${inner} 0 1 0 ${2 * inner} 0 a${inner} ${inner} 0 1 0 ${-2 * inner} 0`, w.ink, { w: 0.8, seed: seed + 'rim' }),
    // glass glint
    stroke(`M${x + inner * 0.35} ${y - inner * 0.8} Q${x + inner * 0.7} ${y - inner * 0.6} ${x + inner * 0.82} ${y - inner * 0.25}`, '#FFFFFF', { w: 1.0 * s + 0.3, op: 0.55, seed: seed + 'gg' }),
    // the "?" sticker, slapped on the bezel
    g(`transform="rotate(12 ${x + r * 0.78} ${y + r * 0.72})"`,
      thing(circleD(x + r * 0.78, y + r * 0.72, 5 * s + 1.4), { fill: w.c, ink: w.ink, w: 0.6, amp: 0.15, mis: w.mis, seed: seed + 'st' }),
      stroke(`M${x + r * 0.78 - 1.8 * s - 0.5} ${y + r * 0.72 - 1.4 * s} C${x + r * 0.78 - 1.8 * s - 0.5} ${y + r * 0.72 - 4.4 * s} ${x + r * 0.78 + 2.4 * s + 0.6} ${y + r * 0.72 - 4.4 * s} ${x + r * 0.78 + 2 * s + 0.4} ${y + r * 0.72 - 1.4 * s} C${x + r * 0.78 + 1.6 * s} ${y + r * 0.72} ${x + r * 0.78} ${y + r * 0.72 - 0.2 * s} ${x + r * 0.78} ${y + r * 0.72 + 1.4 * s}`, w.paper, { w: 1.1 * s + 0.3, seed: seed + 'q' }),
      blob(circleD(x + r * 0.78, y + r * 0.72 + 3.4 * s + 0.3, 0.7 * s + 0.2), w.paper, { seed: seed + 'qd' }),
    ),
  );
}
/** Category tile: rounded card with a cut-paper pictogram. */
function tile(it: Item[], x: number, y: number, sz: number, kind: string, w: World) {
  if (kind === 'none' || sz === 0) return;
  const c = x + sz / 2, m = y + sz / 2, s = sz / 18;
  it.push(shadow(rr(x + 1, y + 1.3, sz, sz, 3), w, 0.5));
  it.push(thing(rr(x, y, sz, sz, 3), { fill: kind === 'cedar' ? '#2E8A5E' : kind === 'drum' ? '#E5484D' : '#5B7CFF', ink: w.ink, w: 0.6, amp: 0.2, mis: w.mis, seed: 'tile' + kind + x }));
  if (kind === 'cedar') {
    // a cedar: wide, flat, layered plates on a short trunk — read as a quiz category, not a flag
    it.push(thing(`M${c - 0.9 * s} ${m + 6 * s} L${c - 0.6 * s} ${m - 3 * s} L${c + 0.7 * s} ${m - 3 * s} L${c + 1 * s} ${m + 6 * s} Z`, { fill: '#7A4A26', ink: w.ink, w: 0.4, amp: 0.05, seed: 'trunk' + x }));
    const plates = [[c - 0.6 * s, m - 5.6 * s, 3.4], [c + 0.8 * s, m - 2.8 * s, 5.6], [c - 0.4 * s, m + 0.2 * s, 7.0], [c + 0.6 * s, m + 3.2 * s, 6.2]];
    plates.forEach(([px, py, hw], i) => it.push(thing(`M${px - hw * s} ${py + 0.9 * s} C${px - hw * 0.8 * s} ${py - 1.0 * s} ${px - hw * 0.2 * s} ${py - 1.4 * s} ${px + 0.3 * s} ${py - 1.2 * s} C${px + hw * 0.4 * s} ${py - 1.5 * s} ${px + hw * 0.9 * s} ${py - 0.6 * s} ${px + hw * s} ${py + 0.8 * s} C${px + hw * 0.5 * s} ${py + 1.5 * s} ${px - hw * 0.5 * s} ${py + 1.4 * s} ${px - hw * s} ${py + 0.9 * s} Z`, { fill: i % 2 ? '#BFF0C8' : '#E9FFE9', ink: w.ink, w: 0.42, amp: 0.06, seed: 'plate' + i + x })));
  } else if (kind === 'drum') {
    // darbuka: goblet drum with a zigzag band
    it.push(thing(`M${c - 4.6 * s} ${m - 5 * s} L${c + 4.6 * s} ${m - 5 * s} C${c + 4.6 * s} ${m - 1 * s} ${c + 1.4 * s} ${m} ${c + 1.6 * s} ${m + 2 * s} L${c + 3 * s} ${m + 6 * s} L${c - 3 * s} ${m + 6 * s} L${c - 1.6 * s} ${m + 2 * s} C${c - 1.4 * s} ${m} ${c - 4.6 * s} ${m - 1 * s} ${c - 4.6 * s} ${m - 5 * s} Z`, { fill: '#FFD84D', ink: w.ink, w: 0.45, amp: 0.08, seed: 'drum' + x }));
    it.push(thing(ellipseD(c, m - 5 * s, 4.6 * s, 1.3 * s), { fill: w.paper, ink: w.ink, w: 0.4, amp: 0.04, seed: 'skin' + x }));
    it.push(stroke(`M${c - 4 * s} ${m - 2.6 * s} L${c - 2.6 * s} ${m - 1.4 * s} L${c - 1.2 * s} ${m - 2.6 * s} L${c + 0.2 * s} ${m - 1.4 * s} L${c + 1.6 * s} ${m - 2.6 * s} L${c + 3 * s} ${m - 1.4 * s} L${c + 4 * s} ${m - 2.4 * s}`, w.c, { w: 0.5, seed: 'zz' + x }));
  } else {
    it.push(thing(circleD(c, m, 5.2 * s), { fill: '#FFFFFF', ink: w.ink, w: 0.5, amp: 0.06, seed: 'ball' + x }));
    it.push(blob(`M${c} ${m - 2 * s} L${c + 1.9 * s} ${m - 0.6 * s} L${c + 1.2 * s} ${m + 1.6 * s} L${c - 1.2 * s} ${m + 1.6 * s} L${c - 1.9 * s} ${m - 0.6 * s} Z`, w.ink, { seed: 'pent' + x }));
    it.push(stroke(`M${c} ${m - 2 * s} L${c} ${m - 5 * s} M${c + 1.9 * s} ${m - 0.6 * s} L${c + 4.8 * s} ${m - 1.6 * s} M${c + 1.2 * s} ${m + 1.6 * s} L${c + 2.8 * s} ${m + 4.2 * s} M${c - 1.2 * s} ${m + 1.6 * s} L${c - 2.8 * s} ${m + 4.2 * s} M${c - 1.9 * s} ${m - 0.6 * s} L${c - 4.8 * s} ${m - 1.6 * s}`, w.ink, { w: 0.4, seed: 'seams' + x }));
  }
}
/** Rounded 70s podium: veneer front, light strip, answer token, buzzer. */
function podium(x: number, top: number, bot: number, wd: number, tok: string, lit: boolean, w: World, seed: string): F3 {
  const hw = wd / 2;
  const body = `M${x - hw} ${top + 4} Q${x - hw} ${top} ${x - hw + 4} ${top} L${x + hw - 4} ${top} Q${x + hw} ${top} ${x + hw} ${top + 4} L${x + hw - 2} ${bot} L${x - hw + 2} ${bot} Z`;
  const parts: F3[] = [];
  parts.push(thing(body, { fill: '#9A6236', ink: w.ink, w: 0.8, amp: 0.25, mis: w.mis, seed: seed + 'b' }));
  for (let i = 0; i < 4; i++) { const xx = x - hw + 5 + i * ((wd - 10) / 3); parts.push(stroke(`M${xx} ${top + 9} L${xx + (i - 1.5) * 0.4} ${bot - 1}`, '#7A4A26', { w: 1.2, seed: seed + 'v' + i })); }
  // light strip: on (white) when answered
  parts.push(thing(rr(x - hw + 1.5, top + 2.5, wd - 3, 4, 1.6), { fill: lit ? '#FFFFFF' : '#C9CFE8', ink: w.ink, w: 0.5, amp: 0.12, seed: seed + 'ls' }));
  // the answer token badge (sun / wave / leaf), shape + colour as in GAME-TRIVIA
  const by = top + (bot - top) * 0.62, br_ = Math.min(6, (bot - top) * 0.28);
  parts.push(thing(circleD(x, by, br_), { fill: '#1B2358', ink: w.ink, w: 0.5, amp: 0.1, seed: seed + 'tb' }));
  if (tok === 'sun') {
    parts.push(blob(circleD(x, by, br_ * 0.42), '#FFC94D', { seed: seed + 'sun' }));
    for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; parts.push(stroke(`M${r2(x + Math.cos(a) * br_ * 0.58)} ${r2(by + Math.sin(a) * br_ * 0.58)} L${r2(x + Math.cos(a) * br_ * 0.82)} ${r2(by + Math.sin(a) * br_ * 0.82)}`, '#FFC94D', { w: 0.6, seed: seed + 'ray' + i })); }
  } else if (tok === 'wave') {
    parts.push(stroke(`M${x - br_ * 0.7} ${by - br_ * 0.15} Q${x - br_ * 0.35} ${by - br_ * 0.55} ${x} ${by - br_ * 0.15} Q${x + br_ * 0.35} ${by + br_ * 0.25} ${x + br_ * 0.7} ${by - br_ * 0.15}`, '#478CFF', { w: 1.0, seed: seed + 'w1' }));
    parts.push(stroke(`M${x - br_ * 0.6} ${by + br_ * 0.35} Q${x - br_ * 0.3} ${by} ${x} ${by + br_ * 0.35} Q${x + br_ * 0.3} ${by + br_ * 0.7} ${x + br_ * 0.6} ${by + br_ * 0.35}`, '#478CFF', { w: 0.8, seed: seed + 'w2' }));
  } else {
    parts.push(blob(`M${x - br_ * 0.55} ${by + br_ * 0.5} C${x - br_ * 0.6} ${by - br_ * 0.3} ${x} ${by - br_ * 0.7} ${x + br_ * 0.6} ${by - br_ * 0.55} C${x + br_ * 0.6} ${by + br_ * 0.2} ${x} ${by + br_ * 0.6} ${x - br_ * 0.55} ${by + br_ * 0.5} Z`, '#1FA88A', { seed: seed + 'leaf' }));
    parts.push(stroke(`M${x - br_ * 0.5} ${by + br_ * 0.45} L${x + br_ * 0.35} ${by - br_ * 0.35}`, '#0E6A55', { w: 0.4, seed: seed + 'vein' }));
  }
  // buzzer
  parts.push(thing(`M${x + hw - 9} ${top} C${x + hw - 9} ${top - 3.4} ${x + hw - 3} ${top - 3.4} ${x + hw - 3} ${top} Z`, { fill: w.c, ink: w.ink, w: 0.5, amp: 0.05, seed: seed + 'bzz' }));
  parts.push(stroke(`M${x + hw - 7.6} ${top - 1.4} Q${x + hw - 6.8} ${top - 2.4} ${x + hw - 5.8} ${top - 2.2}`, '#FFB0B2', { w: 0.45, seed: seed + 'bzh' }));
  parts.push(stroke(`M${x - hw + 3} ${top + 8} Q${x - hw + 2.4} ${top + 16} ${x - hw + 3.6} ${bot - 2}`, '#C98A55', { w: 0.6, op: 0.8, seed: seed + 'hl' }));
  return cat(...parts);
}
/** Cut-paper confetti in the cheering player's own colour and shape (pluses) + gold. */
function confetti(x: number, y: number, sc: number, w: World, seed: string): F3 {
  const r = rng(hashSeed(seed)); const out: F3[] = [];
  const cols = ['#7BFFF4', '#FFD84D', '#7BFFF4', w.paper];
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI * 0.95 + (i / 9) * Math.PI * 0.9, d = (5.5 + r() * 3) * sc;
    const px = x + Math.cos(a) * d * 1.5, py = y + Math.sin(a) * d * 0.45 + 9 * sc, rot = r() * 90, s = (1.0 + r() * 0.5) * sc * 0.85;
    const plus = `M${-0.6 * s} ${-1.8 * s}h${1.2 * s}v${1.2 * s}h${1.2 * s}v${1.2 * s}h${-1.2 * s}v${1.2 * s}h${-1.2 * s}v${-1.2 * s}h${-1.2 * s}v${-1.2 * s}h${1.2 * s}z`;
    const strip = `M${-1.8 * s} ${-0.6 * s}L${1.8 * s} ${-0.8 * s}L${1.9 * s} ${0.5 * s}L${-1.7 * s} ${0.7 * s}Z`;
    out.push(g(`transform="translate(${r2(px)} ${r2(py)}) rotate(${r2(rot)})"`, thing(i % 2 ? plus : strip, { fill: cols[i % 4], ink: w.ink, w: 0.3, amp: 0.03, seed: seed + i })));
  }
  return cat(...out);
}

export const SCENES: Record<string, (L: Layout) => Scene> = { mishana, bluff, likely, trivia };
