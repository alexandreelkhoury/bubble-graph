// build.ts — writes the key-art SVGs (3 boil frames + an animated SVG) and PNG jobs.
// usage: tsx src/build.ts [gameId ...]
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { SCENES, type Layout, type Item } from './scenes.ts';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const OUT = path.join(ROOT, 'out');
fs.mkdirSync(OUT, { recursive: true });
const grain = fs.readFileSync(path.join(ROOT, '../tech/handmade/out/grain-128.png')).toString('base64');
const only = process.argv.slice(2).filter((a) => !a.startsWith('-'));
const noShots = process.argv.includes('--no-shots');

const PX: Record<Layout, [number, number]> = { wide: [960, 540], square: [540, 540] };
const jobs: any[] = [];

for (const [id, fn] of Object.entries(SCENES)) {
  if (only.length && !only.includes(id)) continue;
  for (const L of ['wide', 'square'] as Layout[]) {
    const sc = fn(L);
    const [pw, ph] = PX[L];
    const gdef = `<pattern id="grain" width="16" height="16" patternUnits="userSpaceOnUse"><image href="data:image/png;base64,${grain}" width="16" height="16"/></pattern>`;
    const grainLayer = `<rect width="${sc.w}" height="${sc.h}" fill="url(#grain)" opacity="0.5" style="mix-blend-mode:soft-light"/>`;
    const head = (extra = '') => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${sc.w} ${sc.h}" width="${pw}" height="${ph}">${extra}<defs>${sc.defs}${gdef}</defs>`;
    // static frame files
    for (let f = 0; f < 3; f++) {
      let s = head();
      sc.items.forEach((itm: Item, i) => { s += typeof itm === 'string' ? itm : itm[(f + i) % 3]; });
      s += grainLayer + '</svg>';
      fs.writeFileSync(path.join(OUT, `${id}_${L}_${'ABC'[f]}.svg`), s);
    }
    // animated: every boiling item carries its three drawings; one shared clock (8 fps), seeded start offsets
    const css = `<style>.f{opacity:0;animation:boil .375s steps(1,end) infinite}.f1{animation-delay:-.25s}.f2{animation-delay:-.125s}@keyframes boil{0%{opacity:1}33.333%{opacity:0}100%{opacity:0}}@media (prefers-reduced-motion:reduce){.f{animation:none}.f0{opacity:1}}</style>`;
    let a = head(css);
    sc.items.forEach((itm: Item, i) => {
      if (typeof itm === 'string') { a += itm; return; }
      if (itm[0] === itm[1] && itm[1] === itm[2]) { a += itm[0]; return; }
      for (let f = 0; f < 3; f++) a += `<g class="f f${(f + i) % 3}">${itm[f]}</g>`;
    });
    a += grainLayer + '</svg>';
    fs.writeFileSync(path.join(OUT, `${id}_${L}.svg`), a);
    for (const f of ['A', 'B', 'C']) {
      const html = path.join(OUT, `.${id}_${L}_${f}.html`);
      fs.writeFileSync(html, `<html><body style="margin:0;background:#000"><img src="${id}_${L}_${f}.svg" style="width:${pw}px;height:${ph}px;display:block"></body></html>`);
      if (f === 'A') {
        jobs.push({ src: html, out: path.join(OUT, `${id}_${L}@1x.png`), w: pw, h: ph, scale: 1 });
        jobs.push({ src: html, out: path.join(OUT, `${id}_${L}@2x.png`), w: pw, h: ph, scale: 2 });
      } else jobs.push({ src: html, out: path.join(OUT, `.${id}_${L}_${f}@1x.png`), w: pw, h: ph, scale: 1 });
    }
    const kb = (fs.statSync(path.join(OUT, `${id}_${L}.svg`)).size / 1024).toFixed(0);
    console.log(id, L, kb + ' KB animated');
  }
}
if (!noShots && jobs.length) execFileSync('node', [path.join(ROOT, 'src/shot.mjs'), JSON.stringify(jobs)], { stdio: 'inherit' });
