// titles.ts — one lettering material per world (ART-DIRECTION §7, DESIGN-JAMAA §1.6).
// Mish Ana!  : sign-paint on plaster (flat brush, one magenta shade, a couple of drips)
// Bluff!     : bent neon tube on a board (monoline glass, clips, dark blockout ends)
// Most Likely: gold leaf on glass (burnished leaf squares, dark outline, ink shadow — no orange drop)
// Trivia     : cut felt letters (fuzzy edge, fibre speckle, depth ≤ 4 % of the cap height)
// Each lockup also carries ONE ornament drawn in the same material, sitting between the two scripts.
import { type F3, type World, brush, cat, stroke, blob, thing, samplePath, rng, hashSeed, r2, uid, circleD } from './lib.ts';

const LAT = { nib: 30, wMax: 2.95, wMin: 0.7, amp: 0.1 };
const AR = { nib: 70, wMax: 2.5, wMin: 0.75, amp: 0.1 };
const dOf = (strokes: string[], o: any, f: number) => strokes.map((s) => brush(s, o, f)).join('');
const F = [0, 1, 2];

/** Gold leaf: ink shadow, dark-gold outline, leaf in burnished squares with seams, a few paper ticks. */
export function goldLeaf(strokes: string[], k: number, w: World, arabic: boolean, seed: string, defs: string[], cap: number): F3 {
  const B = arabic ? AR : LAT;
  const r = rng(hashSeed(seed));
  // bbox of the centrelines, for the leaf grid
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const s of strokes) for (const sub of samplePath(s, 1)) for (const p of sub) { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }
  x0 -= 4; y0 -= 4; x1 += 4; y1 += 4;
  // leaf squares, laid slightly crooked (a gilder lays them by hand), two tones of gold
  const sq = cap * 0.5; let lightSq = '', seams = '';
  for (let yy = y0, row = 0; yy < y1; yy += sq, row++) for (let xx = x0 - (row % 2) * sq * 0.4; xx < x1; xx += sq) {
    const j = () => (r() - 0.5) * sq * 0.12;
    const q = `M${r2(xx + j())} ${r2(yy + j())}L${r2(xx + sq + j())} ${r2(yy + j())}L${r2(xx + sq + j())} ${r2(yy + sq + j())}L${r2(xx + j())} ${r2(yy + sq + j())}Z`;
    if (r() < 0.45) lightSq += q;
    seams += `M${r2(xx)} ${r2(yy + sq * (0.98 + (r() - 0.5) * 0.06))}L${r2(xx + sq)} ${r2(yy + sq * (0.98 + (r() - 0.5) * 0.06))}`;
  }
  return F.map((f) => {
    const id = uid('gl');
    const body = dOf(strokes, { ...B, seed, k }, f);
    const key = dOf(strokes, { ...B, seed: seed + 'k', k, add: 1.25 }, f);
    defs.push(`<clipPath id="${id}"><path d="${body}"/></clipPath>`);
    return `<g transform="translate(${r2(0.55 * k)} ${r2(0.75 * k)})" opacity="0.75"><path d="${key}" fill="${w.ink}"/></g>` +
      `<path d="${key}" fill="#4A2A06"/>` +
      `<path d="${body}" fill="#E7AE36"/>` +
      `<g clip-path="url(#${id})"><path d="${lightSq}" fill="#FFD465" opacity="0.5"/><path d="${seams}" stroke="#A86F12" stroke-width="${r2(0.16 * k)}" fill="none" opacity="0.7"/>` +
      // bottom stamped edge: the lower third a step darker
      `<path d="M${r2(x0)} ${r2(y1 - (y1 - y0) * 0.22)}L${r2(x1)} ${r2(y1 - (y1 - y0) * 0.25)}L${r2(x1)} ${r2(y1)}L${r2(x0)} ${r2(y1)}Z" fill="#B87A12" opacity="0.35" style="mix-blend-mode:multiply"/></g>`;
  });
}
/** paper burnish ticks on the gold (top-start of a few letters) */
export function goldTicks(strokes: string[], w: World, seed: string, every = 3): F3 {
  const out: F3[] = [];
  strokes.forEach((s, i) => {
    if (i % every) return;
    const pts = samplePath(s, 0.5)[0]; if (!pts || pts.length < 4) return;
    const p = pts[Math.floor(pts.length * 0.25)];
    out.push(stroke(`M${r2(p.x - 0.5)} ${r2(p.y + 0.6)} L${r2(p.x + 0.2)} ${r2(p.y - 0.6)}`, '#FFF4C9', { w: 0.55, op: 0.9, seed: seed + i }));
  });
  return cat(...out);
}

/** Small 5-point award star in gold leaf, the Most Likely ornament (it is the rosette's star). */
export function goldStar(x: number, y: number, R: number, w: World, seed: string): F3 {
  let d = '';
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * Math.PI) / 5, rr = i % 2 ? R * 0.46 : R; d += `${i ? 'L' : 'M'}${r2(x + Math.cos(a) * rr)} ${r2(y + Math.sin(a) * rr)}`; }
  d += 'Z';
  return cat(
    thing(d.replace(/(-?\d+\.?\d*) (-?\d+\.?\d*)/g, (_, a, b) => `${r2(+a + 0.6)} ${r2(+b + 0.8)}`), { fill: w.ink, fillOp: 0.75, noInk: true, amp: 0.1, seed: seed + 'sh' }),
    thing(d, { fill: '#E7AE36', ink: '#4A2A06', w: 0.7, amp: 0.12, seed }),
    blob(`M${r2(x - R * 0.15)} ${r2(y - R * 0.55)}L${r2(x + R * 0.12)} ${r2(y - R * 0.55)}L${r2(x + R * 0.05)} ${r2(y + R * 0.1)}L${r2(x - R * 0.2)} ${r2(y + R * 0.1)}Z`, '#FFD465', { seed: seed + 'l' }),
    stroke(`M${r2(x - R * 0.45)} ${r2(y - R * 0.1)} L${r2(x - R * 0.25)} ${r2(y - R * 0.38)}`, '#FFF4C9', { w: 0.5, op: 0.9, seed: seed + 't' }),
  );
}

/** Felt letters: depth ≤ 4 % of cap height, fuzzy cut edge, fibre speckle. */
export function felt(strokes: string[], k: number, w: World, arabic: boolean, seed: string, defs: string[], cap: number, fill = w.paper): F3 {
  // felt is cut, not brushed: a slimmer Arabic cut keeps the counters of ق and ة open
  const B = arabic ? { ...AR, wMax: 2.05, wMin: 0.6 } : LAT;
  const fid = uid('fz');
  defs.push(`<filter id="${fid}" x="-5%" y="-10%" width="110%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="1.4" numOctaves="2" seed="${hashSeed(seed) % 97}"/><feDisplacementMap in="SourceGraphic" scale="${r2(0.55)}" xChannelSelector="R" yChannelSelector="G"/></filter>`);
  const depth = cap * 0.04; // the only 3D lettering allowed, ≤ 4 %
  const r = rng(hashSeed(seed + 'fib'));
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const s of strokes) for (const sub of samplePath(s, 1)) for (const p of sub) { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }
  let fib = '';
  for (let i = 0; i < (x1 - x0) * (y1 - y0 + 6) * 0.9; i++) { const fx = x0 - 2 + r() * (x1 - x0 + 4), fy = y0 - 3 + r() * (y1 - y0 + 6), a = r() * Math.PI, l = 0.35 + r() * 0.4; fib += `M${r2(fx)} ${r2(fy)}l${r2(Math.cos(a) * l)} ${r2(Math.sin(a) * l)}`; }
  return F.map((f) => {
    const id = uid('fc');
    const body = dOf(strokes, { ...B, seed, k }, f);
    defs.push(`<clipPath id="${id}"><path d="${body}"/></clipPath>`);
    return `<g filter="url(#${fid})">` +
      `<g transform="translate(${r2(depth * 0.5)} ${r2(depth)})"><path d="${body}" fill="${w.ink}"/></g>` +
      `<g transform="translate(${r2(depth * 0.25)} ${r2(depth * 0.5)})"><path d="${body}" fill="${w.ink}" opacity="0.85"/></g>` +
      `<path d="${body}" fill="${fill}"/>` +
      `<g clip-path="url(#${id})"><path d="${fib}" stroke="${w.ink}" stroke-width="0.14" opacity="0.22" fill="none"/></g>` +
      `</g>`;
  });
}
/** Felt rule: a short scalloped strip of felt between the two lines (the Trivia ornament). */
export function feltRule(cx: number, y: number, wd: number, w: World, seed: string, defs: string[], color: string): F3 {
  let d = `M${r2(cx - wd / 2)} ${r2(y)}`;
  const n = 7;
  for (let i = 0; i < n; i++) { const xa = cx - wd / 2 + (wd * (i + 0.5)) / n, xb = cx - wd / 2 + (wd * (i + 1)) / n; d += ` Q${r2(xa)} ${r2(y + (i % 2 ? 1.6 : -1.6))} ${r2(xb)} ${r2(y)}`; }
  return felt([d], 1, w, false, seed, defs, 12, color);
}

/** Neon: tube clips (little screwed brackets) at the middle of every other stroke. */
export function neonClips(strokes: string[], seed: string, every = 2): F3 {
  const out: F3[] = [];
  strokes.forEach((s, i) => {
    if (i % every) return;
    const pts = samplePath(s, 0.4)[0]; if (!pts || pts.length < 6) return;
    const m = Math.floor(pts.length * 0.55), a = pts[m - 1], b = pts[m + 1];
    const ang = (Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI + 90;
    const p = pts[m];
    out.push(cat(`<g transform="translate(${r2(p.x)} ${r2(p.y)}) rotate(${r2(ang)})">`,
      stroke('M-1.5 0 L1.5 0', '#6B5A48', { w: 0.5, seed: seed + i, op: 0.85 }),
      `<circle cx="-1.6" cy="0" r="0.36" fill="#A89478"/><circle cx="1.6" cy="0" r="0.36" fill="#A89478"/></g>`));
  });
  return cat(...out);
}
/** The Bluff ornament: a moustache bent in neon tube (centrelines for neon()). */
export function neonMoustacheStrokes(cx: number, cy: number, s: number): string[] {
  const R = (u: number, v: number) => `${r2(cx + u * s)} ${r2(cy + v * s)}`;
  // handlebar: a dip at the philtrum, two swept lobes, each tip rolled up into a full curl
  return [-1, 1].map((d) => `M${R(0, -0.9)} C${R(d * 1.4, -2.4)} ${R(d * 3.8, -2.0)} ${R(d * 5.2, -0.2)} C${R(d * 6.4, 1.3)} ${R(d * 8.6, 1.5)} ${R(d * 9.4, -0.6)} C${R(d * 9.9, -2.2)} ${R(d * 8.5, -3.5)} ${R(d * 7.4, -2.6)} C${R(d * 6.8, -2.0)} ${R(d * 7.3, -1.2)} ${R(d * 8.0, -1.4)}`);
}

/** Sign-paint drips under a few letters (Mish Ana! is painted straight on the wall). */
export function drips(strokes: string[], color: string, seed: string, k: number): F3 {
  const r = rng(hashSeed(seed));
  const out: F3[] = [];
  strokes.forEach((s, i) => {
    if (r() > 0.22) return;
    const pts = samplePath(s, 0.5)[0]; if (!pts) return;
    let lo = pts[0]; for (const p of pts) if (p.y > lo.y) lo = p;
    const L = (1.6 + r() * 2.6) * k;
    out.push(stroke(`M${r2(lo.x)} ${r2(lo.y)} C${r2(lo.x + 0.1)} ${r2(lo.y + L * 0.4)} ${r2(lo.x - 0.1)} ${r2(lo.y + L * 0.7)} ${r2(lo.x)} ${r2(lo.y + L)}`, color, { w: 0.55 * k, seed: seed + i }));
    out.push(blob(circleD(lo.x, lo.y + L, 0.5 * k), color, { seed: seed + 'd' + i }));
  });
  return cat(...out);
}
/** The Mish Ana! ornament: a painted bang burst (three ticks and a dot), shared by both scripts. */
export function paintBurst(x: number, y: number, s: number, w: World, seed: string): F3 {
  return cat(
    stroke(`M${x - 3 * s} ${y + 1 * s} L${x - 5.6 * s} ${y - 1.6 * s}`, w.a, { w: 1.1 * s, seed: seed + 1 }),
    stroke(`M${x} ${y - 1 * s} L${x + 0.3 * s} ${y - 4.6 * s}`, w.a, { w: 1.2 * s, seed: seed + 2 }),
    stroke(`M${x + 3 * s} ${y + 1 * s} L${x + 5.8 * s} ${y - 1.4 * s}`, w.a, { w: 1.1 * s, seed: seed + 3 }),
    blob(circleD(x + 0.1 * s, y + 2.4 * s, 0.75 * s), w.a, { seed: seed + 4 }),
  );
}
