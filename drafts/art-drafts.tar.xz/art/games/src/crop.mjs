// usage: node src/crop.mjs in.png out.png x y w h [scale]  — crop/zoom via chromium
import { createRequire } from 'node:module';
const require = createRequire('/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/art/tools/package.json');
const { chromium } = require('playwright-core');
import path from 'node:path';
const [inp, out, x, y, w, h, s = '2'] = process.argv.slice(2);
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome' });
const p = await b.newPage({ viewport: { width: +w * +s, height: +h * +s } });
import fs from 'node:fs';
const hf = path.resolve('tmp/.crop.html');
fs.writeFileSync(hf, `<body style="margin:0;overflow:hidden"><div style="width:${+w * +s}px;height:${+h * +s}px;overflow:hidden;position:relative"><img src="file://${path.resolve(inp)}" style="position:absolute;left:${-x * s}px;top:${-y * s}px;transform-origin:0 0;transform:scale(${s});image-rendering:auto"></div></body>`);
await p.goto('file://' + hf);
await p.waitForTimeout(200);
await p.screenshot({ path: out });
await b.close();
