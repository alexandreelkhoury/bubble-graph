// lib.ts — drawing kit for the JAMAA game key art.
// Everything is hand-authored path data run through the seeded "hand"
// (../../tech/handmade/src/handmade.ts). Each drawing call returns F3: three
// boil frames (A, B, C) as SVG strings. Far layers pass boil:false.
import { handmade, handStroke, handBlob, parsePath, hashSeed, rng, polyToD, circleD, ellipseD } from '../../tech/handmade/src/handmade.ts';
import { SHAPES } from '../../tech/handmade/src/shapes.ts';
export { circleD, ellipseD, hashSeed, rng };

export const N = 3;
export type F3 = string[];
export const same = (s: string): F3 => [s, s, s];
export const cat = (...fs: (F3 | string)[]): F3 => [0, 1, 2].map((i) => fs.map((f) => (typeof f === 'string' ? f : f[i])).join(''));
export const g = (attrs: string, ...fs: (F3 | string)[]): F3 => cat(`<g ${attrs}>`, ...fs, '</g>');
let UID = 0;
export const uid = (p = 'c') => `${p}${(UID++).toString(36)}`;
export const r2 = (v: number) => Math.round(v * 100) / 100;

export type World = {
  id: string; ink: string; paper: string; a: string; b: string; c: string;
  deep: string; top: string; surface: string; elevated: string; accent: string; glow: string; signal?: string;
  mis: [number, number];
};

// ------------------------------------------------------------- things ----
export type ThingOpts = {
  seed?: string; fill?: string; ink?: string; w?: number; amp?: number; boil?: boolean;
  mis?: [number, number]; hatch?: boolean; hatchColor?: string; hatchOp?: number;
  rim?: string; rimW?: number; noInk?: boolean; fillOp?: number; pressure?: number;
  overshoot?: number; shade?: { x: number; y: number }; extra?: string; wave?: [number, number]; rot?: number;
};
/** A drawn object: misregistered flat fill + pressure ink ribbon (+ hatch, paper rim). */
export function thing(d: string, o: ThingOpts = {}): F3 {
  const vs = handmade(d, {
    seed: o.seed ?? 'x' + hashSeed(d), dp: 2, hatch: !!o.hatch,
    hand: { amp: o.amp ?? 0.3, waveMin: o.wave?.[0] ?? 5.5, waveMax: o.wave?.[1] ?? 16, rot: o.rot ?? 0.35, shift: 0.1 } as any,
    pen: { width: o.w ?? 0.6, pressure: o.pressure ?? 0.35, overshoot: o.overshoot ?? 1.6 } as any,
    shade: o.shade ?? { x: 0.55, y: 0.83 },
  });
  const mis = o.mis ?? [0, 0];
  return [0, 1, 2].map((i) => {
    const v = vs[o.boil === false ? 0 : i];
    let s = '';
    if (o.rim) s += `<path d="${v.paper}" fill="${o.rim}" stroke="${o.rim}" stroke-width="${o.rimW ?? 1.2}" stroke-linejoin="round"/>`;
    if (o.fill) {
      const fo = o.fillOp != null ? ` fill-opacity="${o.fillOp}"` : '';
      s += `<g transform="translate(${mis[0]} ${mis[1]})"><path d="${v.fill}" fill="${o.fill}"${fo}/>`;
      if (o.hatch && v.hatch) {
        const id = uid('h');
        s += `<clipPath id="${id}"><path d="${v.fill}"/></clipPath><path clip-path="url(#${id})" d="${v.hatch}" fill="${o.hatchColor ?? o.ink ?? '#000'}" opacity="${o.hatchOp ?? 0.22}"/>`;
      }
      s += `</g>`;
    }
    if (o.extra) s += o.extra;
    if (!o.noInk) s += `<path d="${v.ink}" fill="${o.ink ?? '#000'}"/>`;
    return s;
  });
}
/** Flat silhouette, no line (far layers). */
export function flat(d: string, color: string, o: { amp?: number; boil?: boolean; seed?: string; op?: number; blend?: string } = {}): F3 {
  const vs = handmade(d, { seed: o.seed ?? 'f' + hashSeed(d), dp: 2, hatch: false, fillAmp: 1, hand: { amp: o.amp ?? 0.35, waveMin: 5.5, waveMax: 16, rot: 0.2, shift: 0.05 } as any });
  const st = (o.op != null ? ` opacity="${o.op}"` : '') + (o.blend ? ` style="mix-blend-mode:${o.blend}"` : '');
  return [0, 1, 2].map((i) => `<path d="${vs[o.boil === true ? i : 0].fill}" fill="${color}"${st}/>`);
}
/** Open hand stroke (ribbon) — wires, cords, hatch marks, squiggles. */
export function stroke(d: string, color: string, o: { w?: number; amp?: number; boil?: boolean; seed?: string; op?: number } = {}): F3 {
  const vs = handStroke(d, { seed: o.seed ?? 's' + hashSeed(d), width: o.w ?? 0.5, dp: 2, hand: { amp: o.amp ?? 0.12, waveMin: 3, waveMax: 12, rot: 0, shift: 0.03 } as any });
  const st = o.op != null ? ` opacity="${o.op}"` : '';
  return [0, 1, 2].map((i) => `<path d="${vs[o.boil === false ? 0 : i]}" fill="${color}"${st}/>`);
}
export function blob(d: string, color: string, o: { amp?: number; boil?: boolean; seed?: string; op?: number; blend?: string } = {}): F3 {
  const vs = handBlob(d, { seed: o.seed ?? 'b' + hashSeed(d), dp: 2, hand: { amp: o.amp ?? 0.07, waveMin: 1, waveMax: 3, rot: 2, shift: 0.04 } as any });
  const st = (o.op != null ? ` opacity="${o.op}"` : '') + (o.blend ? ` style="mix-blend-mode:${o.blend}"` : '');
  return [0, 1, 2].map((i) => `<path d="${vs[o.boil === false ? 0 : i]}" fill="${color}"${st}/>`);
}
/** Ink shadow shape, multiply (hand-cut, not soft). */
export const shadow = (d: string, w: World, op = 0.28, o: { amp?: number } = {}) => flat(d, w.ink, { op, blend: 'multiply', amp: o.amp ?? 0.25 });

// ----------------------------------------------------------- geometry ----
type P = { x: number; y: number };
function bez(c: number[], t: number): P {
  const u = 1 - t;
  return { x: u * u * u * c[0] + 3 * u * u * t * c[2] + 3 * u * t * t * c[4] + t * t * t * c[6], y: u * u * u * c[1] + 3 * u * u * t * c[3] + 3 * u * t * t * c[5] + t * t * t * c[7] };
}
export function samplePath(d: string, step = 0.25): P[][] {
  return parsePath(d).map((s) => {
    const pts: P[] = [];
    for (const c of s.segs) {
      const L = Math.hypot(c[6] - c[0], c[7] - c[1]) + Math.hypot(c[2] - c[0], c[3] - c[1]) * 0.3 + Math.hypot(c[6] - c[4], c[7] - c[5]) * 0.3;
      const k = Math.max(2, Math.ceil(L / step));
      for (let j = pts.length ? 1 : 0; j <= k; j++) pts.push(bez(c as any, j / k));
    }
    return pts;
  });
}
export function bboxOf(d: string) {
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const sub of samplePath(d, 0.5)) for (const p of sub) { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }
  return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0 };
}
/** x extents of a closed path at height y */
function spanAt(d: string, y: number) {
  let lo = 1e9, hi = -1e9;
  for (const sub of samplePath(d, 0.2)) for (let i = 0; i < sub.length; i++) {
    const a = sub[i], b = sub[(i + 1) % sub.length];
    if ((a.y - y) * (b.y - y) <= 0 && a.y !== b.y) { const x = a.x + ((y - a.y) / (b.y - a.y)) * (b.x - a.x); lo = Math.min(lo, x); hi = Math.max(hi, x); }
  }
  return { lo, hi };
}

// ---------------------------------------------------------- characters ----
export type Expr = 'idle' | 'shock' | 'point' | 'smug' | 'think' | 'shy' | 'cheer' | 'happy' | 'whisper' | 'side';
export type CharOpts = {
  x: number; y: number; s: number; expr: Expr; world: World;
  lean?: number; squash?: number; look?: [number, number]; dir?: 1 | -1; nub?: 1 | -1; nubLen?: number;
  prop?: 'moustache' | 'rosette' | 'none'; seed?: string; faceScale?: number; faceDy?: number; groundShadow?: boolean; brows?: boolean; cheeks?: boolean;
  /** shade shape opacity (default 0.2) and hatch opacity (default 0.18; 0 = none). Light bodies get no hatch: on them it reads as gloss. */
  shadeOp?: number; hatchOp?: number;
};
export const shapeById = (id: string) => SHAPES.find((s) => s.id === id)!;

/** One shilleh in its key pose. (x, y) = bottom centre in scene units; s = scale of the 24 box. */
export function character(shapeId: string, o: CharOpts): F3 {
  const sh = shapeById(shapeId), w = o.world;
  const seed = o.seed ?? `${w.id}:${shapeId}:${o.expr}`;
  const bb = bboxOf(sh.d);
  const sq = o.squash ?? 1, sx = 1 / Math.sqrt(sq);
  const glyph = sh.glyph === 'ink' ? '#120A1F' : '#FFF7EC';
  const dir = o.dir ?? 1;
  const layers: F3[] = [];
  // pointing nub, behind the body so the body line cuts it
  const LIGHT = ['plus', 'crescent', 'star', 'arch'].includes(shapeId);
  const shadeOp = o.shadeOp ?? (LIGHT ? 0 : 0.2), hatchOp = o.hatchOp ?? (LIGHT ? 0 : 0.18);
  const must = o.prop === 'moustache' ? moustache(sh, o, seed) : null;
  if (must) layers.push(must.back);
  if (o.nub) {
    const yA = bb.y0 + bb.h * 0.6, sp = spanAt(sh.d, yA);
    const L = o.nubLen ?? 6.5;
    const ax = o.nub > 0 ? sp.hi - 1.4 : sp.lo + 1.4, k = o.nub;
    const nd = `M${ax - k * 1.5} ${yA - 1.7} C${ax + k * 2} ${yA - 2.0} ${ax + k * (L - 1.6)} ${yA - 2.1} ${ax + k * L} ${yA - 1.5} C${ax + k * (L + 0.9)} ${yA - 1.1} ${ax + k * (L + 0.7)} ${yA + 0.3} ${ax + k * (L - 0.3)} ${yA + 0.35} C${ax + k * 3} ${yA + 0.7} ${ax + k * 1} ${yA + 1.6} ${ax - k * 1.5} ${yA + 1.9} Z`;
    layers.push(thing(nd, { seed: seed + 'nub', fill: sh.color, ink: w.ink, w: 0.8, amp: 0.12, mis: [-0.3, 0.3], rim: w.paper, rimW: 1.6 }));
  }
  // body
  const vs = handmade(sh.d, { seed, dp: 2, hatch: true, hand: { amp: 0.24 } as any, pen: { width: 0.95 } as any });
  const body: F3 = [0, 1, 2].map((i) => {
    const v = vs[i], id = uid('b');
    const shadeC = `M${bb.x0 + bb.w * 0.95} ${bb.y0 - 4} C${bb.x1 + 6} ${bb.y0 + bb.h * 0.5} ${bb.x0 + bb.w * 0.7} ${bb.y1 + 4} ${bb.x0 - 3} ${bb.y1 + 1.5} L${bb.x0 - 3} ${bb.y1 - bb.h * 0.15} C${bb.x0 + bb.w * 0.5} ${bb.y1 - bb.h * 0.12} ${bb.x0 + bb.w * 0.82} ${bb.y0 + bb.h * 0.55} ${bb.x0 + bb.w * 0.72} ${bb.y0 - 4} Z`;
    const hx = bb.x0 + bb.w * 0.28, hy = bb.y0 + bb.h * 0.22;
    return `<path d="${v.paper}" fill="${w.paper}" stroke="${w.paper}" stroke-width="${r2(Math.min(1.9, 2.4 / o.s))}" stroke-linejoin="round"/>` +
      `<clipPath id="${id}"><path d="${v.fill}"/></clipPath>` +
      `<g transform="translate(${r2(-0.38 / o.s)} ${r2(0.34 / o.s)})"><path d="${v.fill}" fill="${sh.color}"/>` +
      (shapeId === 'diamond'
        ? `<g clip-path="url(#${id})"><path d="M2 12 L12 22 L22 12 L19.4 12.2 C17 15.2 14.6 17.6 12.2 19.2 C9 17.4 6.2 14.8 4.4 12.4 Z" fill="${w.ink}" opacity="${r2(shadeOp * 1.2)}" style="mix-blend-mode:multiply"/><path d="M14.6 4.2 L17.2 6.8 M16.2 3.9 L18.4 6.1" stroke="${w.ink}" stroke-width="0.35" stroke-linecap="round" opacity="0" /></g></g>`
        : `<g clip-path="url(#${id})"><path d="${shadeC}" fill="${w.ink}" opacity="${shadeOp}" style="mix-blend-mode:multiply"/>${hatchOp > 0 ? `<path d="${v.hatch}" fill="${w.ink}" opacity="${hatchOp}"/>` : ''}</g></g>`) +
      `<path d="${v.ink}" fill="${w.ink}"/>`;
  });
  layers.push(body);
  // highlight ticks on the top-start shoulder (not on the near-white bodies)
  if (!['star', 'plus', 'crescent'].includes(shapeId)) {
    const hx = bb.x0 + bb.w * 0.27, hy = bb.y0 + bb.h * 0.2 + (shapeId === 'triangle' || shapeId === 'drop' ? bb.h * 0.25 : 0);
    layers.push(stroke(`M${hx} ${hy + 2.2} Q${hx + 0.2} ${hy + 0.6} ${hx + 1.5} ${hy}`, w.paper, { w: 0.75, seed: seed + 'hl1', op: 0.7 }));
    layers.push(stroke(`M${hx + 0.7} ${hy + 3.6} L${hx + 0.95} ${hy + 3.0}`, w.paper, { w: 0.6, seed: seed + 'hl2', op: 0.7 }));
  }
  layers.push(face(sh, o, glyph, seed));
  if (must) layers.push(must.front);
  if (o.prop === 'rosette') layers.push(rosette(sh, o, seed));
  const lean = o.lean ?? 0;
  const cx = (bb.x0 + bb.x1) / 2;
  const tf = `translate(${r2(o.x)} ${r2(o.y)}) rotate(${lean}) scale(${r2(o.s * sx)} ${r2(o.s * sq)}) translate(${r2(-cx)} ${r2(-bb.y1 - 0.4)})`;
  const out: F3[] = [];
  if (o.groundShadow !== false) {
    const gw = bb.w * 0.42 * o.s, gh = 1.3 * o.s;
    out.push(flat(`M${o.x - gw} ${o.y + 0.3} C${o.x - gw} ${o.y - gh} ${o.x + gw * 1.05} ${o.y - gh * 0.8} ${o.x + gw * 1.05} ${o.y + 0.4} C${o.x + gw} ${o.y + gh * 1.1} ${o.x - gw * 0.9} ${o.y + gh} ${o.x - gw} ${o.y + 0.3} Z`, w.ink, { op: 0.32, blend: 'multiply', seed: seed + 'gs' }));
  }
  out.push(g(`transform="${tf}"`, ...layers));
  return cat(...out);
}

function face(sh: ReturnType<typeof shapeById>, o: CharOpts, glyph: string, seed: string): F3 {
  const fs = o.faceScale ?? ({ star: 1.3, bolt: 1.3, plus: 1.2, crescent: 1.15 } as any)[sh.id] ?? 1.1;
  const f0 = sh.face, f = { x: f0.x + (f0.w * (1 - fs)) / 2, y: f0.y + (f0.h * (1 - fs)) / 2 + (o.faceDy ?? 0), w: f0.w * fs, h: f0.h * fs };
  const k = f.w / 12, dir = o.dir ?? 1, w = o.world;
  const lx = o.look?.[0] ?? 0, ly = o.look?.[1] ?? 0;
  const mx = (u: number) => 6 + (u - 6) * dir; // mirror in face space
  const X = (u: number) => r2(f.x + mx(u) * k), Y = (v: number) => r2(f.y + v * k);
  const parts: F3[] = [];
  const eyeE = (cx: number, cy: number, rx: number, ry: number) => `M${X(cx) - rx * k} ${Y(cy)}a${rx * k} ${ry * k} 0 1 0 ${2 * rx * k} 0a${rx * k} ${ry * k} 0 1 0 ${-2 * rx * k} 0z`;
  const sw = (wd: number) => wd * k;
  const hl = (cx: number, cy: number) => blob(circleD(X(cx + 0.35 * dir), Y(cy - 0.45), 0.36 * k), w.paper, { seed: seed + cx + 'hl' });
  const E = o.expr;
  const e1 = 3.8 + lx, e2 = 8.2 + lx, ey = 3.6 + ly;
  const pushEyes = (sc1 = 1, sc2 = 0.95, hi = true) => {
    // one eye a hair higher and smaller: a hand draws them
    parts.push(blob(eyeE(e1, ey, 1.1 * sc1, 1.45 * sc1) + eyeE(e2, ey - 0.12, 1.1 * sc2, 1.45 * sc2), glyph, { seed: seed + 'eyes' }));
    if (hi && glyph !== '#FFF7EC') { parts.push(hl(e1, ey)); parts.push(hl(e2, ey - 0.12)); }
  };
  const mouth = (d: string, wd = 0.85) => parts.push(stroke(d, glyph, { w: sw(wd), amp: 0.05, seed: seed + 'm' + E }));
  const filled = (d: string) => parts.push(blob(d, glyph, { seed: seed + 'fm' + E, amp: 0.05 }));
  const brow = (x1: number, y1: number, x2: number, y2: number) => parts.push(stroke(`M${X(x1)} ${Y(y1)} Q${X((x1 + x2) / 2)} ${Y(Math.min(y1, y2) - 0.35)} ${X(x2)} ${Y(y2)}`, glyph, { w: sw(0.75), amp: 0.04, seed: seed + 'br' + x1 }));
  const cheeks = (c = '#FF96C5', op = 0.6) => {
    for (const cx of [2.0, 10.0]) parts.push(stroke(`M${X(cx - 0.9)} ${Y(6.3)} L${X(cx - 0.4)} ${Y(5.4)} M${X(cx - 0.1)} ${Y(6.4)} L${X(cx + 0.4)} ${Y(5.5)} M${X(cx + 0.7)} ${Y(6.4)} L${X(cx + 1.1)} ${Y(5.7)}`, c, { w: sw(0.45), op, seed: seed + 'ck' + cx }));
  };
  switch (E) {
    case 'idle': pushEyes(); mouth(`M${X(4.4)} ${Y(6.6)} Q${X(6)} ${Y(7.6)} ${X(7.6)} ${Y(6.6)}`); break;
    case 'happy': {
      for (const cx of [3.8, 8.2]) mouth(`M${X(cx - 1.1)} ${Y(4.2)} Q${X(cx)} ${Y(2.4)} ${X(cx + 1.1)} ${Y(4.2)}`, 0.8);
      filled(`M${X(4.2)} ${Y(6.0)} L${X(7.8)} ${Y(6.0)} Q${X(7.6)} ${Y(8.1)} ${X(6)} ${Y(8.1)} Q${X(4.4)} ${Y(8.1)} ${X(4.2)} ${Y(6.0)} Z`);
      break;
    }
    case 'shock': {
      const whites = eyeE(3.6, 3.5, 1.55, 1.6) + eyeE(8.4, 3.4, 1.45, 1.5);
      parts.push(blob(whites, w.paper, { seed: seed + 'wh' }));
      parts.push(stroke(`M${X(3.6) - 1.55 * k} ${Y(3.5)}a${1.55 * k} ${1.6 * k} 0 1 0 ${3.1 * k} 0a${1.55 * k} ${1.6 * k} 0 1 0 ${-3.1 * k} 0`, glyph, { w: sw(0.5), seed: seed + 'wo1' }));
      parts.push(stroke(`M${X(8.4) - 1.45 * k} ${Y(3.4)}a${1.45 * k} ${1.5 * k} 0 1 0 ${2.9 * k} 0a${1.45 * k} ${1.5 * k} 0 1 0 ${-2.9 * k} 0`, glyph, { w: sw(0.5), seed: seed + 'wo2' }));
      parts.push(blob(circleD(X(3.6 + lx * 0.6), Y(3.6 + ly * 0.6), 0.5 * k) + circleD(X(8.4 + lx * 0.6), Y(3.5 + ly * 0.6), 0.48 * k), '#120A1F', { seed: seed + 'pu' }));
      brow(2.4, 1.0, 4.8, 0.6); brow(7.2, 0.5, 9.6, 0.9);
      filled(`M${X(6) - 0.75 * k} ${Y(7.0)}a${0.75 * k} ${0.95 * k} 0 1 0 ${1.5 * k} 0a${0.75 * k} ${0.95 * k} 0 1 0 ${-1.5 * k} 0z`);
      break;
    }
    case 'point': {
      pushEyes();
      filled(`M${X(4.7)} ${Y(6.4)} L${X(7.5)} ${Y(6.3)} Q${X(7.2)} ${Y(7.6)} ${X(6.1)} ${Y(7.6)} Q${X(4.9)} ${Y(7.6)} ${X(4.7)} ${Y(6.4)} Z`);
      if (o.brows) { brow(2.6, 1.6, 4.8, 2.0); brow(7.2, 2.0, 9.4, 1.4); }
      break;
    }
    case 'smug': {
      // half-lidded: ellipse with the top cut flat
      const lid = (cx: number, cy: number, rx: number, ry: number) => {
        const lyv = cy - ry * 0.05, dx = rx * Math.sqrt(1 - ((lyv - cy) / ry) ** 2);
        return `M${X(cx - dx * dir) } ${Y(lyv)} L${X(cx + dx * dir)} ${Y(lyv)} A${rx * k} ${ry * k} 0 1 ${dir > 0 ? 1 : 0} ${X(cx - dx * dir)} ${Y(lyv)} Z`;
      };
      parts.push(blob(lid(3.8 + lx, 3.8, 1.15, 1.45) + lid(8.2 + lx, 3.65, 1.1, 1.4), glyph, { seed: seed + 'lids' }));
      parts.push(stroke(`M${X(2.5)} ${Y(3.55)} L${X(5.1)} ${Y(3.7)} M${X(6.9)} ${Y(3.45)} L${X(9.5)} ${Y(3.5)}`, glyph, { w: sw(0.6), seed: seed + 'lidl' }));
      parts.push(stroke(`M${X(2.5)} ${Y(1.5)} Q${X(3.7)} ${Y(0.9)} ${X(5.0)} ${Y(1.4)} M${X(6.9)} ${Y(1.0)} Q${X(8.2)} ${Y(0.1)} ${X(9.6)} ${Y(-0.2)}`, glyph, { w: sw(0.5), amp: 0.04, seed: seed + 'sbr' }));
      { const md = o.prop === 'moustache' ? 1.5 : 0; mouth(`M${X(4.6)} ${Y(6.9 + md)} Q${X(6.8)} ${Y(7.6 + md)} ${X(8.0)} ${Y(6.1 + md)}`, 0.9); }
      break;
    }
    case 'think': {
      parts.push(blob(eyeE(3.8 + 0.9, 3.0, 1.05, 1.4) + eyeE(8.2 + 0.9, 2.85, 1.0, 1.35), glyph, { seed: seed + 'eyes' }));
      if (glyph !== '#FFF7EC') { parts.push(hl(4.7, 3.0)); parts.push(hl(9.1, 2.85)); }
      brow(2.9, 0.9, 5.0, 1.1); brow(7.8, 0.2, 10.0, 0.0);
      mouth(`M${X(5.0)} ${Y(6.9)} Q${X(6.2)} ${Y(6.6)} ${X(7.6)} ${Y(6.8)}`, 0.85);
      break;
    }
    case 'shy': {
      parts.push(blob(eyeE(3.8, 4.4, 1.0, 1.25) + eyeE(8.2, 4.3, 0.95, 1.2), glyph, { seed: seed + 'eyes' }));
      cheeks(sh.color === '#FF96C5' ? '#D63A6E' : '#FF96C5', sh.color === '#FF96C5' ? 0.8 : 0.6);
      mouth(`M${X(5.2)} ${Y(7.0)} Q${X(6)} ${Y(7.6)} ${X(6.8)} ${Y(7.0)}`, 0.75);
      break;
    }
    case 'cheer': {
      const star = (cx: number, cy: number, s: number) => `M${X(cx)} ${Y(cy - s)} Q${X(cx + 0.25 * s * dir)} ${Y(cy - 0.25 * s)} ${X(cx + s * dir)} ${Y(cy)} Q${X(cx + 0.25 * s * dir)} ${Y(cy + 0.25 * s)} ${X(cx)} ${Y(cy + s)} Q${X(cx - 0.25 * s * dir)} ${Y(cy + 0.25 * s)} ${X(cx - s * dir)} ${Y(cy)} Q${X(cx - 0.25 * s * dir)} ${Y(cy - 0.25 * s)} ${X(cx)} ${Y(cy - s)} Z`;
      filled(star(3.7, 3.4, 1.75) + star(8.3, 3.25, 1.65));
      parts.push(blob(`M${X(3.6)} ${Y(5.7)} L${X(8.4)} ${Y(5.6)} Q${X(8.2)} ${Y(8.7)} ${X(6)} ${Y(8.7)} Q${X(3.8)} ${Y(8.7)} ${X(3.6)} ${Y(5.7)} Z`, glyph, { seed: seed + 'cm' }));
      parts.push(blob(`M${X(4.8)} ${Y(8.1)} Q${X(6)} ${Y(7.1)} ${X(7.2)} ${Y(8.1)} Q${X(6)} ${Y(8.6)} ${X(4.8)} ${Y(8.1)} Z`, '#FF7A8A', { seed: seed + 'tg' }));
      break;
    }
    case 'whisper': {
      parts.push(blob(eyeE(3.8 + lx, 3.9, 1.05, 1.0) + eyeE(8.2 + lx, 3.8, 1.0, 0.95), glyph, { seed: seed + 'eyes' }));
      brow(2.7, 2.0, 4.9, 2.4); brow(7.1, 2.3, 9.3, 1.8);
      filled(`M${X(7.6) - 0.5 * k} ${Y(6.9)}a${0.5 * k} ${0.55 * k} 0 1 0 ${1.0 * k} 0a${0.5 * k} ${0.55 * k} 0 1 0 ${-1.0 * k} 0z`);
      break;
    }
    case 'side': {
      pushEyes(1, 0.95);
      mouth(`M${X(4.8)} ${Y(6.9)} Q${X(6.4)} ${Y(7.2)} ${X(7.8)} ${Y(6.5)}`, 0.8);
      brow(7.2, 1.6, 9.4, 1.2);
      break;
    }
  }
  return cat(...parts);
}

function moustache(sh: ReturnType<typeof shapeById>, o: CharOpts, seed: string): { back: F3; front: F3 } {
  // The fake moustache on a stick (DESIGN-JAMAA §4.5). It is worn ABOVE the mouth, like a real
  // moustache; the stick leaves from its outer tip and runs down and away to a hand nub that
  // pokes out of the body at chin level. Nothing points at the mouth (no pipe, no cigarette read).
  const w = o.world;
  const fs = o.faceScale ?? 1.1, f0 = sh.face;
  const f = { x: f0.x + (f0.w * (1 - fs)) / 2, y: f0.y + (f0.h * (1 - fs)) / 2 + (o.faceDy ?? 0), w: f0.w * fs, h: f0.h * fs };
  const k = f.w / 12, dir = o.dir ?? 1;
  const FX = (u: number) => f.x + (6 + (u - 6) * dir) * k, FY = (v: number) => f.y + v * k;
  const cx = FX(6.0), cy = FY(6.0), s = k * 0.74;
  const m = moustacheShape(cx, cy, s);
  // hand at chin level, outside the body edge on the `dir` side
  const bb = bboxOf(sh.d);
  const chinY = FY(10.2);
  const sp = spanAt(sh.d, chinY);
  const edge = dir > 0 ? sp.hi : sp.lo;
  const hx = edge + dir * 4.2, hy = chinY + 1.2;
  const tipX = cx + dir * 4.4 * s, tipY = cy + 0.5 * s;
  // stick: a thin wooden dowel from the moustache tip, through the fist, a little beyond
  const ux = hx - tipX, uy = hy - tipY, ul = Math.hypot(ux, uy), nx = -uy / ul, ny = ux / ul, ex = hx + (ux / ul) * 3.2, ey = hy + (uy / ul) * 3.2, t = 0.42;
  const stick = `M${r2(tipX + nx * t)} ${r2(tipY + ny * t)} L${r2(ex + nx * t * 0.9)} ${r2(ey + ny * t * 0.9)} Q${r2(ex + (ux / ul) * 0.5)} ${r2(ey + (uy / ul) * 0.5)} ${r2(ex - nx * t * 0.9)} ${r2(ey - ny * t * 0.9)} L${r2(tipX - nx * t)} ${r2(tipY - ny * t)} Z`;
  // arm: from inside the body to the fist (drawn behind the body, so the body line cuts it)
  const ax = edge - dir * 2.2, ay = chinY - 0.4;
  const arm = `M${r2(ax)} ${r2(ay - 1.5)} C${r2(ax + dir * 2.4)} ${r2(ay - 1.8)} ${r2(hx - dir * 1.2)} ${r2(hy - 1.9)} ${r2(hx)} ${r2(hy - 1.5)} L${r2(hx)} ${r2(hy + 1.4)} C${r2(hx - dir * 1.6)} ${r2(hy + 1.6)} ${r2(ax + dir * 2.0)} ${r2(ay + 1.6)} ${r2(ax)} ${r2(ay + 1.6)} Z`;
  // fist: a rounded nub wrapped over the stick, with one knuckle tick
  const fist = `M${r2(hx - dir * 1.1)} ${r2(hy - 1.9)} C${r2(hx + dir * 0.6)} ${r2(hy - 2.6)} ${r2(hx + dir * 2.3)} ${r2(hy - 1.6)} ${r2(hx + dir * 2.2)} ${r2(hy + 0.1)} C${r2(hx + dir * 2.1)} ${r2(hy + 1.8)} ${r2(hx + dir * 0.4)} ${r2(hy + 2.4)} ${r2(hx - dir * 1.0)} ${r2(hy + 1.8)} C${r2(hx - dir * 1.7)} ${r2(hy + 0.9)} ${r2(hx - dir * 1.8)} ${r2(hy - 1.2)} ${r2(hx - dir * 1.1)} ${r2(hy - 1.9)} Z`;
  return {
    back: thing(arm, { seed: seed + 'arm', fill: sh.color, ink: w.ink, w: 0.75, amp: 0.1, mis: [-0.3, 0.3], rim: w.paper, rimW: 1.4 }),
    front: cat(
      thing(stick, { seed: seed + 'stick', fill: '#D9A066', ink: w.ink, w: 0.42, amp: 0.06, rim: w.paper, rimW: 0.8 }),
      // handlebar: two fat lobes meeting at a notch, tips curling up (curls are brush strokes)
      ...[-1, 1].map((sd) => stroke(`M${r2(cx + sd * 5.0 * s)} ${r2(cy - 0.1 * s)} C${r2(cx + sd * 6.6 * s)} ${r2(cy - 0.3 * s)} ${r2(cx + sd * 7.0 * s)} ${r2(cy - 2.4 * s)} ${r2(cx + sd * 5.9 * s)} ${r2(cy - 2.9 * s)} C${r2(cx + sd * 5.2 * s)} ${r2(cy - 3.1 * s)} ${r2(cx + sd * 4.9 * s)} ${r2(cy - 2.3 * s)} ${r2(cx + sd * 5.4 * s)} ${r2(cy - 2.0 * s)}`, w.ink, { w: 0.8, seed: seed + 'curl' + sd })),
      thing(m, { seed: seed + 'mst', fill: '#3B2416', ink: w.ink, w: 0.5, amp: 0.08, rim: w.paper, rimW: 0.9 }),
      // hair: short combed ticks in a lighter brown, fanning out from the notch
      stroke([-4.2, -2.9, -1.6, 1.5, 2.8, 4.1].map((u) => `M${r2(cx + u * s)} ${r2(cy - 0.35 * s)} L${r2(cx + (u + Math.sign(u) * 0.7) * s)} ${r2(cy + 0.55 * s)}`).join(' '), '#8A5A3A', { w: 0.26, op: 0.9, seed: seed + 'hair' }),
      thing(fist, { seed: seed + 'fist', fill: sh.color, ink: w.ink, w: 0.7, amp: 0.08, mis: [-0.3, 0.3] }),
      stroke(`M${r2(hx + dir * 0.5)} ${r2(hy - 1.2)} Q${r2(hx + dir * 1.0)} ${r2(hy)} ${r2(hx + dir * 0.5)} ${r2(hy + 1.1)}`, w.ink, { w: 0.35, op: 0.8, seed: seed + 'kn' }),
    ),
  };
}
function moustacheShape(cx: number, cy: number, s: number) {
  // centre notch at the top (the philtrum), lobes swelling outward, thin tips at ±5 s
  const R = (u: number, v: number) => `${r2(cx + u * s)} ${r2(cy + v * s)}`;
  return `M${R(0, -0.55)} C${R(0.9, -1.35)} ${R(2.6, -1.45)} ${R(3.8, -0.95)} C${R(4.4, -0.7)} ${R(4.8, -0.4)} ${R(5.2, -0.15)} C${R(4.6, 0.9)} ${R(3.0, 1.45)} ${R(1.6, 1.1)} C${R(0.9, 0.95)} ${R(0.35, 0.7)} ${R(0, 0.55)} ` +
    `C${R(-0.35, 0.7)} ${R(-0.9, 0.95)} ${R(-1.6, 1.1)} C${R(-3.0, 1.45)} ${R(-4.6, 0.9)} ${R(-5.2, -0.15)} C${R(-4.8, -0.4)} ${R(-4.4, -0.7)} ${R(-3.8, -0.95)} C${R(-2.6, -1.45)} ${R(-0.9, -1.35)} ${R(0, -0.55)} Z`;
}
function rosette(sh: ReturnType<typeof shapeById>, o: CharOpts, seed: string): F3 {
  const bb = bboxOf(sh.d), w = o.world;
  const cx = (bb.x0 + bb.x1) / 2 + bb.w * 0.36, cy = bb.y1 - bb.h * 0.1, R = 2.4;
  const gold = '#FFC94D', dark = '#C98A1A';
  let petals = '';
  const n = 11;
  for (let i = 0; i <= n; i++) {
    const a0 = (i / n) * Math.PI * 2, a1 = ((i + 0.5) / n) * Math.PI * 2;
    const p = (a: number, r: number) => `${r2(cx + Math.cos(a) * r)} ${r2(cy + Math.sin(a) * r)}`;
    petals += (i === 0 ? `M${p(a0, R)}` : ` L${p(a0, R)}`) + ` L${p(a1, R * 1.22)}`;
  }
  petals += 'Z';
  const tails = `M${cx - 1.4} ${cy + 1.4} L${cx - 2.6} ${cy + 6.2} L${cx - 1.5} ${cy + 5.4} L${cx - 0.6} ${cy + 6.4} L${cx} ${cy + 1.6} Z M${cx + 0.4} ${cy + 1.6} L${cx + 1.2} ${cy + 6.2} L${cx + 2.0} ${cy + 5.2} L${cx + 3.0} ${cy + 5.8} L${cx + 1.6} ${cy + 1.2} Z`;
  return cat(
    thing(tails, { seed: seed + 'rt', fill: w.c, ink: w.ink, w: 0.4, amp: 0.06, rim: w.paper, rimW: 0.8 }),
    thing(petals, { seed: seed + 'rp', fill: gold, ink: w.ink, w: 0.45, amp: 0.08, rim: w.paper, rimW: 0.9 }),
    thing(circleD(cx, cy, R * 0.55), { seed: seed + 'rc', fill: dark, ink: w.ink, w: 0.35, amp: 0.05 }),
    blob(`M${cx - 0.5} ${cy - 0.9} L${cx + 0.1} ${cy - 0.9} L${cx + 0.2} ${cy + 0.9} L${cx - 0.4} ${cy + 0.9} Z`, gold, { seed: seed + 'r1' }),
  );
}

// ------------------------------------------------------------ lettering ----
// A broad-brush stroke engine: centreline strokes, width set by the angle of
// the stroke against a flat brush/nib (Latin ≈ 30°, Arabic Ruq'ah ≈ 70°),
// a slow seeded wobble, a landing swell and a lifting taper. Filled polygons
// only, so the lettering ships as outlines.
export type BrushOpts = { nib: number; wMax: number; wMin: number; amp: number; seed: string; grow?: number; k?: number; add?: number };
function wob(L: number, r: () => number, amp: number, wMin = 3, wMax = 9) {
  const t: { f: number; a: number; p: number }[] = [];
  for (let i = 0; i < 3; i++) t.push({ f: (2 * Math.PI) / (wMin + r() * (wMax - wMin)), a: (0.5 + 0.5 * r()) * amp / 1.7, p: r() * 6.283 });
  return (s: number) => t.reduce((v, q) => v + q.a * Math.sin(q.f * s + q.p), 0);
}
export function brush(d: string, o: BrushOpts, frame: number): string {
  const out: string[] = [];
  let si = 0;
  for (const pts0 of samplePath(d, 0.16 * (o.k ?? 1))) {
    const r = rng(hashSeed(`${o.seed}:${d}:${si++}:${frame}`));
    // resample by arc length
    const pts: P[] = [pts0[0]]; const ss = [0]; let acc = 0;
    for (let i = 1; i < pts0.length; i++) { const l = Math.hypot(pts0[i].x - pts0[i - 1].x, pts0[i].y - pts0[i - 1].y); if (l < 1e-6) continue; acc += l; pts.push(pts0[i]); ss.push(acc); }
    const L = acc || 0.01;
    const K = o.k ?? 1;
    const wb = wob(L, r, o.amp * K, 6 * K, 18 * K), press = wob(L, r, 0.14, 5 * K, 14 * K);
    const dx0 = (r() - 0.5) * o.amp * 0.8 * (o.k ?? 1), dy0 = (r() - 0.5) * o.amp * 0.8 * (o.k ?? 1);
    const nibA = ((o.nib + (r() - 0.5) * 6) * Math.PI) / 180;
    const left: P[] = [], right: P[] = [];
    const n = pts.length;
    const W: number[] = [], NX: number[] = [], NY: number[] = [], CX: number[] = [], CY: number[] = [];
    for (let i = 0; i < n; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
      let tx = b.x - a.x, ty = b.y - a.y; const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
      const nx = -ty, ny = tx;
      const th = Math.atan2(-ty, tx);
      const s = ss[i];
      const land = Math.min(1, 0.82 + 0.18 * (s / Math.min(1.2 * K, L * 0.3 + 0.01)));
      const lift = Math.min(1, 0.72 + 0.28 * ((L - s) / Math.min(1.6 * K, L * 0.35 + 0.01)));
      const wv = ((o.wMin + (o.wMax - o.wMin) * Math.abs(Math.sin(th - nibA))) * (1 + press(s)) * land * lift * (o.grow ?? 1) + (o.add ?? 0)) * K;
      const off = wb(s);
      CX.push(pts[i].x + nx * off + dx0); CY.push(pts[i].y + ny * off + dy0); W.push(wv / 2); NX.push(nx); NY.push(ny);
    }
    for (let i = 0; i < n; i++) { left.push({ x: CX[i] + NX[i] * W[i], y: CY[i] + NY[i] * W[i] }); right.push({ x: CX[i] - NX[i] * W[i], y: CY[i] - NY[i] * W[i] }); }
    // round-ish caps (a brush end is soft, not a square)
    const cap = (i: number, sgn: number) => {
      const res: P[] = [];
      const ang0 = Math.atan2(NY[i], NX[i]);
      for (let k = 1; k < 6; k++) { const a = ang0 + (sgn * Math.PI * k) / 6; res.push({ x: CX[i] + Math.cos(a) * W[i] * 0.92, y: CY[i] + Math.sin(a) * W[i] * 0.92 }); }
      return res;
    };
    const poly = [...left, ...cap(n - 1, -1), ...right.reverse(), ...cap(0, -1).map((p) => ({ x: 2 * CX[0] - p.x, y: 2 * CY[0] - p.y }))];
    // thin out: keep every other point
    let area = 0;
    for (let i = 0; i < poly.length; i++) { const a = poly[i], b = poly[(i + 1) % poly.length]; area += a.x * b.y - b.x * a.y; }
    if (area < 0) poly.reverse(); // one orientation for all, so overlapping strokes union under nonzero
    out.push(polyToD(poly, 2));
  }
  return out.join('');
}
function polyLine(p: P[]) { return 'M' + p.map((q) => `${r2(q.x)} ${r2(q.y)}`).join('L') + 'Z'; }

export type Glyph = { w: number; s: string[] };
// Sign-painter casual capitals, centrelines in a cap-10 box (baseline y=0, cap y=-10).
export const LATIN: Record<string, Glyph> = {
  A: { w: 6.6, s: ['M0.4 0.1 C1.4 -3 2.4 -7 3.3 -10.1', 'M3.0 -10.1 C4 -6.8 5 -3.4 6.2 0', 'M1.5 -3.6 C2.8 -3.9 4.0 -4.0 5.2 -3.8'] },
  B: { w: 6.6, s: ['M0.9 -9.9 L0.8 0', 'M0.6 -9.8 C4.2 -10.6 6.0 -9.2 5.6 -7.3 C5.2 -5.7 3.3 -5.2 1.4 -5.3', 'M1.4 -5.5 C4.6 -5.7 6.6 -4.4 6.3 -2.4 C6 -0.5 3.8 0.2 0.5 -0.1'] },
  E: { w: 5.8, s: ['M1.0 -9.9 L0.9 0', 'M0.8 -9.9 C2.4 -10.1 3.8 -10.0 5.4 -10.2', 'M1.1 -5.2 C2.2 -5.3 3.2 -5.4 4.4 -5.3', 'M0.7 0 C2.4 -0.1 3.9 0.1 5.6 -0.2'] },
  F: { w: 5.6, s: ['M1.0 -9.9 L0.9 0.1', 'M0.8 -9.9 C2.4 -10.1 3.8 -10.0 5.5 -10.3', 'M1.1 -5.3 C2.2 -5.4 3.2 -5.5 4.5 -5.4'] },
  G: { w: 6.9, s: ['M6.1 -8.3 C5.4 -9.7 4.2 -10.2 3.1 -10.0 C1.0 -9.6 0.4 -7.0 0.4 -4.8 C0.4 -1.8 1.9 0.2 3.8 0.1 C5.4 0.0 6.3 -1.3 6.3 -3.3 L6.3 -4.3', 'M3.6 -4.5 C4.6 -4.6 5.6 -4.6 6.8 -4.5'] },
  H: { w: 6.6, s: ['M0.9 -10.0 L0.8 0.1', 'M5.8 -10.1 L5.7 0', 'M0.9 -5.2 C2.6 -5.5 4.1 -5.6 5.8 -5.6'] },
  I: { w: 2.2, s: ['M1.1 -10.1 L1.0 0'] },
  K: { w: 6.4, s: ['M0.9 -10.0 L0.8 0.1', 'M5.7 -10.0 C4.0 -8.0 2.6 -6.2 1.0 -4.4', 'M2.4 -5.7 C3.6 -3.6 4.8 -1.8 6.2 0.1'] },
  L: { w: 5.6, s: ['M1.0 -10.1 L0.9 -0.2', 'M0.8 -0.1 C2.4 -0.1 3.8 0 5.5 -0.4'] },
  M: { w: 8.2, s: ['M0.6 0.1 C0.8 -3.4 1.0 -6.6 1.3 -10.0', 'M1.3 -10.0 C2.2 -7.6 3.1 -5.2 4.0 -2.9', 'M4.0 -2.9 C4.9 -5.2 5.9 -7.8 6.8 -10.1', 'M6.8 -10.1 C7.1 -6.8 7.3 -3.2 7.5 0.1'] },
  N: { w: 6.8, s: ['M0.8 0.1 L0.9 -10.0', 'M0.9 -10.0 C2.6 -6.6 4.1 -3.4 5.8 0', 'M5.8 0 C5.8 -3.4 5.9 -6.8 6.0 -10.2'] },
  O: { w: 7.2, s: ['M3.9 -10.1 C1.4 -10.2 0.3 -7.4 0.3 -4.9 C0.3 -2.1 1.6 0.1 3.7 0.1 C5.9 0.1 7.0 -2.4 7.0 -5.1 C7.0 -7.8 5.8 -10.0 3.4 -9.9'] },
  R: { w: 6.4, s: ['M0.9 -9.9 L0.8 0.1', 'M0.6 -9.8 C4.4 -10.6 6.2 -9.0 5.8 -7.0 C5.4 -5.2 3.4 -4.8 1.2 -5.0', 'M3.0 -5.0 C4.0 -3.2 5.0 -1.6 6.3 0.1'] },
  V: { w: 6.6, s: ['M0.1 -10.1 C1.2 -6.8 2.2 -3.4 3.3 0.1', 'M3.3 0.1 C4.3 -3.4 5.3 -6.8 6.5 -10.2'] },
  Q: { w: 7.4, s: ['M3.9 -10.1 C1.4 -10.2 0.3 -7.4 0.3 -4.9 C0.3 -2.1 1.6 0.1 3.7 0.1 C5.9 0.1 7.0 -2.4 7.0 -5.1 C7.0 -7.8 5.8 -10.0 3.4 -9.9', 'M4.3 -2.4 C5.4 -1.0 6.4 0.2 7.8 1.1'] },
  S: { w: 6.4, s: ['M5.6 -8.5 C5.0 -9.7 4.0 -10.1 3.0 -10.0 C1.6 -9.9 0.7 -8.9 0.8 -7.6 C0.9 -5.9 2.8 -5.4 3.9 -5.0 C5.4 -4.4 6.2 -3.4 6.0 -2.0 C5.8 -0.6 4.6 0.1 3.2 0.1 C1.9 0.1 1.0 -0.6 0.4 -1.7'] },
  T: { w: 6.2, s: ['M0.0 -9.8 C2.0 -10.0 4.2 -10.2 6.4 -10.1', 'M3.2 -10.0 L3.3 0.1'] },
  U: { w: 6.6, s: ['M0.8 -10.1 L0.8 -3.3 C0.8 -1.0 2.0 0.1 3.4 0.1 C4.9 0.1 5.9 -1.0 5.9 -3.3 L6.0 -10.1'] },
  Y: { w: 6.2, s: ['M0.2 -10.0 C1.2 -8.4 2.2 -6.8 3.2 -5.0', 'M6.3 -10.1 C5.2 -8.2 4.2 -6.6 3.2 -5.0 L3.2 0.1'] },
  Z: { w: 6.2, s: ['M0.6 -9.8 C2.4 -9.9 4.2 -10.0 6.0 -10.1', 'M6.0 -10.1 C4.2 -6.6 2.4 -3.4 0.4 0', 'M0.4 0 C2.4 -0.1 4.2 -0.1 6.2 -0.3'] },
  '!': { w: 2.6, s: ['M1.4 -10.2 C1.3 -7.6 1.2 -5.4 1.1 -3.3', 'M1.0 -0.7 L1.15 -0.15'] },
  ' ': { w: 2.8, s: [] },
};

export type LetterOpts = { size: number; track?: number; bounce?: number; rot?: number; seed: string; nib?: number; wMax?: number; wMin?: number; amp?: number; slant?: number; scaleJit?: number };
/** Lay out a word with a bouncing baseline; returns stroke centrelines (transformed) and the width. */
export function layoutLatin(text: string, o: LetterOpts) {
  const r = rng(hashSeed(o.seed + text));
  let x = 0; const strokes: string[] = [];
  const k = o.size / 10;
  for (const ch of text) {
    const gl = LATIN[ch];
    if (!gl) throw new Error('no glyph ' + ch);
    const by = (r() - 0.5) * 2 * (o.bounce ?? 0.35);
    const rot = (r() - 0.5) * 2 * (o.rot ?? 3);
    const sc = 1 + (r() - 0.5) * 2 * (o.scaleJit ?? 0.03);
    const sl = o.slant ?? -0.06;
    const cxg = gl.w / 2, cyg = -5;
    const ca = Math.cos((rot * Math.PI) / 180), sa = Math.sin((rot * Math.PI) / 180);
    for (const sd of gl.s) {
      // transform points of the centreline: slant, rotate about glyph centre, scale, shift
      strokes.push(mapPath(sd, (px, py) => {
        let X = px + sl * (py), Y = py;
        X -= cxg; Y -= cyg;
        const rx = X * ca - Y * sa, ry = X * sa + Y * ca;
        return [(rx * sc + cxg) * k + x, (ry * sc + cyg) * k + by * k];
      }));
    }
    x += (gl.w + (o.track ?? 0.3)) * k;
  }
  return { strokes, width: x - (o.track ?? 0.3) * k };
}
/** Apply a point map to path data made of M/L/C commands (absolute). */
export function mapPath(d: string, f: (x: number, y: number) => [number, number]) {
  return d.replace(/([MLC])([^MLCZ]*)/g, (_, c: string, args: string) => {
    const n = args.trim().split(/[\s,]+/).filter(Boolean).map(Number);
    const out: string[] = [];
    for (let i = 0; i < n.length; i += 2) { const [X, Y] = f(n[i], n[i + 1]); out.push(`${r2(X)} ${r2(Y)}`); }
    return c + out.join(' ');
  });
}
/** Render centreline strokes as brush lettering in 3 boil frames. */
export function letter(strokes: string[], o: BrushOpts): F3 {
  return [0, 1, 2].map((f) => `<path d="${strokes.map((s) => brush(s, o, f)).join('')}"/>`);
}

// --------------------------------------------------------------- utils ----
export function svgDoc(w: number, h: number, vbW: number, vbH: number, defs: string, body: string, extraStyle = '') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${vbW} ${vbH}" width="${w}" height="${h}">${extraStyle ? `<style>${extraStyle}</style>` : ''}<defs>${defs}</defs>${body}</svg>`;
}

// ------------------------------------------------------ title lockups ----
import { ARABIC } from './arabic.ts';
export type Lockup = { lat: string[]; ar: string[]; latK: number; arK: number; bb: { x0: number; y0: number; x1: number; y1: number } };
/** Arabic word strokes placed so that its right edge is at x (RTL anchor) and baseline at y. */
export function placeArabic(id: string, k: number, x: number, y: number, align: 'right' | 'left' | 'center' = 'right') {
  const src = ARABIC[id];
  const bb = bboxOf(src.join(''));
  const ax = align === 'right' ? bb.x1 : align === 'left' ? bb.x0 : (bb.x0 + bb.x1) / 2;
  return { strokes: src.map((s) => mapPath(s, (px, py) => [x + (px - ax) * k, y + py * k])), w: bb.w * k, top: y + bb.y0 * k, bottom: y + bb.y1 * k };
}
export function placeLatin(text: string, size: number, x: number, y: number, o: Partial<LetterOpts> = {}, align: 'left' | 'center' | 'right' = 'left') {
  const L = layoutLatin(text, { size, seed: o.seed ?? text, track: 0.5, bounce: 0.2, rot: 2.5, ...o });
  const dx = align === 'left' ? x : align === 'center' ? x - L.width / 2 : x - L.width;
  return { strokes: L.strokes.map((s) => mapPath(s, (px, py) => [px + dx, py + y])), w: L.width };
}
const LAT_BRUSH = { nib: 30, wMax: 2.95, wMin: 0.7, amp: 0.1 }; // flat brush at 30°: strong thick/thin
const AR_BRUSH = { nib: 70, wMax: 2.5, wMin: 0.75, amp: 0.1 };
export type Treat = { fill: string; shade: string; shadeOff?: [number, number]; key?: string; keyAdd?: number; hi?: string };
/** Sign-painter treatment: a keyline in `key`, an offset flat drop shade, then the letter. */
export function signPaint(strokes: string[], k: number, t: Treat, arabic = false, seed = 'sp'): F3 {
  const B = arabic ? AR_BRUSH : LAT_BRUSH;
  const so = t.shadeOff ?? [0.9 * k, 1.1 * k];
  const layers: F3[] = [];
  layers.push(letter(strokes, { ...B, seed: seed + 'sh', k, add: t.keyAdd ?? 1.3 }).map((s) => `<g fill="${t.shade}" transform="translate(${r2(so[0])} ${r2(so[1])})">${s}</g>`));
  if (t.key) layers.push(letter(strokes, { ...B, seed: seed + 'k', k, add: t.keyAdd ?? 1.3 }).map((s) => `<g fill="${t.key}">${s}</g>`));
  layers.push(letter(strokes, { ...B, seed, k }).map((s) => `<g fill="${t.fill}">${s}</g>`));
  return cat(...layers);
}
/** Neon tube: uniform tube + two glow sleeves (light, so it may be soft) + a dark backing shadow. */
export function neon(strokes: string[], k: number, tube: string, glow: string, back: string, arabic = false, seed = 'ne', tubeW = 2.0): F3 {
  // tube : glow = 6 : 14 (DESIGN-JAMAA §1.6), widths in scene units, independent of the letter scale
  const glowW = tubeW * 14 / 6;
  const T = (wd: number, amp = 0.05) => ({ nib: arabic ? 70 : 30, wMax: 0, wMin: 0, amp, k, add: wd / k });
  return cat(
    letter(strokes, { ...T(tubeW * 1.15), seed: seed + 'b' }).map((s) => `<g fill="${back}" opacity="0.7" transform="translate(${r2(0.5 * k)} ${r2(0.8 * k)})">${s}</g>`),
    letter(strokes, { ...T(glowW, 0.02), seed: seed + 'g2' }).map((s) => `<g fill="${glow}" opacity="0.2">${s}</g>`),
    letter(strokes, { ...T(glowW * 0.62, 0.02), seed: seed + 'g1' }).map((s) => `<g fill="${glow}" opacity="0.4">${s}</g>`),
    letter(strokes, { ...T(tubeW), seed }).map((s) => `<g fill="${tube}">${s}</g>`),
    letter(strokes, { ...T(tubeW * 0.32, 0.03), seed: seed + 'c' }).map((s) => `<g fill="#FFFFFF" opacity="0.75">${s}</g>`),
  );
}
