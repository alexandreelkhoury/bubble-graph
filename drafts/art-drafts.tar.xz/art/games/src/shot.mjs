// usage: node shot.mjs file.svg out.png width height [scale]
import { createRequire } from 'node:module';
const require = createRequire('/tmp/claude-0/-home-user-bubble-graph/77b6be62-ffd0-56aa-bc1b-92bd03a88678/scratchpad/art/tools/package.json');
const { chromium } = require('playwright-core');
import path from 'node:path';
const jobs = JSON.parse(process.argv[2]);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome' });
for (const j of jobs) {
  const page = await browser.newPage({ viewport: { width: j.w, height: j.h }, deviceScaleFactor: j.scale || 1 });
  await page.goto('file://' + path.resolve(j.src));
  await page.waitForTimeout(j.wait || 150);
  await page.screenshot({ path: j.out, clip: j.clip || { x: 0, y: 0, width: j.w, height: j.h } });
  await page.close();
}
await browser.close();
console.log('shots', jobs.length);
