import fs from 'node:fs';
import { letter, layoutLatin, cat, g, svgDoc, mapPath } from './lib.ts';
import { ARABIC } from './arabic.ts';
const parts: string[][] = [];
let y = 22;
for (const id of Object.keys(ARABIC)) {
  const k = 0.9;
  const st = ARABIC[id].map(s => mapPath(s, (x, yy) => [80 + x * k, y + yy * k]));
  parts.push(letter(st, { nib: 70, wMax: 2.3, wMin: 0.7, amp: 0.12, seed: id, k }).map(s => `<g fill="#FFE9C7">${s}</g>`));
  y += 30;
}
const L = layoutLatin('MISH ANA!', { size: 16, seed: 'a', track: 0.2 });
parts.push(g('transform="translate(130 40)"', letter(L.strokes, { nib: 30, wMax: 2.2, wMin: 0.9, amp: 0.12, seed: 'a', k: 1.6, add: 1.4 }).map(s=>`<g fill="#E2477F" transform="translate(0.8 1)">${s}</g>`), letter(L.strokes, { nib: 30, wMax: 2.2, wMin: 0.9, amp: 0.12, seed: 'a', k: 1.6 }).map(s=>`<g fill="#FFE9C7">${s}</g>`)));
const L2 = layoutLatin('BLUFF! QUIZ NIGHT', { size: 9, seed: 'b', track: 0.4 });
parts.push(g('transform="translate(130 80)"', letter(L2.strokes, { nib: 30, wMax: 2.2, wMin: 0.9, amp: 0.12, seed: 'b', k: 0.9 }).map(s=>`<g fill="#F29B38">${s}</g>`)));
const L3 = layoutLatin('MOST LIKELY', { size: 9, seed: 'c', track: 0.4 });
parts.push(g('transform="translate(130 100)"', letter(L3.strokes, { nib: 30, wMax: 2.2, wMin: 0.9, amp: 0.12, seed: 'c', k: 0.9 }).map(s=>`<g fill="#29D3C2">${s}</g>`)));
const body = cat(`<rect width="240" height="135" fill="#1D1036"/>`, ...parts);
fs.writeFileSync(process.argv[2] + '/test.svg', svgDoc(1920, 1080, 240, 135, '', body[0]));
