// Hand-authored Ruq'ah-style centrelines for the four Arabic titles.
// Units: alef height ≈ 10, baseline y = 0, y down. Words run right → left;
// coordinates are absolute (x grows to the right as in SVG).
// Ruq'ah conventions used: three dots as a caret (^), two dots as a short dash,
// seen/sheen teeth flattened, bowls sit low, no kashida.  [native review]
export const ARABIC: Record<string, string[]> = {
  // مش أنا!
  mishana: [
    // meem (initial): a small closed loop on the baseline, exits left
    'M21.4 -0.3 C23.0 0.0 23.4 -2.6 21.9 -2.7 C20.7 -2.8 20.3 -1.2 21.1 -0.2',
    // joint into sheen: flat ruq'ah teeth, then the deep final bowl
    'M21.4 0 C19.6 0.1 18.6 0 17.8 -1.3 C17.4 -0.2 16.4 0.1 15.6 -1.2 C15.2 -0.2 14.6 0.2 13.8 -0.2 C13.6 2.8 12.0 4.4 9.8 4.4 C7.6 4.4 6.4 3.0 6.3 0.4',
    // the three dots as a caret
    'M14.9 -4.4 L16.3 -6.4', 'M16.3 -6.4 L17.7 -4.4',
    // alef + hamza
    'M3.3 -9.4 C3.1 -6 2.9 -3 2.7 0.1',
    'M4.2 -12.6 C3.7 -13.1 3.0 -12.7 3.25 -12.2 C3.5 -11.85 4.0 -11.9 4.5 -12.2', 'M3.25 -12.15 C3.0 -11.7 2.8 -11.5 2.4 -11.3',
    // nun (initial) tooth + join + final alef
    'M0.2 -2.8 C0.4 -1.0 0.0 0.1 -1.2 0.1 C-2.4 0.1 -3.6 0.1 -4.6 0.1',
    'M-4.6 0.2 C-4.8 -3 -5.0 -6.4 -5.0 -9.6',
    'M-0.5 -4.7 L0.5 -5.4',
    // !
    'M-8.2 -9.4 C-8.3 -7.0 -8.4 -5.0 -8.4 -3.2', 'M-8.5 -0.8 L-8.35 -0.1',
  ],
  // بلوف!
  bluff: [
    // ba (initial) tooth, baseline running under the lam into the waw
    'M17.2 -2.6 C17.4 -0.8 17.0 0.1 15.8 0.1 C14.0 0.1 12.4 0.1 10.8 0.1',
    'M16.0 2.6 L16.9 2.0',
    // lam ascender
    'M12.0 0.1 C12.0 -3.4 12.2 -7.0 12.6 -10.6',
    // waw (final): head loop, tail sweeping below
    'M11.0 0.1 C9.8 0.0 9.6 -2.9 8.4 -2.9 C7.3 -2.9 6.9 -1.6 7.5 -0.9 C8.2 -0.2 9.2 -0.4 9.4 0.6 C9.6 2.0 8.0 3.8 5.2 4.4',
    // fa (isolated): head loop, long low boat
    'M2.6 -0.6 C4.0 -0.4 4.4 -3.0 2.9 -3.1 C1.6 -3.2 1.2 -1.6 2.4 -0.5 C3.4 0.3 3.0 1.1 1.2 1.1 C-1.2 1.1 -3.4 1.1 -5.0 1.0 C-6.2 0.9 -6.8 0.0 -6.6 -1.6',
    'M2.4 -5.0 L3.4 -5.6',
    // !
    'M-9.6 -9.4 C-9.7 -7.0 -9.8 -5.0 -9.8 -3.2', 'M-9.9 -0.8 L-9.75 -0.1',
  ],
  // مين فينا؟
  likely: [
    // meem loop
    'M25.4 -0.2 C27.4 0.2 28.0 -3.2 26.0 -3.3 C24.4 -3.4 23.8 -1.2 25.0 -0.1',
    // baseline: meem → ya tooth → nun bowl
    'M25.2 0 C24.0 0.1 23.2 0.1 22.4 0.1', 'M22.6 0.1 C22.4 -0.8 22.4 -1.6 22.6 -2.6', 'M22.6 0.1 C21.0 0.1 20.0 0.0 19.4 -1.0',
    'M19.4 -1.2 C19.4 2.6 18.0 4.2 15.8 4.2 C13.6 4.2 12.6 2.8 12.6 0.4',
    // ya: two dots below; nun: one dot above the bowl
    'M20.9 2.9 L21.6 3.2', 'M23.7 2.9 L24.4 3.2', 'M15.7 -3.6 L16.4 -3.3',
    // fa (initial) loop
    'M9.8 -0.1 C11.4 0.0 11.6 -2.9 10.0 -3.0 C8.7 -3.1 8.3 -1.2 9.3 -0.1',
    'M9.6 0.1 C7.4 0.1 6.0 0.1 4.6 0.1 C3.0 0.1 1.8 0.1 0.4 0.1',
    // ya tooth, nun tooth, final alef
    'M6.4 0.1 C6.3 -0.8 6.3 -1.6 6.5 -2.5', 'M3.6 0.1 C3.5 -0.8 3.5 -1.7 3.7 -2.6',
    'M0.4 0.2 C0.2 -3 0.0 -6.4 0.0 -9.6',
    // fa: one dot above; ya: two dots below; nun: one dot above
    'M9.9 -5.2 L10.6 -4.9', 'M4.8 2.9 L5.5 3.2', 'M7.5 2.9 L8.2 3.2', 'M3.3 -5.0 L4.0 -4.7',
    // ؟ (mirrored question mark)
    'M-2.6 -8.4 C-2.8 -10.2 -5.4 -10.4 -5.8 -8.6 C-6.1 -7.0 -4.4 -6.4 -4.3 -4.6 L-4.3 -3.2', 'M-4.45 -0.8 L-4.3 -0.1',
  ],
  // مسابقة  (DESIGN-JAMAA §1.6: the Trivia title)  [native review]
  // v2: counters opened up (the 70° nib closes small loops), nuqat drawn as SEPARATE dabs, never a dash.
  trivia: [
    // meem (initial): a round closed loop sitting on the baseline, exits left
    'M32.4 0.0 C34.8 0.2 35.0 -4.2 32.6 -4.3 C30.6 -4.4 30.2 -1.4 31.6 -0.2',
    'M32.0 0.1 L30.2 0.1',
    // seen (medial): three clear teeth
    'M30.2 0.1 C29.6 0.1 29.4 -1.0 29.4 -2.4 C29.4 -0.4 28.6 0.1 27.8 0.1 C27.2 0.1 27.0 -1.0 27.0 -2.4 C27.0 -0.4 26.2 0.1 25.4 0.1 C24.8 0.1 24.6 -1.0 24.6 -2.4 C24.6 -0.4 23.8 0.1 23.0 0.1 L21.6 0.1',
    // alef (final, joined)
    'M21.6 0.3 C21.4 -3.2 21.3 -6.6 21.5 -10.2',
    // ba (initial): a tooth and the baseline
    'M18.6 -3.0 C18.8 -0.8 18.4 0.1 17.2 0.1 L16.4 0.1',
    // qaf (medial): an open round head on the baseline
    'M16.6 0.1 C15.0 0.1 15.4 -5.4 12.6 -5.4 C10.2 -5.4 9.8 -1.6 11.4 -0.5 C12.0 -0.1 11.6 0.1 10.4 0.1 L9.2 0.1',
    // ta marbuta (final, joined): the loop rises up-left and comes home along the baseline
    'M9.2 0.1 C7.8 0.1 7.2 -1.4 6.8 -3.2 C6.2 -5.6 2.8 -6.2 2.0 -3.6 C1.4 -1.4 3.4 0.1 5.8 0.1 C7.0 0.15 7.9 0.1 8.6 0.0',
    // nuqat: ba ONE below; qaf TWO above; ta marbuta TWO above — each a separate dab
    'M17.0 3.1 L17.6 3.5',
    'M10.6 -8.4 L11.2 -8.0', 'M14.4 -8.4 L15.0 -8.0',
    'M2.4 -9.0 L3.0 -8.6', 'M6.2 -9.0 L6.8 -8.6',
  ],
  // هسّ!  («hiss!», Levantine for "hush!", the secret poster)  [native review]
  shh: [
    // ha (initial): a tall teardrop, pointed at the top, so it can't be read as a meem
    'M13.6 -7.4 C11.4 -5.6 9.6 -3.0 10.2 -0.9 C10.8 1.0 14.0 0.8 14.6 -1.0 C15.2 -2.8 14.6 -5.2 13.6 -7.4',
    'M10.4 0.1 L9.6 0.1',
    // seen (final): three teeth, then the deep bowl
    'M9.6 0.1 C9.1 0.1 8.9 -0.8 8.9 -1.9 C8.9 -0.3 8.3 0.1 7.5 -0.1 C7.0 -0.3 6.9 -1.1 6.9 -1.9 C6.9 -0.3 6.3 0.2 5.5 0.0 C5.3 2.6 3.9 4.2 1.9 4.2 C-0.1 4.2 -1.1 2.8 -1.1 0.6',
    // shadda over the seen
    'M6.0 -4.9 C6.0 -3.9 6.8 -3.9 7.0 -4.7 C7.2 -3.9 8.0 -3.9 8.0 -4.9',
    // !
    'M-4.2 -9.4 C-4.3 -7.0 -4.4 -5.0 -4.4 -3.2', 'M-4.5 -0.8 L-4.35 -0.1',
  ],
};
