/** An open tawleh (backgammon) board lying on the table, tipped toward us: inlaid frame, two fields of
 *  copper and green points, a hinge bar, a few checkers mid-game and two dice. */
function tawlehBoard(x: number, table: number, s: number, w: World, seed: string): F3 {
  const y0 = table - 3.2 * s, y1 = table + 10.5 * s, hw0 = 25 * s, hw1 = 28.5 * s;
  const Q = (u: number, v: number) => { const hw = hw0 + (hw1 - hw0) * v; return [x + u * hw, y0 + (y1 - y0) * v]; };
  const poly = (pts: number[][]) => P(pts.map(([u, v]) => Q(u, v)));
  const r = rng(hashSeed(seed));
  const parts: F3[] = [];
  // its shadow on the table front (it overhangs the edge a little)
  parts.push(shadow(P([Q(-1.02, 0.5), Q(1.04, 0.5), [x + hw1 * 1.02, y1 + 2.4 * s], [x - hw1 * 0.98, y1 + 2.0 * s]]), w, 0.45));
  parts.push(thing(poly([[-1, 0], [1, 0], [1, 1], [-1, 1]]), { fill: '#7A4320', ink: w.ink, w: 0.75, amp: 0.2, mis: w.mis, seed: seed + 'fr' }));
  // inlay: a dotted line of bone inlay along the frame (hand dots, not a dash pattern)
  let inl = '';
  for (let i = 0; i <= 26; i++) { const u = -0.97 + (i / 26) * 1.94; const [px, py] = Q(u, 0.045); inl += circleD(px, py, 0.32 * s); const [qx, qy] = Q(u + (r() - 0.5) * 0.01, 0.955); inl += circleD(qx, qy, 0.36 * s); }
  parts.push(blob(inl, '#F3E3C0', { seed: seed + 'inl', amp: 0.04 }));
  for (const side of [-1, 1]) {
    const ua = side < 0 ? -0.93 : 0.07, ub = side < 0 ? -0.07 : 0.93;
    parts.push(thing(poly([[ua, 0.1], [ub, 0.1], [ub, 0.9], [ua, 0.9]]), { fill: '#E2C48E', ink: w.ink, w: 0.45, amp: 0.12, seed: seed + 'fd' + side }));
    // six points on each long edge, alternating copper / green, apex toward the middle
    for (let i = 0; i < 6; i++) {
      const u0 = ua + ((ub - ua) * i) / 6, u1 = ua + ((ub - ua) * (i + 1)) / 6, um = (u0 + u1) / 2;
      const c1 = i % 2 ? w.c : w.b, c2 = i % 2 ? w.b : w.c;
      parts.push(flat(poly([[u0 + 0.004, 0.11], [u1 - 0.004, 0.11], [um + (r() - 0.5) * 0.01, 0.46]]), c1, { amp: 0.06, seed: seed + 'pa' + side + i }));
      parts.push(flat(poly([[u0 + 0.004, 0.89], [u1 - 0.004, 0.89], [um + (r() - 0.5) * 0.01, 0.55]]), c2, { amp: 0.06, seed: seed + 'pb' + side + i }));
    }
  }
  // hinge bar
  parts.push(thing(poly([[-0.065, 0.02], [0.065, 0.02], [0.065, 0.98], [-0.065, 0.98]]), { fill: '#5A3016', ink: w.ink, w: 0.5, amp: 0.08, seed: seed + 'hg' }));
  // checkers mid-game: short stacks on a few points (flat discs, stacked toward the middle)
  const piece = (u: number, v: number, dark: boolean, i: number) => {
    const [px, py] = Q(u, v), rx = 1.7 * s * (0.94 + v * 0.12), ry = 1.0 * s;
    return cat(
      thing(ellipseD(px, py + 0.35 * s, rx, ry), { fill: dark ? '#1E120B' : '#C9B48C', ink: w.ink, w: 0.35, amp: 0.04, seed: seed + 'ps' + i }),
      thing(ellipseD(px, py, rx, ry), { fill: dark ? '#3A2416' : '#FFF1D4', ink: w.ink, w: 0.4, amp: 0.05, seed: seed + 'pt' + i }),
    );
  };
  const um = (side: number, i: number) => (side < 0 ? -0.93 : 0.07) + 0.86 * ((i + 0.5) / 6);
  const stacks: [number, number, boolean, number][] = [[-1, 0, true, 3], [-1, 4, false, 2], [1, 1, false, 4], [1, 5, true, 2], [1, 3, true, 1]];
  let pi = 0;
  for (const [side, i, dark, n] of stacks) {
    const front = (i + (side > 0 ? 1 : 0)) % 2 === 0;
    for (let j = 0; j < n; j++) parts.push(piece(um(side, i), front ? 0.83 - j * 0.11 : 0.17 + j * 0.11, dark, pi++));
  }
  // two dice, just thrown: a five and a two
  const die = (u: number, v: number, rot: number, pips: number[][], i: number) => {
    const [px, py] = Q(u, v), d = 3.1 * s;
    return g(`transform="rotate(${rot} ${r2(px)} ${r2(py)})"`,
      thing(rr(px - d / 2, py - d / 2 - 0.9 * s, d, d, 0.7 * s), { fill: '#FFF6E0', ink: w.ink, w: 0.45, amp: 0.05, seed: seed + 'dt' + i }),
      thing(P([[px - d / 2, py + d / 2 - 0.9 * s], [px + d / 2, py + d / 2 - 0.9 * s], [px + d / 2 - 0.2 * s, py + d / 2 + 0.2 * s], [px - d / 2 + 0.2 * s, py + d / 2 + 0.2 * s]]), { fill: '#D8C49A', ink: w.ink, w: 0.4, amp: 0.03, seed: seed + 'ds' + i }),
      blob(pips.map(([a, b]) => circleD(px + a * d * 0.3, py - 0.9 * s + b * d * 0.3, 0.33 * s)).join(''), w.ink, { seed: seed + 'dp' + i }),
    );
  };
  parts.push(die(0.38, 0.5, -12, [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 0));
  parts.push(die(0.55, 0.42, 9, [[-1, -1], [1, 1]], 1));
  // a varnish tick on the near frame
  parts.push(stroke(`M${r2(x - hw1 * 0.85)} ${r2(y1 - 0.6 * s)} L${r2(x - hw1 * 0.55)} ${r2(y1 - 0.75 * s)}`, w.paper, { w: 0.45, op: 0.5, seed: seed + 'vt' }));
  return cat(...parts);
}
