p='src/scenes.ts'; s=open(p).read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n, (a[:70], s.count(a)); s=s.replace(a,b)
rep("export type Scene = { w: number; h: number; defs: string; items: Item[] };",
"export type Scene = { w: number; h: number; defs: string; items: Item[] };\n/** Marker item: the paper grain goes here (set only); the cast in front gets a light pass (see build.ts). */\nexport const GRAIN = '@@GRAIN@@';")
rep("""  // --- the cast, behind the table (the table hides their feet: they're sitting) ---
  const cy = table + 3;""","""  // the set is done: the café's paper grain and warm wash stop here, the cast keeps its own colour
  it.push(GRAIN);
  // --- the cast, behind the table (the table hides their feet: they're sitting) ---
  const cy = table + 3;
  const clean = { shadeOp: 0.13, hatchOp: 0.07 };""")
for a in ["seed: 'th1', groundShadow: false }","seed: 'th2', groundShadow: false }","seed: 'liar', groundShadow: false }","seed: 'th1s', groundShadow: false }","seed: 'th2s', groundShadow: false }","seed: 'liars', groundShadow: false }"]:
    rep(a, a[:-2]+", ...clean }")
rep("""    it.push(rakweh(92, table, 1, w, 'rk'));
    it.push(tawleh(222, table, w, 'tw'));
    it.push(scroll(112, table + 3, 1, w, 'sc'));""","""    it.push(rakweh(90, table, 1, w, 'rk'));
    it.push(tawlehBoard(130, table, 1, w, 'tb'));""")
rep("""    it.push(scroll(68, table + 3, 0.85, w, 'scs'));""","""    it.push(tawlehBoard(75, table, 0.8, w, 'tbs'));""")
a=s.index("/** Corner of a backgammon (tawleh) board"); b=s.index("/** A small brush \"?\"")
s=s[:a]+open('patches/tawleh.ts').read()+s[b:]
open(p,'w').write(s)
