p='src/scenes.ts'; s=open(p).read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n, (a[:70], s.count(a)); s=s.replace(a,b)
rep("  placeArabic, placeLatin, signPaint, neon, rng, hashSeed, r2, uid, letter,\n} from './lib.ts';", "  placeArabic, placeLatin, signPaint, neon, rng, hashSeed, r2, uid, letter,\n} from './lib.ts';\nimport { goldLeaf, goldTicks as goldBurnish, goldStar, felt as feltL, feltRule, neonClips, neonMoustacheStrokes, drips, paintBurst } from './titles.ts';",1)
# --- Mish Ana
rep("""    it.push(signPaint(lat.strokes, 1.4, { fill: w.paper, shade: w.a, key: w.ink, keyAdd: 1.5 }, false, 'mishL'));
    it.push(signPaint(ar.strokes, 1.55, { fill: w.b, shade: w.ink, key: w.ink, keyAdd: 1.4, shadeOff: [0.9, 1.1] }, true, 'mishA'));""",
"""    it.push(drips(lat.strokes, w.paper, 'mishD', 1.2));
    it.push(signPaint(lat.strokes, 1.4, { fill: w.paper, shade: w.a, key: w.ink, keyAdd: 1.5 }, false, 'mishL'));
    it.push(drips(ar.strokes, w.b, 'mishAD', 1.2));
    it.push(signPaint(ar.strokes, 1.55, { fill: w.b, shade: w.ink, key: w.ink, keyAdd: 1.4, shadeOff: [0.9, 1.1] }, true, 'mishA'));
    it.push(paintBurst(11 + (lat.w - ar.w) / 2 - 4, 48, 1.3, w, 'mishO'));""")
rep("""    it.push(signPaint(lat.strokes, 1.3, { fill: w.paper, shade: w.a, key: w.ink, keyAdd: 1.5 }, false, 'mishLs'));
    it.push(signPaint(ar.strokes, 1.3, { fill: w.b, shade: w.ink, key: w.ink, keyAdd: 1.4 }, true, 'mishAs'));""",
"""    it.push(drips(lat.strokes, w.paper, 'mishDs', 1.1));
    it.push(signPaint(lat.strokes, 1.3, { fill: w.paper, shade: w.a, key: w.ink, keyAdd: 1.5 }, false, 'mishLs'));
    it.push(signPaint(ar.strokes, 1.3, { fill: w.b, shade: w.ink, key: w.ink, keyAdd: 1.4 }, true, 'mishAs'));
    it.push(paintBurst(75 - ar.w / 2 - 9, 40, 1.1, w, 'mishOs'));""")
# --- Bluff
rep("""    it.push(neon(lat.strokes, 1.7, '#FFF4DC', w.a, '#000', false, 'blL', 2.5));
    it.push(neon(ar.strokes, 1.7, '#FFE2BC', w.signal!, '#000', true, 'blA', 2.5));""",
"""    it.push(neon(lat.strokes, 1.7, '#FFF4DC', w.a, '#000', false, 'blL', 2.5));
    it.push(neonClips(lat.strokes, 'blC'));
    it.push(neon(ar.strokes, 1.7, '#FFE2BC', w.signal!, '#000', true, 'blA', 2.5));
    it.push(neonClips(ar.strokes, 'blAC', 3));
    { const ox = (nb.x + 4 + nb.x + nb.w - 8 - ar.w) / 2; const ms = neonMoustacheStrokes(ox, nb.y + 41, 1.35);
      it.push(neon(ms, 1.4, '#FFF4DC', w.a, '#000', false, 'blO', 2.0)); it.push(neonClips(ms, 'blOC', 1)); }""")
rep("""    it.push(neon(lat.strokes, 1.5, '#FFF4DC', w.a, '#000', false, 'blLs', 2.2));
    it.push(neon(ar.strokes, 1.5, '#FFE2BC', w.signal!, '#000', true, 'blAs', 2.2));""",
"""    it.push(neon(lat.strokes, 1.5, '#FFF4DC', w.a, '#000', false, 'blLs', 2.2));
    it.push(neonClips(lat.strokes, 'blCs'));
    it.push(neon(ar.strokes, 1.5, '#FFE2BC', w.signal!, '#000', true, 'blAs', 2.2));
    it.push(neonClips(ar.strokes, 'blACs', 3));
    { const ox = (nb.x + 8 + lat.w + nb.x + nb.w - 7 - ar.w) / 2; const ms = neonMoustacheStrokes(ox, nb.y + 19, 1.05);
      it.push(neon(ms, 1.2, '#FFF4DC', w.a, '#000', false, 'blOs', 1.8)); }""")
# --- Likely
rep("""    it.push(signPaint(lat.strokes, 1.25, T, false, 'lkL'));
    it.push(goldTicks(lat.strokes.length, 10, 42, lat.w, 12.5, w));
    it.push(signPaint(ar.strokes, 1.6, T, true, 'lkA'));""",
"""    it.push(goldLeaf(lat.strokes, 1.25, w, false, 'lkL', defs, 12.5));
    it.push(goldBurnish(lat.strokes, w, 'lkT'));
    it.push(goldLeaf(ar.strokes, 1.6, w, true, 'lkA', defs, 16));
    it.push(goldStar(10 + (lat.w - ar.w) / 2 - 2, 60, 5.2, w, 'lkO'));""")
rep("""    it.push(signPaint(lat.strokes, 1.1, T, false, 'lkLs'));
    it.push(signPaint(ar.strokes, 1.35, T, true, 'lkAs'));""",
"""    it.push(goldLeaf(lat.strokes, 1.1, w, false, 'lkLs', defs, 11));
    it.push(goldBurnish(lat.strokes, w, 'lkTs'));
    it.push(goldLeaf(ar.strokes, 1.35, w, true, 'lkAs', defs, 13.5));
    it.push(goldStar(75 - ar.w / 2 - 8, 54, 4.4, w, 'lkOs'));""")
rep("  const T = { fill: '#FFC94D', shade: '#9A5E0E', key: w.ink, keyAdd: 1.5, shadeOff: [0.5, 1.4] as [number, number] };\n","")
# --- Trivia
rep("""    it.push(felt(lat.strokes, wide ? 1.5 : 1.45, w, false, 'trL' + L));
    it.push(felt(ar.strokes, wide ? 1.42 : 1.4, w, true, 'trA' + L, w.b));""",
"""    it.push(feltL(lat.strokes, wide ? 1.5 : 1.45, w, false, 'trL' + L, defs, wide ? 15.5 : 15));
    it.push(feltL(ar.strokes, wide ? 1.42 : 1.4, w, true, 'trA' + L, defs, 14, w.b));
    it.push(feltRule(cxm, mq.y + (wide ? 49.5 : 47.5), 26, w, 'trO' + L, defs, w.c));""")
rep("""    : [{ x: 26, s: 1.4, sh: 'arch',""","""    : [{ x: 26, s: 1.4, sh: 'triangle',""")
rep("""    ? [{ x: 64, s: 1.75, sh: 'arch',""","""    ? [{ x: 64, s: 1.75, sh: 'triangle',""")
rep("""    if (p.e === 'cheer' && wide) it.push(confetti(p.x, top - p.s * 24 - 4, p.s, w, 'cf' + L));
""","")
rep("""    it.push(podium(p.x, top, floor + 2, wide ? 34 : 30, p.tok, p.e === 'cheer', w, 'pd' + p.sh + L));""",
"""    it.push(podium(p.x, top, floor + 2, wide ? 34 : 30, p.tok, p.e === 'cheer', w, 'pd' + p.sh + L));
    if (p.e === 'cheer') it.push(buzzFlash(p.x + (wide ? 34 : 30) / 2 - 6, top - 1.6, wide ? 1 : 0.85, w, 'bf' + L));""")
# remove confetti fn, add buzzFlash
a=s.index("/** Cut-paper confetti"); b=s.index("export const SCENES")
s=s[:a]+r'''/** The buzzer just went: a cut-paper flash behind the button and brush ticks bursting out of it. */
function buzzFlash(x: number, y: number, s: number, w: World, seed: string): F3 {
  const r = rng(hashSeed(seed));
  let star = '';
  const n = 9;
  for (let i = 0; i < n * 2; i++) { const a = Math.PI + (i / (n * 2 - 1)) * Math.PI, rr = (i % 2 ? 4.2 : 8.4 + r() * 2.2) * s; star += `${i ? 'L' : 'M'}${r2(x + Math.cos(a) * rr * 1.15)} ${r2(y + Math.sin(a) * rr)}`; }
  star += `L${r2(x + 4 * s)} ${r2(y + 0.6)} L${r2(x - 4 * s)} ${r2(y + 0.6)}Z`;
  const out: F3[] = [thing(star, { fill: w.glow, ink: w.ink, w: 0.5, amp: 0.15, mis: w.mis, seed: seed + 'st' })];
  for (let i = 0; i < 5; i++) { const a = Math.PI * (1.12 + i * 0.19), r0 = 10.5 * s, r1 = (13.5 + r() * 2) * s; out.push(stroke(`M${r2(x + Math.cos(a) * r0 * 1.15)} ${r2(y + Math.sin(a) * r0)} L${r2(x + Math.cos(a) * r1 * 1.15)} ${r2(y + Math.sin(a) * r1)}`, w.paper, { w: 0.9 * s, seed: seed + i })); }
  return cat(...out);
}

'''+s[b:]
open(p,'w').write(s)
