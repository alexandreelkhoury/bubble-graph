p='src/scenes.ts'; s=open(p).read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n, (a[:70], s.count(a)); s=s.replace(a,b)
rep("""    : [{ x: 102, y: 56, w: 22, h: 28, r: -4, c: w.a, kind: 'q' }, { x: 124, y: 62, w: 20, h: 24, r: 6, c: w.paper, kind: 'blank' },""",
    """    : [{ x: 107, y: 56, w: 21, h: 27, r: -4, c: w.a, kind: 'q' }, { x: 128, y: 62, w: 18, h: 23, r: 6, c: w.paper, kind: 'blank' },""")
rep("""  const poleX = wide ? 236 : 146;
  it.push(thing(`M${poleX + 1}""","""  const poleX = wide ? 236 : 146;
  if (!wide) {
    // square: no pole (it would graze the posters and the azure one); a wall bracket, clear of the posters
    const bx = 99, byy = 47;
    it.push(shadow(rect(bx + 0.8, byy + 1, 3.4, 9), w, 0.35));
    it.push(thing(rr(bx, byy, 3.4, 9, 0.8), { fill: '#2E2140', ink: w.ink, w: 0.6, amp: 0.1, seed: 'plate' }));
    it.push(blob(circleD(bx + 1.7, byy + 1.8, 0.45) + circleD(bx + 1.7, byy + 7.2, 0.45), '#8C7AA6', { seed: 'bolts' }));
    it.push(thing(`M${bx} ${byy + 3} C${bx - 6} ${byy - 2.6} ${lx + 8} ${ly - 7.6} ${lx + 1} ${ly - 3.2} L${lx + 1} ${ly - 1.6} C${lx + 8} ${ly - 5.6} ${bx - 6} ${byy - 0.6} ${bx} ${byy + 5} Z`, { fill: '#2E2140', ink: w.ink, w: 0.6, amp: 0.15, seed: 'arm' }));
    it.push(stroke(`M${bx} ${byy + 7.5} C${bx - 4} ${byy + 6} ${bx - 6} ${byy + 2} ${bx - 8} ${byy - 0.6}`, w.ink, { w: 0.45, seed: 'strut' }));
  } else
  it.push(thing(`M${poleX + 1}""")
rep("""    it.push(paintBurst(11 + (lat.w - ar.w) / 2 - 4, 48, 1.3, w, 'mishO'));""","""    it.push(paintBurst(11 + lat.w - ar.w - 9, 47, 1.3, w, 'mishO'));""")
open(p,'w').write(s)
