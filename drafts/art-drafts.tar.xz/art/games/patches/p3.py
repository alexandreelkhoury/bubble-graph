p='src/scenes.ts'; s=open(p).read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n, (a[:70], s.count(a)); s=s.replace(a,b)
rep("""    it.push(thing(P([[tx - 14, par - 9], [tx + 30, par - 10], [tx + 30, par - 7], [tx - 14, par - 6]]), { fill: '#5C6B70', ink: w.ink, w: 0.5, amp: 0.15, seed: 'stand' }));
    for (const lx of [tx - 12, tx + 1, tx + 15]) it.push(thing(rect(lx, par - 7, 1.6, floor - par + 7), { fill: '#5C6B70', ink: w.ink, w: 0.45, amp: 0.08, seed: 'leg' + lx }));""",
"""    // a long steel stand: the tank on one end, the gossips perched on the other (feet on the deck)
    it.push(thing(P([[tx - 50, par - 8.6], [tx + 30, par - 10], [tx + 30, par - 6.8], [tx - 50, par - 5.6]]), { fill: '#5C6B70', ink: w.ink, w: 0.5, amp: 0.15, seed: 'stand' }));
    for (const lx of [tx - 48, tx - 30, tx - 12, tx + 1, tx + 15]) it.push(thing(rect(lx, par - 7, 1.6, floor - par + 7), { fill: '#5C6B70', ink: w.ink, w: 0.45, amp: 0.08, seed: 'leg' + lx }));
    it.push(stroke(`M${tx - 47} ${par - 6} L${tx - 31} ${floor - 2} M${tx - 31} ${par - 6} L${tx - 47} ${floor - 2}`, '#3E4D52', { w: 0.45, seed: 'brace' }));""")
rep("""    // the two gossips, sitting on the parapet edge with the city behind them
    it.push(character('bolt', { x: 192, y: par - 2.5, s: 1.0, expr: 'whisper', world: w, lean: 12, look: [0.9, 0], seed: 'g1', groundShadow: false }));
    it.push(character('triangle', { x: 208, y: par - 2.5, s: 0.92, expr: 'shy', world: w, lean: -8, dir: -1, seed: 'g2', groundShadow: false }));
    it.push(whisper2(200, par - 32, w, 'wh'));""",
"""    // the two gossips, up on the tank stand's deck, each with a contact shadow on the steel
    it.push(character('bolt', { x: 189, y: par - 8.8, s: 1.0, expr: 'whisper', world: w, lean: 10, look: [0.9, 0], seed: 'g1' }));
    it.push(character('triangle', { x: 205, y: par - 9.1, s: 0.92, expr: 'shy', world: w, lean: -6, dir: -1, seed: 'g2' }));
    it.push(whisper2(197, par - 37, w, 'wh'));""")
rep("""  // the spotlight on the shy one
  const sx = wide ? 124 : 75;
  it.push(cone([[sx - 5, -4], [sx + 5, -4], [sx + (wide ? 25 : 23), ground + 2], [sx - (wide ? 23 : 22), ground + 2]], w.glow, defs, 0.3));""",
"""  // the light on the shy one has a source: a bare bulb on a cord, hung from the laundry line
  const sx = wide ? 124 : 75;
  const line = wide ? { x1: 106, y1: 38, cx: 175, cy: 46, x2: 246, y2: 30 } : { x1: -4, y1: 70, cx: 75, cy: 76, x2: 154, y2: 66 };
  const onLine = (t: number) => [(1 - t) ** 2 * line.x1 + 2 * t * (1 - t) * line.cx + t * t * line.x2, (1 - t) ** 2 * line.y1 + 2 * t * (1 - t) * line.cy + t * t * line.y2];
  const tAt = (x: number) => { let lo = 0, hi = 1; for (let i = 0; i < 30; i++) { const m = (lo + hi) / 2; if (onLine(m)[0] < x) lo = m; else hi = m; } return lo; };
  if (wide) {
    // an old TV antenna mast on the parapet holds the near end of the line
    it.push(thing(rect(105, 34, 1.5, par - 34 - 2), { fill: '#8FA3A8', ink: w.ink, w: 0.4, amp: 0.06, seed: 'mast' }));
    it.push(stroke(`M99 40 L112 39.4 M101 44.6 L110.6 44.2 M103 49 L109 48.8`, w.ink, { w: 0.55, seed: 'aerial' }));
  }
  it.push(stroke(`M${line.x1} ${line.y1} Q${line.cx} ${line.cy} ${line.x2} ${line.y2}`, '#C9D6D8', { w: 0.4, seed: 'lline' + L }));
  // laundry: a striped towel and a pair of socks, pegged
  const peg = (x: number, y: number, sd: string) => thing(rr(x - 0.5, y - 1.6, 1.0, 2.6, 0.4), { fill: '#D2694A', ink: w.ink, w: 0.3, amp: 0.03, seed: sd });
  { const [x0, y0] = onLine(wide ? 0.33 : 0.13), tw = wide ? 10 : 9, th = wide ? 12 : 10;
    it.push(thing(P([[x0, y0], [x0 + tw, y0 + 0.4], [x0 + tw + 0.4, y0 + th], [x0 + tw * 0.5, y0 + th - 0.6], [x0 - 0.3, y0 + th + 0.3]]), { fill: '#E9E1CF', ink: w.ink, w: 0.45, amp: 0.12, mis: w.mis, seed: 'towel' + L }));
    it.push(stroke(`M${x0 + 0.2} ${y0 + th * 0.62} L${x0 + tw + 0.2} ${y0 + th * 0.65} M${x0 + 0.1} ${y0 + th * 0.78} L${x0 + tw + 0.3} ${y0 + th * 0.8}`, w.c, { w: 0.9, seed: 'tstr' + L }));
    it.push(peg(x0 + 1.2, y0 + 0.4, 'pg1' + L)); it.push(peg(x0 + tw - 1.2, y0 + 0.6, 'pg2' + L)); }
  { const [x0, y0] = onLine(wide ? 0.52 : 0.84);
    for (const [dx, c] of [[0, w.b], [3.4, '#3F7FC0']] as [number, string][]) {
      const x = x0 + dx;
      it.push(thing(`M${x - 0.9} ${y0} L${x + 0.9} ${y0} L${x + 0.9} ${y0 + 5.6} C${x + 0.9} ${y0 + 6.8} ${x + 2.6} ${y0 + 6.6} ${x + 2.6} ${y0 + 7.6} C${x + 2.6} ${y0 + 8.6} ${x - 0.9} ${y0 + 8.6} ${x - 0.9} ${y0 + 7.0} Z`, { fill: c, ink: w.ink, w: 0.4, amp: 0.06, seed: 'sock' + dx + L }));
      it.push(peg(x, y0 + 0.3, 'pgs' + dx + L));
    } }
  // the bulb: cord knotted on the line, socket, bare glowing bulb
  const [kx, ky] = onLine(tAt(sx));
  const by = ky + (wide ? 10 : 5);
  it.push(stroke(`M${r2(kx)} ${r2(ky)} C${r2(kx - 0.8)} ${r2(ky + 2)} ${r2(sx + 0.6)} ${r2(by - 3)} ${r2(sx)} ${r2(by)}`, w.ink, { w: 0.45, seed: 'bcord' + L }));
  it.push(cone([[sx - 2.2, by + 2.4], [sx + 2.2, by + 2.4], [sx + (wide ? 26 : 23), ground + 2], [sx - (wide ? 24 : 22), ground + 2]], w.glow, defs, 0.3));
  it.push(glowDot(sx, by + 3, wide ? 16 : 13, w.glow, defs, 0.6));
  it.push(thing(rr(sx - 1.1, by - 0.4, 2.2, 2.6, 0.5), { fill: '#2B3B40', ink: w.ink, w: 0.4, amp: 0.04, seed: 'sock' + L }));
  it.push(blob(`M${sx - 1.4} ${by + 2.2} C${sx - 3.0} ${by + 3.4} ${sx - 2.4} ${by + 6.4} ${sx} ${by + 6.5} C${sx + 2.4} ${by + 6.4} ${sx + 3.0} ${by + 3.4} ${sx + 1.4} ${by + 2.2} Z`, '#FFFBE6', { seed: 'bulb' + L, amp: 0.08 }));
  it.push(stroke(`M${sx - 0.8} ${by + 3.2} L${sx - 0.3} ${by + 5.0} L${sx + 0.3} ${by + 3.8} L${sx + 0.8} ${by + 5.0}`, '#FFB84D', { w: 0.3, seed: 'fil' + L }));""")
open(p,'w').write(s)
