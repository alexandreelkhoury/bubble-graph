// Prototype (NOT compiled here: no Android SDK in this container). Compose for TV
// renderer for the generated HandmadePaths.kt. Paths are parsed ONCE per
// shape × frame and cached; the boil is a shared 10 fps clock read only in the
// draw phase, so a tick costs one redraw of each character's layer and no
// recomposition. Lite / calm motion: frame 0 forever, no misregistration offset
// change needed (it is part of the look), no hatch below 72 dp.
package app.jamaa.tv.characters

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay

private val Paper = Color(0xFFF3E6CF)
private val Ink = Color(0xFF2A1630)

class BoilPaths(val paper: Path, val fill: Path, val ink: Path, val line: Path, val hatch: Path, val eyes: Path, val mouth: Path)

/** Parse once, keep forever (12 shapes × 3 frames × 7 paths ≈ 250 small Paths). */
object BoilCache {
    private val cache = HashMap<String, Array<BoilPaths>>()
    private fun p(d: String): Path = PathParser().parsePathString(d).toPath() // [VERIFY] API name in the BOM in use
    fun get(id: String): Array<BoilPaths> = cache.getOrPut(id) {
        HandmadePaths.all.getValue(id).map { f ->
            BoilPaths(p(f.paper), p(f.fill), p(f.ink), p(f.line), p(f.hatch), p(f.eyes), p(f.mouth))
        }.toTypedArray()
    }
}

/** One clock for every character on screen (they boil on the same frame, like cel animation). */
val LocalBoilFrame = staticCompositionLocalOf<State<Int>> { mutableIntStateOf(0) }

@Composable
fun BoilClock(enabled: Boolean, content: @Composable () -> Unit) {
    val frame = remember { mutableIntStateOf(0) }
    if (enabled) LaunchedEffect(Unit) {
        while (true) { delay(1000L / HandmadePaths.BOIL_FPS); frame.intValue = (frame.intValue + 1) % HandmadePaths.VARIANTS }
    }
    CompositionLocalProvider(LocalBoilFrame provides frame, content = content)
}

@Composable
fun HandmadeCharacter(id: String, body: Color, glyph: Color, size: Dp, full: Boolean, modifier: Modifier = Modifier) {
    val frames = remember(id) { BoilCache.get(id) }
    val frameState = LocalBoilFrame.current
    Canvas(modifier.then(Modifier.size(size))) {
        val f = frames[frameState.value]          // state read in DRAW phase only
        val k = this.size.width / 28f              // viewBox -2 -2 28 28
        withTransform({ scale(k, k, Offset.Zero); translate(2f, 2f) }) {
            if (full) {
                drawPath(f.paper, Paper)
                drawPath(f.paper, Paper, style = Stroke(width = 1.8f, join = StrokeJoin.Round))
            }
            translate(HandmadePaths.MISREG_X, HandmadePaths.MISREG_Y) {
                drawPath(f.fill, body)
                if (full) clipPath(f.fill) { drawPath(f.hatch, Color(0x38120A1F)) }
            }
            if (full) drawPath(f.ink, Ink)
            else drawPath(f.line, Ink, style = Stroke(width = 0.95f, join = StrokeJoin.Round, cap = StrokeCap.Round))
            drawPath(f.eyes, glyph)
            drawPath(f.mouth, glyph)
        }
    }
}
// Grain: one 128×128 ImageBitmap decoded at start-up → ShaderBrush(ImageShader(tile, TileMode.Repeated, TileMode.Repeated))
// drawn over the stage at 6 % (DESIGN-JAMAA §1.5); off in lite/calm. RuntimeShader (API 33+) is NOT needed for any of this.
