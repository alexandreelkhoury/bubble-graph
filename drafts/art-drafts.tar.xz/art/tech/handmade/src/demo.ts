// The demo page: CSS-only boil (three pre-baked frames, stepped at 8/10/12 fps),
// compared with clean geometry and with a live feTurbulence filter.
import { SHAPES, idleFace } from './shapes.ts';

const INK = '#2A1630', PAPER = '#F3E6CF';
let uid = 0;

type C = { id: string; name: string; color: string; glyph: string; clean: string; variants: any[]; highlights: { x: number; y: number; r: number }[] };

function handSvg(c: C, size: number, extraClass = '') {
  // three stacked <svg> frames; CSS steps their opacity → compositor-only boil
  const id = `h${uid++}`;
  const frames = c.variants.map((v, k) => `<svg class="v v${k}" viewBox="-2 -2 28 28" aria-hidden="true">
      <path class="paper" d="${v.paper}"/>
      <clipPath id="${id}c${k}"><path d="${v.fill}"/></clipPath>
      <g class="mis"><path d="${v.fill}" fill="${c.color}"/><g class="hatch" clip-path="url(#${id}c${k})"><path d="${v.hatch}"/></g></g>
      <path class="ink" d="${v.ink}"/>
      <path class="line" d="${v.line}"/>
      <g fill="${c.glyph}"><path d="${v.eyes}"/><path d="${v.mouth}"/></g>
      ${c.highlights.map((h) => `<circle cx="${h.x}" cy="${h.y}" r="${h.r.toFixed(2)}" fill="#FFF7EC"/>`).join('')}
    </svg>`).join('');
  return `<span class="hand ${extraClass}" style="--s:${size}px">${frames}</span>`;
}

function cleanSvg(c: C, size: number, filter = '') {
  const s = SHAPES.find((x) => x.id === c.id)!, f = idleFace(s.face);
  return `<svg class="clean" viewBox="-2 -2 28 28" width="${size}" height="${size}" aria-hidden="true">
    <g ${filter ? `filter="url(#${filter})"` : ''}>
    <path d="${c.clean}" fill="${c.color}" stroke="${INK}" stroke-width=".95" stroke-linejoin="round"/>
    <path d="${f.eyes}" fill="${c.glyph}"/>
    <path d="${f.mouth}" fill="none" stroke="${c.glyph}" stroke-width="${f.mouthWidth}" stroke-linecap="round"/>
    ${c.highlights.map((h) => `<circle cx="${h.x}" cy="${h.y}" r="${h.r.toFixed(2)}" fill="#FFF7EC"/>`).join('')}
    </g></svg>`;
}

const kb = (n: number) => (n / 1024).toFixed(1) + ' KB';

export function demoHtml(chars: C[], sizes: any, grainUri: string, bench: any) {
  uid = 0;
  const star = chars.find((c) => c.id === 'star')!;
  const benchRows = bench ? bench.results.map((r: any) => `<tr><td>${r.label.replace(/&/g,'&amp;').replace(/</g,'&lt;')}</td>${r.runs.map((x: any) => `<td>${x.fps.toFixed(0)} f/s<br>main ${x.mainMsPerSec.toFixed(0)}<br>raster ${x.rasterMsPerSec.toFixed(0)}<br>draw ${x.vizMsPerSec.toFixed(0)}</td>`).join('')}</tr>`).join('') : '';
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Hand-made Boil</title>
<style>
:root{--bg:#1D1036;--bgTop:#2B1650;--surface:#3A2266;--text:#FFF7EC;--muted:#B8A8D6;--accent:#FFC94D;--primary:#FF4F9A;
  --ink:${INK};--paper:${PAPER};--period:.3s;color-scheme:dark}
:root[data-theme="light"]{--bg:#1D1036}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#1D1036}}
:root[data-theme="dark"]{--bg:#1D1036}
*{box-sizing:border-box}
html,body{margin:0;background:var(--bg);color:var(--text);font:16px/1.45 ui-sans-serif,system-ui,"Segoe UI",Roboto,sans-serif}
body{min-height:100vh;background:
  radial-gradient(90% 55% at 50% -5%,rgb(140 80 230/.45),transparent 70%),
  radial-gradient(70% 45% at 105% 100%,rgb(255 201 77/.14),transparent 70%),
  radial-gradient(60% 50% at -10% 60%,rgb(255 79 154/.12),transparent 70%),
  linear-gradient(180deg,var(--bgTop),#24124A 55%,var(--bg))}
body::after{content:"";position:fixed;inset:0;pointer-events:none;background:url(${grainUri});filter:invert(1);opacity:.07}
body:not(.grain)::after{display:none}
main{max-width:1180px;margin:0 auto;padding:28px 16px 64px}
h1{font:800 clamp(28px,5vw,44px)/1.05 ui-rounded,"SF Pro Rounded",system-ui,sans-serif;margin:0 0 6px;letter-spacing:-.01em}
h1 em{font-style:normal;color:var(--accent)}
h2{font:700 13px/1 system-ui;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin:40px 0 14px}
p.lede{color:#E2D6F5;max-width:62ch;margin:0}
.controls{display:flex;flex-wrap:wrap;gap:10px 18px;margin:22px 0 4px;align-items:center}
.seg{display:inline-flex;background:rgb(0 0 0/.25);border-radius:999px;padding:3px;gap:2px}
.seg button,.tog{font:600 14px system-ui;color:var(--text);background:none;border:0;border-radius:999px;padding:7px 13px;cursor:pointer}
.seg button[aria-pressed="true"]{background:var(--accent);color:#120A1F}
.tog{background:rgb(0 0 0/.25)}.tog[aria-pressed="true"]{box-shadow:inset 0 0 0 2px var(--accent)}
.lbl{font:600 12px system-ui;color:var(--muted);letter-spacing:.08em;text-transform:uppercase}
.trio{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.card{background:rgb(58 34 102/.55);border-radius:22px;padding:14px 14px 12px;display:flex;flex-direction:column;align-items:center}
.card svg.clean{width:100%;height:auto;max-width:300px}.card .hand{width:100%;max-width:300px}
.card b{font:700 15px system-ui;margin-top:4px}.card small{color:var(--muted);text-align:center}
.stage{display:grid;grid-template-columns:repeat(6,1fr);gap:18px 8px;padding:26px 10px 18px;border-radius:26px;background:rgb(0 0 0/.18)}
.who{display:flex;flex-direction:column;align-items:center;gap:2px}
.body{position:relative;width:96px;height:96px;transform-origin:50% 100%}
.anim .body{animation:breathe 3.2s ease-in-out infinite}
.who:nth-child(3n) .body{animation-delay:-1.1s}.who:nth-child(3n+1) .body{animation-delay:-2.3s}
.shadow{width:58px;height:9px;border-radius:50%;background:rgb(0 0 0/.3);margin-top:-12px}
.who span{font:700 14px system-ui;margin-top:4px}
@keyframes breathe{50%{transform:scale(1.012,1.02)}}
/* ------- the boil: three frames, one visible at a time, CSS only ------- */
.hand{position:relative;display:block;width:var(--s);max-width:100%;aspect-ratio:1}
.hand .v{position:absolute;inset:0;width:100%;height:100%;opacity:0}
.hand .v0{opacity:1}
.boil .hand .v{animation:boil var(--period) steps(1,end) infinite;will-change:opacity}
.boil .hand .v1{animation-delay:calc(var(--period) / -3 * 2)}
.boil .hand .v2{animation-delay:calc(var(--period) / -3)}
@keyframes boil{0%{opacity:1}33.333%,100%{opacity:0}}
.frozen .hand .v{animation:none!important}
@media (prefers-reduced-motion:reduce){.hand .v{animation:none!important}.body{animation:none!important}}
/* layers */
.hand .paper{fill:var(--paper);stroke:var(--paper);stroke-width:1.8;stroke-linejoin:round}
.hand .ink{fill:var(--ink)}
.hand .line{fill:none;stroke:var(--ink);stroke-width:.95;stroke-linejoin:round;stroke-linecap:round;display:none}
body.stroke .hand .ink{display:none} body.stroke .hand .line{display:inline}
.hand .hatch path{fill:#120A1F;opacity:.22} body:not(.hatch) .hand .hatch{display:none}
body.misreg .hand .mis{transform:translate(-.35px,.3px)}
body:not(.paper) .hand .paper{display:none}
table{width:100%;border-collapse:collapse;font-size:14px}.scroll{overflow-x:auto;max-width:100%}table.bench{min-width:760px}table.bench td{white-space:nowrap}table.bench td:first-child{white-space:normal;min-width:220px}
html,body{overflow-x:hidden}
td,th{padding:8px 10px;border-bottom:1px solid rgb(255 255 255/.08);text-align:start;vertical-align:top}
th{color:var(--muted);font-weight:600}
code{font:13px ui-monospace,Menlo,monospace;color:#FFD9A0}
.note{color:var(--muted);font-size:14px;max-width:75ch}
@media (max-width:760px){.trio{grid-template-columns:1fr 1fr}.trio .card:first-child{grid-column:1/-1}.stage{grid-template-columns:repeat(3,1fr)}}
@media (max-width:420px){.body{width:84px;height:84px}.body .hand{width:84px}}
</style></head>
<body class="boil anim hatch misreg paper grain">
<svg width="0" height="0" style="position:absolute">${[1, 2, 3].map((k) => `<filter id="wob${k}" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency=".09" numOctaves="2" seed="${k}"/><feDisplacementMap in="SourceGraphic" scale="1.1" xChannelSelector="R" yChannelSelector="G"/></filter>`).join('')}</svg>
<main>
<h1>Drawn by a hand, <em>not a filter</em></h1>
<p class="lede">Each character is clean geometry run through a seeded generator: three passes of the same "hand", cycled at 10 fps. Paper backing, a misregistered colour fill, a pressure ink line that overshoots its own start, and a few hatch strokes on the shadow side. No runtime noise, no JavaScript for the boil, no main-thread work per frame.</p>
<div class="controls">
  <span class="lbl">Boil</span>
  <span class="seg" id="fps"><button data-fps="0">Off</button><button data-fps="8">8 fps</button><button data-fps="10" aria-pressed="true">10 fps</button><button data-fps="12">12 fps</button></span>
  <span class="lbl">Ink</span>
  <span class="seg" id="ink"><button data-ink="ribbon" aria-pressed="true">Pen ribbon</button><button data-ink="stroke">Plain stroke</button></span>
  <button class="tog" data-cls="paper" aria-pressed="true">Paper</button>
  <button class="tog" data-cls="misreg" aria-pressed="true">Misregister</button>
  <button class="tog" data-cls="hatch" aria-pressed="true">Hatch</button>
  <button class="tog" data-cls="grain" aria-pressed="true">Grain</button>
</div>

<h2>Same character, three ways</h2>
<div class="trio">
  <div class="card">${cleanSvg(star, 300)}<b>Clean geometry</b><small>The DESIGN §5.2 glyph as it is today</small></div>
  <div class="card">${handSvg(star, 300)}<b>Hand-made, boiling</b><small>3 pre-baked frames, CSS opacity steps() on the compositor</small></div>
  <div class="card" id="livecard">${cleanSvg(star, 300, 'wob1')}<b>Live SVG filter</b><small>feTurbulence + feDisplacementMap, 3 seeds swapped at the same fps (for comparison only)</small></div>
</div>

<h2>The twelve, on stage at 96 px</h2>
<div class="stage">
${chars.map((c) => `<div class="who"><div class="body">${handSvg(c, 96)}</div><div class="shadow"></div><span>${c.name}</span></div>`).join('\n')}
</div>

<h2>What it costs</h2>
<div class="scroll"><table>
<tr><th>Payload</th><th>Raw</th><th>gzip -9</th></tr>
<tr><td>All 12 characters × ${sizes.variants} frames, full look (paper, fill, ink ribbon, hatch, face)</td><td>${kb(sizes.total.fullBytes)}</td><td>${kb(sizes.total.fullGz)}</td></tr>
<tr><td>All 12 × ${sizes.variants}, lite look (fill + plain stroke + face)</td><td>${kb(sizes.total.liteBytes)}</td><td>${kb(sizes.total.liteGz)}</td></tr>
<tr><td>One character, full look (Lemon star)</td><td>${kb(sizes.perChar.find((p: any) => p.id === 'star').full)}</td><td>${kb(sizes.perChar.find((p: any) => p.id === 'star').fullGz)}</td></tr>
${sizes.runtimeGenerator ? `<tr><td>Or: the generator itself, shipped to the phone (generates all 36 frames at start-up)</td><td>${kb(sizes.runtimeGenerator.min)}</td><td>${kb(sizes.runtimeGenerator.gz)}</td></tr>` : ''}
<tr><td>Kotlin <code>HandmadePaths.kt</code> (strings, parsed once with PathParser)</td><td>${kb(sizes.kotlin.bytes)}</td><td>${kb(sizes.kotlin.gz)}</td></tr>
<tr><td>Grain tile 128 × 128 (PNG palette / WebP)</td><td colspan="2">${sizes.grain.png} B / ${sizes.grain.webp} B</td></tr>
<tr><td>Lottie export of the star (hold keyframes)</td><td>${kb(sizes.lottieStar.bytes)}</td><td>${kb(sizes.lottieStar.gz)}</td></tr>
</table></div>
${bench ? `<h2>Measured in Chromium ${bench.chromium} (${bench.viewport}, 12 characters at 96 px)</h2>
<div class="scroll"><table class="bench"><tr><th>Technique</th>${bench.columns.map((t: string) => `<th>${t}</th>`).join('')}</tr>${benchRows}</table></div>
<p class="note">${bench.note}</p>` : ''}
<p class="note">Reduced motion (or "Off") freezes frame 0: the drawing stays hand-made, it just stops breathing.</p>
</main>
<script>
(()=>{const b=document.body,root=document.documentElement;let timer=0,seed=1;
const wob=document.querySelector('#livecard g[filter]');
function setFps(f){b.classList.toggle('boil',f>0);b.classList.toggle('frozen',f===0);
  if(f)root.style.setProperty('--period',(3/f)+'s');
  clearInterval(timer);if(f&&!matchMedia('(prefers-reduced-motion: reduce)').matches)timer=setInterval(()=>wob.setAttribute('filter','url(#wob'+(seed=seed%3+1)+')'),1000/f);}
document.querySelectorAll('#fps button').forEach(x=>x.onclick=()=>{document.querySelectorAll('#fps button').forEach(y=>y.setAttribute('aria-pressed',String(y===x)));setFps(+x.dataset.fps)});
document.querySelectorAll('#ink button').forEach(x=>x.onclick=()=>{document.querySelectorAll('#ink button').forEach(y=>y.setAttribute('aria-pressed',String(y===x)));b.classList.toggle('stroke',x.dataset.ink==='stroke')});
document.querySelectorAll('.tog').forEach(x=>x.onclick=()=>{const on=x.getAttribute('aria-pressed')!=='true';x.setAttribute('aria-pressed',String(on));b.classList.toggle(x.dataset.cls,on)});
setFps(10);})();
</script>
</body></html>`;
}
