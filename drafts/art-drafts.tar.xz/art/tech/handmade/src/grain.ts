// Seamless 128×128 paper/print grain, deterministic. Returns 8-bit gray + alpha
// (alpha carries the texture; gray is constant) so it can be laid over any
// colour with normal blending, or used as luminance for multiply/overlay.
import { rng } from './handmade.ts';

export function grainTile(size = 128, seed = 7) {
  const r = rng(seed);
  // periodic value noise at a few octaves (wraps at `size`, so the tile repeats seamlessly)
  const octave = (cells: number) => {
    const g = Array.from({ length: cells * cells }, () => r());
    const at = (x: number, y: number) => g[((y + cells) % cells) * cells + ((x + cells) % cells)];
    const sm = (t: number) => t * t * (3 - 2 * t);
    return (x: number, y: number) => {
      const fx = (x / size) * cells, fy = (y / size) * cells;
      const x0 = Math.floor(fx), y0 = Math.floor(fy), tx = sm(fx - x0), ty = sm(fy - y0);
      const a = at(x0, y0), b = at(x0 + 1, y0), c = at(x0, y0 + 1), d = at(x0 + 1, y0 + 1);
      return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
    };
  };
  const o1 = octave(8), o2 = octave(32), o3 = octave(64);
  const px = new Uint8Array(size * size * 2);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    // paper tooth: mid-frequency clumps + fine speckle; a few dark "fibre" pits
    let v = 0.25 * o1(x, y) + 0.35 * o2(x, y) + 0.4 * o3(x, y);
    v = (v - 0.5) * 1.6 + (r() - 0.5) * 0.35;
    if (r() < 0.004) v += 0.9;
    const a = Math.max(0, Math.min(1, v + 0.15));
    const i = (y * size + x) * 2;
    px[i] = 18; px[i + 1] = Math.round(a * 255); // ink-coloured grain; scale opacity at use site
  }
  return { size, px };
}
