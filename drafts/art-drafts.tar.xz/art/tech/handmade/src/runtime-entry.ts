// What a phone would ship if it generated the frames itself (instead of baked SVG strings).
import { handmade, handStroke, handBlob } from './handmade.ts';
import { SHAPES, idleFace } from './shapes.ts';
export function generateAll(variants = 3) {
  return SHAPES.map((s) => {
    const f = idleFace(s.face);
    return { id: s.id, body: handmade(s.d, { seed: s.id, variants }), eyes: handBlob(f.eyes, { seed: s.id, variants }), mouth: handStroke(f.mouth, { seed: s.id, variants, width: f.mouthWidth }) };
  });
}
(globalThis as any).generateAll = generateAll;
