// Character bodies (DESIGN.md §5.2 glyph geometry, 24-unit box) and face boxes
// (DESIGN-JAMAA §4.2). Primitives are converted to path data so the generator
// has one input format. The flower is authored as its true outline (four
// semicircles meeting at the lobe intersections) instead of five overlapping
// circles: an outline needs one silhouette.
import { circleD, rrectD } from './handmade.ts';

export type ShapeDef = { id: string; color: string; name: string; d: string; face: { x: number; y: number; w: number; h: number }; glyph: 'ink' | 'cream' };

export const SHAPES: ShapeDef[] = [
  { id: 'circle', name: 'Coral', color: '#F0183A', glyph: 'ink', d: circleD(12, 12, 9), face: { x: 6, y: 7.5, w: 12, h: 9 } },
  { id: 'square', name: 'Azure', color: '#478CFF', glyph: 'ink', d: rrectD(3.5, 3.5, 17, 17, 3.5), face: { x: 6, y: 7.5, w: 12, h: 9 } },
  { id: 'star', name: 'Lemon', color: '#FFF04D', glyph: 'ink', d: 'M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z', face: { x: 8, y: 9, w: 8, h: 6 } },
  { id: 'triangle', name: 'Jade', color: '#1FA88A', glyph: 'ink', d: 'M12 2.4 21.4 19H2.6z', face: { x: 7.5, y: 11.5, w: 9, h: 6.75 } },
  { id: 'diamond', name: 'Grape', color: '#7A43FF', glyph: 'cream', d: 'M12 2.2 21.8 12 12 21.8 2.2 12z', face: { x: 7, y: 8, w: 10, h: 7.5 } },
  { id: 'hexagon', name: 'Tangerine', color: '#FF7A1F', glyph: 'ink', d: 'M12 2.6 20.2 7.3v9.4L12 21.4 3.8 16.7V7.3z', face: { x: 6.5, y: 7.5, w: 11, h: 8.25 } },
  { id: 'plus', name: 'Aqua', color: '#7BFFF4', glyph: 'ink', d: 'M9 3h6v6h6v6h-6v6H9v-6H3V9h6z', face: { x: 8.5, y: 8.5, w: 7, h: 7 } },
  { id: 'drop', name: 'Rose', color: '#FF96C5', glyph: 'ink', d: 'M12 1.25S5 9.15 5 13.75a7 7 0 0 0 14 0c0-4.6-7-12.5-7-12.5z', face: { x: 7, y: 11, w: 10, h: 7.5 } },
  { id: 'crescent', name: 'Mint', color: '#BDF5C8', glyph: 'ink', d: 'M15 2.7a9.5 9.5 0 1 0 6.3 13.6A7.6 7.6 0 0 1 15 2.7z', face: { x: 4, y: 9, w: 8, h: 6 } },
  { id: 'bolt', name: 'Plum', color: '#C02A8F', glyph: 'cream', d: 'M13.5 2 5 13.5h6L10 22l9-12h-6.2z', face: { x: 8.5, y: 9.5, w: 6, h: 4.5 } },
  { id: 'flower', name: 'Sand', color: '#E6C486', glyph: 'ink', d: 'M7.4 7.4A4.6 4.6 0 0 1 16.6 7.4A4.6 4.6 0 0 1 16.6 16.6A4.6 4.6 0 0 1 7.4 16.6A4.6 4.6 0 0 1 7.4 7.4z', face: { x: 7.5, y: 7.5, w: 9, h: 9 } },
  { id: 'arch', name: 'Lilac', color: '#C9BFFF', glyph: 'ink', d: 'M5 20.75V10.25a7 7 0 0 1 14 0v10.5h-4.5v-6.5a2.5 2.5 0 0 0-5 0v6.5z', face: { x: 7, y: 8.5, w: 10, h: 7.5 } },
];

/** Idle face in face space (12 × 9), mapped into body units by the face box. */
export function idleFace(f: ShapeDef['face']) {
  const k = f.w / 12, X = (u: number) => +(f.x + u * k).toFixed(3), Y = (v: number) => +(f.y + v * k).toFixed(3);
  const e = (cx: number) => `M${X(cx - 1.1)} ${Y(3.6)}a${1.1 * k} ${1.45 * k} 0 1 0 ${2.2 * k} 0a${1.1 * k} ${1.45 * k} 0 1 0 ${-2.2 * k} 0z`;
  return {
    eyes: e(3.8) + e(8.2),
    highlights: [{ x: X(3.8 + 0.35), y: Y(3.6 - 0.45), r: 0.35 * k }, { x: X(8.2 + 0.35), y: Y(3.6 - 0.45), r: 0.35 * k }],
    mouth: `M${X(4.4)} ${Y(6.6)}Q${X(6)} ${Y(7.6)} ${X(7.6)} ${Y(6.6)}`,
    mouthWidth: 0.8 * k,
    cheeks: [{ x: X(2.2), y: Y(5.8), r: 0.9 * k }, { x: X(9.8), y: Y(5.8), r: 0.9 * k }],
  };
}
