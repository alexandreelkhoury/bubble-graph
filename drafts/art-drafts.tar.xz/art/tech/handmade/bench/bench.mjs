// Frame-cost benchmark: 12 characters at 96 px on a 1280×720 "TV" page, 5 s per
// scenario, CPU throttled ×1/×4/×6 (CDP). Main-thread and raster busy time from
// a Chromium trace; frames/s = frames the display compositor actually drew (a 10 fps boil should be ~10).
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
const require = createRequire(import.meta.url);
process.env.PLAYWRIGHT_BROWSERS_PATH = '/opt/pw-browsers';
const { chromium } = require('/home/user/bubble-graph/node_modules/.pnpm/playwright@1.63.0/node_modules/playwright');
const OUT = new URL('../out/', import.meta.url).pathname;
const chars = JSON.parse(readFileSync(OUT + 'characters.boil.json', 'utf8'));
const runtime = readFileSync(OUT + 'runtime.min.js', 'utf8');
const rough = readFileSync(new URL('../../bench/node_modules/roughjs/bundled/rough.js', import.meta.url), 'utf8');
const SECONDS = Number(process.env.SECONDS ?? 5);
const THROTTLES = (process.env.THROTTLES ?? '1,6').split(',').map(Number);
const DSFS = (process.env.DSFS ?? '1,2').split(',').map(Number);

const layers = (v, c) => `<path fill="#F3E6CF" stroke="#F3E6CF" stroke-width="1.8" stroke-linejoin="round" d="${v.paper}"/>
  <g transform="translate(-.35 .3)"><path fill="${c.color}" d="${v.fill}"/><path fill="#120A1F" opacity=".22" d="${v.hatch}"/></g>
  <path fill="#2A1630" d="${v.ink}"/><g fill="${c.glyph}"><path d="${v.eyes}"/><path d="${v.mouth}"/></g>`;
const svg = (inner, extra = '') => `<svg viewBox="-2 -2 28 28" width="96" height="96" ${extra}>${inner}</svg>`;

const scenarios = {
  'Static hand-made (boil off)': () => chars.map((c) => svg(layers(c.variants[0], c))).join(''),
  'Boil: CSS steps(), visibility of 3 <g> in one <svg>': () =>
    chars.map((c) => svg(c.variants.map((v, k) => `<g class="v v${k}">${layers(v, c)}</g>`).join(''))).join('') +
    `<style>.v{visibility:hidden;animation:b .3s steps(1,end) infinite}.v1{animation-delay:-.2s}.v2{animation-delay:-.1s}@keyframes b{0%{visibility:visible}33.333%,100%{visibility:hidden}}</style>`,
  'Boil: 3 stacked <svg> layers, opacity steps() (compositor, recommended)': () =>
    chars.map((c) => `<div style="position:relative;width:96px;height:96px;display:inline-block">${c.variants.map((v, k) => svg(layers(v, c), `class="L L${k}" style="position:absolute;inset:0"`)).join('')}</div>`).join('') +
    `<style>.L{will-change:opacity;opacity:0;animation:o .3s steps(1,end) infinite}.L1{animation-delay:-.2s}.L2{animation-delay:-.1s}@keyframes o{0%{opacity:1}33.333%,100%{opacity:0}}</style>`,
  'Boil: JS swaps path d at 10 fps': () =>
    chars.map((c, i) => svg(layers(c.variants[0], c), `data-i="${i}"`)).join('') +
    `<script>const D=${JSON.stringify(chars.map((c) => c.variants.map((v) => [v.paper, v.fill, v.hatch, v.ink, v.eyes, v.mouth])))};let f=0;
     const P=[...document.querySelectorAll('svg')].map(s=>[...s.querySelectorAll('path')]);
     setInterval(()=>{f=(f+1)%3;P.forEach((ps,i)=>ps.forEach((p,j)=>p.setAttribute('d',D[i][f][j])))},100)</script>`,
  'Live filter: feTurbulence+feDisplacementMap, static': () => filterPage(false),
  'Live filter: feTurbulence, seed animated at 10 fps': () => filterPage(true),
  'roughjs: regenerate 12 shapes at 10 fps': () =>
    chars.map(() => svg('<path fill="none" stroke="#2A1630" stroke-width=".9"/><path class="f"/>')).join('') +
    `<script>${rough}</script><script>const C=${JSON.stringify(chars.map((c) => [c.clean, c.color]))};const g=rough.generator();let s=1;
     const P=[...document.querySelectorAll('svg')].map(x=>x.querySelectorAll('path'));
     setInterval(()=>{s++;C.forEach(([d,col],i)=>{const sh=g.path(d,{seed:s%3+1,roughness:1.2,fill:col,fillStyle:'hachure'});const ps=g.toPaths(sh);P[i][0].setAttribute('d',ps.map(p=>p.d).join(''));})},100)</script>`,
};
function filterPage(animated) {
  // three filters with different seeds; the boil swaps the filter reference (changing a
  // feTurbulence attribute in place does not schedule a repaint in Chromium 14x: measured)
  const f = (k) => `<filter id="w${k}" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency=".09" numOctaves="2" seed="${k}"/><feDisplacementMap in="SourceGraphic" scale="1.1" xChannelSelector="R" yChannelSelector="G"/></filter>`;
  return `<svg width="0" height="0" style="position:absolute">${f(1)}${f(2)}${f(3)}</svg>` +
    chars.map((c) => svg(`<g class="wb" filter="url(#w1)"><path d="${c.clean}" fill="${c.color}" stroke="#2A1630" stroke-width=".95"/></g>`)).join('') +
    (animated ? `<script>let s=1;const G=[...document.querySelectorAll('.wb')];setInterval(()=>{s=s%3+1;G.forEach(g=>g.setAttribute('filter','url(#w'+s+')'))},100)</script>` : '');
}

const page = (body) => `<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;background:#1D1036;display:flex;flex-wrap:wrap;gap:40px;padding:120px 160px;width:1280px;height:720px;box-sizing:border-box}</style></head><body>${body}
</body></html>`;

const b = await chromium.launch({ args: ['--enable-gpu-rasterization'] });
const version = b.version();
const results = [];
const dir = mkdtempSync(tmpdir() + '/boilbench-');
for (const [label, make] of Object.entries(scenarios).filter(([l]) => !process.env.ONLY || l.includes(process.env.ONLY))) {
  const runs = [];
  for (const dsf of DSFS) for (const thr of THROTTLES) {
    const p = await b.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: dsf });
    const cdp = await p.context().newCDPSession(p);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: thr });
    const file = `${dir}/s.html`; writeFileSync(file, page(make()));
    await p.goto('file://' + file);
    await p.waitForTimeout(800);
    const tracePath = `${dir}/t.json`;
    await b.startTracing(p, { path: tracePath, categories: ['devtools.timeline', 'disabled-by-default-devtools.timeline', 'cc', 'toplevel', 'viz'] });
    await p.waitForTimeout(SECONDS * 1000);
    await b.stopTracing();
    const tr = JSON.parse(readFileSync(tracePath, 'utf8'));
    const ev = tr.traceEvents ?? tr;
    const names = {}; for (const e of ev) if (e.ph === 'M' && e.name === 'thread_name') names[`${e.pid}:${e.tid}`] = e.args.name;
    let main = 0, raster = 0, paint = 0, viz = 0, frames = 0;
    for (const e of ev) {
      if (e.ph !== 'X' || !e.dur) continue;
      const th = names[`${e.pid}:${e.tid}`] ?? '';
      if (th === 'CrRendererMain' && e.name === 'ThreadControllerImpl::RunTask') main += e.dur;
      if ((th.startsWith('ThreadPoolForegroundWorker') || th.startsWith('CompositorTileWorker')) && e.name === 'RasterTask') raster += e.dur;
      if (th === 'CrRendererMain' && e.name === 'Paint') paint += e.dur;
      if (th === 'VizCompositorThread' && e.name === 'Display::DrawAndSwap') { viz += e.dur; frames++; }
    }
    const per = (x) => x / 1000 / SECONDS;
    runs.push({ dsf, throttle: thr, fps: frames / SECONDS, mainMsPerSec: per(main), rasterMsPerSec: per(raster), paintMsPerSec: per(paint), vizMsPerSec: per(viz) });
    await p.close();
  }
  results.push({ label, runs });
  console.log(label.padEnd(64), runs.map((r) => `dpr${r.dsf} x${r.throttle}: ${r.fps.toFixed(1)} frames/s main ${r.mainMsPerSec.toFixed(1)} raster ${r.rasterMsPerSec.toFixed(1)} viz ${r.vizMsPerSec.toFixed(1)}`).join(' | '));
}

// runtime generation cost (phone option): generate all 12 × 3 in the page
const gen = [];
for (const thr of THROTTLES) {
  const p = await b.newPage();
  const cdp = await p.context().newCDPSession(p);
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: thr });
  await p.setContent('<html><body></body></html>');
  const ms = await p.evaluate((src) => { const t = performance.now(); (0, eval)(src); const t1 = performance.now(); globalThis.generateAll(3); const t2 = performance.now(); globalThis.generateAll(3); return [t1 - t, t2 - t1, performance.now() - t2]; }, runtime);
  gen.push({ throttle: thr, evalMs: ms[0], firstMs: ms[1], warmMs: ms[2] });
  await p.close();
}
console.log('runtime generator', gen);
await b.close();
writeFileSync(OUT + 'bench.json', JSON.stringify({
  chromium: version, viewport: '1280×720', throttles: THROTTLES, dsfs: DSFS, columns: DSFS.flatMap((d) => THROTTLES.map((t) => `DPR ${d}, CPU ×${t}`)), seconds: SECONDS, results, runtimeGeneration: gen,
  note: `Headless Chromium ${version} on this container (no GPU: compositing and raster are software). CPU ×N is CDP main-thread throttling; raster workers are not throttled, so raster + viz ms/s (software rasterisation and drawing) are the honest cost signal for a weak SoC GPU path. ms/s = busy milliseconds per wall-clock second (1000 = one core saturated).`,
}, null, 2));
