import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
process.env.PLAYWRIGHT_BROWSERS_PATH = '/opt/pw-browsers';
const { chromium } = require('/home/user/bubble-graph/node_modules/.pnpm/playwright@1.63.0/node_modules/playwright');
const out = new URL('../out/', import.meta.url).pathname;
const b = await chromium.launch();
for (const [w, h, name, rm] of [[1280, 1700, 'demo-desktop.png', false], [390, 1500, 'demo-phone.png', false]]) {
  const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: name.includes('phone') ? 2 : 1 });
  await p.goto('file://' + out + 'demo.html');
  await p.evaluate(() => document.body.classList.add('frozen'));
  await p.screenshot({ path: out + name, fullPage: true });
  await p.close();
}
// three boil frames of the hero, side by side
const p = await b.newPage({ viewport: { width: 1000, height: 400 }, deviceScaleFactor: 1 });
await p.goto('file://' + out + 'demo.html');
for (let k = 0; k < 3; k++) {
  await p.evaluate((k) => { document.body.classList.add('frozen'); document.querySelectorAll('.trio .hand .v').forEach((g) => g.style.opacity = g.classList.contains('v' + k) ? '1' : '0'); }, k);
  await p.locator('.trio .card').nth(1).locator('.hand').screenshot({ path: out + `hero-frame${k}.png` });
}
await b.close();
