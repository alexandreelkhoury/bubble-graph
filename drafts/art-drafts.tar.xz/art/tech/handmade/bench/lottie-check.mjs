import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
process.env.PLAYWRIGHT_BROWSERS_PATH = '/opt/pw-browsers';
const { chromium } = require('/home/user/bubble-graph/node_modules/.pnpm/playwright@1.63.0/node_modules/playwright');
const OUT = new URL('../out/', import.meta.url).pathname;
const lib = readFileSync(new URL('../../bench/node_modules/lottie-web/build/player/lottie_light.min.js', import.meta.url), 'utf8');
const data = readFileSync(OUT + 'lottie-star.json', 'utf8');
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 900, height: 300 } });
await p.setContent(`<body style="margin:0;background:#2a1850;display:flex">${[0,1,2].map(i=>`<div id="a${i}" style="width:300px;height:300px"></div>`).join('')}<script>${lib}</script><script>
const d=${data};window.ok=[0,1,2].map(i=>{const a=lottie.loadAnimation({container:document.getElementById('a'+i),renderer:'svg',loop:false,autoplay:false,animationData:d});a.goToAndStop(i*3,true);return a.totalFrames});</script></body>`);
console.log('frames', await p.evaluate(() => window.ok));
await p.screenshot({ path: OUT + 'lottie-frames.png' }); await b.close();
