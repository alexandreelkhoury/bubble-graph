# Hand-made look in code: technique and pipeline (JAMAA)

Status: researched and prototyped on 2026-11-08. All numbers below were measured in this container
(Node 22.23, headless Chromium 153.0.8010.12, esbuild 0.25.12, `gzip -9`). There was no Android SDK, so the
Compose part is code plus reasoning and is marked [VERIFY ON DEVICE].

Prototype: `handmade/` (run `npm run build`, then `npm run bench`). Demo: `handmade/out/demo.html`.

---

## 1. What makes a drawing feel hand-made (and what we will not do)

An artist's line is not a perfect path with noise added. It has:

1. **Slow bows, not buzz.** The wrist wobbles over 5–16 units of the 24-unit body box. High-frequency jitter reads as "filter".
2. **Corners stay corners.** A star point is still sharp. The wobble moves the corner but doesn't round it.
3. **One stroke that closes itself.** The pen starts somewhere, goes round, and **overshoots its own start**, slightly off the line (the "lift").
4. **Pressure.** The width swells and thins along the stroke and tapers where the pen lands and lifts.
5. **The colour is a separate pass.** In print (riso, screen print, a kid's colouring book) the fill never sits exactly inside the line. A fixed **misregistration** offset (−0.35, +0.30 units) shows that.
6. **A material.** Cut-paper backing (the shilleh as shadow-puppet/sticker cut-outs: a nod to Levantine *khayal al-zill* / Karagöz), paper grain, a few hatch strokes on the shadow side.
7. **Boil.** In hand animation every frame is redrawn, so the line "breathes" even on a held pose. 3 drawings cycled at 8–12 fps ("on twos/threes") give that. **Everything boils on the same frame**, like cels.

Rejected: AI image generation; glossy gradients on characters; live noise filters as the main look; random-per-load jitter (it isn't art direction, and it can't be tested).

## 2. Techniques evaluated

### 2.1 Measured frame cost (12 characters at 96 px, 1280×720, 5 s per run)

`frames/s` counts frames the display compositor actually drew. `ms/s` is busy time per wall-clock second (1000 = one core).
CPU ×6 is CDP main-thread throttling, used as a rough stand-in for a low-end TV SoC. Raster workers aren't throttled, and this container has no GPU, so raster and draw are software.

| Technique | DPR 1, CPU ×1: main / raster / draw | DPR 1, CPU ×6: main / raster / draw | Verdict |
|---|---|---|---|
| Static hand-made (boil off) | 0.2 / 0 / 0 (0 frames) | 0.7 / 0 / 0 | the reduced-motion state costs nothing |
| **3 stacked `<svg>` frames, CSS `opacity` `steps()` + `will-change`** | **0.3 / 0 / 7.3** (10 f/s) | **1.0 / 0 / 7.4** | **Recommended for web.** No main-thread work. Each frame is rasterised once and the compositor flips layers. |
| JS swaps `d` of each path at 10 fps | 17 / 37 / 10 | 114 / 39 / 10 | Fallback when layers are not wanted (e.g. 100+ sprites) |
| CSS `steps()` on `visibility` of 3 `<g>` in one `<svg>` | 45 / 36 / 11 | 259 / 39 / 11 | Avoid: a main-thread animation ticks style and paint every vsync |
| feTurbulence + feDisplacementMap, 3 filters swapped at 10 fps | 11.5 / **56** / 10 | 60 / **59** / 10 | **Rejected** as the main look: the most raster work, the cost grows with pixel area, it looks like a filter (uniform, high-frequency) and there is no Compose equivalent below API 33 |
| feTurbulence static (no boil) | 0.2 / 0 / 0 | 1.1 / 0 / 0 | Fine as a one-off static texture. We don't need it. |
| roughjs regenerating 12 shapes at 10 fps | 29 / 26 / 11 | 183 / 26 / 10 | Rejected at runtime. It is also 9.2 KB gz (see 2.2). |

DPR 2 gave the same numbers within noise (see `handmade/out/bench.json`).

Gotcha (measured): changing `seed` or `baseFrequency` on an `feTurbulence` in place does **not** schedule a repaint in Chromium 153. 0 frames were drawn even though a screenshot shows the change. A filter boil has to swap the `filter="url(#…)"` reference between 3 pre-declared filters.

Runtime generation (the phone could run the generator itself): all 12 × 3 frames take **61 ms** cold / 38 ms warm at CPU ×1, and **350 / 248 ms at ×6**. That is too slow to do in one go at start-up on a weak phone, but each character takes about 5–30 ms, so it is fine lazily, one character at a time in `requestIdleCallback`.

### 2.2 Libraries (bundled one import with esbuild `--minify --format=esm`, then gzip -9)

| Library | Version / licence / last release | gz | Use |
|---|---|---|---|
| roughjs | 4.6.6, MIT, last publish 2023-11-20 (stale for 3 years) | 9.2 KB (`roughjs`), 8.2 KB (generator only) | **Not at runtime.** Its "sketchy" look (double strokes, hachure) is the generic "Excalidraw" look, which is exactly the AI-vibe-coded cliché the owner wants to avoid. It also costs 15 % of the phone budget. |
| perfect-freehand | 1.2.3 (2026-02-01), MIT | 1.7 KB | Good pressure strokes for *input* (drawing games). For our generated outlines the prototype's own 40-line ribbon is enough and deterministic. Use it build-time only, or for a future drawing game. |
| lottie-web | 5.12.2, MIT | 78.6 KB full / 48.8 KB `lottie_light` | **Not on product surfaces** (about 80 % of the phone budget). |
| (ours) `handmade.ts` generator | — | **5.3 KB** gz minified, including the shapes and face | Build tool; optionally a lazy phone chunk |

### 2.3 Other techniques

- **Pre-baked boil frames** (chosen). Deterministic, testable (fixture hash), zero runtime noise, and the same drawings on web and TV.
- **Seeded jitter of control points.** The naive version (jitter each Bézier control point) wrecks corners and gives a lumpy, uneven look. The prototype instead resamples the path into knots (~2.2 units apart, corners kept), displaces them along the normal with **band-limited periodic noise over arc length** (≤ 4 sine terms, wavelengths 5.5–16 units, so it is seamless on closed shapes), adds a tiny whole-drawing drift (±0.9°, ±0.12 u), and refits Catmull-Rom cubics with one-sided tangents at corners.
- **Grain / paper.** One seamless 128×128 tile (periodic value noise at 3 octaves + speckle + rare fibre pits): **7.3 KB PNG-32 palette / 5.9 KB WebP**. Draw it as a repeating background (web) or `ImageShader(TileMode.Repeated)` (Compose) at about 6 %. Never regenerate it per frame. Off in lite/calm (matches DESIGN-JAMAA §1.5).
- **Riso misregistration.** A constant translate of the fill layer. It is free on both platforms. Don't animate it: a print doesn't shift.
- **Lottie export from code.** Works. `lottie-star.json` (path keyframes with hold `"h":1`, 3 frames in a 30 fps comp) is **21.5 KB / 4.5 KB gz** for one character, and it renders in lottie-web (`out/lottie-frames.png`). Known glitch: the small eye blobs come out faceted. The tangent export needs a look before it is used. On Android, `lottie-compose` adds an AAR plus per-frame shape evaluation for a result our own `Path` cycling gets for nothing. **Use only for marketing (growth/video, stickers) if wanted.**
- **Compose.**
  - `Path` from SVG data via `PathParser().parsePathString(d).toPath()` [VERIFY API in BOM], parsed once and cached (≈ 250 small Paths for the whole cast).
  - Cycle precomputed paths with a single shared 10 fps clock, read **only in the draw phase**: no recomposition, one redraw per tick.
  - `clipPath(fill) { drawPath(hatch) }` for the hatching.
  - `Stroke(join = Round)` for the paper rim.
  - **RuntimeShader is not needed.** If ever used (API 33+ only), it would be for the stage grain, and the bitmap tile already does that for all API levels.

## 3. Recommended pipeline

```
shared/src/characters/*.ts         clean geometry (DESIGN §5.2 glyphs, faces, expressions)  ← unchanged source of truth
        │
tools/gen-characters  (+ handmade.ts, seeded, no Math.random/Date)
        │  for each shape × expression: N = 3 boil frames
        │  layers: paper · fill · ink(ribbon) · line(plain) · hatch · eyes · mouth
        ├──► web-client/src/characters/boil.gen.ts      (lazy chunk; path strings)
        ├──► tv-app/.../HandmadePaths.kt                 (String constants → PathParser, cached)
        └──► shared/fixtures/v2/characters.boil.json     (+ sha256; web & TV tests parse the same bytes)
```

Seeds are `"${seed}:${pathData}:${frame}"` hashed with FNV-1a → mulberry32. The same input gives the same bytes on every run (checked: two builds have an identical sha256). Changing the clean geometry of one shape changes only that shape's frames.

### 3.1 Parameters (the "hand", art-directable, in body units of the 24 box)

| Param | Default | Note |
|---|---|---|
| `hand.amp` | 0.24 | ≈ 1 dp at 96 dp. Above 0.3 it looks nervous. |
| `hand.waveMin/Max` | 5.5 / 16 | Slow bows only |
| `hand.rot / shift` | 0.9° / 0.12 | Whole-drawing drift between frames: the most "alive" part of the boil |
| `pen.width / pressure` | 0.95 / ±35 % | Ink ribbon |
| `pen.overshoot / lift` | 2.2 / 0.35 | The self-closing pen stroke |
| `fillAmp` | 0.6 × hand | Fills are calmer than lines |
| misregistration | (−0.35, +0.30) | Constant; it is part of the look, kept in lite |
| paper rim | stroke 1.8, cream `#F3E6CF` | Makes the dark ink read on dark stages |
| hatch | 4 tapered strokes, ink at 22 %, clipped to the fill | Shadow side (light from top-start) |
| `variants` | 3 | 4 adds 33 % bytes and barely reads better. 2 looks like flicker. |

RTL: the drawings are not mirrored (characters aren't text). The hatch light direction stays top-left on both, like a printed sheet.

### 3.2 Budgets (measured, all 12 characters, idle face, 3 frames)

| Payload | Raw | gz |
|---|---|---|
| Full look (paper, fill, ink ribbon, hatch, face) | 117.9 KB | **26.7 KB** |
| Lite look (fill + plain stroke + face) | 48.1 KB | **11.8 KB** |
| One character, full | ~10 KB | **2.4–3.0 KB** |
| Generator itself (to run on the phone instead) | 11.6 KB | **5.3 KB** |
| `HandmadePaths.kt` (strings) | 138.5 KB | 32.7 KB (in the APK, dex string pool) |
| Grain tile | 7.3 KB PNG / 5.9 KB WebP | — |

Expressions multiply the face bytes only. Body frames are shared across expressions: about 0.6 KB gz per extra expression per shape.

**Phone (Preact, 60 KB gz main):**
- Nothing new in the main bundle. The main bundle keeps the clean glyphs (already there) for first paint.
- A lazy chunk `boil.gen` (≈ 27 KB gz full, or 12 KB lite) loads after the first screen and swaps characters to hand-made with a 120 ms crossfade.
- Alternative if the chunk is too big: ship the 5.3 KB generator and build frames per character on demand in `requestIdleCallback`. It produces the same output.
- The phone mostly shows 1–4 characters at once, so the full look is affordable.

**Browser TV (`/tv`):**
- Same chunk, full look.
- Boil = 3 stacked `<svg>` per character with an `opacity steps()` animation and `will-change: opacity`. Layer memory: 96 px × DPR² × 4 B × 3 frames ≈ 110 KB per character at DPR 1, ≈ 1.3 MB for 12. Spotlight at 160–400 px: ≈ 1.9 MB per hero at 400 px.
- Cap boiling characters at **≤ 12** (DESIGN-JAMAA §4.4 motion budget). Others hold frame 0.

**Native Android TV (Compose):**
- `HandmadePaths.kt` as `String`s, not `FloatArray` literals. Big array literals compile to `<clinit>` bytecode and run into the 64 KB method limit; strings go to the dex string pool.
- Parse lazily per shape on first use (≈ 21 Paths per shape) and cache them.
- One `BoilClock` (10 fps) per screen, read in the draw phase.
- Per tick: 12 × ~7 `drawPath` calls. Paths are small (≤ 150 segments) and Skia caches path masks for filled paths at a fixed size [VERIFY ON DEVICE with gfxinfo: target ≤ 2 ms per frame of extra draw on the reference TV].
- **Lite motion (low-end): the lite look (no paper rim, no hatch, plain stroke) and no boil**, so it costs the same as today's flat glyph.

### 3.3 Fallbacks

| Condition | Behaviour |
|---|---|
| `prefers-reduced-motion` / Calm animations / TV lite motion | **No boil:** frame 0 held. It is still hand-made, just not breathing. No grain. |
| The boil chunk hasn't loaded / failed | Clean glyphs (today's look) |
| < 40 dp/px (avatar tiles) | Clean glyph tile (faces off, platform §3.7). Hand-made at that size is just noise. |
| 40–72 dp | Lite look, boil allowed |
| ≥ 72 dp | Full look |
| Portal / world entrance transitions | Boil paused (one less moving thing during big motion) |

### 3.4 Tests (add with the generator)

- **Determinism:** generate twice, then compare the sha256 against `shared/fixtures/v2/characters.boil.json`.
- **Parity:** the web parser and Compose `PathParser` produce the same bounds (±0.05 u) for every frame [VERIFY ON DEVICE: the prototype relies on implicit number separators like `.5.5` and `-.2`, which both parsers accept by the SVG grammar].
- **Legibility:** frame-to-frame centroid drift ≤ 0.3 u, and the eyes never leave the face box.
- **Budget:** the chunk is ≤ 30 KB gz, and the main bundle is unchanged (`check-size.mjs`).

## 4. Files

- `handmade/src/handmade.ts`: the generator (parser incl. arcs, corner-aware knots, periodic wobble, Catmull-Rom refit, pressure ribbon with overshoot, hatch, compact relative path output)
- `handmade/src/shapes.ts`: the 12 bodies (flower as a true quatrefoil outline) and the idle face
- `handmade/src/grain.ts`: seamless grain tile
- `handmade/src/build.ts`: JSON fixture, Kotlin, grain PNG/WebP, Lottie, sizes, demo
- `handmade/src/demo.ts` → `handmade/out/demo.html`: the 10 fps boil demo with toggles (fps, ink, paper, misregister, hatch, grain) and the live-filter comparison
- `handmade/bench/bench.mjs`: the frame-cost benchmark → `out/bench.json`
- `handmade/kotlin/BoilingCharacter.kt`: Compose renderer sketch (not compiled)
- `handmade/out/`: `HandmadePaths.kt`, `characters.boil.json`, `grain-128.{png,webp}`, `lottie-star.json`, `sizes.json`, screenshots (`demo-desktop.png`, `demo-phone.png`, `hero-frames.png` = the 3 boil frames, `lottie-frames.png`)
