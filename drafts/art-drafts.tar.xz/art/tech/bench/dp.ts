import { handmade, handStroke, handBlob } from '../handmade/src/handmade.ts';
import { SHAPES, idleFace } from '../handmade/src/shapes.ts';
import { gzipSync } from 'node:zlib';
for (const dp of [1, 2]) for (const step of [0.9, 1.3]) {
  let s = '';
  for (const sh of SHAPES) { for (const v of handmade(sh.d, { seed: sh.id, dp, pen: { step } as any })) s += v.paper + v.fill + v.ink + v.hatch; }
  console.log('dp', dp, 'ribbon step', step, 'raw', s.length, 'gz', gzipSync(s, { level: 9 }).length);
}
