import l from 'lottie-web/build/player/lottie_light'; window.r=l
