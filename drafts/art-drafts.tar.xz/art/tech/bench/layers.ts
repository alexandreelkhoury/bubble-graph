import { handmade } from '../handmade/src/handmade.ts';
import { SHAPES } from '../handmade/src/shapes.ts';
const t: Record<string, number> = {};
for (const sh of SHAPES) for (const v of handmade(sh.d, { seed: sh.id })) for (const k of Object.keys(v)) t[k] = (t[k] ?? 0) + (v as any)[k].length;
console.log(t);
const v = handmade(SHAPES[0].d, { seed: 'circle' })[0]; console.log(v.ink.slice(0, 300)); console.log(v.hatch.slice(0,200));
