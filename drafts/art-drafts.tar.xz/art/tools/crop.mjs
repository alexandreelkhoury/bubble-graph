import sharp from "sharp";
const [src, out, x, y, w, h, scale] = process.argv.slice(2);
let img = sharp(src).extract({ left: +x, top: +y, width: +w, height: +h });
if (scale) img = img.resize(Math.round(+w * +scale));
await img.toFile(out); console.log((await sharp(src).metadata()).height);
