// usage: node render.mjs page.html out.png [theme] [width]
import http from "node:http"; import fs from "node:fs"; import path from "node:path";
import { chromium } from "playwright-core";
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const types = { ".html": "text/html", ".js": "text/javascript", ".mjs": "text/javascript", ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf", ".json": "application/json", ".css": "text/css", ".svg": "image/svg+xml" };
const srv = http.createServer((q, r) => { const p = path.join(ROOT, decodeURIComponent(q.url.split("?")[0])); if (!p.startsWith(ROOT) || !fs.existsSync(p)) { r.writeHead(404); return r.end(); } r.writeHead(200, { "content-type": types[path.extname(p)] || "application/octet-stream" }); fs.createReadStream(p).pipe(r); });
await new Promise((ok) => srv.listen(0, ok)); const port = srv.address().port;
const jobs = []; const args = process.argv.slice(2);
for (let i = 0; i < args.length; i += 3) jobs.push([args[i], args[i + 1], args[i + 2] || "dark"]);
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
for (const [page, out, theme] of jobs) {
  const pg = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  pg.on("console", (m) => { if (m.type() === "error" || m.type() === "warning") console.log("[page]", m.text()); });
  pg.on("pageerror", (e) => console.log("[pageerror]", e.message));
  await pg.goto(`http://127.0.0.1:${port}/${page}?theme=${theme}`);
  await pg.waitForFunction(() => window.__ready === true, null, { timeout: 120000 });
  await pg.screenshot({ path: out, fullPage: true });
  console.log("wrote", out); await pg.close();
}
await browser.close(); srv.close();
