// Proof-of-concept plate for docs/ART-DIRECTION.md: canonical glyph vs the "hand" treatment.
// Seeded jitter, variable-weight ink ring, misregistered fill, multiply shadow, highlight, faces, boil variants.
import fs from 'node:fs';
import path from 'node:path';

const OUT = path.resolve(process.argv[2] || '..');

function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

// ---- shape sampling (24-unit viewBox) ----
function poly(pts, step = 0.35) {
  const out = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]); const n = Math.max(1, Math.round(L / step));
    for (let k = 0; k < n; k++) out.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
  }
  return out;
}
function seg(pts, step = 0.35) { const out = [];
  for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]); const n = Math.max(1, Math.round(L / step));
    for (let k = 0; k < n; k++) out.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]); }
  return out; }
function arc(cx, cy, r, a0, a1, step = 0.35) {
  const n = Math.max(2, Math.round(Math.abs(a1 - a0) * r / step)); const o = [];
  for (let k = 0; k < n; k++) { const t = a0 + (a1 - a0) * k / n; o.push([cx + r * Math.cos(t), cy + r * Math.sin(t)]); }
  return o;
}
const SH = {
  circle: () => arc(12, 12, 9, 0, Math.PI * 2),
  star: () => { const p = 'M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z';
    const pts = [[12, 2.5]]; const rel = [[2.9, 6.1], [6.6, .8], [-4.9, 4.6], [1.3, 6.6]];
    let c = [12, 2.5]; for (const r of rel) { c = [c[0] + r[0], c[1] + r[1]]; pts.push(c); }
    pts.push([12, 17.3]); c = [12, 17.3]; for (const r of [[-5.9, 3.3], [1.3, -6.6], [-4.9, -4.6], [6.6, -.8]]) { c = [c[0] + r[0], c[1] + r[1]]; pts.push(c); }
    pts.pop(); return poly(pts); },
  triangle: () => poly([[12, 2.4], [21.4, 19], [2.6, 19]]),
  arch: () => [...seg([[5, 20.75], [5, 10.25]]), ...arc(12, 10.25, 7, Math.PI, 2 * Math.PI),
    ...seg([[19, 10.25], [19, 20.75], [14.5, 20.75], [14.5, 14.25]]), ...arc(12, 14.25, 2.5, 0, -Math.PI),
    ...seg([[9.5, 14.25], [9.5, 20.75], [5, 20.75]])],
  drop: () => [...poly([[12, 1.25], [5.4, 11.6]]).slice(0, -1), ...arc(12, 13.75, 7, Math.PI * 1.08, Math.PI * 1.92 - Math.PI * 2 + Math.PI * 2 * 0 + Math.PI * 2 - Math.PI * 2, 0.35).length ? arc(12, 13.75, 7, Math.PI * 1.08 - Math.PI * 2 + Math.PI * 2, Math.PI * 1.08 - Math.PI * 2 + Math.PI * 2 - Math.PI * 1.16 * -1 - Math.PI * 2 * 0) : [], ...poly([[18.6, 11.6], [12, 1.25]]).slice(0, -1)],
};
// cleaner drop: left line, big arc under, right line
SH.drop = () => { const a0 = Math.PI * 1.18, a1 = Math.PI * 1.18 - Math.PI * 1.36 - 0; // upper-left, round the bottom, upper-right
  const A0 = Math.PI * 1.18, A1 = -Math.PI * 0.18 + 0; const s0 = [12 + 7 * Math.cos(A0), 13.75 + 7 * Math.sin(A0)];
  const arcPts = arc(12, 13.75, 7, A0, A0 - Math.PI * 1.36); const e = [12 + 7 * Math.cos(A0 - Math.PI * 1.36), 13.75 + 7 * Math.sin(A0 - Math.PI * 1.36)];
  return [...seg([[12, 1.25], s0]), ...arcPts, ...seg([e, [12, 1.25]])]; };

function area(p) { let s = 0; for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += a[0] * b[1] - b[0] * a[1]; } return s / 2; }
function smooth(p, w) { const n = p.length; return p.map((_, i) => { let x = 0, y = 0; for (let k = -w; k <= w; k++) { const q = p[(i + k + n) % n]; x += q[0]; y += q[1]; } return [x / (2 * w + 1), y / (2 * w + 1)]; }); }
function normals(p) { const n = p.length, sgn = area(p) > 0 ? 1 : -1; // y-down: positive area = clockwise on screen
  return p.map((_, i) => { const a = p[(i - 1 + n) % n], b = p[(i + 1) % n]; let dx = b[0] - a[0], dy = b[1] - a[1]; const L = Math.hypot(dx, dy) || 1; return [sgn * dy / L, -sgn * dx / L]; }); }

// Hand-drawn version: seeded low-frequency displacement (<= ~0.3 unit), slight asymmetric scale, smoothing (corner radii vary)
function hand(p0, seed, amp = 0.28) {
  const r = rng(seed); let p = smooth(p0, 1 + Math.floor(r() * 2));
  const ph = [r() * 6.28, r() * 6.28, r() * 6.28], f = [2 + Math.floor(r() * 2), 3 + Math.floor(r() * 3), 7];
  const sx = 1 + (r() - .5) * 0.04, sy = 1 + (r() - .5) * 0.04;
  const N = normals(p), n = p.length;
  p = p.map(([x, y], i) => { const t = i / n * Math.PI * 2;
    const d = amp * (0.55 * Math.sin(f[0] * t + ph[0]) + 0.3 * Math.sin(f[1] * t + ph[1]) + 0.15 * Math.sin(f[2] * t + ph[2]));
    return [12 + (x - 12) * sx + N[i][0] * d, 12 + (y - 12) * sy + N[i][1] * d]; });
  return smooth(p, 1);
}
const d = (p) => 'M' + p.map(q => q[0].toFixed(2) + ' ' + q[1].toFixed(2)).join('L') + 'Z';

// Variable-weight ink ring: thick at bottom-end (in shadow), thin at top-start (in light)
function ring(p, mean = 0.9, rtl = false) {
  const N = normals(p), s = rtl ? [-0.7071, 0.7071] : [0.7071, 0.7071];
  const outer = [], inner = [];
  p.forEach((q, i) => { const w = mean * (1 + 0.32 * (N[i][0] * s[0] + N[i][1] * s[1]));
    outer.push([q[0] + N[i][0] * w * 0.55, q[1] + N[i][1] * w * 0.55]); inner.push([q[0] - N[i][0] * w * 0.45, q[1] - N[i][1] * w * 0.45]); });
  return d(outer) + ' ' + d(inner.reverse());
}

// ---- faces (12 x 9 face space; DESIGN-JAMAA §4.2/§4.3) ----
const FACEBOX = { circle: [6, 7.5, 12, 9], star: [8, 9, 8, 6], triangle: [7.5, 11.5, 9, 6.75], arch: [7, 8.5, 10, 7.5], drop: [7, 11, 10, 7.5] };
function face(shape, expr, col, seed) {
  const [fx, fy, fw] = FACEBOX[shape]; let k = fw / 12; const floor = 1; k *= floor;
  const r = rng(seed); const ey = 3.6 + (r() - .5) * 0.25, ey2 = 3.6 + (r() - .5) * 0.25; // hand: eyes not perfectly level
  const g = []; const st = `stroke="${col}" stroke-width="0.8" stroke-linecap="round" fill="none"`;
  const eye = (x, y, s = 1) => `<ellipse cx="${x}" cy="${y}" rx="${1.1 * s}" ry="${1.45 * s}" fill="${col}"/>` + (col !== '#FFF7EC' ? `<circle cx="${x + .35}" cy="${y - .45}" r=".35" fill="#FFF7EC"/>` : '');
  const taper = (dd, w = 0.85) => `<path d="${dd}" ${st.replace('0.8', w)}/>`;
  switch (expr) {
    case 'idle': g.push(eye(3.8, ey), eye(8.2, ey2, 0.96), taper('M4.4 6.5 Q6 7.7 7.7 6.6')); break;
    case 'shock': g.push(`<circle cx="3.7" cy="${ey}" r="1.45" fill="#FFF7EC" stroke="${col}" stroke-width=".55"/><circle cx="8.3" cy="${ey2}" r="1.38" fill="#FFF7EC" stroke="${col}" stroke-width=".55"/><circle cx="3.8" cy="${ey}" r=".5" fill="${col}"/><circle cx="8.2" cy="${ey2}" r=".48" fill="${col}"/>`,
      taper('M2.6 1.2 Q3.6 .4 4.6 1.0', .7), taper('M7.4 0.9 Q8.4 .3 9.4 1.2', .7), `<ellipse cx="6" cy="7.1" rx=".75" ry=".95" fill="${col}"/>`); break;
    case 'cheer': { const star4 = (x, y, s) => `<path d="M${x} ${y - s}Q${x + .18 * s} ${y - .18 * s} ${x + s} ${y}Q${x + .18 * s} ${y + .18 * s} ${x} ${y + s}Q${x - .18 * s} ${y + .18 * s} ${x - s} ${y}Q${x - .18 * s} ${y - .18 * s} ${x} ${y - s}Z" fill="${col}"/>`;
      g.push(star4(3.8, ey, 1.7), star4(8.2, ey2, 1.6), `<path d="M3.7 5.9 Q6 9.4 8.4 5.9 Z" fill="${col}"/>`); break; }
    case 'smug': g.push(`<path d="M2.7 3.5 h2.2 a1.1 1.0 0 0 1 -2.2 0Z" fill="${col}"/><path d="M7.1 3.4 h2.2 a1.1 1.05 0 0 1 -2.2 0Z" fill="${col}"/>`,
      taper('M2.8 2.2 L4.9 2.3', .7), taper('M7.2 1.9 Q8.3 1.0 9.3 1.4', .7), taper('M4.6 6.9 Q6.8 7.5 7.9 5.9')); break;
    case 'shy': g.push(eye(3.8, ey + .8, .9), eye(8.2, ey2 + .8, .87), taper('M5.2 7.0 Q6 7.5 6.8 7.0', .7),
      `<g stroke="#FF96C5" stroke-width=".45" stroke-linecap="round" opacity=".9"><path d="M1.3 6.3l.6-.9M2.2 6.5l.6-.9M3.1 6.6l.5-.8"/><path d="M8.9 6.6l.6-.9M9.8 6.5l.6-.9M10.7 6.3l.5-.8"/></g>`); break;
  }
  return `<g transform="translate(${fx} ${fy}) scale(${k})">${g.join('')}</g>`;
}

const INK = '#160B26', PAPER = '#FFF1DC';
function character({ shape, color, glyph, expr, seed, x, y, size, variant = 0, canonical = false, rtl = false, misreg = true }) {
  const base = SH[shape]();
  const id = `${shape}${seed}${variant}${canonical ? 'c' : ''}${Math.round(x)}${Math.round(y)}`;
  const sc = size / 24;
  if (canonical) {
    const p = base; return `<g transform="translate(${x} ${y}) scale(${sc})">
      <ellipse cx="12" cy="22.6" rx="6.3" ry="1" fill="#000" opacity=".3"/>
      <path d="${d(p)}" fill="${color}"/>${face(shape, expr, glyph, 1)}</g>`;
  }
  const p = hand(base, seed * 31 + variant * 7);
  const mr = misreg ? (rtl ? [-0.4, 0.4] : [0.4, 0.4]) : [0, 0];
  const r = rng(seed + 99);
  const sh = `M12 ${22.2 + r() * .3} m-6.4 0 q1.2 -1.25 6.6 -1.1 q5.6 .1 6.1 1.0 q-.6 1.05 -6.3 1.15 q-5.3 0 -6.4 -1.05z`;
  return `<g transform="translate(${x} ${y}) scale(${sc})">
    <defs><clipPath id="c${id}"><path d="${d(p)}"/></clipPath></defs>
    <path d="${sh}" fill="${INK}" opacity=".32"/>
    <g transform="translate(${mr[0]} ${mr[1]})"><path d="${d(p)}" fill="${color}"/>
      <g clip-path="url(#c${id})" style="mix-blend-mode:multiply">
        <path d="M-10 -10H40V40H-10Z ${d(p.map(([a, b]) => [a - 1.7, b - 2.1]))}" fill-rule="evenodd" fill="${INK}" opacity=".24"/></g>
      <g clip-path="url(#c${id})" opacity="${['#FFF04D', '#7BFFF4', '#BDF5C8'].includes(color) ? 0 : .75}" stroke="${PAPER}" stroke-linecap="round" fill="none"><g transform="translate(${({triangle:[2.6,4.2],drop:[1.4,3.2],star:[2,2]})[shape]?.join(' ') ?? '0 0'})"><path d="M6.9 7.4 q.7 -1.5 2.1 -2.2" stroke-width=".7"/><path d="M8.4 8.0 q.4 -.8 1.1 -1.2" stroke-width=".55"/></g></g>
    </g>
    <path d="${ring(p, 0.9, rtl)}" fill="${INK}" fill-rule="evenodd"/>
    ${face(shape, expr, glyph, seed + variant)}</g>`;
}

// Tile border strip (cement-tile vocabulary: quatrefoil + thick white edge), hand variants
function tileRow(x, y, n, s) {
  let o = ''; for (let i = 0; i < n; i++) { const r = rng(500 + i % 4), j = () => (r() - .5) * s * 0.03, X = x + i * s;
    o += `<g transform="translate(${X} ${y}) rotate(${(r() - .5) * 1.2} ${s / 2} ${s / 2})">
      <rect x="${1 + j()}" y="${1 + j()}" width="${s - 2}" height="${s - 2}" rx="${s * 0.05}" fill="#F4E6CC"/>
      <rect x="${s * .09 + j()}" y="${s * .09 + j()}" width="${s * .82}" height="${s * .82}" rx="${s * .03}" fill="#2F5DA8"/>
      ${[[.5, .27], [.73, .5], [.5, .73], [.27, .5]].map(([a, b]) => `<circle cx="${s * a + j()}" cy="${s * b + j()}" r="${s * .17}" fill="#C8553D"/>`).join('')}
      <circle cx="${s / 2 + j()}" cy="${s / 2 + j()}" r="${s * .12}" fill="#E8A33A"/>
      ${[[.09, .09], [.91, .09], [.91, .91], [.09, .91]].map(([a, b]) => `<path d="M${s * a} ${s * b} m${a < .5 ? 0 : -s * .16} 0 h${s * .16} v${b < .5 ? s * .16 : -s * .16}z" fill="#E8A33A" transform="rotate(0)"/>`).join('')}
    </g>`; }
  return o;
}

const W = 1600, H = 1000;
const cast = [
  { shape: 'circle', color: '#F0183A', glyph: '#120A1F', expr: 'idle', seed: 3 },
  { shape: 'star', color: '#FFF04D', glyph: '#120A1F', expr: 'cheer', seed: 5 },
  { shape: 'triangle', color: '#1FA88A', glyph: '#120A1F', expr: 'smug', seed: 8 },
  { shape: 'drop', color: '#FF96C5', glyph: '#120A1F', expr: 'shy', seed: 11 },
  { shape: 'arch', color: '#C9BFFF', glyph: '#120A1F', expr: 'shock', seed: 13 },
];
const label = (x, y, t, s = 22, c = '#FFF7EC', w = 700, a = 'start') => `<text x="${x}" y="${y}" font-family="Cairo, 'Noto Sans', sans-serif" font-weight="${w}" font-size="${s}" fill="${c}" text-anchor="${a}">${t}</text>`;

function plate() {
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
  <defs>
    <linearGradient id="st" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2B1650"/><stop offset=".55" stop-color="#24124A"/><stop offset="1" stop-color="#1D1036"/></linearGradient>
    <radialGradient id="lamp" cx=".78" cy=".2" r=".6"><stop offset="0" stop-color="#FFC94D" stop-opacity=".22"/><stop offset="1" stop-color="#FFC94D" stop-opacity="0"/></radialGradient>
    <filter id="paper" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9 .55" numOctaves="3" seed="7"/><feColorMatrix values="0 0 0 0 1  0 0 0 0 .95  0 0 0 0 .86  0 0 0 .09 0"/></filter>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#st)"/><rect width="${W}" height="${H}" fill="url(#lamp)"/>`;
  s += label(60, 78, 'JAMAA art direction — proof of concept (code-drawn, no bitmaps)', 30);
  s += label(60, 112, 'Same geometry as DESIGN §5.2 and the faces of DESIGN-JAMAA §4. Only the hand changes.', 19, '#E2D6F5', 600);
  s += label(60, 180, 'TODAY: canonical glyphs, uniform, perfect', 20, '#B8A8D6', 700);
  cast.forEach((c, i) => { s += character({ ...c, x: 60 + i * 300, y: 200, size: 170, canonical: true }); });
  s += label(60, 450, 'ART DIRECTION: hand-traced (seeded), thick-thin ink ring, misregistered fill, multiply shadow, paper brush-tick highlight', 20, '#FFC94D', 700);
  cast.forEach((c, i) => { s += character({ ...c, x: 60 + i * 300, y: 470, size: 170 }); });
  s += label(60, 720, 'LINE BOIL: 3 traced variants A / B / C, cycled at 8 fps (see boil.html)', 20, '#FFC94D', 700);
  ['A', 'B', 'C'].forEach((v, i) => { s += character({ ...cast[0], expr: 'idle', x: 60 + i * 190, y: 740, size: 150, variant: i }); s += label(135 + i * 190, 915, v, 18, '#E2D6F5', 700, 'middle'); });
  s += `${['A', 'B', 'C'].map((v, i) => `<g opacity="${i ? .4 : 1}">${character({ ...cast[0], expr: 'idle', x: 640, y: 740, size: 150, variant: i, misreg: false })}</g>`).join('')}`;
  s += label(715, 915, 'A+B+C overlaid', 18, '#E2D6F5', 700, 'middle');
  s += label(900, 720, 'ORNAMENT: cement-tile border, 4 drawn variants, tiny rotations', 20, '#FFC94D', 700);
  s += tileRow(900, 750, 10, 62);
  s += label(900, 860, 'Light top-start · line thickest bottom-end · fill offset 0.4 u one way for the whole screen', 17, '#E2D6F5', 600);
  s += label(900, 888, 'Hub: ink #160B26 · paper #FFF1DC · rust #C8553D · saffron #E8A33A · blue #2F5DA8', 17, '#E2D6F5', 600);
  s += `<rect width="${W}" height="${H}" filter="url(#paper)" style="mix-blend-mode:overlay"/>`;
  return s + '</svg>';
}

function boil() {
  const frames = [0, 1, 2].map(v => `<svg class="f f${v}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1500 330" width="1500" height="330">${cast.map((c, i) => character({ ...c, x: 20 + i * 300, y: 20, size: 260, variant: (v + i) % 3 })).join('')}</svg>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>Line boil demo</title><style>
  body{margin:0;background:linear-gradient(#2B1650,#1D1036);min-height:100vh;display:grid;place-items:center;font-family:Cairo,sans-serif;color:#FFF7EC}
  .stage{position:relative;width:1500px;height:330px}.f{position:absolute;inset:0;visibility:hidden}
  .f0{animation:b0 .375s steps(1) infinite}.f1{animation:b1 .375s steps(1) infinite}.f2{animation:b2 .375s steps(1) infinite}
  @keyframes b0{0%{visibility:visible}33.3%,100%{visibility:hidden}}@keyframes b1{0%{visibility:hidden}33.3%{visibility:visible}66.6%,100%{visibility:hidden}}@keyframes b2{0%,66.6%{visibility:hidden}66.7%{visibility:visible}}
  @media (prefers-reduced-motion:reduce){.f0{animation:none;visibility:visible}.f1,.f2{animation:none}}
  p{opacity:.8}</style></head><body><div><div class="stage">${frames}</div><p>Line boil at 8 fps (125 ms per drawing), each character starts on a different variant. Reduced motion holds variant A.</p></div></body></html>`;
}

fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'plate.svg'), plate());
fs.writeFileSync(path.join(OUT, 'plate.html'), `<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;background:#1D1036}</style></head><body>${plate()}</body></html>`);
fs.writeFileSync(path.join(OUT, 'boil.html'), boil());
console.log('wrote', OUT);
