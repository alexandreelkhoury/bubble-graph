#!/usr/bin/env bash
# Usage: run.sh [gradle args...]  (default: test). REPO and TV_PKG override the repo root and the Kotlin package path.
set -euo pipefail
H="$(cd "$(dirname "$0")" && pwd)"
export REPO="${REPO:-/home/user/bubble-graph}"
if [ -z "${TV_PKG:-}" ]; then TV_PKG="$(cd "$REPO/tv-app/app/src/main/java" && ls -d app/*/tv | head -1)"; fi
export TV_PKG
python3 -I "$H/gen-r.py" "$REPO" "$TV_PKG"
mkdir -p "$H/stubs/$TV_PKG/game"
sed "s|@PKG@|${TV_PKG//\//.}|" "$H/ProductionDepsStub.kt.in" > "$H/stubs/$TV_PKG/game/ProductionDepsStub.kt"
VER="$(sed -n 's/.*versionName = "\(.*\)".*/\1/p' "$REPO/tv-app/app/build.gradle.kts" | head -1)"
printf 'package %s\nobject BuildConfig {\n    const val DEBUG = true\n    const val SERVER_URL = "https://example.invalid"\n    const val VERSION_NAME = "%s"\n}\n' "${TV_PKG//\//.}" "$VER" > "$H/build/gen-r/$TV_PKG/BuildConfig.kt"
cd "$H" && exec gradle --no-daemon -q "${@:-test}"
