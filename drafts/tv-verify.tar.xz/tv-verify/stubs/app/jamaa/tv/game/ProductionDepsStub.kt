package app.jamaa.tv.game
/** The real ProductionDeps.kt needs Android (OkHttp socket factory, SoundPool, prefs); tests always pass their own deps. */
internal fun productionDeps(app: android.app.Application): GameDeps = error("productionDeps is not available in the JVM harness")
