package android.app
open class Activity : android.content.Context()
open class Application : android.content.Context()
