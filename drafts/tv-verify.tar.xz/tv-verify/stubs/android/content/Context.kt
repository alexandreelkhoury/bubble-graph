package android.content
open class Context {
    open val applicationContext: Context get() = this
    open fun getSharedPreferences(name: String, mode: Int): SharedPreferences = MemPrefs()
    companion object { const val MODE_PRIVATE = 0 }
}
interface SharedPreferences {
    fun getString(k: String, d: String?): String?
    fun getLong(k: String, d: Long): Long
    fun getBoolean(k: String, d: Boolean): Boolean
    fun edit(): Editor
    interface Editor {
        fun putString(k: String, v: String?): Editor
        fun putLong(k: String, v: Long): Editor
        fun putBoolean(k: String, v: Boolean): Editor
        fun remove(k: String): Editor
        fun clear(): Editor
        fun apply()
        fun commit(): Boolean
    }
}
private class MemPrefs : SharedPreferences {
    val m = HashMap<String, Any?>()
    override fun getString(k: String, d: String?) = (m[k] as String?) ?: d
    override fun getLong(k: String, d: Long) = (m[k] as Long?) ?: d
    override fun getBoolean(k: String, d: Boolean) = (m[k] as Boolean?) ?: d
    override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
        override fun putString(k: String, v: String?) = apply { m[k] = v }
        override fun putLong(k: String, v: Long) = apply { m[k] = v }
        override fun putBoolean(k: String, v: Boolean) = apply { m[k] = v }
        override fun remove(k: String) = apply { m.remove(k) }
        override fun clear() = apply { m.clear() }
        override fun apply() {}
        override fun commit() = true
    }
}
