package androidx.lifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
abstract class ViewModel {
    internal val scope: CoroutineScope by lazy { CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate) }
    protected open fun onCleared() {}
    /** Test hook: what the framework does when the owner is destroyed. */
    fun clearForTest() { onCleared(); scope.cancel() }
}
open class AndroidViewModel(@Suppress("unused") val app: android.app.Application) : ViewModel()
val ViewModel.viewModelScope: CoroutineScope get() = scope
