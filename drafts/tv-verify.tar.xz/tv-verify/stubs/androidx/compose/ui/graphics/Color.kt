package androidx.compose.ui.graphics
@JvmInline value class Color(val argb: Long) { companion object { val Transparent = Color(0x00000000) ; val White = Color(0xFFFFFFFF); val Black = Color(0xFF000000) } }
fun Color.toArgb(): Int = argb.toInt()
fun Color.copy(alpha: Float): Color = Color(((alpha * 255).toInt().toLong() shl 24) or (argb and 0xFFFFFF))
