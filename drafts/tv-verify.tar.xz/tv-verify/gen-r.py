# Writes build/gen-r/<pkg>/R.kt from every string/plurals name in tv-app res/values/*.xml.
import os, re, sys, glob
repo, pkg = sys.argv[1], sys.argv[2]
res = os.path.join(repo, "tv-app/app/src/main/res/values")
names = {"string": set(), "plurals": set(), "raw": set()}
for f in glob.glob(os.path.join(res, "*.xml")):
    for kind, n in re.findall(r'<(string|plurals)\s+name="([^"]+)"', open(f, encoding="utf-8").read()):
        names[kind].add(n)
# res/raw/*.ogg → R.raw.<name> (generated game sound cues, games/<id>/SoundCues<Id>.kt).
for f in glob.glob(os.path.join(repo, "tv-app/app/src/main/res/raw", "*")):
    names["raw"].add(os.path.splitext(os.path.basename(f))[0])
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build/gen-r", pkg)
os.makedirs(out, exist_ok=True)
lines = [f"package {pkg.replace('/', '.')}", "object R {"]
BASE = {"string": 0, "plurals": 0x10000, "raw": 0x20000}
for kind in ("string", "plurals", "raw"):
    lines.append(f"    object {kind} {{")
    for i, n in enumerate(sorted(names[kind])):
        lines.append(f"        const val {n} = {0x7f000000 + BASE[kind] + i}")
    lines.append("    }")
lines.append("}")
open(os.path.join(out, "R.kt"), "w").write("\n".join(lines) + "\n")
print(f"R.kt: {len(names['string'])} strings, {len(names['plurals'])} plurals, {len(names['raw'])} raw")
