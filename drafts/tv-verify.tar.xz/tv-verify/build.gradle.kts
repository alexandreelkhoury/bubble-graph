// Pure-JVM harness for tv-app (Google Maven is blocked here): compiles the non-UI TV code against
// small Android stubs and runs the JVM unit tests against /shared/fixtures. Versions = tv-app/gradle/libs.versions.toml.
plugins {
    kotlin("jvm") version "2.4.20"
    kotlin("plugin.serialization") version "2.4.20"
}
val repo = file(System.getenv("REPO") ?: "/home/user/bubble-graph")
val pkg = System.getenv("TV_PKG") ?: "app/jamaa/tv"
val app = File(repo, "tv-app/app/src")
kotlin { jvmToolchain(21) }
sourceSets {
    main {
        kotlin {
            srcDir(File(app, "main/java")); srcDir(File(app, "debug/java")); srcDir("stubs"); srcDir("build/gen-r")
            include("android/**", "androidx/**", "$pkg/R.kt", "$pkg/BuildConfig.kt", "$pkg/game/ProductionDepsStub.kt")
            include("$pkg/*.kt", "$pkg/billing/**", "$pkg/game/**", "$pkg/protocol/**", "$pkg/net/**", "$pkg/settings/**")
            include("$pkg/i18n/I18nKeys.kt", "$pkg/i18n/Locales.kt", "$pkg/i18n/games/**")
            include("$pkg/ui/components/QrMatrix.kt", "$pkg/ui/components/BrandPaths.kt", "$pkg/games/**", "$pkg/platform/**", "$pkg/motion/**")
            include("$pkg/ui/characters/CharacterPaths.kt", "$pkg/ui/theme/WorldColors.kt")
            include("$pkg/ui/screens/LobbyMetrics.kt", "$pkg/ui/screens/StoreMetrics.kt", "$pkg/ui/theme/JamaaColors.kt")
            exclude("$pkg/MainActivity.kt", "$pkg/game/ProductionDeps.kt", "$pkg/billing/PlayBillingGateway.kt", "$pkg/billing/GatewayFactory.kt")
            // Compose UI (Google Maven blocked): the game screens registry and every games/<id>/ui/** file.
            exclude("$pkg/games/GameScreens.kt", "$pkg/games/mishana/MishanaLogo.kt", "$pkg/games/**/ui/**")
        }
    }
    test { kotlin { srcDir(File(app, "test/java")) } }
}
dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.11.0")
    implementation("com.squareup.okhttp3:okhttp:5.5.0")
    implementation("com.google.zxing:core:3.5.4")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.11.0")
    testImplementation("app.cash.turbine:turbine:1.2.1")
    testImplementation("com.squareup.okhttp3:mockwebserver3:5.5.0")
}
tasks.test {
    workingDir = File(repo, "tv-app/app")
    testLogging { events("failed"); exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL }
}
